package com.huawei.genexcloud.http.download;

import android.text.TextUtils;

import androidx.annotation.NonNull;


import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.http.util.OkHttpManager;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.util.FileUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DownloadImpl {

    private static OkHttpClient downloadClient;
    private static DownloadImpl impl;

    public static DownloadImpl getImpl() {
        if (null == impl) {
            synchronized (DownloadImpl.class) {
                if (null == impl) {
                    impl = new DownloadImpl();
                    downloadClient = OkHttpManager.getDownloadClient(BaseApplication.getAppContext());
                }
            }
        }
        return impl;
    }



    public synchronized void download(DownloadEntry entry) {
        if (isInProgress(entry)) {
            return;
        }
        Request request = buildRequest(entry);
        Call call = downloadClient.newCall(request);

        entry.onWait();

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                entry.setLength(0);
                entry.setCurrentLength(0);
                entry.setState(DownloadState.STATE_FAILED);

                entry.onFailed();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        long contentLength = response.body().contentLength();
                        entry.setLength(contentLength);
                        boolean createFile = FileUtil.checkExistNorCreate(entry.getPath());
                        if (!createFile) {
                            entry.onFailed();
                            return;
                        }
                        InputStream is = response.body().byteStream();
                        int length;
                        byte[] buffer = new byte[1024];
                        long currentLength = 0;
                        SpeedControl speedControl = new SpeedControl();
                        speedControl.startDownload();
                        FileOutputStream fos = new FileOutputStream(entry.getPath());
                        while( (length = is.read(buffer)) != -1) {

                            currentLength += length;

                            while (!speedControl.canRead(currentLength)) {
                            }

                            fos.write(buffer, 0, length);
                            entry.onDownload(contentLength, currentLength);
                            // 检查下载取消flag
                            if (entry.isCancelFlag()) {
                                // 取消下载
                                entry.setCancelFlag(false);
                                entry.onFailed();
                                fos.close();
                                is.close();
                                return;
                            }
                        }
                        fos.close();
                        is.close();
                        entry.onDownloadSuccess();
                    }
                } catch (Exception e) {
                    entry.onFailed();
                    GCLogger.error("error", e.toString());
                }
            }
        });
    }

    private Request buildRequest(DownloadEntry entry) {
        Request.Builder builder = new Request.Builder()
                .url(entry.getUrl())
                .get()
                .tag(entry.getUrl());
        return builder.build();
    }

    /**
     * 是否在下载任务中
     * @param entry
     * @return
     */
    public boolean isInProgress(DownloadEntry entry) {
        if (null == entry) {
            return false;
        }
        try {
            for (Call call : downloadClient.dispatcher().runningCalls()) {
                Object tag = call.request().tag();
                if (entry.getUrl().equals(tag)) {
                    return true;
                }
            }
            for (Call call : downloadClient.dispatcher().queuedCalls()) {
                Object tag = call.request().tag();
                if (entry.getUrl().equals(tag)) {
                    return true;
                }
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        return false;
    }

    public void cancel(String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        try {
            for (Call call : downloadClient.dispatcher().runningCalls()) {
                Object tag = call.request().tag();
                if (url.equals(tag)) {
                    call.cancel();
                    return;
                }
            }
            for (Call call : downloadClient.dispatcher().queuedCalls()) {
                Object tag = call.request().tag();
                if (url.equals(tag)) {
                    call.cancel();
                    return;
                }
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        return;
    }
}
