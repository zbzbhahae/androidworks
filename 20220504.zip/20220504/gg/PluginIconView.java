package com.huawei.genexcloud.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextUtils;
import android.util.AttributeSet;

import com.facebook.drawee.generic.GenericDraweeHierarchy;
import com.facebook.drawee.view.SimpleDraweeView;
import com.huawei.genexcloud.logger.GCLogger;

public class PluginIconView extends SimpleDraweeView {

    public static final int STATUS_IDLE = 0;
    public static final int STATUS_CONNECTING = 1;
    public static final int STATUS_DOWNLOADING = 2;
    public static final int STATUS_DOWNLOAD_FAILED = 3;
    public static final int STATUS_INSTALLING = 4;
    public static final int STATUS_PREPARING = 5;
    public static final int STATUS_READY = 6;

    private static final String STATUS_TEXT_CONNECTING = "连接中";
    private static final String STATUS_TEXT_DOWNLOADING = "下载中";
    private static final String STATUS_TEXT_FAILED = "下载失败";
    private static final String STATUS_TEXT_INSTALLING = "安装中";
    private static final String STATUS_TEXT_PREPARING = "准备中";


    private int mStatus = STATUS_IDLE;

    private int width, height;
    private Paint textPaint, progressPaint;

    // 状态文字大小
    private float statusTextSize = sp2px(10);
    // 状态文字颜色
    private int statusTextColor = 0xFF000000;
    // 进度条背景颜色
    private int progressBackgroudColor = 0xFF666666;
    // 进度条进度颜色
    private int progressColor = 0xFF4F7AFD;
    // 进度条宽高
    private float progressWidth = 0, progressHeight = dp2px(5);
    // 进度条宽度占view宽度的百分比
    private float progressWidthPercent = 0.7f;
    // 下载进度
    private long currentValue, totalValue;


    public PluginIconView(Context context, GenericDraweeHierarchy hierarchy) {
        super(context, hierarchy);
        init();
    }
    public PluginIconView(Context context) {
        super(context);
        init();
    }
    public PluginIconView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    public PluginIconView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }
    public PluginIconView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }
    private int dp2px(int dp) {
        int px = (int) (getContext().getResources().getDisplayMetrics().density * dp + .5);
        return px;
    }
    private float sp2px(float sp) {
        return getResources().getDisplayMetrics().scaledDensity * sp;
    }
    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            width = getWidth();
            height = getHeight();
            // 计算进度条的宽度
            progressWidth = progressWidthPercent * width;
        }
    }

    private void init() {
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTextSize(statusTextSize);
        textPaint.setColor(statusTextColor);

        progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        progressPaint.setColor(progressBackgroudColor);
        progressPaint.setStyle(Paint.Style.FILL);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setStrokeWidth(progressHeight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawStatusText(canvas, mStatus);
        drawProgress(canvas, mStatus);
    }

    /**
     * 画状态文字
     * @param canvas
     * @param mStatus
     */
    private void drawStatusText(Canvas canvas, int mStatus) {
        String statusText = getStatusText(mStatus);
        if (TextUtils.isEmpty(statusText)) {
            return;
        }
        float textWidth = textPaint.measureText(statusText);
        Paint.FontMetricsInt fontInfo = textPaint.getFontMetricsInt();
        float textHeight = fontInfo.bottom - fontInfo.top;
        float baseLine = (fontInfo.descent - fontInfo.ascent) * 0.5f - fontInfo.descent;

        float textX = (width - textWidth) * 0.5f;
        float textY = 0.5f * height + baseLine;
        canvas.drawText(statusText, textX, textY, textPaint);
    }

    private String getStatusText(int mStatus) {
        String statusText = null;
        switch (mStatus) {
            case STATUS_IDLE:
            case STATUS_READY:
                break;
            case STATUS_CONNECTING:
                statusText = STATUS_TEXT_CONNECTING;
                break;
            case STATUS_DOWNLOADING:
                statusText = STATUS_TEXT_DOWNLOADING;
                break;
            case STATUS_DOWNLOAD_FAILED:
                statusText = STATUS_TEXT_FAILED;
                break;
            case STATUS_INSTALLING:
                statusText = STATUS_TEXT_INSTALLING;
                break;
            case STATUS_PREPARING:
                statusText = STATUS_TEXT_PREPARING;
                break;
        }
        return statusText;
    }

    /**
     * 画进度条
     * @param canvas
     * @param mStatus
     */
    private void drawProgress(Canvas canvas, int mStatus) {
        if (STATUS_DOWNLOADING == mStatus) {
            // 画进度条
            // 画进度条背景
            float progressX = (width - progressWidth) * 0.5f;
            float progressY = width * 0.8f;
            progressPaint.setColor(progressBackgroudColor);
            canvas.drawLine(progressX, progressY, (progressX + progressWidth), progressY, progressPaint);
            // 画前端进度条
            float currentProgressWidth = 0;
            if (totalValue <= 0 || currentValue <= 0) {
                currentProgressWidth = 0;
            } else if (totalValue <= currentValue) {
                currentProgressWidth = progressWidth;
            } else {
                currentProgressWidth = currentValue * 1f / totalValue * progressWidth;
            }
            progressPaint.setColor(progressColor);
            canvas.drawLine(progressX, progressY, (progressX + currentProgressWidth), progressY, progressPaint);
        }
    }

    /**
     * 设置图标状态
     * @param status
     */
    public void setStatus(int status) {
        mStatus = status;
        invalidate();
    }

    /**
     * 设置下载进度，状态会变为下载中
     * @param currentValue 当前进度
     * @param totalValue 总进度
     */
    public void setProgress(long currentValue, long totalValue) {
        mStatus = STATUS_DOWNLOADING;
        this.currentValue = currentValue;
        this.totalValue = totalValue;
        invalidate();
    }
}
