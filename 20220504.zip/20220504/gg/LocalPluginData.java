package com.huawei.genexcloud.database;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.huawei.genexcloud.bean.PluginBean;

@Entity(tableName = "t_local_plugin")
public class LocalPluginData {

    @PrimaryKey
    @NonNull
    public String packageName;
    @NonNull
    public String startActivity;
    // 版本号，并不是插件apk真正的版本号，而是服务器数据库中定义的versioncode版本号，用来对比升级
    public int versionCode;
    // 同版本号，均为服务器数据库中定义的
    public String versionName;
    public String showName;
    public String downloadPath;
    public String iconUrl;
    public int position;

    /**
     * 将服务器的插件信息转换为本地数据库中的插件信息 用于插入更新数据库
     * @param pluginBean
     * @return
     */
    public static LocalPluginData parsePluginData(PluginBean pluginBean) {
        if (null == pluginBean) {
            return null;
        }
        LocalPluginData data = new LocalPluginData();
        data.packageName = pluginBean.packageName;
        data.startActivity = pluginBean.startActivity;
        data.versionCode = pluginBean.versionCode;
        data.versionName = pluginBean.versionName;
        data.showName = pluginBean.showName;
        data.downloadPath = pluginBean.path;
        data.iconUrl = pluginBean.getPluginImagePath();
        data.position = pluginBean.position;
        if (data.isAvailableData()) {
            return data;
        }
        return null;
    }

    /**
     * 是否是一个有效的本地已安装插件的bean
     * @return
     */
    private boolean isAvailableData() {
        if (TextUtils.isEmpty(packageName) || TextUtils.isEmpty(startActivity) || TextUtils.isEmpty(versionName)
                || TextUtils.isEmpty(downloadPath) || TextUtils.isEmpty(iconUrl) || versionCode < 0) {
            return false;
        }
        return true;
    }
}
