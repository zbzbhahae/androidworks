package com.huawei.genexcloud.http.download;

/**
 * 下载限速类，单个线程限速
 */
public class SpeedControl {

    private long startedTime = 0;
    private long timePassed;
    private long limitSpeedPerSecond = 400 * 1024;  //
    private long cachedLength = 0;

    public void startDownload() {
        startedTime = System.currentTimeMillis();
    }

    public boolean canRead(long downloadedLength) {
        if (0 == startedTime) {
            startedTime = System.currentTimeMillis();
            cachedLength = downloadedLength;
            timePassed = 1;
        }
        timePassed = System.currentTimeMillis() - startedTime;
        if (downloadedLength * 1f / (timePassed * 1f / 1000) > limitSpeedPerSecond) {
            return false;
        }
        return true;
    }
}
