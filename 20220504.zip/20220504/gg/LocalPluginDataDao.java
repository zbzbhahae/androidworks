package com.huawei.genexcloud.database;

import android.content.Context;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LocalPluginDataDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertLocalPluginData(LocalPluginData data);

    @Query("DELETE FROM t_local_plugin")
    void cleanAll();

    @Query("DELETE FROM t_local_plugin WHERE `packageName` = :packageName")
    void deleteByPackageName(String packageName);

    @Query("SELECT * FROM t_local_plugin WHERE `packageName` = :packageName LIMIT 1")
    LocalPluginData getLocalPluginByPackageName(String packageName);

    @Query("SELECT * FROM t_local_plugin")
    List<LocalPluginData> getLocalPlugins();

    static LocalPluginDataDao getInstance(Context context) {
        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
        LocalPluginDataDao localPluginDataDao = database.localPluginDataDao();
        return localPluginDataDao;
    }
}
