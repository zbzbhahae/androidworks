package com.huawei.genexcloud.util;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.huawei.genexcloud.BuildConfig;
import com.huawei.genexcloud.logger.GCLogger;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;

/**
 * 存储路径工具类
 */
public class PathUtil {

    // 内置数据路径
    private static String appFilePath;
    private static String appCachePath;
    // APP内置路径根目录
    private static String appInternalPath;
    // 外置数据路径
    private static String appExternalFilePath;
    private static String appExternalCachePath;
    private static String appExternalPath;
    // 系统公共路径
    private static String publicDownloadPath;
    private static String publicDocumentPath;
    private static String publicDCIMPath;
    // 外置数据根目录
    private static String externalPath;

    private static boolean initial = false;

    public static void listPath() {
        if (!initial) {
            throw new IllegalStateException("PathUtil should init first~");
        }
        Log.e("path", "appFilePath->" + appFilePath);
        Log.e("path", "appCachePath->" + appCachePath);
        Log.e("path", "appExternalFilePath->" + appExternalFilePath);
        Log.e("path", "appExternalCachePath->" + appExternalCachePath);
        Log.e("path", "publicDownloadPath->" + publicDownloadPath);
        Log.e("path", "publicDCIMPath->" + publicDCIMPath);
        Log.e("path", "publicDocumentPath->" + publicDocumentPath);
        Log.e("path", "externalPath->" + externalPath);
        Log.e("path", "appInternalPath->" + appInternalPath);
        Log.e("path", "appExternalPath->" + appExternalPath);
    }

    /**
     * 初始化路径数据
     * @param context
     */
    public static void init(Context context) {
        /**
         * type The type of storage directory to return. Should be one of
         *      *            {@link #DIRECTORY_MUSIC}, {@link #DIRECTORY_PODCASTS},
         *      *            {@link #DIRECTORY_RINGTONES}, {@link #DIRECTORY_ALARMS},
         *      *            {@link #DIRECTORY_NOTIFICATIONS}, {@link #DIRECTORY_PICTURES},
         *      *            {@link #DIRECTORY_MOVIES}, {@link #DIRECTORY_DOWNLOADS},
         *      *            {@link #DIRECTORY_DCIM}, or {@link #DIRECTORY_DOCUMENTS}.
         */
        publicDownloadPath = Environment
                .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
        publicDocumentPath = Environment
                .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath();
        publicDCIMPath = Environment.
                getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath();
        // 应用在内部的存储
        appFilePath = context.getFilesDir().getAbsolutePath();
        appCachePath = context.getCacheDir().getAbsolutePath();
        appInternalPath = Objects.requireNonNull(context.getFilesDir().getParentFile()).getAbsolutePath();
        // 外置存储路径
        appExternalFilePath = context.getExternalFilesDir("").getAbsolutePath();
        appExternalCachePath = context.getExternalCacheDir().getAbsolutePath();
        appExternalPath = context.getExternalCacheDir().getParentFile().getAbsolutePath();
        // 外置存储根目录
        externalPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        initial = true;
    }


    /**
     * /data/user/0/com.huawei.genexcloud/files
     */
    public static String getAppFilePath() {
        return appFilePath;
    }

    /**
     * /data/user/0/com.huawei.genexcloud/cache
     */
    public static String getAppCachePath() {
        return appCachePath;
    }

    /**
     * /data/user/0/com.huawei.genexcloud/log
     */
    public static String getAppLogPath() {
        return appInternalPath + File.separator + "log";
    }

    /**
     * /data/user/0/com.huawei.genexcloud
     */
    public static String getAppInternalPath() {
        return appInternalPath;
    }

    /**
     * /storage/emulated/0/Android/data/com.huawei.genexcloud/files
     */
    public static String getExternalAppFilePath() {
        return appExternalFilePath;
    }

    /**
     * /storage/emulated/0/Android/data/com.huawei.genexcloud/files/plugins
     */
    public static String getAppPluginPath() {
        return getExternalAppFilePath() + File.separator + "plugins";
    }

    /**
     * /storage/emulated/0/Android/data/com.huawei.genexcloud/cache
     */
    public static String getExternalAppCachePath() {
        return appExternalCachePath;
    }

    /**
     * /storage/emulated/0/Android/data/com.huawei.genexcloud/log
     */
    public static String getExternalAppLogPath() {
        return appExternalPath + File.separator + "log";
    }

    /**
     * /storage/emulated/0/Android/data/com.huawei.genexcloud
     */
    public static String getExternalAppPath() {
        return appExternalPath;
    }

    /**
     * /storage/emulated/0/Download
     */
    public static String getPublicDownloadPath() {
        return publicDownloadPath;
    }

    /**
     * /storage/emulated/0/Documents
     */
    public static String getPublicDocumentPath() {
        return publicDocumentPath;
    }

    /**
     * /storage/emulated/0/DCIM
     */
    public static String getPublicDCIMPath() {
        return publicDCIMPath;
    }
    /**
     * /storage/emulated/0
     */
    public static String getExternalPath() {
        return externalPath;
    }


    /** https://genexcloud-china-dongguan.sd.huawei.com
     * 函 数 名：formatImagePath 功能描述：根据返回的图片路径进行切割然后拼接成url 日 期：2017年1月26日 参 数：@param
     */
    public static String formatDownloadPath(String path) {
        if (TextUtils.isEmpty(path)) {
            return path;
        }
        String fileName = "";
        String url = "";
        try {
            if (path.contains("VideoOrReSolutionFiles")) {
                fileName = path.substring(path.indexOf("VideoOrReSolutionFiles\\") + 23, path.length());
                String hostUrl = "";
                if (BuildConfig.DEBUG) {
                    hostUrl = BuildConfig.HOST_GC_ADDRESS + "/mobileinfomgmtapps/downLoadFileAction?Url=downLoad_test";
                } else {
                    hostUrl = BuildConfig.HOST_GC_ADDRESS + "/mobileinfomgmtapps/downLoadFileAction?Url=downLoad";
                }
                url = hostUrl + "&fileName=" + URLEncoder.encode(fileName, "UTF-8");
            } else {
                url = path;
            }
        } catch (UnsupportedEncodingException e) {
            GCLogger.error("error", e.toString());
        }
        return url;
    }
}
