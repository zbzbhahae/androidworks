package com.huawei.genexcloud.http.download;

import android.text.TextUtils;

import com.huawei.genexcloud.util.UrlUtil;

public class DownloadManager {
    private static DownloadManager instance;

    public static DownloadManager getInstance() {
        if (null == instance) {
            synchronized (DownloadManager.class) {
                if (null == instance) {
                    instance = new DownloadManager();

                }
            }
        }
        return instance;
    }

    public void download(String url) {
        download(url, null, null);
    }
    public void download(String url, String fileName, String path) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        if (TextUtils.isEmpty(fileName)) {
            fileName = UrlUtil.getFileNameFromUrl(url);
        }
        DownloadEntry entry = new DownloadEntry(url, fileName, path);
        DownloadImpl.getImpl().download(entry);
    }

    public void download(DownloadEntry entry) {
        if (null == entry || TextUtils.isEmpty(entry.getUrl())) {
            return;
        }
        DownloadImpl.getImpl().download(entry);
    }

    public void cancel(DownloadEntry entry) {
        if (null == entry || TextUtils.isEmpty(entry.getUrl())) {
            return;
        }
        entry.setCancelFlag(true);
        cancel(entry.getUrl());
    }
    public void cancel(String url) {
        DownloadImpl.getImpl().cancel(url);
    }


}
