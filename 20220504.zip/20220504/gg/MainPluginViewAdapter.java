package com.huawei.genexcloud.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.apply.CustomProgressBar;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.bean.PluginBean;
import com.huawei.genexcloud.bean.PluginBeanWrapper;
import com.huawei.genexcloud.database.LocalPluginData;
import com.huawei.genexcloud.database.LocalPluginDataDao;
import com.huawei.genexcloud.databinding.ItemPluginBinding;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.download.DownloadManager;
import com.huawei.genexcloud.http.download.DownloadState;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.plugin.GCPluginManager;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.widget.PluginIconView;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.qihoo360.replugin.model.PluginInfo;

import java.util.ArrayList;
import java.util.List;

public class MainPluginViewAdapter extends RecyclerView.Adapter<MainPluginViewAdapter.PluginViewHolder> {

    private final List<PluginBeanWrapper> pluginList = new ArrayList<>();
    private ClickListener clickListener;

    @NonNull
    @Override
    public PluginViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PluginViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_plugin, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PluginViewHolder holder, int position) {
        final PluginBeanWrapper data = pluginList.get(position);
        List<PluginInfo> installedPlugin = GCPluginManager.getInstalledPlugin();
        if (data == null) {
            holder.binding.content.setVisibility(View.INVISIBLE);
            holder.binding.icon.setOnClickListener(null);
        } else {
            holder.binding.content.setVisibility(View.VISIBLE);
            if (data.pluginBean == null) {
                holder.binding.icon.setImageURI(Uri.parse("res:///" + R.drawable.icon_plugin_more));
                holder.binding.name.setText("更多应用");
            } else {
                holder.binding.icon.setImageURI(data.pluginBean.getPluginImagePath());
                holder.binding.name.setText(data.pluginBean.showName);
            }
            holder.binding.downloadProgress.setVisibility(data.isDownloading? View.VISIBLE: View.GONE);
            holder.binding.content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickListener != null) {
                        clickListener.onClick(data);
                    }
                }
            });
            setIconStatus(holder, data);
            LiveEventBus.get(DownloadEntry.class).observeForever(new Observer<DownloadEntry>() {
                @Override
                public void onChanged(DownloadEntry downloadEntry) {
                    if (null != data && null != data.pluginBean && null != data.getDownloadEntry() && data.getDownloadEntry().getUrl().equals(downloadEntry.getUrl())) {
                        if (downloadEntry != data.getDownloadEntry()) {
                            data.setDownloadEntry(downloadEntry);
                        }
                        setIconStatus(holder, data);
                    }
                }
            });
        }
    }

    private void setIconStatus(PluginViewHolder holder, PluginBeanWrapper bean) {
        DownloadEntry entry = bean.getDownloadEntry();
        if (null == entry || null == bean.pluginBean) {
            return;
        }
        holder.binding.downloadProgress.setVisibility(View.GONE);
        switch (entry.getState()) {
            case DownloadState.STATE_IDLE:
                holder.binding.icon.setStatus(PluginIconView.STATUS_IDLE);

                holder.binding.icon.setOnClickListener(v->{
                    // 检查安装状态
                    if (GCPluginManager.isPluginInstalled(bean.pluginBean.packageName)) {
                        if (GCPluginManager.needUpdate(bean.pluginBean)) {
                            // 需要升级
                        } else {
                            // 不需要升级 打开插件
                            GCPluginManager.openPlugin(holder.binding.getRoot().getContext(), bean.pluginBean.packageName, bean.pluginBean.startActivity);
                        }
                    } else {
                        DownloadManager.getInstance().download(entry);
                    }
                });
                break;
            case DownloadState.STATE_FAILED:
                holder.binding.icon.setStatus(PluginIconView.STATUS_IDLE);

                holder.binding.icon.setOnClickListener(v->{
                    DownloadManager.getInstance().download(entry);
                });
                break;
            case DownloadState.STATE_WAIT:
                holder.binding.icon.setOnClickListener(v->{
                    // 加入下载 等待下载开始 点击取消
                    DownloadManager.getInstance().cancel(entry);
                });
                GCLogger.error("view", "下载连接中");
                holder.binding.icon.setStatus(PluginIconView.STATUS_CONNECTING);
                break;
            case DownloadState.STATE_DOWNLOADING:
                holder.binding.icon.setOnClickListener(v->{
                    // 下载中 点击取消
                    DownloadManager.getInstance().cancel(entry);
                });
                GCLogger.error("view", "下载中");
                holder.binding.icon.setProgress(entry.getCurrentLength(), entry.getLength());
                holder.binding.downloadProgress.setVisibility(View.VISIBLE);
                holder.binding.downloadProgress.setMax((int) entry.getLength());
                holder.binding.downloadProgress.setProgress((int) entry.getCurrentLength());
                break;
            case DownloadState.STATE_SUCCESS:
                long startT = System.currentTimeMillis();
                PluginInfo pluginInfo = GCPluginManager.installPlugin(entry.getPath());
                GCLogger.error("plugin", "安装方法调用耗时:" + (System.currentTimeMillis() - startT));
                if (null != pluginInfo) {
                    // 插件安装成功 数据库需要存储相关记录
                    LocalPluginDataDao.getInstance(holder.binding.getRoot().getContext())
                            .insertLocalPluginData(LocalPluginData.parsePluginData(bean.pluginBean));
                }
                startT = System.currentTimeMillis();
                GCPluginManager.preparePlugin(pluginInfo);
                GCLogger.error("plugin", "preload方法耗时:" + (System.currentTimeMillis() - startT));
                // 检查安装状态
                holder.binding.icon.setStatus(PluginIconView.STATUS_READY);
                entry.setState(DownloadState.STATE_OK);
                holder.binding.icon.setOnClickListener(v->{
                    // 检查安装状态
                    if (GCPluginManager.isPluginInstalled(bean.pluginBean.packageName)) {
                        GCPluginManager.openPlugin(holder.binding.getRoot().getContext(), bean.pluginBean.packageName, bean.pluginBean.startActivity);
                    } else {
                        DownloadManager.getInstance().download(entry);
                    }
                });
                break;
            case DownloadState.STATE_OK:
                holder.binding.icon.setStatus(PluginIconView.STATUS_READY);
                holder.binding.icon.setOnClickListener(v->{
                    // 检查安装状态
                    if (GCPluginManager.isPluginInstalled(bean.pluginBean.packageName)) {
                        GCPluginManager.openPlugin(holder.binding.getRoot().getContext(), bean.pluginBean.packageName, bean.pluginBean.startActivity);
                    } else {
                        DownloadManager.getInstance().download(entry);
                    }
                });
                break;
        }
    }

    @Override
    public int getItemCount() {
        return pluginList.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<PluginBeanWrapper> list) {
        if (list != null) {
            pluginList.clear();
            pluginList.addAll(list);
            notifyDataSetChanged();
        }
    }

    public void setClickListener(@NonNull ClickListener listener) {
        this.clickListener = listener;
    }

    static public class PluginViewHolder extends RecyclerView.ViewHolder {

        private final ItemPluginBinding binding;

        public PluginViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemPluginBinding.bind(itemView);
        }
    }

    public static interface ClickListener {
        public void onClick(PluginBeanWrapper plugin);
    }
}
