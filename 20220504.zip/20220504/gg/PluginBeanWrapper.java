package com.huawei.genexcloud.bean;

import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.util.PathUtil;

import java.io.File;

public class PluginBeanWrapper {
    public final PluginBean pluginBean;
    public boolean isDownloading = false;
    private DownloadEntry downloadEntry;

    public PluginBeanWrapper(PluginBean bean) {
        pluginBean = bean;
    }

    public void createDownloadEntry() {
        if (null == pluginBean) {
            return;
        }
        downloadEntry = new DownloadEntry(pluginBean.path, pluginBean.showName + ".apk", PathUtil.getAppPluginPath() + File.separator + pluginBean.showName + ".apk");
    }

    public DownloadEntry getDownloadEntry() {
        if (null == downloadEntry) {
            createDownloadEntry();
        }
        return downloadEntry;
    }
    public void setDownloadEntry(DownloadEntry downloadEntry) {
        this.downloadEntry = downloadEntry;
    }
}
