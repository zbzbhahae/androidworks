package com.huawei.genexcloud.netwoekstructure.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.huawei.genexcloud.netwoekstructure.R;
import com.huawei.genexcloud.netwoekstructure.bean.CitySiteDataBean;
import com.huawei.genexcloud.netwoekstructure.widget.DoubleHBar;

import java.util.List;

/**
 * 高潜站 refarming页面list的适配器
 */
public class HighRefarmingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // 数据类型 分别为5g高潜站解决率、偏移率、RefarmingLTE进展、UMTS进展
    public final int DATA_TYPE_HANDLED = 1;
    public final int DATA_TYPE_OFFSET = 2;
    public final int DATA_TYPE_CUCC = 3;
    public final int DATA_TYPE_CTCC = 4;
    private final int ITEM_TYPE_NORMAL = 1;
    private final int ITEM_TYPE_FOOT = 2;  // viewType  footer是展开收起的布局
    private List<CitySiteDataBean> data;
    private boolean showAllItem = false;
    private int mBarValueTextMode = DoubleHBar.MODE_VALUE_TEXT_PERCENTAGE;
    private double maxValue;
    private final int ITEM_COUNT_COLLAPSE_MODE = 10; // 不显示全部数据时，最多显示多少条
    private int dataType = 1;

    private OnItemClickedListener listener;

    /**
     * 设置回调接口
     *
     * @param listener
     */
    public void setListener(OnItemClickedListener listener) {
        this.listener = listener;
    }

    @Deprecated
    public void setData(List<CitySiteDataBean> data) {
        this.data = data;
        showAllItem = false;
        maxValue = 0;
        dataType = 1;
        notifyDataSetChanged();
    }

    public void setData(List<CitySiteDataBean> data, int dataType) {
        this.data = data;
        showAllItem = false;
        this.dataType = dataType;
        calcMaxValue();
        notifyDataSetChanged();
    }

    private void calcMaxValue() {
        maxValue = 0;
        // 获得最大值
        if (null != data && data.size() > 0) {
            int itemCount = data.size();
            if (itemCount > 10 && !showAllItem) {
                itemCount = 10;
            }
            for (int i = 0; i < itemCount; i++) {
                CitySiteDataBean item = data.get(i);
                switch (dataType) {
                    case DATA_TYPE_HANDLED:
                        maxValue = Math.max(maxValue, item.getHighPotentialResRate());
                        break;
                    case DATA_TYPE_OFFSET:
                        maxValue = Math.max(maxValue, item.getHighPotentialSiteOffsetRate());
                        break;
                    case DATA_TYPE_CUCC:
                        maxValue = Math.max(maxValue, item.getFreShiftCellDoneCTCCRate());
                        break;
                    case DATA_TYPE_CTCC:
                        maxValue = Math.max(maxValue, item.getFreShiftCellDoneCUCCRate());
                        break;
                }
            }
        }
        // 全是各种率 不超过100%
        if (maxValue > 1) {
            maxValue = 1;
        }
    }

    /**
     * 设置是否显示全部数据
     *
     * @param showAllItem
     */
    public void setShowAll(boolean showAllItem) {
        if (this.showAllItem != showAllItem) {
            this.showAllItem = showAllItem;
            calcMaxValue();
            notifyDataSetChanged();
        }
    }

    /**
     * 设置数值文字显示模式
     *
     * @param showValueTextDetail DoubleHBar 的数值文字显示模式 是否显示具体数值
     */
    public void setShowValueTextDetail(boolean showValueTextDetail) {
        if (showValueTextDetail) {
            mBarValueTextMode = DoubleHBar.MODE_VALUE_TEXT_DETAIL;
        } else {
            mBarValueTextMode = DoubleHBar.MODE_VALUE_TEXT_PERCENTAGE;
        }
        notifyDataSetChanged();
    }

    /**
     * 获得item的view类型， 一种是正常的数据view 一种是点击展开的footer
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        if (null == data || data.size() < (position + 1)) {
            return ITEM_TYPE_FOOT;
        }
        if (!showAllItem && hasFooter() && position == ITEM_COUNT_COLLAPSE_MODE) {
            return ITEM_TYPE_FOOT;
        }
        return ITEM_TYPE_NORMAL;
    }

    @Override
    public int getItemCount() {
        if (null == data || 0 == data.size()) {
            return 0;
        }
        if (showAllItem) {
            if (data.size() > ITEM_COUNT_COLLAPSE_MODE) {
                return data.size() + 1; // 多一个footer
            } else {
                return data.size(); // 条目数不够 不显示footer
            }
        } else {
            if (data.size() > ITEM_COUNT_COLLAPSE_MODE) {
                return ITEM_COUNT_COLLAPSE_MODE + 1; // 多一个footer
            } else {
                return data.size(); // 条目数不够 不显示footer
            }
        }
    }

    /**
     * 是否显示footer
     *
     * @return
     */
    private boolean hasFooter() {
        return null != data && data.size() > ITEM_COUNT_COLLAPSE_MODE;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        if (ITEM_TYPE_NORMAL == viewType) {
            View itemView = LayoutInflater.from(viewGroup.getContext())
                    .inflate(R.layout.item_refarming, viewGroup, false);
            return new VH(itemView);
        } else {
            View itemView = LayoutInflater.from(viewGroup.getContext())
                    .inflate(R.layout.item_expand_foot, viewGroup, false);
            return new FooterVH(itemView);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        final int finalPosition = position;
        if (ITEM_TYPE_NORMAL == getItemViewType(position)) {
            VH vh = (VH) viewHolder;
            CitySiteDataBean bean = data.get(position);
            final String provinceName = bean.getProvinceName();
            final String cityName = bean.getCityName();
            vh.cityTxt.setText(bean.getCityName());

            switch (dataType) {
                case DATA_TYPE_OFFSET:
                    vh.bar.setData(bean.getHighPotentialSiteOffset(), bean.getHighPotentialSiteDepl(), bean.getHighPotentialSiteOffsetRate(), maxValue);
                    break;
                case DATA_TYPE_CUCC:
                    vh.bar.setData(bean.getFreShiftCellDoneCTCC(), bean.getFreShiftCellCTCC(), bean.getFreShiftCellDoneCTCCRate(), maxValue);
                    break;
                case DATA_TYPE_CTCC:
                    vh.bar.setData(bean.getFreShiftCellDoneCUCC(), bean.getFreShiftCellCUCC(), bean.getFreShiftCellDoneCUCCRate(), maxValue);
                    break;
                case DATA_TYPE_HANDLED:
                default:
                    vh.bar.setData(bean.getHighPotentialSiteDepl(), bean.getHighPotentialRate(), bean.getHighPotentialResRate(), maxValue);
                    break;
            }
            vh.bar.setValueTextMode(mBarValueTextMode);
            vh.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != listener) {
                        listener.onClick(finalPosition, provinceName, cityName);
                    }
                }
            });
        } else { // Footer
            FooterVH footer = (FooterVH) viewHolder;
            if (showAllItem) {
                footer.expandTxt.setText("收起全部");
                footer.expandIv.setImageResource(R.drawable.icon_arrow_up);
            } else {
                footer.expandTxt.setText("展开全部");
                footer.expandIv.setImageResource(R.drawable.icon_arrow_down);
            }
            footer.expandLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAllItem = !showAllItem;
                    calcMaxValue();
                    notifyDataSetChanged();
                }
            });
        }
    }

    /**
     * 点击回调
     */
    public interface OnItemClickedListener {
        void onClick(int position, String provinceName, String cityName);
    }

    protected class VH extends RecyclerView.ViewHolder {

        private final TextView cityTxt;
        private final DoubleHBar bar;

        public VH(@NonNull View itemView) {
            super(itemView);
            cityTxt = itemView.findViewById(R.id.item_refarming_text);
            bar = itemView.findViewById(R.id.item_refarming_bar);
        }
    }

    protected class FooterVH extends RecyclerView.ViewHolder {

        private final TextView expandTxt;
        private final ImageView expandIv;
        private final ViewGroup expandLayout;

        public FooterVH(@NonNull View itemView) {
            super(itemView);
            expandTxt = itemView.findViewById(R.id.item_expand_text);
            expandIv = itemView.findViewById(R.id.item_expand_image);
            expandLayout = itemView.findViewById(R.id.item_expand_layout);
        }
    }
}
