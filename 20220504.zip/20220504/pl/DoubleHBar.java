package com.huawei.genexcloud.netwoekstructure.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import java.text.DecimalFormat;

/**
 * 两种颜色的横向柱子 两个value  all是总长度 part是占比 maxValue用来在list中使用时限制总长度
 */
public class DoubleHBar extends View {

    private final int leftColor = 0xFF6FBAFF;  // 管子左边颜色
    private final int rightColor = 0xFFFF5E5E;
    private Paint textPaint, barPaint;
    private final int textColor = 0xFF444444;
    private final float textSize = sp2px(8);
    private float baseLine; // 所有数值文字都是8sp 使用同一个baseline
    private double valueAll, valuePart; // 全部大小和所显示大小
    private double partRatioValue; // valuePart / valueAll   不自己计算 使用传入的数据
    private double maxValue = -1; // 用于对比的数值
    private float valueTextWidth; // 右侧文字宽度
    private final String VALUE_TEXT_STUB = "(99.99%)"; // 右侧站位文字
    private final float valueTextSpacing = dp2px(5); // 右侧文字与管子间距
    private final float barHeight = dp2px(8); // 管子粗细 8dp
    private float barMaxLength; // 管子最长宽度
    private int width, height;
    private boolean drawValueText = true;

    private final RectF rect = new RectF();
    private final DecimalFormat valueFormat = new DecimalFormat("#");
    private final DecimalFormat percentageFormat = new DecimalFormat("#.##");

    // 文字显示模式 1.显示百分比 2.显示具体数值
    public static final int MODE_VALUE_TEXT_PERCENTAGE = 1, MODE_VALUE_TEXT_DETAIL = 2;
    private int mValueTextMode = MODE_VALUE_TEXT_PERCENTAGE;


    public DoubleHBar(Context context) {
        this(context, null);
    }

    public DoubleHBar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DoubleHBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(textColor);
        textPaint.setTextSize(textSize);

        barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setStyle(Paint.Style.FILL);
//        barPaint.setStrokeCap(Paint.Cap.ROUND);
        barPaint.setStrokeWidth(barHeight);
    }

    private float dp2px(float dp) {
        return getResources().getDisplayMetrics().density * dp;
    }

    private float sp2px(float sp) {
        return getResources().getDisplayMetrics().scaledDensity * sp;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            width = getWidth();
            height = getHeight();
            initData();
            invalidate();
        }
    }


    public void setData(double valuePart, double valueAll, double partRatioValue, double maxValue) {
        this.valueAll = valueAll;
        this.valuePart = valuePart;
        this.maxValue = maxValue;
        this.partRatioValue = partRatioValue;
        initData();
        invalidate();
    }

    /**
     * 初始化作图数据
     */
    private void initData() {
        valueTextWidth = textPaint.measureText(VALUE_TEXT_STUB);
        Paint.FontMetricsInt fmi = textPaint.getFontMetricsInt();
        baseLine = (fmi.descent - fmi.ascent) * 0.5f - fmi.descent;
        barMaxLength = width - valueTextWidth - valueTextSpacing;
        if (barMaxLength < 0) {
            barMaxLength = 0;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 允许分子比分母大 即占比超过100% 实际显示100%
//        || valuePart > valueAll
        if (valuePart < 0 || valueAll < 0
                || 0 == width || 0 == height) {
            return;
        }
        drawContent(canvas);
    }

    private void drawContent(Canvas canvas) {
        String partString = getValueString(valuePart, valueAll, mValueTextMode);
        String allString = getValueString((valueAll - valuePart), valueAll, mValueTextMode);

        String percentageString = getPercentageString(valuePart, valueAll);
        float partTextWidth = textPaint.measureText(partString);
        float allTextWidth = textPaint.measureText(allString);
        float centerY = height * 0.5f;

        float allValueWidth = 0; // maxValue是part / all 结果最大的，是按比率排序
        float partValueWidth = 0;
        if (0 == valueAll) {
            allValueWidth = allTextWidth + partTextWidth;
            partValueWidth = partTextWidth;
        } else {
            if (maxValue > (valuePart / valueAll)) {
                allValueWidth = (float) ((valuePart / valueAll) / maxValue * barMaxLength);
            } else if (maxValue == (valuePart / valueAll)) {
                allValueWidth = barMaxLength;
            } else {
                allValueWidth = barMaxLength;
            }

            // 如果allValue 数值计算出的柱子宽度小于文字宽度，则最少应该有文字宽度
            if (allValueWidth < (allTextWidth + partTextWidth)) {
                allValueWidth = allTextWidth + +partTextWidth;
            }

            partValueWidth = (float) (valuePart / valueAll * allValueWidth);


            // partValue宽度最少是数值文字宽度
            if (partValueWidth < partTextWidth) {
                partValueWidth = partTextWidth;
            }
            // 但同时不能占用allValue的数值文字宽度
            if (allValueWidth - partValueWidth < allTextWidth) {
                partValueWidth = allValueWidth - allTextWidth;
            }
        }
        // 画柱子
        barPaint.setColor(rightColor);
        rect.set(0, centerY - 0.5f * barHeight, allValueWidth, centerY + 0.5f * barHeight);
        canvas.drawRoundRect(rect, dp2px(2), dp2px(4), barPaint);

        barPaint.setColor(leftColor);
        rect.set(0, centerY - 0.5f * barHeight, partValueWidth, centerY + 0.5f * barHeight);
        canvas.drawRoundRect(rect, dp2px(2), dp2px(4), barPaint);

        if (drawValueText) {
            float leftTextX = (partValueWidth - partTextWidth) * 0.5f;
            canvas.drawText(partString, leftTextX, centerY + baseLine, textPaint);
            float rightTextX = (allValueWidth - partValueWidth - allTextWidth) * 0.5f + partValueWidth;
            canvas.drawText(allString, rightTextX, centerY + baseLine, textPaint);
            float percentageTextX = allValueWidth;
            canvas.drawText(percentageString, percentageTextX, centerY + baseLine, textPaint);
        }
    }

    private void drawLeft(Canvas canvas) {
        String valueString = getValueString(valuePart);
        float valueTextWidth = textPaint.measureText(valueString);
        float valueWidth = 0;
        float centerY = height * 0.5f;
        if (0 == maxValue) {
            valueWidth = valueTextWidth;
        } else {
            valueWidth = (float) (valuePart / maxValue * barMaxLength);
        }
        if (valueWidth < valueTextWidth) {
            valueWidth = valueTextWidth;
        }

        String percentageString = getPercentageString(valuePart, valueAll);

        // 画柱子
        barPaint.setColor(leftColor);
        rect.set(0, centerY - 0.5f * barHeight, valueWidth, centerY + 0.5f * barHeight);
        canvas.drawRoundRect(rect, dp2px(2), dp2px(4), barPaint);

        if (drawValueText) {
            float leftTextX = (barMaxLength - valueWidth) * 0.5f;
            canvas.drawText(valueString, leftTextX, centerY + baseLine, textPaint);
            float percentageTextX = valueWidth;
            canvas.drawText(percentageString, percentageTextX, centerY + baseLine, textPaint);
        }
    }

    private void drawRight(Canvas canvas) {
        String valueString = getValueString(valueAll);
        float valueTextWidth = textPaint.measureText(valueString);
        float valueWidth = 0;
        float centerY = height * 0.5f;
        if (0 == maxValue) {
            valueWidth = valueTextWidth;
        } else {
            valueWidth = (float) (valueAll / maxValue * barMaxLength);
        }
        if (valueWidth < valueTextWidth) {
            valueWidth = valueTextWidth;
        }

        String percentageString = getPercentageString(valuePart, valueAll);

        // 画柱子
        barPaint.setColor(rightColor);
        rect.set(0, centerY - 0.5f * barHeight, valueWidth, centerY + 0.5f * barHeight);
        canvas.drawRoundRect(rect, dp2px(2), dp2px(4), barPaint);

        if (drawValueText) {
            float leftTextX = (barMaxLength - valueWidth) * 0.5f;
            canvas.drawText(valueString, leftTextX, centerY + baseLine, textPaint);
            float percentageTextX = valueWidth;
            canvas.drawText(percentageString, percentageTextX, centerY + baseLine, textPaint);
        }
    }

    private String getValueString(double value) {
        if (value <= 0) {
            return "";
        }
        return " " + valueFormat.format(value) + " ";
    }

    private String getPercentageString(double valuePart, double valueAll) {
        if (valueAll == 0) {
            return "0%";
        }
        return percentageFormat.format(partRatioValue * 100) + "%";
    }

    /**
     * 显示数值文字模式
     * @param valueTextMode
     */
    public void setValueTextMode(int valueTextMode) {
        if (valueTextMode != MODE_VALUE_TEXT_PERCENTAGE && valueTextMode != MODE_VALUE_TEXT_DETAIL) {
            return;
        }
        mValueTextMode = valueTextMode;
        invalidate();
    }

    /**
     * 根据显示模式与数值 返回数值文字
     * @param value
     * @param valueAll
     * @param mValueTextMode 显示模式 1是显示百分比，2是显示具体数值
     * @return
     */
    private String getValueString(double value, double valueAll, int mValueTextMode) {
        if (-255 == value || Double.isNaN(value) || value <= 0) {
            return "";
        }
        if (mValueTextMode == MODE_VALUE_TEXT_PERCENTAGE) {
            // 显示百分比
            if (-255 == valueAll || Double.isNaN(valueAll) || valueAll <= 0) {
                return "100%";
            } else {
                return percentageFormat.format( (value / valueAll) * 100) + "%";
            }
        } else {
            return percentageFormat.format(value);
        }
    }
}
