package com.huawei.genexcloud.netwoekstructure.activity.controller;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.huawei.genexcloud.netwoekstructure.R;
import com.huawei.genexcloud.netwoekstructure.activity.ProvinceActivity;
import com.huawei.genexcloud.netwoekstructure.activity.data.StatusViewModel;
import com.huawei.genexcloud.netwoekstructure.adapter.HighRefarmingAdapter;
import com.huawei.genexcloud.netwoekstructure.bean.HighRefarmingData;
import com.huawei.genexcloud.netwoekstructure.utils.AppUtil;

/**
 * 高潜站点 下面的数据表部分
 */
public class HighRiskListController extends BaseController implements HighRefarmingAdapter.OnItemClickedListener, HighRiskMapController.OnTypeChangeListener {

    private RecyclerView recyclerView;
    private HighRefarmingAdapter adapter;
    private TextView dataHintTxt;

    private CheckBox valueSwitcher; // 是否显示数值文字
    private TextView noDataTxt; // 无数据的提示文字

    private int dataType = TYPE_HANDLE;
    private HighRefarmingData dataBean;

    private TextView legendTv1, legendTv2;

    public HighRiskListController(Context context) {
        super(context);
    }


    @Override
    protected View getRootView(Context context) {
        return LayoutInflater.from(context)
                .inflate(R.layout.controller_risk_list, null, false);
    }

    @Override
    protected void initViews(Context context) {
        recyclerView = find(R.id.risk_list_list);
        adapter = new HighRefarmingAdapter();
        valueSwitcher = find(R.id.risk_list_switcher);
        dataHintTxt = find(R.id.risk_list_data_hint);
        noDataTxt = find(R.id.risk_list_no_data);
        legendTv1 = find(R.id.risk_list_name1);
        legendTv2 = find(R.id.risk_list_name2);
    }

    @Override
    protected void initData() {
        recyclerView.setLayoutManager(new LinearLayoutManager(weakContext.get()));
        recyclerView.setAdapter(adapter);
        adapter.setListener(this);
        adapter.setShowAll(false);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);


        // 是否显示数值的开关
        valueSwitcher.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                adapter.setShowValueTextDetail(isChecked);
            }
        });
    }

    @Override
    public void initViewState() {
        noDataTxt.setVisibility(View.GONE);
        valueSwitcher.setChecked(true);
    }

    public void setData(HighRefarmingData data) {
        noDataTxt.setVisibility(View.GONE);
        dataBean = data;
        if (null == data) {
            setNoData(null);
            return;
        }
        if (dataType == TYPE_HANDLE) {
            dataHintTxt.setText("注：高潜站点解决率=高潜站点解决数/高潜站点数");
            adapter.setData(data.getHighHandledCitySiteList(), adapter.DATA_TYPE_HANDLED);
            legendTv1.setText("解决数");
            legendTv2.setText("未解决数");
        } else if (dataType == TYPE_OFFSET) {
            dataHintTxt.setText("注：高潜站点偏移率=高潜站点偏移数(50M)/高潜站点开通数");
            adapter.setData(data.getHighOffsetCitySiteList(), adapter.DATA_TYPE_OFFSET);
            legendTv1.setText("偏移数");
            legendTv2.setText("未偏移");
        }

        if (0 == adapter.getItemCount()) { // 没数据
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(weakContext.get().getString(R.string.no_data));
        }
    }

    @Override
    public void setNoData(String message) {
        adapter.setData(null);
        if (TextUtils.isEmpty(message)) {
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(weakContext.get().getString(R.string.no_data));
        } else {
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(message);
        }
    }

    @Override
    public void onClick(int position, String provinceName, String cityName) {
        if (TextUtils.isEmpty(provinceName) && TextUtils.isEmpty(cityName)
                || AppUtil.isFastDoubleClick() || !isContextAvailable()) {
            return;
        }
        Intent i = new Intent(weakContext.get(), ProvinceActivity.class);
        i.putExtra("city", cityName);
        i.putExtra("province", provinceName);
        i.putExtra("operator", StatusViewModel.getSelectedOperator());
        weakContext.get().startActivity(i);
    }


    /**
     * 显示数据改变
     *
     * @param type
     */
    @Override
    public void onChange(int type) {
        if (type == TYPE_HANDLE) { // 显示解决率数据
            dataType = TYPE_HANDLE;
        } else if (type == TYPE_OFFSET) { // 显示偏移率数据
            dataType = TYPE_OFFSET;
        }
        setData(dataBean);
    }
}
