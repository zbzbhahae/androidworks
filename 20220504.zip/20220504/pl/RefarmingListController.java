package com.huawei.genexcloud.netwoekstructure.activity.controller;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.huawei.genexcloud.netwoekstructure.R;
import com.huawei.genexcloud.netwoekstructure.activity.ProvinceActivity;
import com.huawei.genexcloud.netwoekstructure.adapter.HighRefarmingAdapter;
import com.huawei.genexcloud.netwoekstructure.bean.HighRefarmingData;
import com.huawei.genexcloud.netwoekstructure.utils.AppUtil;

/**
 * NR Refarming 的底部列表数据部分
 */
public class RefarmingListController extends BaseController implements View.OnClickListener, HighRefarmingAdapter.OnItemClickedListener {

    private RadioGroup typeGroup;
    private RadioButton lteBtn, umtsBtn; // LTE移频进展、UMTS移频进展

    private CheckBox valueTextSwitcher;
    private RecyclerView recyclerView;
    private HighRefarmingAdapter adapter;

    private TextView noDataTxt; // 无数据时的提示

    private HighRefarmingData dataBean; // 数据bean

    public RefarmingListController(Context context) {
        super(context);
    }

    @Override
    protected View getRootView(Context context) {

        return LayoutInflater.from(context)
                .inflate(R.layout.controller_refarming_list, null, false);
    }

    @Override
    protected void initViews(Context context) {
        typeGroup = find(R.id.refarming_list_group);
        lteBtn = find(R.id.refarming_list_lte);
        umtsBtn = find(R.id.refarming_list_umts);

        valueTextSwitcher = find(R.id.refarming_list_switcher);
        recyclerView = find(R.id.refarming_list_list);

        noDataTxt = find(R.id.refarming_list_no_data);

    }

    @Override
    protected void initData() {
        adapter = new HighRefarmingAdapter();
        adapter.setListener(this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(weakContext.get()));
        recyclerView.setAdapter(adapter);


        valueTextSwitcher.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                adapter.setShowValueTextDetail(isChecked);
            }
        });

        typeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setData(dataBean);
            }
        });
    }

    @Override
    public void initViewState() {
        valueTextSwitcher.setChecked(true);
    }

    @Override
    public void setNoData(String message) {
        if (TextUtils.isEmpty(message)) {
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(weakContext.get().getString(R.string.no_data));
        } else {
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(message);
        }
    }

    public void setData(HighRefarmingData data) {
        noDataTxt.setVisibility(View.GONE);
        dataBean = data;
        if (null == data) {
            setNoData(null);
            return;
        }
        if (lteBtn.isChecked()) {
            adapter.setData(data.getRefarmingLteCitySiteList(), adapter.DATA_TYPE_CUCC);
        } else if (umtsBtn.isChecked()) {
            adapter.setData(data.getRefarmingUMTSCitySiteList(), adapter.DATA_TYPE_CTCC);
        } else {
            lteBtn.setChecked(true);
            adapter.setData(data.getRefarmingLteCitySiteList(), adapter.DATA_TYPE_CUCC);
        }
        if (0 == adapter.getItemCount()) {
            noDataTxt.setVisibility(View.VISIBLE);
            noDataTxt.setText(weakContext.get().getString(R.string.no_data));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        }
    }

    public void setRadioButtonTextByOperator(String operator) {
        if (TextUtils.isEmpty(operator)) {
            return;
        }
        switch (operator) {
            case "CUCC":
            case "CUTC":
            case "联通":
                lteBtn.setText("联通承建区域\n联通清频进展");
                umtsBtn.setText("联通承建区域\n电信清频进展");
                break;
            case "CNTC":
            case "电信":
                lteBtn.setText("电信承建区域\n联通清频进展");
                umtsBtn.setText("电信承建区域\n电信清频进展");
                break;
        }
    }


    /**
     * 点击图表条目
     *
     * @param position
     * @param cityName
     */
    @Override
    public void onClick(int position, String provinceName, String cityName) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (isContextAvailable() && !TextUtils.isEmpty(cityName)) {
            Intent i = new Intent(weakContext.get(), ProvinceActivity.class);
            i.putExtra("city", cityName);
            weakContext.get().startActivity(i);
        }
    }
}
