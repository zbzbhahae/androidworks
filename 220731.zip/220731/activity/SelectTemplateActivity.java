package com.huawei.genexcloud.survey.activity;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.huawei.genexcloud.framework.bean.Template;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.adapter.SelectTemplateAdapter;
import com.huawei.genexcloud.survey.base.BaseActivity;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.dialog.SVAlertDialog;
import com.huawei.genexcloud.survey.http.CopyTemplateImpl;
import com.huawei.genexcloud.survey.http.DeleteTemplateImpl;
import com.huawei.genexcloud.survey.http.QueryTemplateListImpl;
import com.huawei.genexcloud.survey.http.SetDefaultTemplateImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.views.MyEditText;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;

public class SelectTemplateActivity extends BaseActivity
        implements View.OnClickListener, AdapterView.OnItemClickListener, SelectTemplateAdapter.OnOperationListener {
    private final int REQUESTCODE = 1;
    private List<Template> templateList = new ArrayList<>();
    private ListView listView;
    private SelectTemplateAdapter seleteTemplateAdapter;
    private int flag; //0 新建 1 改造
    private final int deleteIndex = -1;
    private LinearLayout ll;

    private EditText etSearch;
    private PopupWindow popupWindow;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_selete_template;
    }

    @Override
    protected void initView() {
        ll = (LinearLayout) findViewById(R.id.activity_selete_template);
        findViewById(R.id.back).setOnClickListener(this);
        listView = (ListView) findViewById(R.id.listViews);
        findViewById(R.id.tv_add).setOnClickListener(this);

        etSearch = (EditText) findViewById(R.id.et_search);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                queryDBdata(etSearch.getText().toString().trim());
            }
        });
    }

    @Override
    protected void initData() {
        flag = getIntent().getIntExtra("FLAG", 0);
        seleteTemplateAdapter = new SelectTemplateAdapter(this);
        listView.setAdapter(seleteTemplateAdapter);
        listView.setOnItemClickListener(this);
        requestTemplateList();
        seleteTemplateAdapter.setOnOperationListener(this);

    }

    /**
     * 查询数据库数据，展示
     */
    public void queryDBdata(String key) {
        templateList = (ArrayList<Template>) DBManager.getInstance(BaseApplication.getAppContext()).getTemplateDB()
                .queryAllByAccountOrName(key);
        seleteTemplateAdapter.setListData(templateList);
        seleteTemplateAdapter.notifyDataSetChanged();
    }

    private void showDeletePopupwindow(final String templateId) {
        new SVAlertDialog()
                .cancelContent("取消")
                .confirmContent("确定")
                .content(getString(R.string.tv_pop_delete_template))
                .backgroundImage(R.drawable.bg_delete)
                .setConfirmListener(v -> {
                    requestDeleteTemplate(templateId);
                })
                .show(getSupportFragmentManager());
    }

    /**
     * 查询模板列表
     */
    private void requestTemplateList() {
        QueryTemplateListImpl.getInstance().getTemplateList(new QueryTemplateListImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog(SelectTemplateActivity.this);
            }

            @Override
            public void onAfter() {
                closeLoadDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                if (null != e && e.errorCode != ErrorBean.ERROR_CANCELED) {
                    showToast(e.message);
                }
                seleteTemplateAdapter.setListData(null);
                templateList = null;
            }

            @Override
            public void onResponse(List<Template> response) {
                if (null == response || response.isEmpty()) {
                    showToast("暂无数据");
                }
                templateList = response;
                seleteTemplateAdapter.setListData(response);
            }
        });
    }

    /**
     * 删除模板
     */
    private void requestDeleteTemplate(String templateId) {
        createLoadingDialog(this, this, "", false);
        DeleteTemplateImpl.getInstance().deleteTemplate(templateId, new DeleteTemplateImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                if (null != e && !TextUtils.isEmpty(e.message)) {
                    showToast(e.message);
                } else {
                    showToast("删除模板失败");
                }
            }

            @Override
            public void onResponse(Boolean response) {
                closeLoadDialog();
                if (null != response && response) {
                    showToast("删除模板成功");
                    requestTemplateList();
                } else {
                    showToast("删除模板失败");
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                finish();
                break;
            case R.id.tv_add:
                createTemplate();
                break;
            default:
                break;
        }
    }

    private void createTemplate() {
        showPopupWindow(1000, "", "");
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (null == templateList || templateList.isEmpty() || position < 0
                || position >= templateList.size()) {
            return;
        }
        setDefaultTemplate(templateList.get(position).getBaseType(), templateList.get(position).getTemplateId());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUESTCODE && resultCode == RESULT_OK) {
            requestTemplateList();
        }
    }

    @Override
    public void onClickDelete(int position) {
        String templateId = "";
        if (templateList != null && templateList.size() > position) {
            templateId = templateList.get(position).getTemplateId();
        }
        showDeletePopupwindow(templateId);
    }

    @Override
    public void onClickCopy(int position) {
        String name = "";
        String templateId = "";
        if (templateList != null && templateList.size() > position) {
            name = templateList.get(position).getTemplateName();
            templateId = templateList.get(position).getTemplateId();
        }

        showPopupWindow(1001, name + "-01", templateId);
    }

    @Override
    public void onClickEdit(int position) {
        String name = "";
        String templateId = "";
        if (templateList != null && templateList.size() > position) {
            name = templateList.get(position).getTemplateName();
            templateId = templateList.get(position).getTemplateId();
        }

        Intent intent = new Intent();
        //最起码有基础模板，不会为空
        intent.putExtra("templateName", name);
        intent.putExtra("TemplateId", templateId);
        intent.putExtra("FLAG", 1);
        intent.setClass(SelectTemplateActivity.this, EditTemplateActivity.class);
        startActivityForResult(intent, REQUESTCODE);
    }

    /**
     * 模板名称编辑框
     *
     * @param flag
     * @param name
     */
    private void showPopupWindow(final int flag, final String name, final String templateId) {
        View view = LayoutInflater.from(this).inflate(R.layout.template_popwindow, null);
        TextView tvTitle = (TextView) view.findViewById(R.id.tv_pop_title);
        final MyEditText editText = (MyEditText) view.findViewById(R.id.et_rename);
        view.findViewById(R.id.tv_pop_bg).setOnClickListener(this);
        if (flag == 1001) {
            tvTitle.setText("复制模板");
            editText.setText(name);
        } else if (flag == 1000) {
            tvTitle.setText("新建模板");
            editText.setHint("请输入模板名称");
        }
        popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(ll, Gravity.CENTER, 0, 0);
        view.findViewById(R.id.btn_pop_create).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String templateName = editText.getText().toString();
                if (TextUtils.isEmpty(templateName)) {
                    showToast("模板名称不能为空", Gravity.BOTTOM);
                    return;
                }
                //所有模板名称
                String templateNames = "";
                if (templateList.size() > 0) {
                    for (int i = 0; i < templateList.size(); i++) {
                        templateNames = templateNames + templateList.get(i).getTemplateName() + ",";
                    }
                }

                if (!TextUtils.isEmpty(templateNames)) {
                    templateNames = templateNames.substring(0, templateNames.length() - 1);
                }

                String[] strName = templateNames.split(",");
                for (int i = 0; i < strName.length; i++) {
                    if (templateName.equals(strName[i])) {
                        showToast("该模板名已存在，请重新输入模板名", Gravity.BOTTOM);
                        return;
                    }
                }

                if (flag == 1000) {
                    Intent intent = new Intent();
                    //最起码有基础模板，不会为空
                    intent.putExtra("templateName", templateName);
                    intent.putExtra("FLAG", 1);
                    intent.setClass(SelectTemplateActivity.this, CreateTemplateActivity.class);
                    startActivityForResult(intent, REQUESTCODE);
                } else {
                    copyTemplate(templateId, templateName);
                }

                popupWindow.dismiss();
            }
        });

        view.findViewById(R.id.btn_pop_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
    }

    /**
     * 设置默认模板
     */
    private void setDefaultTemplate(int templateFlag, String templateId) {
        SetDefaultTemplateImpl.getInstance().setDefaultTemplate(templateId, new SetDefaultTemplateImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
            }

            @Override
            public void onResponse(Boolean response) {
            }
        });
        Intent intent = new Intent();
        intent.putExtra("FLAG", templateFlag);
        intent.putExtra("TemplateId", templateId);
        setResult(RESULT_OK, intent);
        finish();
    }

    /**
     * 复制模板
     */
    private void copyTemplate(String templateId, String name) {
        createLoadingDialog(this, this, "", false);
        CopyTemplateImpl.getInstance().createCopyTemplate(templateId, name, new CopyTemplateImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
            }

            @Override
            public void onResponse(Boolean response) {
                closeLoadDialog();
                if (null != response && response) {
                    showToast("复制成功");
                    requestTemplateList();
                } else {
                    showToast("复制失败");
                }
            }
        });
    }
}
