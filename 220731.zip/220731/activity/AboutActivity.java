package com.huawei.genexcloud.survey.activity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.huawei.genexcloud.framework.bean.VersionInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.ui.AvailableClickDrawable;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.DensityUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.base.BaseActivity;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.fragment.UpdateDialogFragment;
import com.huawei.genexcloud.survey.http.QueryAppUpdateImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.util.ShareUtil;
import com.huawei.genexcloud.survey.views.BadgeView;
import com.huawei.genexcloud.survey.views.CircleDrawable;

/**
 * 关于界面
 */
public class AboutActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "AboutActivity";
    private RelativeLayout mContantUs;
    private RelativeLayout mCheckVersion;
    private TextView newVersion;
    private BadgeView badgeview;
    private TextView version;
    private Dialog dialog;

    private void createDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View parent = inflater.inflate(R.layout.no_update_dialog_layout, null);// 得到加载view

        TextView tipTitle = (TextView) parent.findViewById(R.id.tv_tip_title);
        tipTitle.setText("最新版本" + AppUtil.getAppVersionName(this));
        Button button = (Button) parent.findViewById(R.id.btn_sure);

        if (dialog == null) {
            dialog = new Dialog(AboutActivity.this, R.style.Dialog_Fullscreen);
        }
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setContentView(parent);// 设置布局
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    protected void initView() {
        TextView tvTitle = (TextView) findViewById(R.id.tv_title);
        tvTitle.setText("关于勘测APP");

        ImageButton llBack = (ImageButton) findViewById(R.id.back_view);
        llBack.setBackground(new AvailableClickDrawable(ContextCompat.getColor(this, R.color.transparent_white),
                ContextCompat.getColor(this, R.color.transparent_black_30)));
        llBack.setOnClickListener(this);

        mContantUs = (RelativeLayout) findViewById(R.id.rela_contant);
        mCheckVersion = (RelativeLayout) findViewById(R.id.check_version);

        version = (TextView) findViewById(R.id.version);
        //设置版本号

        mContantUs.setOnClickListener(this);
        mCheckVersion.setOnClickListener(this);

        badgeview = new BadgeView(this, mCheckVersion);
        badgeview.setMaxHeight(30);
        badgeview.setMaxWidth(30);
        badgeview.setBadgeMargin(DensityUtil.getPixByWidthPercent(this, 0.7f), 45);
        badgeview.setBadgePosition(BadgeView.POSITION_TOP_RIGHT);
        badgeview.setBackground(new CircleDrawable(Color.parseColor("#EE3636"), Color.TRANSPARENT, 0));
        newVersion = (TextView) findViewById(R.id.new_version);
        badgeview.hide();
        newVersion.setVisibility(View.GONE);

        String serVersion = ShareUtil.readString(Constants.SER_VERSION, "");
        version.setText(getString(R.string.my_app_version) + AppUtil.getAppVersionName(this));

        if (AppUtil.checkVersionCode(BaseApplication.getAppContext(), serVersion)) {
            badgeview.show();
            newVersion.setVisibility(View.VISIBLE);
            newVersion.setText("");
        } else {
            badgeview.hide();
            newVersion.setVisibility(View.VISIBLE);
            newVersion.setText(getString(R.string.update_noupdate));
        }
    }

    @Override
    protected void initData() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_about;
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.back_view:
                finish();// 关闭当前的Activity
                break;
            case R.id.rela_contant:
                startActivity(new Intent(this, ConnectUsActivity.class));
                break;
            case R.id.check_version:// 判断点击是否过快
                createLoadingDialog(this, this, "", false);
                checkVersion();
                break;
            default:
                break;
        }
    }

    /**
     * 查询版本
     */
    public void checkVersion() {
        QueryAppUpdateImpl.getInstance().getUpdate(new QueryAppUpdateImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                showToast(getResources().getString(R.string.my_query_fail));
            }

            @Override
            public void onResponse(VersionInfo response) {
                closeLoadDialog();
                if (null == response) {
                    showToast(getResources().getString(R.string.my_query_fail));
                    return;
                }
                if (!isFinishing()) {
                    VersionInfo info = response;
                    ShareUtil.save(Constants.SER_VERSION, info.getVersionName());
                    int level = info.getVersionLevel();// 获取到升级等级
                    if (AppUtil.checkVersionCode(getApplicationContext(), info.getVersionName())) {
                        new UpdateDialogFragment().setLevel(level, info.getDescribe(), info.getAppPath())
                                .show(getSupportFragmentManager(), "update_apk_fragment");
                        badgeview.show();
                        newVersion.setVisibility(View.VISIBLE);
                        newVersion.setText("");
                    } else {
                        createDialog();
                        badgeview.hide();
                        newVersion.setVisibility(View.VISIBLE);
                        newVersion.setText(getString(R.string.update_noupdate));
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}
