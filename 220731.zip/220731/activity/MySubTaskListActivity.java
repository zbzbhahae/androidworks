package com.huawei.genexcloud.survey.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.bean.SimulationReqInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.QueryCPquerySurveystatusUtil;
import com.huawei.genexcloud.framework.http.UpdateEmulationUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.adapter.MyTaskAdapter;
import com.huawei.genexcloud.survey.base.BaseActivity;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.base.IBaseResultLinstener;
import com.huawei.genexcloud.survey.http.QueryMyEmulationGroupImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.util.ShareUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 我的仿真任务列表（子任务列表）
 */
public class MySubTaskListActivity extends BaseActivity implements View.OnClickListener {
    private static final int SIMULATIONING = 0; //仿真中
    private static final int SIMULATION_FAIL = 1; //仿真失败
    private static final int QUERY_TASK_STATE_FAIL = 2; //查询任务状态失败
    private static final int SIMULATION_DELETE = 3; //仿真任务删除
    private static final int SIMULATION_STOP = 4; //仿真任务停止
    private static final int GETPICNING = 5; //获取仿真结果
    private MyTaskAdapter subTaskAdapter;
    private String currGroupId;
    private String currGroupName;
    private String currTaskId;
    private String currTaskName;
    private PopupWindow popupWindow;

    private final List<EmulationEntrance> noCompleteList = new ArrayList<>();
    private final List<EmulationEntrance> completedList = new ArrayList<>();

    private TextView tvNoComplete;

    private TextView tvCompleted;

    private TextView tvNoCompleteLine;

    private TextView tvCompletedLine;

    private TextView tvNoData;

    private ListView lvMytask;

    private boolean isComplete = false;

    private List<EmulationEntrance> showList = new ArrayList<>();

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.QUERY_STAYUS_SUCCESS:
                    closeLoadDialog();
                    int CPSurvey = (int) msg.obj;
                    SimulationReqInfo simulationReqInfo = new SimulationReqInfo();
                    simulationReqInfo.setProjectId(Constants.PROJECT_ID);
                    simulationReqInfo.setGroupid(currGroupId);
                    simulationReqInfo.setGroupName(currGroupName);
                    simulationReqInfo.setTaskId(currTaskId);
                    simulationReqInfo.setTaskName(currTaskName);
                    if (CPSurvey == 4) {
                        //任务失败
                        showTipPopupWindow(SIMULATION_FAIL);
                        simulationReqInfo.setResultImg("");
                        simulationReqInfo.setFinish(false);
                        simulationReqInfo.setStatus(4);
                        update(simulationReqInfo);
                    } else if (CPSurvey == -1) {
                        //任务删除
                        showTipPopupWindow(SIMULATION_DELETE);
                        simulationReqInfo.setResultImg("");
                        simulationReqInfo.setFinish(false);
                        simulationReqInfo.setStatus(-1);
                        update(simulationReqInfo);
                    } else if (CPSurvey == 5) {
                        //任务停止
                        showTipPopupWindow(SIMULATION_STOP);
                        simulationReqInfo.setResultImg("");
                        simulationReqInfo.setFinish(false);
                        simulationReqInfo.setStatus(5);
                        update(simulationReqInfo);
                    } else if (CPSurvey == 3) {
                        //仿真完成更新状态
                        EmulationEntrance info = DBManager.getInstance(BaseApplication.getAppContext())
                                .getSimulationTaskDB().queryById(Constants.PROJECT_ID, currGroupId, currTaskId);

                        simulationReqInfo.setFinish(true);
                        simulationReqInfo.setStatus(3);

                        if (!TextUtils.isEmpty(info.getSchemeImageUrl()) && !"null".equals(info.getSchemeImageUrl())) {
                            simulationReqInfo.setResultImg(info.getSchemeImageUrl());
                            update(simulationReqInfo);
                            enterSimulationResult(info);
                        } else {
                            showTipPopupWindow(GETPICNING);
                            simulationReqInfo.setResultImg("");
                            update(simulationReqInfo);
                        }
                    } else {
                        showTipPopupWindow(SIMULATIONING);
                        simulationReqInfo.setResultImg("");
                        simulationReqInfo.setFinish(false);
                        simulationReqInfo.setStatus(CPSurvey);
                        update(simulationReqInfo);
                    }
                    break;
                case Constants.QUERY_STAYUS_FAILED:
                    closeLoadDialog();
                    showTipPopupWindow(QUERY_TASK_STATE_FAIL);
                    break;
            }
        }
    };

    @Override
    protected void initView() {

        findViewById(R.id.back).setOnClickListener(this);
        tvNoComplete = (TextView) findViewById(R.id.tv_no_complete);
        tvNoComplete.setOnClickListener(this);

        tvCompleted = (TextView) findViewById(R.id.tv_completed);
        tvCompleted.setOnClickListener(this);

        tvNoCompleteLine = (TextView) findViewById(R.id.tv_no_complete_line);
        tvCompletedLine = (TextView) findViewById(R.id.tv_completed_line);

        tvNoData = (TextView) findViewById(R.id.tv_no_data);
        lvMytask = (ListView) findViewById(R.id.lv_task);

        subTaskAdapter = new MyTaskAdapter(this);
        lvMytask.setAdapter(subTaskAdapter);
        lvMytask.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (isComplete & completedList != null && completedList.size() > 0) {
                    //仿真完成
                    enterSimulationResult(completedList.get(position));
                } else {
                    String taskId = noCompleteList.get(position).getTaskId();
                    if (!TextUtils.isEmpty(taskId)) {
                        currGroupId = noCompleteList.get(position).getGroupId();
                        currGroupName = noCompleteList.get(position).getGroupName();
                        currTaskName = noCompleteList.get(position).getTaskName();
                        queryStatus(noCompleteList.get(position).getTaskId());
                    }
                }
            }
        });
    }

    @Override
    protected void initData() {
        queryTaskList();
    }

    public ArrayAdapter getAdapter(int arrayID) {
        ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource(this, arrayID, R.layout.spinner_sumilation_selete);
        arrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        return arrayAdapter;
    }

    /**
     * 查询仿真任务列表
     */
    private void queryTaskList() {
        noCompleteList.clear();
        completedList.clear();
        showList.clear();
        createLoadingDialog(this, this, "", false);
        QueryMyEmulationGroupImpl.getInstance().getMyEmulationGroup(new QueryMyEmulationGroupImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                tvNoData.setVisibility(View.VISIBLE);
                lvMytask.setVisibility(View.GONE);
                if (null != e && !TextUtils.isEmpty(e.message)) {
                    showToast(e.message);
                }
            }

            @Override
            public void onResponse(List<EmulationEntrance> response) {
                closeLoadDialog();
                String account = ShareUtil.readString(Constants.LOGIN_USER_KEY, "");
                List<EmulationEntrance> schemeInfoList = DBManager.getInstance(BaseApplication.getAppContext())
                        .getSimulationTaskDB().queryNormalByAccount(account);
                if (schemeInfoList != null && schemeInfoList.size() > 0) {
                    dealList(schemeInfoList);
                    if (isComplete) {
                        if (completedList != null && completedList.size() > 0) {
                            tvNoData.setVisibility(View.GONE);
                            lvMytask.setVisibility(View.VISIBLE);
                            showList = completedList;
                            subTaskAdapter.setList(showList);
                            subTaskAdapter.notifyDataSetChanged();
                        } else {
                            tvNoData.setVisibility(View.VISIBLE);
                            lvMytask.setVisibility(View.GONE);
                        }
                    } else {
                        if (noCompleteList != null && noCompleteList.size() > 0) {
                            tvNoData.setVisibility(View.GONE);
                            lvMytask.setVisibility(View.VISIBLE);
                            showList = noCompleteList;
                            subTaskAdapter.setList(showList);
                            subTaskAdapter.notifyDataSetChanged();
                        } else {
                            tvNoData.setVisibility(View.VISIBLE);
                            lvMytask.setVisibility(View.GONE);
                        }
                    }
                } else {
                    tvNoData.setVisibility(View.VISIBLE);
                    lvMytask.setVisibility(View.GONE);
                }
            }
        });
    }

    private void dealList(List<EmulationEntrance> schemeInfoList) {
        for (int i = 0; i < schemeInfoList.size(); i++) {
            if (schemeInfoList.get(i).isFinish) {
                completedList.add(schemeInfoList.get(i));
            } else {
                noCompleteList.add(schemeInfoList.get(i));
            }
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_mysub_task_list;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                this.finish();
                break;
            case R.id.tv_no_complete:
                setTextBg(tvNoComplete, true);
                setTextBg(tvCompleted, false);
                tvCompletedLine.setVisibility(View.GONE);
                tvNoCompleteLine.setVisibility(View.VISIBLE);

                isComplete = false;

                if (noCompleteList != null && noCompleteList.size() > 0) {
                    tvNoData.setVisibility(View.GONE);
                    lvMytask.setVisibility(View.VISIBLE);

                    showList = noCompleteList;

                    subTaskAdapter.setList(noCompleteList);
                    subTaskAdapter.notifyDataSetChanged();
                } else {
                    tvNoData.setVisibility(View.VISIBLE);
                    lvMytask.setVisibility(View.GONE);
                }

                break;
            case R.id.tv_completed:
                setTextBg(tvNoComplete, false);
                setTextBg(tvCompleted, true);
                tvCompletedLine.setVisibility(View.VISIBLE);
                tvNoCompleteLine.setVisibility(View.GONE);
                isComplete = true;

                if (completedList != null && completedList.size() > 0) {
                    tvNoData.setVisibility(View.GONE);
                    lvMytask.setVisibility(View.VISIBLE);

                    showList = completedList;

                    subTaskAdapter.setList(completedList);
                    subTaskAdapter.notifyDataSetChanged();
                } else {
                    tvNoData.setVisibility(View.VISIBLE);
                    lvMytask.setVisibility(View.GONE);
                }
                break;
            default:
                break;
        }
    }

    private void setTextBg(TextView textView, boolean isSelect) {
        if (isSelect) {
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setTextColor(Color.parseColor("#000000"));
        } else {
            textView.setTypeface(Typeface.DEFAULT);
            textView.setTextColor(Color.parseColor("#999999"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        queryTaskList();
    }

    /**
     * 进入仿真结果页面
     *
     * @param info
     */
    private void enterSimulationResult(EmulationEntrance info) {
        Intent intent = new Intent(this, SimulationResultActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("EmulationEntrance", info);
        intent.putExtras(bundle);
        startActivityForResult(intent, 0);
    }

    /**
     * 查询任务
     */
    private void queryStatus(String taskId) {
        createLoadingDialog(this, this, "", true);
        Thread thread = new Thread(new GetStatusRunnable(taskId));
        thread.start();
    }

    /**
     * 显示提示框
     */
    private void showTipPopupWindow(final int type) {
        View contextView = LayoutInflater.from(this).inflate(R.layout.tip_dialog, null);

        TextView textView = (TextView) contextView.findViewById(R.id.tv_dialog_title);
        TextView button = (TextView) contextView.findViewById(R.id.tv_btn);
        ImageView imageView = (ImageView) contextView.findViewById(R.id.iv_image);
        switch (type) {
            case SIMULATIONING:
                textView.setText(getResources().getString(R.string.tv_pop_simulation));
                imageView.setImageResource(R.drawable.bg_tip);
                break;
            case SIMULATION_FAIL:
                textView.setText(getResources().getString(R.string.tv_pop_simulation_fail));
                imageView.setImageResource(R.drawable.bg_fail);
                break;
            case QUERY_TASK_STATE_FAIL:
                textView.setText(getResources().getString(R.string.tv_pop_query_simulation_state_fail));
                imageView.setImageResource(R.drawable.bg_fail);
                break;
            case SIMULATION_DELETE:
                textView.setText(getResources().getString(R.string.tv_pop_simulation_delete));
                imageView.setImageResource(R.drawable.bg_tip);
                break;
            case SIMULATION_STOP:
                textView.setText(getResources().getString(R.string.tv_pop_simulation_stop));
                imageView.setImageResource(R.drawable.bg_tip);
                break;
            case GETPICNING:
                textView.setText(getResources().getString(R.string.tv_pop_simulation_getpic));
                imageView.setImageResource(R.drawable.bg_tip);
                break;
        }

        if (popupWindow != null) {
            popupWindow.dismiss();
        }

        popupWindow = new PopupWindow(contextView, android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.FILL_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        popupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        popupWindow.showAtLocation(contextView, Gravity.CENTER, 0, 0);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
    }

    /**
     * 更新仿真結果
     */
    private void update(SimulationReqInfo simulationReqInfo) {
        UpdateEmulationUtil.getInstance().asyncExecute(simulationReqInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                if (popupWindow != null) {
                    popupWindow.dismiss();
                }
                queryTaskList();
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
            }
        });
    }

    private class GetStatusRunnable implements Runnable {
        public GetStatusRunnable(String taskId) {
            currTaskId = taskId;
        }

        @Override
        public void run() {
            EmulationEntrance reqInfo = new EmulationEntrance();
            reqInfo.setProjectId(Constants.PROJECT_ID);
            reqInfo.setGroupId(currGroupId);
            reqInfo.setGroupName(currGroupName);
            reqInfo.setTaskId(currTaskId);
            reqInfo.setTaskName(currTaskName);
            QueryCPquerySurveystatusUtil.getInstance().asyncExecute(reqInfo, mHandler);
        }
    }
}
