package com.huawei.genexcloud.survey.util;

import com.huawei.genexcloud.survey.base.BaseApplication;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class TestUtil {

    public static String getAntennaData() {
        return getTestData("CPGetAntennaList");
    }
    public static String getFrequencyBandData() {
        return getTestData("CPGetFrequencyBandInfo");
    }
    public static String getGroupData() {
        return getTestData("CPGroupInfoList");
    }
    public static String getSiteData() {
        return getTestData("CPProjectParam");
    }
    public static String getSurveyStatusData() {
        return getTestData("CPQuerySurveyStatus");
    }
    public static String getPropagationModelData() {
        return getTestData("getPropagationModelList");
    }
    public static String getProjectIdData() {
        return getTestData("showProjectIDNameList");
    }


    public static String getTestData(String fileName) {
        try {
            InputStream is = BaseApplication.getAppContext().getAssets().open("cpdata/" + fileName + ".txt");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int length = 0;
            while( (length = is.read(buffer)) != -1) {
                baos.write(buffer, 0, length);
            }
            String result = new String(baos.toByteArray());
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
