package com.huawei.genexcloud.survey.fragment;

import static com.huawei.genexcloud.framework.util.EnvironmentInfo.getSdCardRootDirectory;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.common.DataPath;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.DataCleanManager;
import com.huawei.genexcloud.framework.util.EnvironmentInfo;
import com.huawei.genexcloud.framework.util.FileUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.activity.AboutActivity;
import com.huawei.genexcloud.survey.activity.BigImageShowActivity;
import com.huawei.genexcloud.survey.activity.LoginActivity;
import com.huawei.genexcloud.survey.activity.MySubTaskListActivity;
import com.huawei.genexcloud.survey.activity.NoticeActivity;
import com.huawei.genexcloud.survey.activity.ShowTwoDimensionCodeAcitvity;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.QueryMyEmulationGroupImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.util.ShareUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wWX553206 on 2019/10/15.
 */
public class MyFragment extends BaseFragment implements View.OnClickListener {

    private View rootView;

    private TextView tvAccount;

    private TextView tvLocation;

    private TextView tvTaskContent;

    private RelativeLayout rlMyTaskLay;

    private RelativeLayout rlMyCodeLay;

    private RelativeLayout rlCacheLay;

    private TextView tvCache;

    private RelativeLayout rlNoticeLay;

    private RelativeLayout rlAboutLay;

    private RelativeLayout rlGinsLay;

    private Dialog dialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_my_page_layout, null);
        }
        initView();
        initData();
        return rootView;
    }

    @Override
    public void initView() {
        tvAccount = (TextView) rootView.findViewById(R.id.tv_account);
        tvLocation = (TextView) rootView.findViewById(R.id.tv_current_location);

        tvTaskContent = (TextView) rootView.findViewById(R.id.tv_task_content);

        rootView.findViewById(R.id.btn_exit).setOnClickListener(this);

        rlMyTaskLay = (RelativeLayout) rootView.findViewById(R.id.rl_mytask);
        rlMyTaskLay.setOnClickListener(this);

        rlMyCodeLay = (RelativeLayout) rootView.findViewById(R.id.rl_erweima);
        rlMyCodeLay.setOnClickListener(this);

        rlCacheLay = (RelativeLayout) rootView.findViewById(R.id.rl_cache);
        rlCacheLay.setOnClickListener(this);
        tvCache = (TextView) rootView.findViewById(R.id.tv_cache);

        rlNoticeLay = (RelativeLayout) rootView.findViewById(R.id.rl_falv);
        rlNoticeLay.setOnClickListener(this);

        rlAboutLay = (RelativeLayout) rootView.findViewById(R.id.rl_about);
        rlAboutLay.setOnClickListener(this);

        rlGinsLay = (RelativeLayout) rootView.findViewById(R.id.rl_gins);
        rlGinsLay.setOnClickListener(this);

        rootView.findViewById(R.id.rl_zhidao).setOnClickListener(this);
    }

    @Override
    public void initData() {
        tvAccount.setText(ShareUtil.readString(Constants.LOGIN_USER_KEY, ""));
        tvLocation.setText(ShareUtil.readString(Constants.ADDRESS, ""));

        String sdDir = getSdCardRootDirectory();
        try {
            tvCache.setText(DataCleanManager.getTotalSDCardCacheSize(new File(sdDir)));
        } catch (Exception e) {
            GCLogger.error("MyFragment", "getTotalSDCardCacheSize Exception e= " + e.toString());
        }
    }

    @Override
    public void onShow() {
        super.onShow();

        try {
            tvCache
                    .setText(DataCleanManager.getTotalSDCardCacheSize(new File(EnvironmentInfo.getProductFileDirectory())));
        } catch (Exception e) {
            GCLogger.error("MyFragment", "getTotalSDCardCacheSize Exception e= " + e.toString());
        }

        queryaMyTaskList();
    }

    /**
     * 查询仿真任务列表
     */
    private void queryaMyTaskList() {
        QueryMyEmulationGroupImpl.getInstance().getMyEmulationGroup(new QueryMyEmulationGroupImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                if (null != e && !TextUtils.isEmpty(e.message)) {
                    showToast(e.message);
                }
            }

            @Override
            public void onResponse(List<EmulationEntrance> response) {
                closeLoadDialog();
                String account = ShareUtil.readString(Constants.LOGIN_USER_KEY, "");
                List<EmulationEntrance> finishList = DBManager.getInstance(BaseApplication.getAppContext())
                        .getSimulationTaskDB().queryFinishByAccount(account);
                List<EmulationEntrance> unFinishList = DBManager.getInstance(BaseApplication.getAppContext())
                        .getSimulationTaskDB().queryUnFinishByAccount(account);

                String txt = "已完成" + finishList.size() + "个/" + "未完成" + unFinishList.size() + "个";
                SpannableString msp = new SpannableString(txt);
                msp.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getActivity(), R.color.warning_hint)),
                        txt.indexOf("/") + 1, txt.length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
                tvTaskContent.setText(msp);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_exit:
                cleanStaticData();
                startActivity(new Intent(getActivity(), LoginActivity.class));
                getActivity().finish();
                break;
            case R.id.rl_mytask:
                startActivity(new Intent(getActivity(), MySubTaskListActivity.class));
                break;
            case R.id.rl_erweima:
                startActivity(new Intent(getActivity(), ShowTwoDimensionCodeAcitvity.class));
                break;
            case R.id.rl_cache:
                createDialog(getResources().getString(R.string.my_confirm_clear_app_cache));
                break;
            case R.id.rl_about:
                startActivity(new Intent(getActivity(), AboutActivity.class));
                break;
            case R.id.rl_falv:
                startActivity(new Intent(getActivity(), NoticeActivity.class));
                break;
            case R.id.rl_zhidao:
                Intent intent = new Intent();
                intent.setClass(getActivity(), BigImageShowActivity.class);
                List<Integer> imageList = new ArrayList<Integer>();
                imageList.add(R.drawable.icon_guide1);
                imageList.add(R.drawable.icon_guide2);
                imageList.add(R.drawable.icon_guide3);
                imageList.add(R.drawable.icon_guide4);
                imageList.add(R.drawable.icon_guide5);
                imageList.add(R.drawable.icon_guide6);
                imageList.add(R.drawable.icon_guide7);
                imageList.add(R.drawable.icon_guide8);
                imageList.add(R.drawable.icon_guide9);
                imageList.add(R.drawable.icon_guide10);
                intent.putIntegerArrayListExtra("imageList", (ArrayList<Integer>) imageList);
                intent.putExtra("type", 1);
                intent.putExtra("name", "使用指导");
                startActivity(intent);
                break;
            case R.id.rl_gins:
                writeAuthFile();
                String url = DataPath.GINS_DOWNLOAD_ADDRESS;
                boolean isSEApkInstall = AppUtil.isAPKInstalled(getActivity(), "com.huawei.gins");
                if (isSEApkInstall) {
                    AppUtil.openGins(BaseApplication.getAppContext());
                } else {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    getActivity().startActivity(intent);
                }
                break;
            default:
                break;
        }
    }

    /**
     * 创建确认取消框
     */
    private Dialog createDialog(String msg) {
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View parent = inflater.inflate(R.layout.my_setting_dialog_layout, null);// 得到加载view

        TextView tipTitle = (TextView) parent.findViewById(R.id.tip);

        Button button = (Button) parent.findViewById(R.id.btn_sure);

        Button cancel = (Button) parent.findViewById(R.id.btn_cancel);

        if (dialog == null) {
            dialog = new Dialog(getActivity(), R.style.Dialog_Fullscreen);
        }

        dialog.setCancelable(false);

        dialog.setContentView(parent);// 设置布局

        tipTitle.setText(msg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cleanCache();
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();

        return dialog;
    }

    private void cleanCache() {
        try {
            String crashLog = EnvironmentInfo.getProductFileDirectory() + DataPath.CRASH_LOG;
            FileUtil.deleteFiles(new File(crashLog));

            String simImg = EnvironmentInfo.getProductFileDirectory() + DataPath.DIR_SIM_IMG;
            FileUtil.deleteFiles(new File(simImg));

            String dirLog = EnvironmentInfo.getProductFileDirectory() + DataPath.DIR_LOG;
            FileUtil.deleteFiles(new File(dirLog));

            String template = EnvironmentInfo.getProductFileDirectory() + Constants.DIR_TEMPLATE;
            FileUtil.deleteFiles(new File(template));


            tvCache
                    .setText(DataCleanManager.getTotalSDCardCacheSize(new File(EnvironmentInfo.getProductFileDirectory())));

            DBManager manager = DBManager.getInstance(BaseApplication.getAppContext());
            manager.getSiteTemplateDB().deleteAll();
            manager.getSiteLocParamDB().deleteAll();
            manager.getAntennaDB().deleteAll();
            manager.getBandDB().deleteAll();
            manager.getCellInfoDBImpl().deleteAll();
            manager.getCellTemplateDB().deleteAll();
            manager.getSimulationTaskDB().deleteAll();
            manager.getSimulationParamDB().deleteAll();
            manager.getSiteParamDB().deleteAll();
            manager.getTempTaskInfoDB().deleteAll();
        } catch (Exception e) {
            GCLogger.error("MyFragment", "cleanCache Exception e= " + e.toString());
        }
    }

    private void writeAuthFile() {
        String path = EnvironmentInfo.getSDCardFilesDir() + "auth.txt";
        File file = new File(path);
        if (FileUtil.isFileExist(file)) {
            FileUtil.deleteFiles(file);
        }

        FileUtil.createFile(path);

        String sessionId = ShareUtil.readString(Constants.SESSION_ID, "");
        String phu_csrftoken = ShareUtil.readString(Constants.CSFToken, "");
        String content = sessionId + ";" + phu_csrftoken;
        FileUtil.writeFile(file, content);
    }
}
