package com.huawei.genexcloud.survey.fragment;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.CircleOptions;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.Polygon;
import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.map.Projection;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.navi.BaiduMapNavigation;
import com.baidu.mapapi.navi.NaviParaOption;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.utils.DistanceUtil;
import com.baidu.mapapi.utils.OpenClientUtil;
import com.baidu.mapapi.utils.SpatialRelationUtil;
import com.huawei.genexcloud.framework.bean.CellInfo;
import com.huawei.genexcloud.framework.bean.CellInfoBean;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.bean.Gps;
import com.huawei.genexcloud.framework.bean.ProjectInfo;
import com.huawei.genexcloud.framework.bean.SimulationParam;
import com.huawei.genexcloud.framework.bean.SimulationReqInfo;
import com.huawei.genexcloud.framework.bean.SiteInfo;
import com.huawei.genexcloud.framework.bean.SiteParam;
import com.huawei.genexcloud.framework.bean.StationResp;
import com.huawei.genexcloud.framework.bean.TaskInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.CreateEmulationUtil;
import com.huawei.genexcloud.framework.http.SendEmailUtil;
import com.huawei.genexcloud.framework.http.UpdateEmulationUtil;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.service.TaskService;
import com.huawei.genexcloud.framework.util.ActivityTackUtil;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.DensityUtil;
import com.huawei.genexcloud.framework.util.PositionUtils;
import com.huawei.genexcloud.framework.util.SiteUtils;
import com.huawei.genexcloud.framework.util.StringUtil;
import com.huawei.genexcloud.framework.util.TimeUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.activity.BigImageShowPortraitActivity;
import com.huawei.genexcloud.survey.activity.BuildguideActivity;
import com.huawei.genexcloud.survey.activity.LoginActivity;
import com.huawei.genexcloud.survey.activity.SelectSiteTemplateActivity;
import com.huawei.genexcloud.survey.activity.SiteSurveyInfoActivity;
import com.huawei.genexcloud.survey.activity.SubTaskListActivity;
import com.huawei.genexcloud.survey.adapter.GroupAdapter;
import com.huawei.genexcloud.survey.adapter.MulitipeAdapter;
import com.huawei.genexcloud.survey.adapter.ProjectAdapter;
import com.huawei.genexcloud.survey.adapter.SimpleAdapter;
import com.huawei.genexcloud.survey.adapter.SiteAdapter;
import com.huawei.genexcloud.survey.adapter.TaskAdapter;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.base.IBaseResultLinstener;
import com.huawei.genexcloud.survey.dialog.AddSitePopupWindow;
import com.huawei.genexcloud.survey.dialog.EditSurveySitePopupWindow;
import com.huawei.genexcloud.survey.dialog.SVAlertDialog;
import com.huawei.genexcloud.survey.dialog.StartSurveySitePopupWindow;
import com.huawei.genexcloud.survey.http.QueryCPAntennaListImpl;
import com.huawei.genexcloud.survey.http.QueryCPFrequencyBandImpl;
import com.huawei.genexcloud.survey.http.QueryCPProjectImpl;
import com.huawei.genexcloud.survey.http.QueryCPProjectParamImpl;
import com.huawei.genexcloud.survey.http.QueryGroupInfoImpl;
import com.huawei.genexcloud.survey.http.QueryCPPropagationModelImpl;
import com.huawei.genexcloud.survey.http.QuerySiteTemplateImpl;
import com.huawei.genexcloud.survey.http.QueryWorkParaSurveyedImpl;
import com.huawei.genexcloud.survey.http.SiteSurveyImpl;
import com.huawei.genexcloud.survey.http.UploadOrUpdateWordParamImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.interfaces.OnClickStart;
import com.huawei.genexcloud.survey.presenter.impl.SitePresenterImpl;
import com.huawei.genexcloud.survey.util.MapUtil;
import com.huawei.genexcloud.survey.util.ShareUtil;
import com.huawei.genexcloud.survey.views.DragView;
import com.huawei.genexcloud.survey.views.SimulationListView;
import com.huawei.genexcloud.survey.views.SiteListView;
import com.huawei.genexcloud.survey.views.SurveyFinishView;
import com.huawei.genexcloud.survey.views.SurveyStartView;
import com.huawei.genexcloud.survey.views.test.view.DragScaleView;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import okhttp3.Request;

/**
 * 勘测仿真页面
 */
@SuppressLint({"InflateParams", "HandlerLeak", "SimpleDateFormat"})
public class MainTabFragment extends BaseFragment
        implements View.OnClickListener, OnClickStart, DragView.onDrawListener {

    private static final float DEFAULT_ZOOM = 17.0f;
    private static final int DRAW_MARKER = 2;
    private final static int REQUESTCODE = 10000;

    private static final int SHOW_TASK = 10001;
    private static final int SIMULATIONING = 0; //仿真中
    private static final int SIMULATION_FAIL = 1; //仿真失败
    private static final int QUERY_TASK_STATE_FAIL = 2; //查询任务状态失败
    private static final int LOGIN_AGAIN = 3; //长时间未操作，重新登录
    private static final int LOGIN_NO_LIMIT = 4; //长时间未操作，重新登录


    /*************************/
    // 用于添加新勘测站点的popupwindow
    private AddSitePopupWindow addSitePopupWindow;
    // 点击勘测过的站点的marker后弹出的popupwindow
    private EditSurveySitePopupWindow surveySitePopupWindow;
    // 点击未勘测过的站点弹出的操作框
    private StartSurveySitePopupWindow startSurveyPopupWindow;
    /*************************/

    List<TaskInfo> groups = new ArrayList<>();
    private MapView mMapView;
    private BaiduMap mBaiduMap;
    private float zoom = 17.0f;
    private GeoCoder mSearch;
    private ArrayList<SiteParam> siteList;
    private HandlerThread handlerThread;
    private Handler myHandler;
    private RelativeLayout rlSurvey;
    private LinearLayout ll;
    private SurveyStartView surveyStartView;
    private SurveyFinishView surveyFinishView;
    private SimulationListView simulationListView;
    private SiteListView siteListView;
    private TextView mLocationTv;
    private boolean isFirstLoc = true;
    private MyLocationListener mMyLocationListener;

    private LocationClient locationClient;
    private LatLng myLocationLatLng;
    private Marker addMarker;
    private boolean isAddMoveMarker = false;

    private Button btnAddSite;
    private ListView lvGroupList;
    private TaskInfo currTaskInfo;
    private ListView lvSimple;
    private ListView lvMultipe;
    private MulitipeAdapter mulitipeAdapter;
    private SimpleAdapter simpleAdapter;
    private ListView lvProject;
    private ReceiveBroadCast mBroadcastReceiver;
    private SitePresenterImpl sitePresenter;
    private List<ProjectInfo> projectInfos;
    private Button btnloc;
    private ImageButton changeView;
    private int selProjectIndex = -1;
    /**
     * 地图绘制的站点
     */
    private List<SiteInfo> drawInfos = new ArrayList<>();

    private final Map<String, String> queryResultMap = new HashMap<>();

    private InfoWindow clickMarkerIndicator;

    private ImageButton ibtnSiteList;

    private boolean isSiteOpen = false;

    private SiteInfo currSiteInfo;

    private ScrollView scrollView;

    private String newStationAddress = "";

    private TextView tvLoadTip;

    private PopupWindow groupPopupWindow;

    private PopupWindow taskPopupWindow;

    private PopupWindow tipPopupWindow;

    private LinearLayout llSeaceh;
    private EditText edtSeaceh;
    private ListView lvSiteInfo;

    private SiteAdapter adapter;

    private List<SiteInfo> seacehList = new ArrayList<>();
    private TextView tvBg;
    private TextView tvGroupName;
    private TextView tvTaskCountList;
    private TextView tvTaskCount;
    private TextView tvParameter;
    private View rootView;
    private Context mContext;
    private DragScaleView mMapCrooView;
    private CheckBox checkRange;
    private String scenario = "BATCH";
    private PopupWindow popupWindow;
    private DragView mDragView;
    //多边形
    private Polygon polygon;
    private LatLng clickLatLng;
    private final Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.UPDATE_PARAM:
                    List<SiteParam> siteParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB()
                            .queryAllByTaskId(Constants.PROJECT_ID, groupId);
                    //站点信息发生改变
                    queryIsSurveySiteParams(siteParams, false);
                    sitePresenter.querySimulationList(Constants.PROJECT_ID, groupId, tvTaskCount);
                    break;
            }
        }
    };

    /**
     * 获取指定像素，相差纬度
     *
     * @return
     */
    private static double getBetweenLatByPix(BaiduMap mBaiduMap, int px) {
        Projection projection = mBaiduMap.getProjection();
        double result = 0;
        if (projection != null) {
            Point point = new Point(0, 0);
            LatLng latLng1 = projection.fromScreenLocation(point);
            Point point1 = new Point(0, px);
            LatLng latLng2 = projection.fromScreenLocation(point1);
            result = Math.abs(latLng1.latitude - latLng2.latitude);
        }

        return result;
    }

    /**
     * 获取指定距离，相差纬度
     *
     * @return
     */
    private static double getBetweenLatByMetre(LatLng point, int dis) {

        LatLng point1 = new LatLng(point.latitude + 1, point.longitude);
        //两点间距离
        double realDistance = DistanceUtil.getDistance(point, point1);

        double result = dis / realDistance;

        return result;
    }

    /**
     * 获取指定距离，相差纬度 经线上，变化 1纬度 的距离 L = 10000 / 90 ≈ 111.11 km 纬度为θ的纬线上，变化 1经度 的距离 L = R' / 360 ≈ 111.11 cosθ km
     *
     * @return
     */
    private static double getBetweenLngByMetre(LatLng point, int dis) {

        LatLng point1 = new LatLng(point.latitude, point.longitude + 1);
        //两点间距离
        double realDistance = DistanceUtil.getDistance(point, point1);

        double result = dis / realDistance;

        return result;
    }

    /**
     * 获取指定像素，相差经度
     *
     * @return
     */
    private static double getBetweenLngByPix(BaiduMap mBaiduMap, int px) {
        Projection projection = mBaiduMap.getProjection();
        double result = 0;
        if (projection != null) {
            Point point = new Point(0, 0);
            LatLng latLng1 = projection.fromScreenLocation(point);
            Point point1 = new Point(px, 0);
            LatLng latLng2 = projection.fromScreenLocation(point1);
            result = Math.abs(latLng2.longitude - latLng1.longitude);
        }
        return result;
    }

    /**
     * 获取工参相关模型
     * 包含：天线数据、传播模型数据、带宽功率信息
     */
    private void getSiteModelParams() {
        String projectId = Constants.PROJECT_ID;
        String taskId = ShareUtil.readString(Constants.TASK_ID, "");
        QueryCPAntennaListImpl.getInstance().getAntennaList(projectId, taskId);
        QueryCPPropagationModelImpl.getInstance().getPropagationModelData(projectId, taskId);
        QueryCPFrequencyBandImpl.getInstance().getFrequencyBand(projectId, taskId);
    }

    @Override
    public void onDrawEnd(int x, int y, int width, int height) {
        y = y - DensityUtil.dip2px(getActivity(), 100) - 1;

        int leftX = 0;
        int rightX = 0;

        int topY = 0;
        int bottomY = 0;

        if (zoom < 18) {
            leftX = x - DensityUtil.dip2px(getActivity(), 4.0f);
            rightX = x + DensityUtil.dip2px(getActivity(), 4.0f);
            topY = y - DensityUtil.dip2px(getActivity(), 4.0f);
            bottomY = y + DensityUtil.dip2px(getActivity(), 4.0f);
        } else if (zoom >= 18 && zoom < 19) {
            leftX = x - DensityUtil.dip2px(getActivity(), 3.5f);
            rightX = x + DensityUtil.dip2px(getActivity(), 4.0f);
            topY = y - DensityUtil.dip2px(getActivity(), 4.0f);
            bottomY = y + DensityUtil.dip2px(getActivity(), 3.5f);
        } else if (zoom >= 19 && zoom < 21) {
            leftX = x - DensityUtil.dip2px(getActivity(), 3.0f);
            rightX = x + DensityUtil.dip2px(getActivity(), 4.0f);
            topY = y - DensityUtil.dip2px(getActivity(), 4.0f);
            bottomY = y + DensityUtil.dip2px(getActivity(), 3.0f);
        }

        Point leftTopPoint = new Point(leftX, topY);
        LatLng leftTopLatLng = mBaiduMap.getProjection().fromScreenLocation(leftTopPoint);

        Point leftBottomPoint = new Point(leftX, bottomY + height);
        LatLng leftBottomLatLng = mBaiduMap.getProjection().fromScreenLocation(leftBottomPoint);

        Point rightTopPoint = new Point(rightX + width, topY);
        LatLng rightTopLatLng = mBaiduMap.getProjection().fromScreenLocation(rightTopPoint);

        Point rightBottomPoint = new Point(rightX + width, bottomY + height);
        LatLng rightBottomLatLng = mBaiduMap.getProjection().fromScreenLocation(rightBottomPoint);


        List<LatLng> pts = new ArrayList<>();
        pts.add(leftTopLatLng);
        pts.add(rightTopLatLng);
        pts.add(rightBottomLatLng);
        pts.add(leftBottomLatLng);

        checkSiteInRect(pts, leftTopLatLng.latitude, rightBottomLatLng.latitude, leftTopLatLng.longitude,
                rightBottomLatLng.longitude);
    }

    //计算区域内站点个数
    private void checkSiteInRect(List<LatLng> mPoints, double topLat, double bottomLat, double leftLng, double rightLng) {

        List<SiteInfo> inSites = new ArrayList<>();
        if (drawInfos != null && drawInfos.size() > 0) {
            for (int i = 0; i < drawInfos.size(); i++) {
                LatLng showPostion = PositionUtils.gps_84_To_bd09(drawInfos.get(i).getLat(), drawInfos.get(i).getLng());
                if (SpatialRelationUtil.isPolygonContainsPoint(mPoints, showPostion)) {
                    inSites.add(drawInfos.get(i));
                }
            }
        }

        List<SiteParam> allSiteParams = new ArrayList<>();
        if (inSites != null && inSites.size() > 0) {
            for (int i = 0; i < inSites.size(); i++) {
                SiteInfo info = inSites.get(i);
                List<SiteParam> siteParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                        .queryAllBySiteId(Constants.PROJECT_ID, groupId, info.getNodebId() + "");

                if (siteParams != null && siteParams.size() > 0) {
                    allSiteParams.addAll(siteParams);
                }
            }
            showSimulationPopupWindow(inSites.size(), getPolygon(topLat, bottomLat, leftLng, rightLng), allSiteParams);
        } else {
            showToast("请保证选择框内至少有一个站点");
        }
    }

    /**
     * 判断在区域内的站点
     */
    private void checkSiteInRect1(double topLat, double bottomLat, double leftLng, double rightLng) {
        List<SiteInfo> inSites = new ArrayList<>();
        if (drawInfos != null && drawInfos.size() > 0) {
            for (int i = 0; i < drawInfos.size(); i++) {
                LatLng showPostion = PositionUtils.gps_84_To_bd09(drawInfos.get(i).getLat(), drawInfos.get(i).getLng());
                double currLat = showPostion.latitude;
                double currLng = showPostion.longitude;
                if (bottomLat < currLat && currLat < topLat && currLng > leftLng && currLng < rightLng) {
                    inSites.add(drawInfos.get(i));
                }
            }
        }
    }

    /**
     * 获取勘测范围
     *
     * @param topLat
     * @param bottomLat
     * @param leftLng
     * @param rightLng
     * @return
     */
    private String getPolygon(double topLat, double bottomLat, double leftLng, double rightLng) {
        /**
         * "leftuplon":"100.454648", "leftuplat":"14.162227", "rightuplon":"100.619825", "rightuplat":"14.000858",
         * "rightdownlon":"", "rightdownlat":"", "leftdownlon":"", "leftdownlat":""
         */


        Gps leftTopGps = PositionUtils.bd09_To_Gps84(topLat, leftLng);
        Gps rightBottomGps = PositionUtils.bd09_To_Gps84(bottomLat, rightLng);

        double topLatGps = leftTopGps.getWgLat();
        double bottomLatGps = rightBottomGps.getWgLat();
        double leftLngGps = leftTopGps.getWgLon();
        double rightLngGps = rightBottomGps.getWgLon();

        JSONObject jsonObject = new JSONObject();
        try {
            //左上
            jsonObject.put("leftuplon", leftLngGps);
            jsonObject.put("leftuplat", topLatGps);

            //右上
            jsonObject.put("rightuplon", rightLngGps);
            jsonObject.put("rightuplat", topLatGps);

            //右下
            jsonObject.put("rightdownlon", rightLngGps);
            jsonObject.put("rightdownlat", bottomLatGps);

            //左下
            jsonObject.put("leftdownlon", leftLngGps);
            jsonObject.put("leftdownlat", bottomLatGps);
        } catch (JSONException e) {
            GCLogger.error("error", e.toString());
        }
        return jsonObject.toString();
    }

    @Override
    public void initView() {
        tvLoadTip = (TextView) rootView.findViewById(R.id.tv_load_tip);

        mMapView = (MapView) rootView.findViewById(R.id.bmapview);
        MapView.setMapCustomEnable(true);

        mLocationTv = (TextView) rootView.findViewById(R.id.location_tv);
        tvTaskCountList = (TextView) rootView.findViewById(R.id.tv_task_list);
        tvTaskCountList.setOnClickListener(this);
        tvTaskCount = (TextView) rootView.findViewById(R.id.tv_task_count);

        tvParameter = (TextView) rootView.findViewById(R.id.tv_parameter);
        tvParameter.setOnClickListener(this);

        rlSurvey = (RelativeLayout) rootView.findViewById(R.id.rl_container_survey);
        tvBg = (TextView) rootView.findViewById(R.id.tv_bg);
        rootView.findViewById(R.id.simulation_test_list).setOnClickListener(this);
        ll = (LinearLayout) rootView.findViewById(R.id.title_layout);
        surveyStartView = new SurveyStartView(mContext);
        mMapCrooView = (DragScaleView) rootView.findViewById(R.id.map_crpo_view);
        mDragView = (DragView) rootView.findViewById(R.id.dragview);
        mDragView.setOnDrawListener(this);

        checkRange = (CheckBox) rootView.findViewById(R.id.btn_simulation_range);
        checkRange.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (TextUtils.isEmpty(groupId) || drawInfos == null || drawInfos.size() == 0) {
                    checkRange.setChecked(false);
                    return;
                }
                if (isChecked) {

                    mDragView.setVisibility(View.VISIBLE);
                    int width = getActivity().getWindowManager().getDefaultDisplay().getWidth();
                    int height = getActivity().getWindowManager().getDefaultDisplay().getHeight()
                            - DensityUtil.dip2px(getActivity(), 130);
                    mDragView.addDragView(R.layout.my_self_view, (width / 2) - DensityUtil.dip2px(getActivity(), 80),
                            (height / 2) - DensityUtil.dip2px(getActivity(), 80),
                            (width / 2) + DensityUtil.dip2px(getActivity(), 80),
                            (height / 2) + DensityUtil.dip2px(getActivity(), 80), false, false);
                } else {
                    mDragView.removeAllViews();
                    mDragView.setVisibility(View.GONE);
                }
            }
        });
        surveyFinishView = new SurveyFinishView(mContext);
        mLocationTv.setOnClickListener(this);

        siteListView = new SiteListView(mContext);
        siteListView.setOnClickStart(this);

        simulationListView = new SimulationListView(mContext);
        simulationListView.setOnClickStart(this);

        tvGroupName = (TextView) rootView.findViewById(R.id.tv_group_name);
        tvGroupName.setOnClickListener(this);

        scrollView = (ScrollView) rootView.findViewById(R.id.scrollView);

        btnAddSite = (Button) rootView.findViewById(R.id.btn_add_site);
        btnAddSite.setOnClickListener(this);

        btnloc = (Button) rootView.findViewById(R.id.btn_loc);
        btnloc.setOnClickListener(this);

        changeView = (ImageButton) rootView.findViewById(R.id.change_view_type);
        changeView.setOnClickListener(this);

        ibtnSiteList = (ImageButton) rootView.findViewById(R.id.ibtn_site_list);
        ibtnSiteList.setOnClickListener(this);

        llSeaceh = (LinearLayout) rootView.findViewById(R.id.ll_seaceh);
        rootView.findViewById(R.id.btn_seaceh).setOnClickListener(this);

        edtSeaceh = (EditText) rootView.findViewById(R.id.edt_seaceh);

        edtSeaceh.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                queryDBdata(edtSeaceh.getText().toString().trim());
            }
        });

        lvSiteInfo = (ListView) rootView.findViewById(R.id.lv_site);
        adapter = new SiteAdapter(getActivity());
        lvSiteInfo.setAdapter(adapter);

        lvSiteInfo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (seacehList != null && seacehList.size() > 0) {
                    SiteInfo info = seacehList.get(position);
                    clickSite(info);

                    llSeaceh.setVisibility(View.GONE);
                    edtSeaceh.setText("");
                    seacehList.clear();
                    adapter.notifyDataSetChanged();
                    hideInputWindow(edtSeaceh);
                }
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Override
    public void initData() {
        sitePresenter = new SitePresenterImpl();
        mBroadcastReceiver = new ReceiveBroadCast();
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction(Constants.STATUS_CHANGE);
        myIntentFilter.addAction(Constants.ADD_SITE);
        myIntentFilter.addAction(Constants.UPDATE_SITE);
        myIntentFilter.addAction(Constants.CANCEL_SIMULATION);
        myIntentFilter.addAction(Constants.EXPIRE_COOKIE);
        myIntentFilter.addAction(Constants.NO_LIMIT);
        // 注册广播
        mContext.registerReceiver(mBroadcastReceiver, myIntentFilter, Constants.PERMISSION_BROADCAST, null);

        initHandler();
        initBaiduMap();

        mBaiduMap.setMyLocationEnabled(true);
        if (!locationClient.isStarted()) {
            locationClient.registerLocationListener(mMyLocationListener);
            locationClient.start();
        }

        surveyStartView.setOnClickStart(this);
        surveyFinishView.setOnClickStart(this);

        queryProject();
    }

    /**
     * 查询数据库数据，展示
     */
    public void queryDBdata(String key) {
        if (TextUtils.isEmpty(key)) {
            seacehList.clear();
        } else {
            List<SiteParam> siteParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                    .queryByKey(Constants.PROJECT_ID, groupId, key);

            if (siteParams != null && siteParams.size() > 0) {
                seacehList = sitePresenter.transformSiteInfos(Constants.PROJECT_ID, groupId, siteParams);
            }
        }
        adapter.setSiteParams(seacehList);
        adapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_main_page_layout, null);
        }
        initView();
        initData();
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (!TextUtils.isEmpty(groupId) && !TextUtils.isEmpty(Constants.PROJECT_ID) && tvTaskCount != null) {
            //查询仿真任务数量
            sitePresenter.querySimulationList(Constants.PROJECT_ID, groupId, tvTaskCount);
        }

    }

    /**
     * 查询到用户项目信息后，根据上次存储的项目id(无存储则默认选择第一个)
     * 查询分组任务
     */
    private void queryGroups() {
        if (groups != null) {
            groups.clear();
        }
        //切换项目任务，隐藏任务数
        tvTaskCount.setVisibility(View.GONE);
        selectedGroupId = "";
        cleanStaticData();
        showGroupTitle("");
        showParameterTitle("");
        if (lvGroupList != null) {
            lvGroupList.setVisibility(View.VISIBLE);
        }
        checkRange.setChecked(false);
        hideInfoWindow();

        if (taskPopupWindow != null) {
            taskPopupWindow.dismiss();
        }

        createLoadingDialog(this.getActivity(), mContext, "", true);

        QueryGroupInfoImpl.getInstance().getGroupInfoList(Constants.PROJECT_ID, new QueryGroupInfoImpl.GroupListCallback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                if (null != e && !TextUtils.isEmpty(e.message)) {
                    showCommonPop("获取任务分组信息失败:" + e.message, R.drawable.bg_fail);
                } else {
                    showCommonPop("获取任务分组信息失败, 请稍后再试！", R.drawable.bg_fail);
                }
            }

            @Override
            public void onResponse(List<TaskInfo> response) {
                // 查询分组信息成功
                closeLoadDialog();

                // 这里查询按照groupid分组后的taskinfo
                groups = DBManager.getInstance(BaseApplication.getAppContext()).getGroupInfoDB()
                        .queryAllByProject(Constants.PROJECT_ID);
                if (null != groups && !groups.isEmpty() && null != response && !response.isEmpty()) {
                    // 每组任务都只取一个，查看respone中是否包含上次打开的任务
                    String groupId = ShareUtil.readString(Constants.LAST_SELECTED_GROUP_ID, "");
                    String taskId = ShareUtil.readString(Constants.LAST_SELECTED_TASK_ID, "");
                    if (!TextUtils.isEmpty(groupId) && !TextUtils.isEmpty(taskId) && null != response && !response.isEmpty()) {
                        // 便利response查看其中是否有上次打开的任务
                        for (TaskInfo item : response) {
                            if (groupId.equals(item.groupId) && taskId.equals(item.getTaskId())) {
                                // 项目中包含上次打开的任务，则将任务加入groups并取消groups中对应groupid下的task
                                Iterator<TaskInfo> iterator = groups.iterator();
                                boolean removed = false;
                                while (iterator.hasNext()) {
                                    TaskInfo next = iterator.next();
                                    if (groupId.equals(next.groupId)) {
                                        iterator.remove();
                                        removed = true;
                                    }
                                }
                                if (removed) {
                                    groups.add(item);
                                }
                                break;
                            }
                        }
                    }
                }
//                groups = response;
                if (groups != null && groups.size() > 0) {
                    showGroupPopupWindow();
                } else {
                    showCommonPop("该项目没有任务分组信息，请选择其他项目", R.drawable.bg_tip);
                }
            }
        });
    }

    /**
     * 查询工参
     */
    private void queryWorkerParameter(TaskInfo taskInfo) {
        cleanMap();
        if (drawInfos != null) {
            drawInfos.clear();
        }
        getWorkerParameter(taskInfo);
    }

    /**
     *  查询用户项目id
     */
    private void queryProject() {
        showLoadingDialog(getContext());
        QueryCPProjectImpl.getInstance().getUserProjects(new QueryCPProjectImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                showCommonPop("查询项目信息失败", R.drawable.bg_fail);
            }

            @Override
            public void onResponse(List<ProjectInfo> response) {
                closeLoadDialog();
                projectInfos = response;
                String projectId = "";
                String saveProjectId = ShareUtil.readString("projectId", "");
                String projectName = "";
                String saveProjectName = ShareUtil.readString("projectName", "");
                //有历史记录
                if (!TextUtils.isEmpty(saveProjectId) && !TextUtils.isEmpty(saveProjectName)) {
                    projectId = saveProjectId;
                    projectName = saveProjectName;
                } else {
                    //没有历史记录，默认第一个项目
                    if (projectInfos != null && projectInfos.size() > 0) {
                        projectId = projectInfos.get(0).getProjectId();
                        projectName = projectInfos.get(0).getProjectName();
                    }
                }
                Constants.PROJECT_ID = projectId;
                saveStaticData("projectId", Constants.PROJECT_ID);
                saveStaticData("projectName", projectName);
                mLocationTv.setText(projectName);

                queryGroups();
            }
        });
    }

    private boolean needMoveToPoint = true;
    private boolean isMultiPointMode = false;

    private void initHandler() {
        handlerThread = new HandlerThread("backgroundThread");
        handlerThread.start();
        myHandler = new Handler(handlerThread.getLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // 绘制站点
                if (msg.what == DRAW_MARKER) {
                    float zoom = mBaiduMap.getMapStatus().zoom;

                    List<SiteParam> siteParamList = (List<SiteParam>) msg.obj;

                    if (null != siteParamList && siteParamList.size() > 0) {
                        if (needMoveToPoint) {
                            try {
                                LatLng firstLocation = PositionUtils.gps_84_To_bd09(Double.parseDouble(siteParamList.get(0).getSiteLat()),
                                        Double.parseDouble(siteParamList.get(0).getSiteLng()));
                                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(firstLocation));
                                needMoveToPoint = false;
                            } catch (Exception e) {
                                GCLogger.error("error", e.toString());
                            }
                        }
                    }
                    if (zoom >= 16) {
                        List<SiteParam> temSiteParam = SiteUtils.filterSiteParamToRect(siteParamList, mBaiduMap.getMapStatus().bound.southwest, mBaiduMap.getMapStatus().bound.northeast);
                        drawInfos = sitePresenter.transformSiteInfos(Constants.PROJECT_ID, groupId,
                                temSiteParam);
                    } else {
                        currSiteInfo = null;
                        drawInfos = sitePresenter.transformSiteInfos(Constants.PROJECT_ID, groupId,
                                siteParamList);
                    }
                    if (mBaiduMap != null) {
                        try {
                            mBaiduMap.clear();
                        } catch (Exception e) {
                            GCLogger.error("MainTabFragment", "mBaiduMap.clear() Exception=" + e.toString());
                        }
                    }

                    if (drawInfos == null || drawInfos.size() == 0) {
                        return;
                    }


//                    if (currSiteInfo != null) {
//                        for (int i = 0; i < drawInfos.size(); i++) {
//                            if (currSiteInfo.getNodebId() == drawInfos.get(i).getNodebId()) {
//                                currSiteInfo = drawInfos.get(i);
//                            }
//                        }
//                        mHandler.sendEmptyMessage(SHOW_SURVEY);
//                    }
                    if (currSiteInfo != null && clickMarkerIndicator != null) {
                        mBaiduMap.showInfoWindow(clickMarkerIndicator);
                    }
                    //12649049
                    try {
                        if (zoom < 16) {
                            List<OverlayOptions> options = SiteUtils.getMultiSiteOption(drawInfos);
                            mBaiduMap.addOverlays(options);
                        } else {
                            long startT = System.currentTimeMillis();
                            for (SiteInfo infomsg : drawInfos) {
                                if (mBaiduMap == null) {
                                    return;
                                }
                                OverlayOptions options = null;
                                if (zoom > 16.8) {
                                    options = SiteUtils.getIncSiteMarkerOption(MainTabFragment.this.getActivity(), mBaiduMap, infomsg, true);
                                } else {
                                    options = SiteUtils.getIncSiteMarkerOption(MainTabFragment.this.getActivity(), mBaiduMap, infomsg, false);
                                }

                                // 在发送绘制消息前会判断地图缩放级别和清除当前地图内容
                                Marker marker = (Marker) mBaiduMap.addOverlay(options);

                                Bundle bundle = new Bundle();
                                bundle.putSerializable("info", infomsg);
                                marker.setExtraInfo(bundle);
                            }
                            GCLogger.error("view", "添加范围内点用时：" + (System.currentTimeMillis() - startT) + " ms  总点数量：" + drawInfos.size());
                        }
                    } catch (Exception e) {
                        GCLogger.error("MainTabFragment", "for drawInfos  Exception=" + e.toString());
                    }
                }
            }
        };
    }

    /**
     * 初始化百度地图(UI层)
     */
    private void initBaiduMap() {
        mBaiduMap = mMapView.getMap();
        MapUtil.initBaiduMap(mMapView, null, new BaiduMap.OnMapStatusChangeListener() {
            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus) {
            }

            @Override
            public void onMapStatusChangeStart(MapStatus mapStatus, int i) {
            }

            @Override
            public void onMapStatusChange(MapStatus mapStatus) {
                // 如果是添加勘测站点模式,则在移动中,位置标记跟随屏幕变化
                if (isAddMoveMarker && null != addMarker) {
                    addMarker.setPosition(mapStatus.target);
                }
            }

            @Override
            public void onMapStatusChangeFinish(MapStatus mapStatus) {
                zoom = mapStatus.zoom;
                GCLogger.error("test", "mapStatus.zoom = " + zoom);
                if (isAddMoveMarker) {
                    // 如果正在添加站点状态
                    if (addMarker != null) {
                        addMarker.setPosition(mapStatus.target);
                    }
                    if (null != addSitePopupWindow && addSitePopupWindow.isShowing()) {
                        addSitePopupWindow.updateLocation(mapStatus.target);
                    } else {
                        isAddMoveMarker = false;
                    }
                } else {
                    if (null != siteList) {
                        Message message = myHandler.obtainMessage();
                        //此处对msg进行赋值，可以创建一个Bundle进行承载
                        message.what = DRAW_MARKER;
                        message.obj = siteList;
                        myHandler.removeCallbacksAndMessages(null);
                        message.sendToTarget();
                    }
                }
            }
        }, new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                checkRange.setChecked(false);
                hideInfoWindow();
            }

            @Override
            public void onMapPoiClick(MapPoi mapPoi) {

            }
        }, new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                hideInfoWindow();
                lastClickedMarker = marker;
                showSurveyView(marker);
                return true;
            }
        });

        mSearch = GeoCoder.newInstance();

        mSearch.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {

            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
                if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
                    return;
                }
                newStationAddress = result.getAddress();
            }

            @Override
            public void onGetGeoCodeResult(GeoCodeResult result) {

            }
        });

        locationClient = MapUtil.createLocationClient(getContext());
        mMyLocationListener = new MyLocationListener();
    }

    // 记录上次点击的marker
    private Marker lastClickedMarker = null;

    @Override
    public void hideInfoWindow() {
        rlSurvey.setVisibility(View.GONE);
        currSiteInfo = null;
        tvBg.setVisibility(View.GONE);
        mBaiduMap.hideInfoWindow();
        if (null != lastClickedMarker) {
            lastClickedMarker.hideInfoWindow();
            lastClickedMarker = null;
        }
        if (addMarker != null) {
            addMarker.remove();
            isAddMoveMarker = false;
            addMarker = null;
        }
        // 如果正在显示添加站点的popupwindow 那么隐藏它
        if (null != addSitePopupWindow && addSitePopupWindow.isShowing()) {
            addSitePopupWindow.dismiss();
            addSitePopupWindow = null;
        }
        if (null != clickMarkerIndicator) {
            mBaiduMap.hideInfoWindow(clickMarkerIndicator);
        }
        // 如果正在显示 点击已勘测站点的弹窗  那么隐藏它
        if (null != surveySitePopupWindow && surveySitePopupWindow.isShowing()) {
            surveySitePopupWindow.dismiss();
            surveySitePopupWindow = null;
        }
        // 如果正在显示 点击未勘测站点的操作popupwindow 那么隐藏它
        if (null != startSurveyPopupWindow && startSurveyPopupWindow.isShowing()) {
            startSurveyPopupWindow.dismiss();
            startSurveyPopupWindow = null;
        }
        GCLogger.error("view", "触发了hideInfoWindow()");
    }

    /**
     * 显示勘测布局
     *
     * @param marker
     */
    private void showSurveyView(Marker marker) {
        GCLogger.error("view", "触发了showSurveyView()");
        // 图钉图标
        LinearLayout viewCache = (LinearLayout) View.inflate(getActivity(),
                R.layout.marker_clice_pop, null);
        int width = DensityUtil.getPixByWidthPercent(getActivity(), .08f);
        viewCache.getChildAt(0).setLayoutParams(new LinearLayout.LayoutParams(width, width * 3 / 2));

        //隐藏框选区域
        checkRange.setChecked(false);
        // 显示信息
        if (marker != null && !isAddMoveMarker) {
            final LatLng ll = marker.getPosition();
            BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(viewCache);
            clickMarkerIndicator = new InfoWindow(cacheDescriptor, ll, 0, null);

            if (marker.getExtraInfo() != null && marker.isVisible()) {
                mBaiduMap.showInfoWindow(clickMarkerIndicator);
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(ll));

                if (!TextUtils.isEmpty(groupId)) {
                    rlSurvey.setVisibility(View.VISIBLE);
                    SiteInfo info = (SiteInfo) marker.getExtraInfo().get("info");

                    currSiteInfo = info;

                    int num = info.getIsSurvey();
                    if (0 == num) { // 未勘测过
                        showStartSurveySitePopupWindow(info);
                    } else { // 已勘测过
                        clickLatLng = ll;
                        showSurveyedSitePopup(info);
                    }
                }
            }
        }
    }


    /**
     * 展示未勘测站点的操作popupwindow
     * 在点击marker和搜索站点时会使用到
     *
     * @param siteInfo
     */
    private void showStartSurveySitePopupWindow(SiteInfo siteInfo) {
        if (null == siteInfo) {
            return;
        }
        if (null != startSurveyPopupWindow && startSurveyPopupWindow.isShowing()) {
            startSurveyPopupWindow.dismiss();
            startSurveyPopupWindow = null;
        }
        startSurveyPopupWindow = new StartSurveySitePopupWindow(getContext(), siteInfo);
        startSurveyPopupWindow.setStartSurveyPopupListener(new StartSurveySitePopupWindow.StartSurveyPopupListener() {
            @Override
            public void onNaviClicked(LatLng latLng) {
                navi(latLng);
            }
        });
        startSurveyPopupWindow.show(getView());
    }

    /**
     * 展示已勘测站点的操作popupwindow
     * 在点击marker和搜索站点时会使用到
     *
     * @param siteInfo
     */
    private void showSurveyedSitePopup(SiteInfo siteInfo) {
        if (null == siteInfo) {
            return;
        }

        if (null != surveySitePopupWindow && surveySitePopupWindow.isShowing()) {
            surveySitePopupWindow.dismiss();
            surveySitePopupWindow = null;
        }
        surveySitePopupWindow = new EditSurveySitePopupWindow(getContext(), Constants.PROJECT_ID, groupId, siteInfo);
        surveySitePopupWindow.setEditListener(new EditSurveySitePopupWindow.EditSurveySiteListener() {
            @Override
            public void onNaviClicked(LatLng target) {
                navi(target);
            }

            @Override
            public void onSiteEditClicked(SiteInfo site) {
                Intent intent = new Intent();
                intent.setClass(mContext, SiteSurveyInfoActivity.class);
                intent.putExtra("location", myLocationLatLng);
                intent.putExtra("IndoorId", site.getIndoorId());
                intent.putExtra("FLAG", 1);
                intent.putExtra("siteInfo", site);
                intent.putExtra("source", "");
                startActivity(intent);
            }

            @Override
            public void onSurveyClicked(int flag, SiteInfo siteInfo) {
                startSurvey(siteInfo.getIndoorId(), flag, siteInfo);
            }
        });
        surveySitePopupWindow.show(getView());
    }

    @Override
    public void onStop() {
        locationClient.unRegisterLocationListener(mMyLocationListener);
        locationClient.stop();
        super.onStop();
    }

    /**
     * 添加可移动Marker
     * 用于新增勘测站点
     *
     * @param latLng 经纬度
     */
    private void addMoveMarker(LatLng latLng) {
        if (TextUtils.isEmpty(groupId)) {
            return;
        }

        if (!isAddMoveMarker) {

            //定义Maker坐标点
            LatLng point = latLng;
            //构建Marker图标
            BitmapDescriptor bitmap = BitmapDescriptorFactory.fromView(
                    MainTabFragment.this.getActivity().getLayoutInflater().inflate(R.layout.marker_move_pop, null));
            //构建MarkerOption，用于在地图上添加Marker
            OverlayOptions options = new MarkerOptions().position(point) //设置marker的位置
                    .icon(bitmap); //设置marker图标
            //在地图上添加Marker，并显示
            addMarker = (Marker) (mBaiduMap.addOverlay(options));

            if (null == addSitePopupWindow) {
                addSitePopupWindow = new AddSitePopupWindow(getContext(), Constants.PROJECT_ID, groupId);
            } else {
                addSitePopupWindow.updateProjectAndGroup(Constants.PROJECT_ID, groupId);
            }
            addSitePopupWindow.setListener(new AddSitePopupWindow.AddSiteListener() {
                @Override
                public void onSiteAdded(SiteInfo site) {
                    Intent intent = new Intent();
                    intent.setClass(mContext, SiteSurveyInfoActivity.class);
                    intent.putExtra("location", myLocationLatLng);
                    intent.putExtra("IndoorId", site);
                    intent.putExtra("FLAG", 0);
                    intent.putExtra("siteInfo", site);
                    intent.putExtra("source", "");
                    startActivity(intent);

                    Intent intent1 = new Intent(Constants.ADD_SITE);
                    intent1.setPackage(Constants.PACKAGE_NAME);
                    intent1.putExtra("data", site);
                    BaseApplication.getAppContext().sendBroadcast(intent1, Constants.PERMISSION_BROADCAST);
                }

                @Override
                public void onTemplateButtonClicked() {
                    selectTemplate();
                }

                @Override
                public void onGuideClicked() {
                    startActivity(new Intent(mContext, BuildguideActivity.class));
                }
            });

            addSitePopupWindow.updateLocation(mBaiduMap.getMapStatus().target);
            if (!addSitePopupWindow.isShowing()) {
                addSitePopupWindow.show(getView());
            }

            isAddMoveMarker = true;
        }
    }

    private void insertParameter(List<SiteParam> beans) {
        String projectId = Constants.PROJECT_ID;
        String groupId = ShareUtil.readString(Constants.GROUP_ID, "");
        UploadOrUpdateWordParamImpl.getInstance().uploadOrUpdateVoidResult(projectId, groupId,
                UploadOrUpdateWordParamImpl.TYPE_UPLOAD_TO_WORK_PARAM, beans);
        UploadOrUpdateWordParamImpl.getInstance().uploadOrUpdateVoidResult(projectId, groupId,
                UploadOrUpdateWordParamImpl.TYPE_UPLOAD_TO_GC_WORK_PARAM, beans);
    }

    /**
     * 查询已勘测站点工参
     */
    private void queryIsSurveySiteParams(final List<SiteParam> siteParams, final boolean isInsertParameter) {
        final String projectId = Constants.PROJECT_ID;
        // TODO 这里查询后台已勘测站点是taskid还是groupid
        QueryWorkParaSurveyedImpl.getInstance().getSurveySite(projectId, groupId, new QueryWorkParaSurveyedImpl.SiteParamCallback() {
            @Override
            public void onBefore(Request request) {
                createLoadingDialog(MainTabFragment.this.getActivity(), mContext, "获取已勘测站点数据中...", true);
            }

            @Override
            public String getProjectId() {
                return projectId;
            }

            @Override
            public String getGroupId() {
                return groupId;
            }

            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                siteList = (ArrayList<SiteParam>) siteParams;
                Message message = myHandler.obtainMessage();
                //此处对msg进行赋值，可以创建一个Bundle进行承载
                message.what = DRAW_MARKER;
                message.obj = siteList;
                message.sendToTarget();
            }

            @Override
            public void onResponse(List<SiteParam> response) {
                GCLogger.debug("Test  查询已勘测站点完成，开始对比已勘测站点");
                List<SiteParam> surveyParams = response;
                closeLoadDialog();
                createLoadingDialog(MainTabFragment.this.getActivity(), mContext, "合并站点数据中...", true);
                BaseApplication.getSingleThreadExecutor().execute(new CombineSiteRunnable(siteParams, surveyParams));

                if (isInsertParameter) {
                    GCLogger.debug("Test  平台工参插入后台数据");
                    //将平台工参插入后台数据库
                    insertParameter(siteParams);
                    GCLogger.debug("Test  平台工参插入后台数据完成");
                }
            }

        });
    }

    private class CombineSiteRunnable implements Runnable {

        private List<SiteParam> siteFromGCPT, siteSurveyed;

        public CombineSiteRunnable(List<SiteParam> siteFromGCPT, List<SiteParam> siteSurveyed) {
            // 防止出现线程问题
            this.siteFromGCPT = new ArrayList<>();
            this.siteSurveyed = new ArrayList<>();
            if (null != siteFromGCPT) {
                this.siteFromGCPT.addAll(siteFromGCPT);
            }
            if (null != siteSurveyed) {
                this.siteSurveyed.addAll(siteSurveyed);
            }
        }

        @Override
        public void run() {
            long startT = System.currentTimeMillis();
            // 将所有站点信息和已勘测站点信息、本地存储站点信息进行去重组合
            // TODO 这里数据库中查询数据是taskid还是groupid
            List<SiteParam> result = (ArrayList<SiteParam>) sitePresenter.getShowParams(Constants.PROJECT_ID, groupId,
                    siteSurveyed, siteFromGCPT);
            GCLogger.error("view", "合并平台工参点，本地和后台勘测点用时：" + (System.currentTimeMillis() - startT)
                    + " ms  总点数量 平台点  ：" + (siteFromGCPT == null ? 0 : siteFromGCPT.size()) + " 后台勘测点  "
                    + (siteSurveyed == null ? 0 : siteSurveyed.size()));
            GCLogger.error("view", "合并后数量:" + (null == result ? 0 : result.size()));

            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    closeLoadDialog();
                    siteList = (ArrayList<SiteParam>) result;
                    Message message = myHandler.obtainMessage();
                    //此处对msg进行赋值，可以创建一个Bundle进行承载
                    message.what = DRAW_MARKER;
                    message.obj = siteList;
                    message.sendToTarget();
                }
            });

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        locationClient.unRegisterLocationListener(mMyLocationListener);
        locationClient.stop();
        locationClient = null;

        if (mBroadcastReceiver != null) {
            mContext.unregisterReceiver(mBroadcastReceiver);
            mBroadcastReceiver = null;
        }
        queryResultMap.clear();
        cleanStaticData();
        Constants.PROJECT_ID = "";
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        hideInfoWindow();
        switch (v.getId()) {
            case R.id.tv_group_name:
                queryGroups();
                break;
            case R.id.tv_task_list:
                startActivity(new Intent(mContext, SubTaskListActivity.class));
                break;
            case R.id.tv_parameter:
                showParameterPopupWindow();
                break;
            case R.id.btn_add_site:
                // 如果没有分组信息或者没有站点信息
                if (TextUtils.isEmpty(groupId) || siteList == null || siteList.isEmpty()) {
                    return;
                }

                if (!isAddMoveMarker) {
                    UiSettings settings = mBaiduMap.getUiSettings();
                    settings.setAllGesturesEnabled(true);
                    settings.setRotateGesturesEnabled(false);
                    mDragView.removeAllViews();
                    mDragView.setVisibility(View.GONE);

                    showAddSitePopupWindow(mBaiduMap.getMapStatus().target);
                }
                break;
            case R.id.btn_loc:
                // 点击定位按钮的操作  TODO 逻辑需完善
                if (drawInfos != null && drawInfos.size() > 0 && null != myLocationLatLng) {
                    LatLng firstLocation = PositionUtils.gps_84_To_bd09(drawInfos.get(0).getLat(),
                            drawInfos.get(0).getLng());
                    if (DistanceUtil.getDistance(myLocationLatLng, firstLocation) > 5_000) {
                        new SVAlertDialog()
                                .content("当前定位所在区域可能没有站点信息,是否要回到当前位置?")
                                .cancelContent("取消")
                                .confirmContent("确定")
                                .setConfirmListener(v1 -> moveToMyLocation())
                                .show(getChildFragmentManager());
                    } else {
                        moveToMyLocation();
                    }
                } else {
                    moveToMyLocation();
                }
                break;
            case R.id.location_tv:
                showProjectPopupWindow();
                if (groupPopupWindow != null) {
                    groupPopupWindow.dismiss();
                }
                if (taskPopupWindow != null) {
                    taskPopupWindow.dismiss();
                }
                break;
            case R.id.change_view_type:
                if (mBaiduMap.getMapType() == BaiduMap.MAP_TYPE_NORMAL) {
                    mBaiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE);
                } else {
                    mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
                }
                break;
            case R.id.ibtn_site_list:
                if (isSiteOpen) {
                    rlSurvey.setVisibility(View.GONE);
                    isSiteOpen = false;
                } else {
                    rlSurvey.setVisibility(View.VISIBLE);
                    rlSurvey.removeAllViews();
                    tvBg.setVisibility(View.VISIBLE);
                    rlSurvey.addView(siteListView.getView(drawInfos));
                    isSiteOpen = true;
                }
                break;
            case R.id.btn_seaceh:
                if (llSeaceh.getVisibility() == View.VISIBLE) {
                    llSeaceh.setVisibility(View.GONE);
                } else {
                    llSeaceh.setVisibility(View.VISIBLE);
                }
                break;
            default:
                break;

        }
    }

    /**
     * 将地图移动到用户当前的定位位置,并缩放到默认级别
     */
    private void moveToMyLocation() {
        if (null == myLocationLatLng) {
            return;
        }
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(myLocationLatLng));
        MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(DEFAULT_ZOOM);
        mBaiduMap.setMapStatus(msu);
    }

    /**
     * 显示选择的分组任务
     */
    private void showGroupTitle(String content) {
        if (!TextUtils.isEmpty(content)) {
            String txt = "任务分组：" + content;
            tvGroupName.setTypeface(Typeface.DEFAULT_BOLD);
            tvGroupName.setText(txt);
            Drawable drawable_news = getResources().getDrawable(R.drawable.icon_arrow_black);
            drawable_news.setBounds(0, 0, DensityUtil.dip2px(getActivity(), 12), DensityUtil.dip2px(getActivity(), 12));
            tvGroupName.setCompoundDrawables(null, null, drawable_news, null);
        } else {
            tvGroupName.setTypeface(Typeface.DEFAULT);
            tvGroupName.setText(content);
            tvGroupName.setCompoundDrawables(null, null, null, null);
        }
    }

    /**
     * 显示选择的工参任务
     */
    private void showParameterTitle(String content) {
        String txt = "选择工参：" + content;
        tvParameter.setText(txt);

        if (!TextUtils.isEmpty(content)) {
            Drawable drawable_news = getResources().getDrawable(R.drawable.icon_arrow_black);
            drawable_news.setBounds(0, 0, DensityUtil.dip2px(getActivity(), 12), DensityUtil.dip2px(getActivity(), 12));
            tvParameter.setCompoundDrawables(null, null, drawable_news, null);
        } else {
            tvParameter.setCompoundDrawables(null, null, null, null);
        }
    }

    /**
     * @param IndoorId 0 室内 1室外
     * @param flag     0代表新建，1代表改造（已建站）, 2 (新建站) 3：单站仿真
     * @param info     如果是新建勘测站点 则传入参数是0, 2, 构建的默认参数的siteinfo
     */
    @Override
    public void startSurvey(final int IndoorId, final int flag, final SiteInfo info) {
        info.setAddress(newStationAddress);
        if (flag == 3) {
            currSiteInfo = info;

            List<SiteParam> parmas = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                    .queryAllBySiteId(Constants.PROJECT_ID, groupId, currSiteInfo.getNodebId() + "");

            //polygon 取传模半径+75
            int mainCalculationRadius = 800;
            if (parmas != null && parmas.size() > 0) {
                mainCalculationRadius = Integer.parseInt(parmas.get(0).getMainCalculationRadius()) + 75;
            }

            //工参里面的经纬度为GPS，需要转换为百度的计算范围
            LatLng latLng = PositionUtils.gps_84_To_bd09(currSiteInfo.getLat(), currSiteInfo.getLng());
            double topLat = latLng.latitude + getBetweenLatByMetre(latLng, mainCalculationRadius);
            double bottomLat = latLng.latitude - getBetweenLatByMetre(latLng, mainCalculationRadius);
            double leftLng = latLng.longitude - getBetweenLngByMetre(latLng, mainCalculationRadius);
            double rightLng = latLng.longitude + getBetweenLngByMetre(latLng, mainCalculationRadius);

            String polygonPoints = getPolygon(topLat, bottomLat, leftLng, rightLng);


            showSimulationPopupWindow(1, polygonPoints, parmas);

        } else {
            //直接跳转站点规划
            Intent intent = new Intent();
            intent.setClass(mContext, SiteSurveyInfoActivity.class);
            intent.putExtra("location", myLocationLatLng);
            intent.putExtra("IndoorId", IndoorId);
            intent.putExtra("FLAG", flag);
            intent.putExtra("siteInfo", info);
            intent.putExtra("source", "");
            startActivity(intent);
        }
    }

    /**
     * 测试polygonPoints是否可以包含单站 如果有大于两个点，就画多边形
     */
    private void drawPolygon(List<LatLng> pts) {
        if (polygon != null) {
            polygon.remove();
        }
        LatLng ll = null;
        OverlayOptions ooPolygon = new PolygonOptions().points(pts).stroke(new Stroke(5, 0xAA00FF00))
                .fillColor(0xAAFFFF00);
        polygon = (Polygon) mBaiduMap.addOverlay(ooPolygon);
    }

    private void drawYuan(LatLng ll) {
        OverlayOptions ooCircle = new CircleOptions().fillColor(0x384d73b3).center(ll).stroke(new Stroke(3, 0x784d73b3))
                .radius(800);
        mBaiduMap.addOverlay(ooCircle);
    }

    @Override
    public void startPreview(CellInfoBean cellInfoBean) {
        //        //直接跳转站点规划
        Intent intent = new Intent();
        intent.setClass(mContext, BigImageShowPortraitActivity.class);
        if (cellInfoBean != null && cellInfoBean.getCellImgList() != null && cellInfoBean.getCellImgList().size() > 0) {
            intent.putExtra("cellInfo", cellInfoBean);
            startActivity(intent);
        } else {
            showToast("没有图片预览！");
        }
    }

    @Override
    public void clickSite(SiteInfo info) {
        currSiteInfo = info;

        LinearLayout viewCache = (LinearLayout) View.inflate(mContext, R.layout.marker_clice_pop, null);
        int width = DensityUtil.getPixByWidthPercent(mContext, .08f);
        viewCache.getChildAt(0).setLayoutParams(new LinearLayout.LayoutParams(width, width * 3 / 2));

        LatLng showPostion = PositionUtils.gps_84_To_bd09(info.getLat(), info.getLng());

        BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(viewCache);
        clickMarkerIndicator = new InfoWindow(cacheDescriptor, showPostion, 0, null);

        mBaiduMap.showInfoWindow(clickMarkerIndicator);
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(showPostion));

        if (!TextUtils.isEmpty(groupId)) {
            rlSurvey.setVisibility(View.VISIBLE);
            int num = info.getIsSurvey();
            if (0 == num) {
                showStartSurveySitePopupWindow(info);
            } else {
                clickLatLng = showPostion;
                showSurveyedSitePopup(info);
            }
        }
    }

    @Override
    public void selectTemplate() {
        Intent intent = new Intent(getActivity(), SelectSiteTemplateActivity.class);
        startActivity(intent);
    }

    @Override
    public void deleteSite() {
        deleteConfirm();
    }

    private void deleteConfirm() {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_pop_delete_site, null);
        final PopupWindow popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(ll, Gravity.CENTER, 0, 0);
        view.findViewById(R.id.tv_bg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.tv_cancel_delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.tv_confirm_delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "真的删除了", Toast.LENGTH_SHORT).show();
                popupWindow.dismiss();
            }
        });
    }

    /**
     * 显示选择项目
     */
    private void showProjectPopupWindow() {
        if (projectInfos == null || projectInfos.size() == 0)
            return;
        View contextView = LayoutInflater.from(mContext).inflate(R.layout.project_dialog, null);

        lvProject = (ListView) contextView.findViewById(R.id.lv_project);
        ProjectAdapter adapter = new ProjectAdapter();
        lvProject.setAdapter(adapter);

        // 过滤后的project
        List<ProjectInfo> localProjectData = new ArrayList<>();
        localProjectData.addAll(projectInfos);
        adapter.setData(localProjectData);
        adapter.setSelectedProjectId(Constants.PROJECT_ID);

        // 搜索框部分
        View searchLayout = contextView.findViewById(R.id.search_layout);
        EditText inputEt = contextView.findViewById(R.id.search_input);
        TextView cancelTv = contextView.findViewById(R.id.search_cancel);

        inputEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (0 == s.length()) {
                    cancelTv.setVisibility(View.INVISIBLE);
                    localProjectData.clear();
                    localProjectData.addAll(projectInfos);
                } else {
                    cancelTv.setVisibility(View.VISIBLE);
                    localProjectData.clear();
                    String[] filterStrings = s.toString().toLowerCase(Locale.ROOT).split(" ");
                    for (ProjectInfo pi : projectInfos) {
                        boolean fit = true;
                        for (String str : filterStrings) {
                            if (!TextUtils.isEmpty(str)) {
                                if (TextUtils.isEmpty(pi.projectName) || !pi.projectName.toLowerCase(Locale.ROOT).contains(str)) {
                                    fit = false;
                                    break;
                                }
                            }
                        }
                        if (fit) {
                            localProjectData.add(pi);
                        }
                    }
                }
                adapter.setData(localProjectData);
            }
        });
        cancelTv.setOnClickListener(v -> {
            inputEt.setText("");
        });

        ImageView ivUp = (ImageView) contextView.findViewById(R.id.iv_up);

        final PopupWindow popupWindow = new PopupWindow(contextView, ViewGroup.LayoutParams.MATCH_PARENT,
                DensityUtil.dip2px(getContext(), 300));
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        popupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        popupWindow.showAsDropDown(ll, 0, 0);

        lvProject.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Constants.PROJECT_ID = localProjectData.get(position).getProjectId();
                saveStaticData("projectId", Constants.PROJECT_ID);
                saveStaticData("projectName", localProjectData.get(position).getProjectName());
                mLocationTv.setText(localProjectData.get(position).getProjectName());

                queryGroups();
                popupWindow.dismiss();
            }
        });

        ivUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
    }

    private String selectedGroupId = "";

    /**
     * 显示选择指定项目下的分组信息
     * // TODO 过滤逻辑 分组显示逻辑需优化
     */
    private void showGroupPopupWindow() {
        if (groups == null || groups.size() == 0)
            return;

        View contextView = LayoutInflater.from(mContext).inflate(R.layout.project_dialog, null);
        lvGroupList = (ListView) contextView.findViewById(R.id.lv_project);
        GroupAdapter adapter = new GroupAdapter();
        lvGroupList.setAdapter(adapter);

        List<TaskInfo> temGroupData = new ArrayList<>();
        temGroupData.addAll(groups);
        adapter.setData(temGroupData);
        adapter.setSelectedGroupId(selectedGroupId);

        ImageView ivUp = (ImageView) contextView.findViewById(R.id.iv_up);

        // 搜索框部分
        View searchLayout = contextView.findViewById(R.id.search_layout);
        EditText inputEt = contextView.findViewById(R.id.search_input);
        TextView cancelTv = contextView.findViewById(R.id.search_cancel);

        inputEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (0 == s.length()) {
                    cancelTv.setVisibility(View.INVISIBLE);
                } else {
                    cancelTv.setVisibility(View.VISIBLE);
                }
                temGroupData.clear();
                String[] filterStrings = s.toString().toLowerCase(Locale.ROOT).split(" ");
                for (TaskInfo ti : groups) {
                    boolean fit = true;
                    for (String str : filterStrings) {
                        if (!TextUtils.isEmpty(str)) {
                            if (TextUtils.isEmpty(ti.groupName) || !ti.groupName.toLowerCase(Locale.ROOT).contains(str)) {
                                fit = false;
                                break;
                            }
                        }
                    }
                    if (fit) {
                        temGroupData.add(ti);
                    }
                }
                adapter.setData(temGroupData);
            }
        });
        cancelTv.setOnClickListener(v -> {
            inputEt.setText("");
        });

        if (groupPopupWindow != null) {
            groupPopupWindow.dismiss();
        }

        if (taskPopupWindow != null) {
            taskPopupWindow.dismiss();
        }

        groupPopupWindow = new PopupWindow(contextView, ViewGroup.LayoutParams.MATCH_PARENT,
                DensityUtil.dip2px(getContext(), 300));
        groupPopupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        groupPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        groupPopupWindow.showAsDropDown(ll, 0, 0);

        lvGroupList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedGroupId = temGroupData.get(position).groupId;

                currTaskInfo = temGroupData.get(position);
                groupId = currTaskInfo.getGroupId();
                groupName = currTaskInfo.getGroupName();
                saveStaticData(Constants.GROUP_ID, groupId);
                saveStaticData(Constants.GROUP_NAME, groupName);

                if (!AppUtil.isServiceRunning(getActivity(), "com.huawei.genexcloud.framework.service.TaskService")) {
                    Intent taskService = new Intent(getActivity(), TaskService.class);
                    getActivity().startService(taskService);
                }

                saveStaticData(Constants.TASK_ID, currTaskInfo.getTaskId());
                saveStaticData(Constants.TASK_NAME, currTaskInfo.getTaskName());
                saveStaticData(Constants.OPERATOR_ID, currTaskInfo.getOperatorId());
                Constants.PROJECT_ID = currTaskInfo.getProjectId();
                saveStaticData(Constants.PROJECTID, Constants.PROJECT_ID);

                showGroupTitle(groupName);
                showParameterTitle(currTaskInfo.getTaskName());

                currSiteInfo = null;
                //选择任务后，请求站点数据
                queryWorkerParameter(currTaskInfo);

                //切换任务，隐藏任务数
                tvTaskCount.setVisibility(View.GONE);
                //查询仿真任务数量
                sitePresenter.querySimulationList(Constants.PROJECT_ID, groupId, tvTaskCount);

                //临时表中是否有创建中任务
                TaskInfo info = DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB()
                        .queryById(Constants.PROJECT_ID, groupId);
                if (info != null) {
                    tvLoadTip.setVisibility(View.VISIBLE);
                } else {
                    tvLoadTip.setVisibility(View.GONE);
                }
            }
        });

        ivUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(groupId)) {
                    showToast("请选择任务");
                } else {
                    if (drawInfos != null && drawInfos.size() > 0) {
                        groupPopupWindow.dismiss();
                    } else {
                        showToast("该任务没有工参，请重新选择任务！");
                    }
                }
            }
        });
    }

    private String selectedTaskId = "";

    /**
     * 显示工参任务
     */
    private void showParameterPopupWindow() {
        final List<TaskInfo> taskInfos = DBManager.getInstance(BaseApplication.getAppContext()).getGroupInfoDB()
                .queryAllByGroupId(Constants.PROJECT_ID, groupId);

        View contextView = LayoutInflater.from(mContext).inflate(R.layout.project_dialog, null);
        ListView lvTask = (ListView) contextView.findViewById(R.id.lv_project);
        TaskAdapter adapter = new TaskAdapter();
        lvTask.setAdapter(adapter);

        // TODO
        selectedTaskId = Constants.TASK_ID;

        List<TaskInfo> temTaskData = new ArrayList<>();
        temTaskData.addAll(taskInfos);
        adapter.setData(taskInfos, selectedTaskId);


        // 搜索框部分
        View searchLayout = contextView.findViewById(R.id.search_layout);
        EditText inputEt = contextView.findViewById(R.id.search_input);
        TextView cancelTv = contextView.findViewById(R.id.search_cancel);

        inputEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (0 == s.length()) {
                    cancelTv.setVisibility(View.GONE);
                } else {
                    cancelTv.setVisibility(View.VISIBLE);
                }
                temTaskData.clear();
                String[] filterStrings = s.toString().toLowerCase(Locale.ROOT).split(" ");
                for (TaskInfo ti : groups) {
                    boolean fit = true;
                    for (String str : filterStrings) {
                        if (!TextUtils.isEmpty(str)) {
                            if (TextUtils.isEmpty(ti.getTaskName()) || !ti.getTaskName().toLowerCase(Locale.ROOT).contains(str)) {
                                fit = false;
                                break;
                            }
                        }
                    }
                    if (fit) {
                        temTaskData.add(ti);
                    }
                }
                adapter.setData(temTaskData);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        cancelTv.setOnClickListener(v -> {
            inputEt.setText("");
        });

        ImageView ivUp = (ImageView) contextView.findViewById(R.id.iv_up);

        if (groupPopupWindow != null) {
            groupPopupWindow.dismiss();
        }

        if (taskPopupWindow != null) {
            taskPopupWindow.dismiss();
        }

        taskPopupWindow = new PopupWindow(contextView, ViewGroup.LayoutParams.MATCH_PARENT,
                DensityUtil.dip2px(getContext(), 300));
        taskPopupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        taskPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        taskPopupWindow.showAsDropDown(ll, 0, 0);

        lvTask.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                currTaskInfo = taskInfos.get(position);
                selectedTaskId = currTaskInfo.getTaskName();

                saveStaticData(Constants.TASK_ID, currTaskInfo.getTaskId());
                saveStaticData(Constants.TASK_NAME, currTaskInfo.getTaskName());
                saveStaticData(Constants.OPERATOR_ID, currTaskInfo.getOperatorId());
                Constants.PROJECT_ID = currTaskInfo.getProjectId();
                saveStaticData(Constants.PROJECTID, Constants.PROJECT_ID);

                showParameterTitle(currTaskInfo.getTaskName());

                currSiteInfo = null;
                //选择任务后，请求站点数据
                queryWorkerParameter(currTaskInfo);
            }
        });

        ivUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(groupId)) {
                    showToast("请选择任务");
                } else {
                    if (drawInfos != null && drawInfos.size() > 0) {
                        taskPopupWindow.dismiss();
                    } else {
                        showToast("该任务没有工参，请重新选择任务！");
                    }
                }
            }
        });
    }

    /**
     * 新建站点提示框
     * 内容: 是否新增站点 是:否
     */
    private void showAddSitePopupWindow(final LatLng latLng) {
        if (TextUtils.isEmpty(groupId)) {
            return;
        }
        new SVAlertDialog()
                .content(getString(R.string.tv_pop_add_site))
                .confirmContent("确定")
                .cancelContent("取消")
                .setConfirmListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addMoveMarker(latLng);
                        // 查询默认站点小区模板
                        querySiteTemplate();
                    }
                }).show(getChildFragmentManager());
    }

    /**
     * 开始二次仿真
     *
     * @siteCount 站点数
     */
    private void showSimulationPopupWindow(int siteCount, final String polygonPoints,
                                           final List<SiteParam> allSiteParams) {
        //临时表中是否有创建中任务
        TaskInfo info = DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB()
                .queryById(Constants.PROJECT_ID, groupId);
        if (info != null) {
            showCommonPop("正在创建仿真任务中，请稍后！", R.drawable.bg_tip);
            return;
        }

        if (TextUtils.isEmpty(groupId)) {
            return;
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_pop_create_simulation, null);

        final EditText etSubTaskName = (EditText) view.findViewById(R.id.et_subtask_name);
        TextView titleTv = (TextView) view.findViewById(R.id.tv_simulation_name);

        if (siteCount == 1) {
            scenario = "SINGLE";
            titleTv.setText("单站仿真");
        } else {
            scenario = "BATCH";
            titleTv.setText(Html.fromHtml(createContainsBlueHtmlText("当前区域站点总数 ", siteCount)));
        }

        final PopupWindow popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(ll, Gravity.CENTER, 0, 0);
        view.findViewById(R.id.tv_cancel_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.tv_confirm_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = etSubTaskName.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    showToast("请输入任务名称");
                    return;
                }

                if (!checkName(name)) {
                    Toast.makeText(getActivity(), "任务名称输入不符合规则！", Toast.LENGTH_LONG).show();
                    return;
                }

                if (name.length() > 30) {
                    showToast("任务名称不能超过30个字符");
                    return;
                }

                // TODO 仿真任务逻辑代码
                secondaryPrediction(name, polygonPoints, scenario, allSiteParams);
                popupWindow.dismiss();
            }
        });
    }

    private boolean checkName(String str) {
        String pattern = "^[0-9\\u4e00-\\u9fa5A-Za-z\\_]{1,30}$";
        return Pattern.matches(pattern, str);
    }

    /**
     * 提示仿真站点过多弹出框
     */
    private void showTooMuchSitePopupWindow() {
        if (TextUtils.isEmpty(groupId)) {
            return;
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_pop_too_much_site, null);

        final PopupWindow popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(ll, Gravity.CENTER, 0, 0);
        view.findViewById(R.id.tv_bg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.tv_confirm_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
            }
        });
    }

    /**
     * 创建有蓝色的title 的字体
     *
     * @param title
     * @param redCount
     * @return
     */
    public String createContainsBlueHtmlText(String title, int redCount) {

        return "<body>" + "<font color=\"black\">" + title + "</font>" + "<font color=\"#09D3C2\"><big>" + redCount
                + "</big></font>" + "</body>";
    }

    /**
     * 显示提示框
     */
    private void showTipPopupWindow(final int type, String content) {
        if (tipPopupWindow != null) {
            tipPopupWindow.dismiss();
        }

        final View contextView = LayoutInflater.from(mContext).inflate(R.layout.tip_dialog, null);

        TextView title = (TextView) contextView.findViewById(R.id.tv_dialog_title);
        ImageView imageView = (ImageView) contextView.findViewById(R.id.iv_image);
        if (type == LOGIN_AGAIN) {
            title.setText(getString(R.string.tv_pop_login_again));
            imageView.setImageResource(R.drawable.bg_overtime);
        } else if (type == LOGIN_NO_LIMIT) {
            title.setText(getString(R.string.tv_pop_login_noLimit));
            imageView.setImageResource(R.drawable.bg_overtime);
        } else {
            title.setText(content);
            imageView.setImageResource(R.drawable.bg_fail);
        }

        TextView button = (TextView) contextView.findViewById(R.id.tv_btn);
        tipPopupWindow = new PopupWindow(contextView, android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.FILL_PARENT);
        tipPopupWindow.setFocusable(true);
        tipPopupWindow.setOutsideTouchable(true);
        tipPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        tipPopupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        tipPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        tipPopupWindow.showAtLocation(contextView, Gravity.CENTER, 0, 0);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipPopupWindow.dismiss();
                if (type == LOGIN_AGAIN) {
                    ActivityTackUtil.getInstance().popAllActivity();
                    ShareUtil.save(Constants.LOGIN_PASS_KEY, "");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                    getActivity().finish();
                }
            }
        });

    }

    /**
     * 清空地图站点
     */
    private void cleanMap() {
        if (mBaiduMap != null) {
            mBaiduMap.clear();

            MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(DEFAULT_ZOOM);
            mBaiduMap.setMaxAndMinZoomLevel(21f, 4);
            mBaiduMap.setMapStatus(msu);
        }
    }

    /**
     * 二次仿真
     */
    private void secondaryPrediction(final String name, final String polygonPoints, final String scenario,
                                     final List<SiteParam> allSiteParams) {
        tvLoadTip.setVisibility(View.VISIBLE);

        //由于平台接口响应比较慢，客户要求不等平台响应，自行建立一个创建中的任务，
        //待平台响应更新状态为仿真中，或创建失败；
        //这时如果退出程序，将接收不到平台响应，产生一个永远为创建中的任务
        final SimulationReqInfo reqInfo = new SimulationReqInfo();
        reqInfo.setProjectId(Constants.PROJECT_ID);
        reqInfo.setProjectName(ShareUtil.readString(Constants.PROJECT_NAME, ""));

        reqInfo.setGroupid(ShareUtil.readString(Constants.GROUP_ID, ""));
        reqInfo.setGroupName(ShareUtil.readString(Constants.GROUP_NAME, ""));

        //新建一个任务id为空，名称为新起的任务的名称
        reqInfo.setTaskId("");
        reqInfo.setTaskName(name);

        //依赖那个任务建立的仿真任务
        String taskId = ShareUtil.readString(Constants.TASK_ID, "");
        reqInfo.setRelyTaskId(taskId);
        reqInfo.setRelyTaskName(ShareUtil.readString(Constants.TASK_NAME, ""));

        reqInfo.setSimulationParams(transformParamsToSimulation(Constants.PROJECT_ID, groupId, allSiteParams));
        // 提示信息错误 todo
        if (null == reqInfo.getSimulationParams() || reqInfo.getSimulationParams().isEmpty()) {
            showTipPopupWindow(SIMULATION_FAIL, "区域内未获取到站点信息！");
            tvLoadTip.setVisibility(View.GONE);
            return;
        }
        CreateEmulationUtil.getInstance().asyncExecute(reqInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                if (resultCode == 204) {
                    showTipPopupWindow(SIMULATION_FAIL, getString(R.string.error_code_name_repeat));
                } else if (0 != resultCode) {
                    showTipPopupWindow(SIMULATION_FAIL, getString(R.string.tv_pop_task_fail) + "错误码：" + resultCode);
                } else {
                    showTipPopupWindow(SIMULATION_FAIL, getString(R.string.tv_pop_task_fail));
                }
                tvLoadTip.setVisibility(View.GONE);
            }

            @Override
            public void onSuccess(Object obj) {
                checkRange.setChecked(false);
                Thread thread = new Thread(new GetSimulationRunnable(name, polygonPoints, scenario, allSiteParams));
                thread.start();
                //查询仿真任务数量
                sitePresenter.querySimulationList(reqInfo.getProjectId(), reqInfo.getGroupid(), tvTaskCount);
            }

            @Override
            public void onEmpty() {
                checkRange.setChecked(false);
                Thread thread = new Thread(new GetSimulationRunnable(name, polygonPoints, scenario, allSiteParams));
                thread.start();
                //查询仿真任务数量
                sitePresenter.querySimulationList(reqInfo.getProjectId(), reqInfo.getGroupid(), tvTaskCount);
            }
        });
    }

    /**
     * 更新仿真任务
     */
    private void updateEmulation(final EmulationEntrance entrance) {
        final SimulationReqInfo reqInfo = new SimulationReqInfo();
        reqInfo.setProjectId(entrance.getProjectId());
        reqInfo.setGroupid(entrance.getGroupId());
        reqInfo.setGroupName(entrance.getGroupName());
        reqInfo.setTaskId(entrance.getTaskId());
        reqInfo.setTaskName(entrance.getTaskName());
        reqInfo.setStatus(entrance.getStatus());
        reqInfo.setFinish(false);

        //更新任务状态
        DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB().updateStatus(
                reqInfo.getProjectId(), reqInfo.getGroupId(), reqInfo.getTaskId(), reqInfo.getTaskName(),
                reqInfo.getStatus());
        Intent intent = new Intent(Constants.STATUS_CHANGE);
        intent.setPackage(Constants.PACKAGE_NAME);
        BaseApplication.getAppContext().sendBroadcast(intent, Constants.PERMISSION_BROADCAST);

        UpdateEmulationUtil.getInstance().asyncExecute(reqInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                //查询仿真任务数量
                sitePresenter.querySimulationList(reqInfo.getProjectId(), reqInfo.getGroupid(), tvTaskCount);
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
            }
        });
    }

    private List<SimulationParam> transformParamsToSimulation(String projectId, String groupId,
                                                              List<SiteParam> siteParams) {
        List<SiteInfo> siteInfos = sitePresenter.transformSiteInfos(projectId, groupId, siteParams);
        //仿真站点
        List<SimulationParam> simulationParams = new ArrayList<>();
        for (int i = 0; i < siteInfos.size(); i++) {
            SiteInfo siteInfo = siteInfos.get(i);
            SimulationParam simulationParam = new SimulationParam();
            simulationParam.setSiteId(siteInfo.getNodebId());

            simulationParams.add(simulationParam);
        }
        return simulationParams;
    }

    @Override
    public void onShow() {
        super.onShow();

        if (TextUtils.isEmpty(groupId) || drawInfos == null || drawInfos.size() == 0) {
            showGroupPopupWindow();
        }
    }

    @Override
    public void onHide() {
        super.onHide();

        if (groupPopupWindow != null) {
            groupPopupWindow.dismiss();
        }

        if (taskPopupWindow != null) {
            taskPopupWindow.dismiss();
        }
    }

    /**
     * 查询默认的站点小区模板
     */
    private void querySiteTemplate() {
        QuerySiteTemplateImpl.getInstance().getSiteTemplate(new QuerySiteTemplateImpl.SiteTemplateCallback() {
            @Override
            public void onFailure(ErrorBean e) {
            }

            @Override
            public void onResponse(List<CellInfo> response) {
            }
        });
    }


    private double getPiexValueByRealDistance(int realDistance) {
        // 根据输入范围值(单位：米) 计算出需要画的区域像素：px
        LatLng pointA = mBaiduMap.getMapStatus().target;
        Point pointAPixel = mBaiduMap.getProjection().toScreenLocation(pointA);

        LatLng pointB = new LatLng(pointA.latitude + 0.001, pointA.longitude);
        Point pointBPixel = mBaiduMap.getProjection().toScreenLocation(pointB);
        //像素距离
        int piexlDistanceBetween2Points = Math.abs(pointBPixel.y - pointAPixel.y);
        double realDistanceBetween2Points = DistanceUtil.getDistance(pointA, pointB);

        double pixelDistance = realDistance / (realDistanceBetween2Points / piexlDistanceBetween2Points);

        return pixelDistance;
    }

    /**
     * 获取指定像素，相差纬度
     *
     * @return
     */
    private double getBetweenLatByPix(LatLng latLng, int px) {
        Projection projection = mBaiduMap.getProjection();
        double latitude = latLng.latitude;
        if (projection != null) {
            Point point = projection.toScreenLocation(latLng);
            Point point1 = new Point(point.x, point.y - px);
            LatLng latLng1 = projection.fromScreenLocation(point1);
            latitude = latLng1.latitude - latLng.latitude;
        }
        return latitude;
    }

    /**
     * 获取指定像素，相差纬度
     *
     * @return
     */
    private double getBetweenLngByPix(LatLng latLng, int px) {
        Projection projection = mBaiduMap.getProjection();
        double longitude = latLng.longitude;
        if (projection != null) {
            Point point = projection.toScreenLocation(latLng);
            Point point1 = new Point(point.x - px, point.y);
            LatLng latLng1 = projection.fromScreenLocation(point1);
            longitude = latLng.longitude - latLng1.longitude;
        }
        return longitude;
    }

    @Override
    public void getReport(SiteInfo info, StationResp stationResp) {
        confirmMail(info, stationResp);
    }

    @Override
    public void navi(LatLng latLng) {
        startNavigation(latLng);
    }

    private void confirmMail(final SiteInfo info, final StationResp stationResp) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.item_send_email, null);

        final EditText etMailAddress = (EditText) view.findViewById(R.id.et_email);

        popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(rlSurvey, Gravity.CENTER, 0, 0);

        view.findViewById(R.id.btn_pop_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.btn_pop_sure).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail(info, stationResp, etMailAddress.getText().toString());
            }
        });
    }

    // todo mark 发送邮件的代码
    private void sendEmail(SiteInfo info, StationResp stationResp, String mailAddress) {

        if (TextUtils.isEmpty(mailAddress)) {
            showToast("请输入邮箱");
            return;
        }
        String address = mailAddress + "@huawei.com";

        if (!StringUtil.isEmail(address)) {
            showToast("请输入正确邮箱");
            return;
        }

        createLoadingDialog(this.getActivity(), mContext, "", false);

        HashMap<String, Object> params = new HashMap<>();
        params.put("to", address); //接收人
        params.put("subject", "请查收_" + info.getSiteName() + "站点勘测报告");

        StringBuffer buffer = new StringBuffer();
        String saveProjectName = ShareUtil.readString("projectName", "");
        buffer.append("1、报告项目归属：" + saveProjectName + ";<br>");
        String reportUrl = stationResp.StationReportUrl;
        if (!TextUtils.isEmpty(reportUrl) && reportUrl.contains("_") && reportUrl.contains(".")) {
            String name = info.getSiteName() + "_";
            String time = "";
            if (reportUrl.contains(name)) {
                time = TimeUtil.dateToStrLong(
                        reportUrl.substring(reportUrl.indexOf(name) + name.length(), reportUrl.indexOf(".")));
            } else {
                time = TimeUtil.dateToStrLong(reportUrl.substring(reportUrl.indexOf("_") + 1, reportUrl.indexOf(".")));
            }

            buffer.append("2、报告生成时间：" + time);
        } else {
            buffer.append("2、报告生成时间：" + stationResp.Recordtime);
        }

        params.put("content", buffer.toString());
        params.put("attachment", reportUrl);

        SendEmailUtil.getInstance().asyncExecute(params, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
                showToast("发送失败");
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                showToast("发送成功");
                if (popupWindow != null) {
                    popupWindow.dismiss();
                }
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
                showToast("发送失败");
            }
        });
    }

    private void startNavigation(LatLng distLatLng) {
        if (distLatLng != null && myLocationLatLng != null) {
            NaviParaOption naviParaOption = new NaviParaOption();
            naviParaOption.startPoint(myLocationLatLng);
            naviParaOption.endPoint(distLatLng);
            BaiduMapNavigation.setSupportWebNavi(false);
            if (isAvilible(BaseApplication.getAppContext(), "com.baidu.BaiduMap")) {
                boolean isSuccess = BaiduMapNavigation.openBaiduMapNavi(naviParaOption,
                        BaseApplication.getAppContext());
                if (!isSuccess) {
                    Intent intent;
                    try {
                        intent = Intent.getIntent("intent://map/direction?origin=latlng:" + myLocationLatLng.latitude
                                + "," + myLocationLatLng.longitude + "|name:从这里开始&destination=" + "latlng:"
                                + distLatLng.latitude + "," + distLatLng.longitude + "|name:到这里结束"
                                + "&mode=driving&referer=Autohome|GasStation#Intent;scheme=bdapp;package=com.baidu.BaiduMap;end");
                        startActivity(intent);
                    } catch (URISyntaxException e) {
                        showToast("打开导航失败", Toast.LENGTH_SHORT);
                    }
                }
            } else {
                showAppDialog();
            }
        } else {
            showToast(getResources().getString(R.string.stationmap_please_selectsite_andbegain_navigation),
                    Toast.LENGTH_SHORT);
        }
    }

    private void showAppDialog() {
        if (tipPopupWindow != null) {
            tipPopupWindow.dismiss();
        }

        final View contextView = LayoutInflater.from(mContext).inflate(R.layout.layout_common_tip_dialog, null);

        TextView title = (TextView) contextView.findViewById(R.id.tv_dialog_title);
        title.setText(getString(R.string.heatmap_not_installbaidumap_press_toinstall));

        TextView sure = (TextView) contextView.findViewById(R.id.delete_dialog_ok);
        TextView cancle = (TextView) contextView.findViewById(R.id.delete_dialog_cancle);
        tipPopupWindow = new PopupWindow(contextView, android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.FILL_PARENT);
        tipPopupWindow.setFocusable(true);
        tipPopupWindow.setOutsideTouchable(true);
        tipPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        tipPopupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        tipPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        tipPopupWindow.showAtLocation(contextView, Gravity.CENTER, 0, 0);

        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipPopupWindow.dismiss();
                OpenClientUtil.getLatestBaiduMapApp(getActivity());
            }
        });

        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipPopupWindow.dismiss();
            }
        });
    }

    /**
     * @param context
     * @param packageName
     * @return
     * @function:判断手机是否安装了某应用
     */
    private boolean isAvilible(Context context, String packageName) {
        final PackageManager packageManager = context.getPackageManager();//获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);//获取所有已安装程序的包信息
        List<String> pName = new ArrayList<String>();//用于存储所有已安装程序的包名
        //从pinfo中将包名字逐一取出，压入pName list中
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                pName.add(pn);
            }
        }
        return pName.contains(packageName);//判断pName中是否有目标程序的包名，有TRUE，没有FALSE
    }

    /**
     * 查询全部工参
     */
    private void getWorkerParameter(TaskInfo taskInfo) {
        if (null == taskInfo) {
            return;
        }
        createLoadingDialog(this.getActivity(), mContext, "获取工参数据中...", true);
        needMoveToPoint = true;
        final String projectId = taskInfo.getProjectId();
        final String groupId = taskInfo.getGroupId();
        final String taskId = taskInfo.getTaskId();
        QueryCPProjectParamImpl.getInstance().getSiteParam(projectId, taskInfo.getTaskId(), new QueryCPProjectParamImpl.SiteParamCallback() {
            @Override
            public String getProjectId() {
                return projectId;
            }

            @Override
            public String getGroupId() {
                return groupId;
            }

            @Override
            public void onFailure(ErrorBean e) {
                closeLoadDialog();
                showCommonPop("获取工参信息失败，请重试或选择其他任务", R.drawable.bg_fail);
            }

            @Override
            public void onResponse(List<SiteParam> response) {
                closeLoadDialog();
                List<SiteParam> site5GInfos = response;
                if (null == site5GInfos || 0 == site5GInfos.size()) {
                    closeLoadDialog();
                    showCommonPop("该任务没有工参信息，请选择其他任务", R.drawable.bg_tip);
                } else {
                    //查询已勘测站点
                    queryIsSurveySiteParams(site5GInfos, true);

                    // 获取工参相关模型数据
                    getSiteModelParams();

                    if (lvGroupList != null) {
                        lvGroupList.setVisibility(View.GONE);
                    }
                    if (groupPopupWindow != null && groupPopupWindow.isShowing()) {
                        groupPopupWindow.dismiss();
                    }
                    if (taskPopupWindow != null && taskPopupWindow.isShowing()) {
                        taskPopupWindow.dismiss();
                    }
                    // 将本次的groupId和taskId存储为上次所选
                    ShareUtil.save(Constants.LAST_SELECTED_GROUP_ID, groupId);
                    ShareUtil.save(Constants.LAST_SELECTED_TASK_ID, taskId);
                }
            }
        });
    }

    private class MyLocationListener implements BDLocationListener {
        @Override
        public void onReceiveLocation(BDLocation location) {
            int locType = location.getLocType();
            if (null == location || locType == BDLocation.TypeCriteriaException || locType == BDLocation.TypeNone
                    || location.getLatitude() == 4.9E-324 || location.getLongitude() == 4.9E-324
                    || null == mMapView) {
                // 无效的定位信息
                return;
            }
            String content = "";
            if (!TextUtils.isEmpty(location.getCity())) {
                content = location.getCity();
            }
            if (!TextUtils.isEmpty(location.getDistrict())) {
                content = content + location.getDistrict();
            }
            if (!TextUtils.isEmpty(location.getStreet())) {
                content = content + location.getStreet();
            }
            if (!TextUtils.isEmpty(content)) {
                ShareUtil.save(Constants.ADDRESS, content);
            }
            // 设置当前位置信息
            myLocationLatLng = new LatLng(location.getLatitude(), location.getLongitude());
            MyLocationData locData = new MyLocationData.Builder()
                    .latitude(location.getLatitude())
                    .longitude(location.getLongitude()).build();
            mBaiduMap.setMyLocationData(locData);

            if (isFirstLoc) {
                isFirstLoc = false;
                if (null == siteList) { // 如果当前没有获取过工参信息
                    mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(myLocationLatLng));
                }
            }

            String cityName = location.getCity();
            String provinceName = location.getProvince();
            String district = location.getDistrict();

            if (!TextUtils.isEmpty(provinceName)) {
                if (provinceName.contains("省")) {
                    provinceName = provinceName.substring(0, provinceName.indexOf("省"));
                }

                ShareUtil.save(Constants.CURRENT_PROVINCE, provinceName);
            }

            if (!TextUtils.isEmpty(cityName)) {
                if (cityName.contains("市")) {
                    cityName = cityName.substring(0, cityName.indexOf("市"));
                }

                ShareUtil.save(Constants.CURRENT_CITY, cityName);
            }

            ShareUtil.save(Constants.CURRENT_DISTRICT, district);
        }

    }

    /**
     * 接收状态改变广播
     *
     * @author lWX348305
     */
    class ReceiveBroadCast extends BroadcastReceiver {
        /**
         * {@inheritDoc}
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Constants.STATUS_CHANGE.equals(action)) {
            }
            if (Constants.CANCEL_SIMULATION.equals(action)) {
                sitePresenter.querySimulationList(Constants.PROJECT_ID, groupId, tvTaskCount);
            } else if (Constants.ADD_SITE.equals(action) || Constants.UPDATE_SITE.equals(action)
                    || Constants.ADD_SIMULATION.equals(action) || Constants.ADD_EFFECT.equals(action)) {
                hideInfoWindow();
                //pg库数据更新慢,需要等待1-2s查询数据
                mHandler.sendEmptyMessageDelayed(Constants.UPDATE_PARAM, 1000);
            } else if (Constants.EXPIRE_COOKIE.equals(action)) {
                if (!getActivity().isFinishing()) {
                    showTipPopupWindow(LOGIN_AGAIN, "");
                    getActivity().stopService(new Intent(getActivity(), TaskService.class));
                    if (mBroadcastReceiver != null) {
                        getActivity().unregisterReceiver(mBroadcastReceiver);
                        mBroadcastReceiver = null;
                    }
                }
            } else if (Constants.NO_LIMIT.equals(action)) {
                if (!getActivity().isFinishing()) {
                    showTipPopupWindow(LOGIN_NO_LIMIT, "");
                    getActivity().stopService(new Intent(getActivity(), TaskService.class));
                    if (mBroadcastReceiver != null) {
                        getActivity().unregisterReceiver(mBroadcastReceiver);
                        mBroadcastReceiver = null;
                    }
                }
            }
        }
    }

    private class GetSimulationRunnable implements Runnable {
        String polygonPoints;
        String scenario;
        List<SiteParam> allSiteParams;
        String newTaskName;

        public GetSimulationRunnable(String name, String polygonPoints, String scenario, List<SiteParam> allSiteParams) {
            this.polygonPoints = polygonPoints;
            this.scenario = scenario;
            this.allSiteParams = allSiteParams;
            this.newTaskName = name;
        }

        @Override
        public void run() {
            String taskId = ShareUtil.readString(Constants.TASK_ID, "");

            final EmulationEntrance simulationTaskInfo = new EmulationEntrance();

            simulationTaskInfo.setProjectId(Constants.PROJECT_ID);
            simulationTaskInfo.setProjectName(ShareUtil.readString(Constants.PROJECT_NAME, ""));
            simulationTaskInfo.setGroupId(groupId);
            simulationTaskInfo.setGroupName(groupName);

            simulationTaskInfo.setTaskName(newTaskName);
            simulationTaskInfo.setNewTaskName(newTaskName);

            //依赖的仿真ID
            simulationTaskInfo.setRelyTaskId(taskId);

            simulationTaskInfo.setScenario(scenario);
            simulationTaskInfo.setPolygonPoints(polygonPoints);

            //临时表插入创建任务,以分组为主键
            TaskInfo info = new TaskInfo();
            info.setProjectId(Constants.PROJECT_ID);
            info.setGroupId(groupId);
            DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB().insert(info);

            simulationTaskInfo.setSiteParams(allSiteParams);
            //
            SiteSurveyImpl.getInstance().beginSiteSurvey(simulationTaskInfo, new SiteSurveyImpl.SurveyCallback() {
                @Override
                public EmulationEntrance getSentEmulationEntrance() {
                    return simulationTaskInfo;
                }

                @Override
                public void onAfter() {
                    closeLoadDialog();
                }

                @Override
                public void onFailure(ErrorBean e) {
                    DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB()
                            .delete(simulationTaskInfo.getProjectId(), simulationTaskInfo.getGroupId());

                    closeLoadDialog();
                    tvLoadTip.setVisibility(View.GONE);
                    int resultCode = null == e ? 0 : e.errorCode;
                    if (resultCode == 204) {
                        showTipPopupWindow(SIMULATION_FAIL, getString(R.string.error_code_name_repeat));
                    } else if (resultCode == Constants.HTTP_PARSE_ERROR) {
                        showTipPopupWindow(SIMULATION_FAIL, getString(R.string.error_code_network));
                    } else if (null != e && e.errorCode != 0) {
                        if (e.errorCode < 12 && !TextUtils.isEmpty(e.message)) {
                            showTipPopupWindow(SIMULATION_FAIL, "仿真任务创建失败，原因：" + e.message);
                        } else {
                            showTipPopupWindow(SIMULATION_FAIL, "仿真任务创建失败，错误码：" + e.errorCode);
                        }
                    } else {
                        showTipPopupWindow(SIMULATION_FAIL, getString(R.string.tv_pop_task_fail));
                    }
                }

                @Override
                public void onResponse(EmulationEntrance response) {
                    if (null == response) {
                        return;
                    }
                    response.setStatus(0);
                    updateEmulation(response);
                    DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB()
                            .delete(response.getProjectId(), response.getGroupId());

                    tvLoadTip.setVisibility(View.GONE);
                    checkRange.setChecked(false);
                    showToast("仿真任务创建成功");
                }
            });
        }
    }
}
