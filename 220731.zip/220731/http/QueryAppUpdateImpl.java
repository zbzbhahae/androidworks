package com.huawei.genexcloud.survey.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.VersionInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.util.ShareUtil;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 查询app更新信息
 */
public class QueryAppUpdateImpl extends CSharpHttpUtil {

    private static QueryAppUpdateImpl instance;

    public static QueryAppUpdateImpl getInstance() {
        synchronized (QueryAppUpdateImpl.class) {
            if (instance == null) {
                instance = new QueryAppUpdateImpl();
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "QueryFRAppVersion";
    }

    public void getUpdate(Callback callback) {
        String account = ShareUtil.readString(Constants.LOGIN_USER_KEY, "");
        Map<String, Object> body = new HashMap<>();
        body.put("Account", account);
        body.put("VersionCode", AppUtil.getAppVersionCode(BaseApplication.getAppContext()));
        body.put("Ver", AppUtil.getAppVersionName(BaseApplication.getAppContext()));
        post(body, callback);
    }

    public static abstract class Callback extends GCCallback<VersionInfo> {
        @Override
        public VersionInfo parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject json = new JSONObject(response);
            VersionInfo versionInfo = new VersionInfo();
            versionInfo.setVersionName(json.optString("Ver"));
            versionInfo.setDescribe(json.optString("Describe"));
            versionInfo.setVersionLevel(json.optInt("Level"));
            versionInfo.setAppPath(json.optString("AppPath"));
            versionInfo.setVersionCode(json.optInt("VersionCode"));
            if (!TextUtils.isEmpty(versionInfo.getVersionName()) && !TextUtils.isEmpty(versionInfo.getAppPath())) {
                return versionInfo;
            }
            return null;
        }
    }
}
