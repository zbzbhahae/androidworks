package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;

import java.util.HashMap;
import java.util.Map;

/**
 * 删除 创建站点默认模板中的小区
 */
public class DeleteStationCellImpl extends CSharpHttpUtil {

    private static DeleteStationCellImpl instance;

    public static DeleteStationCellImpl getInstance() {
        synchronized (DeleteStationCellImpl.class) {
            if (instance == null) {
                instance = new DeleteStationCellImpl();
            }
        }
        return instance;
    }
    @Override
    protected String getMessageName() {
        return "DeleteStationTmplateInfo";
    }

    public void deleteStationCell(String templateId, String cellId, Callback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("Templateid", templateId);
        body.put("CellId", cellId);
        post(body, callback);
    }

    public static abstract class Callback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            return null;
        }
    }
}
