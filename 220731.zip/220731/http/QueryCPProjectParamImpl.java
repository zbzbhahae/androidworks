package com.huawei.genexcloud.survey.http;

import android.text.Html;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.SiteParam;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.http.util.HttpErrorException;
import com.huawei.genexcloud.survey.util.TestUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 查询平台 指定项目 分组下的指定任务工参的所有工参数据 外部GC接口
 */
public class QueryCPProjectParamImpl extends GCPTHttpUtil {

    private static QueryCPProjectParamImpl instance;

    public static QueryCPProjectParamImpl getInstance() {
        synchronized (QueryCPProjectParamImpl.class) {
            if (instance == null) {
                instance = new QueryCPProjectParamImpl();
            }
        }
        return instance;
    }

    @Override
    public String getUrlMessage() {
//        return "/genex/g5prediction-service/ASPCovPredict/CPProjectParam";
        return "/genexcloud/general/showProjectIDNameList.do";
    }

    /**
     * @param projectId 项目信息
     * @param taskId    任务信息
     * @param callback
     */
    public void getSiteParam(String projectId, String taskId, SiteParamCallback callback) {
        Map<String, String> headers = getHeaders(projectId);
        String jsonBody = "";
        try {
            JSONObject json = new JSONObject();
            json.put("taskId", taskId);
            jsonBody = json.toString();
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }

        postSingle(instance, jsonBody, callback);
    }

    public static abstract class SiteParamCallback extends GCCallback<List<SiteParam>> {
        public abstract String getProjectId();

        public abstract String getGroupId();

        @Override
        public List<SiteParam> parseNetworkResponse(@NonNull String response) throws Exception {
            response = TestUtil.getSiteData();
            JSONObject jsonObject = new JSONObject(response);
            int resultCode = jsonObject.optInt("resultCode");
            String resultMessage = jsonObject.optString("resultMessage");
            if (resultCode != 20000) {
                ErrorBean eb = new ErrorBean(ErrorBean.ERROR_NOT_SUCCESS, (TextUtils.isEmpty(resultMessage) ? "访问数据失败" : resultMessage), new Exception());
                HttpErrorException e = new HttpErrorException(eb);
                throw e;
            }
            // 访问成功

            List<SiteParam> site5GInfos = new ArrayList<>();

            String data = "";
            if (jsonObject.has("data")) {
                data = jsonObject.optString("data");
            }
            // 无数据
            if (TextUtils.isEmpty(data) || "null".equals(data)) {
                return null;
            }

            String errorMessage = "";
            String task_id = "";
            JSONObject resultObject = new JSONObject(data);

            if (resultObject.has("taskId")) {
                task_id = resultObject.optString("taskId");
            }
            String groupId = getGroupId();

            if (resultObject.has("CPProjectParam")) {
                JSONObject projectObject = resultObject.getJSONObject("CPProjectParam");

                if (projectObject.has("4GProjectParameter")) {
                }

                if (projectObject.has("5GProjectParameter")) {
                    JSONArray array = projectObject.getJSONArray("5GProjectParameter");
                    if (array != null && array.length() > 0) {

                        // 用于存放表头和表头index的map
                        Map<String, Integer> headerParamter = new HashMap<>();

                        String header = array.get(0).toString();
                        header = Html.fromHtml(header).toString();
                        header = header.replaceAll("\\[", "\\[\"").replaceAll(",", "\",\"").replaceAll("\\]", "\\\"]")
                                .replaceAll("\"\"", "\"");
                        JSONArray headerArray = new JSONArray(header);
                        for (int j = 0; j < headerArray.length(); j++) {
                            headerParamter.put(headerArray.getString(j), j);
                        }

                        for (int i = 1; i < array.length(); i++) {
                            String json = array.get(i).toString();
                            json = json.replace("\t", "").replaceAll("\\\\\"", "");

                            json = Html.fromHtml(json).toString();
                            json = json.replaceAll("\\[", "\\[\"").replaceAll(",", "\",\"").replaceAll("\\]", "\\\"]")
                                    .replaceAll("\"\"", "\"").replaceAll(",\",", ",\"\",");
                            JSONArray jsonArray = new JSONArray(json);
                            SiteParam siteParam = parseSiteInfo(jsonArray, headerParamter, getProjectId(), getGroupId());
                            siteParam.setGroupId(groupId);
                            siteParam.setProjectId(Constants.PROJECT_ID);
                            siteParam.setCellStatus("ORIGINAL");
                            site5GInfos.add(siteParam);
                        }
                    }
                }

                //
                List<SiteParam> siteParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                        .queryAllByTaskId(getProjectId(), getGroupId());
                if (siteParams == null || siteParams.size() == 0 || siteParams.size() < site5GInfos.size()) {
                    DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().deleteByTask(getProjectId(), getGroupId());
                    DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().insert(site5GInfos);
                }
                //全量更新平台工参
                DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB()
                        .deleteByTask(getProjectId(), getGroupId());
                DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB().insert(site5GInfos);

                return site5GInfos;
            } else {
                return null;
            }
        }
    }


    private static String replaceString(String result) {
        result = result.replace("\\t", "")
                .replaceAll("\\\\\"", "");
        return result;
    }

    private static SiteParam parseSiteInfo(JSONArray array, Map<String, Integer> headerParamter, String projectId, String groupId) throws JSONException {
        int size = array.length();

        SiteParam info = new SiteParam();
        info.setProjectId(projectId);
        info.setGroupId(groupId);
        info.setSiteName(getValueByTitle(array, headerParamter, "Site Name"));
        info.setSiteLng(getValueByTitle(array, headerParamter, "Site Longitude"));
        info.setSiteLat(getValueByTitle(array, headerParamter, "Site Latitude"));
        info.setAntenna(getValueByTitle(array, headerParamter, "Antenna"));
        info.setAzimuth(getValueByTitle(array, headerParamter, "Azimuth"));
        info.setCellName(getValueByTitle(array, headerParamter, "Cell Name"));
        info.setFrequencyBand(getValueByTitle(array, headerParamter, "Frequency Band"));
        if (headerParamter.get("DlBandwidth(MHz)") != null) {
            info.setDlBandwidth(getValueByTitle(array, headerParamter, "DlBandwidth(MHz)"));
        }

        if (headerParamter.get("DlBandwidth") != null) {
            info.setDlBandwidth(getValueByTitle(array, headerParamter, "DlBandwidth"));
        }

        info.setSiteId(Integer.parseInt(getValueByTitle(array, headerParamter, "Site ID")));
        info.setCellId(Integer.parseInt(getValueByTitle(array, headerParamter, "Cell ID")));

        info.setDlEarfcn(getValueByTitle(array, headerParamter, "DlEarfcn"));
        info.setRRUName(getValueByTitle(array, headerParamter, "RRU Name"));
        info.setBEAMSCENARIO(getValueByTitle(array, headerParamter, "BEAMSCENARIO"));
        info.setRSPower(getValueByTitle(array, headerParamter, "RS Power"));
        info.setAntennaLng(getValueByTitle(array, headerParamter, "Antenna Longitude"));
        info.setAntennaLat(getValueByTitle(array, headerParamter, "Antenna Latitude"));
        info.setHeight(getValueByTitle(array, headerParamter, "Height"));
        info.setMechanicalDowntilt(getValueByTitle(array, headerParamter, "Mechanical Downtilt"));
        info.setTotalLossDL(getValueByTitle(array, headerParamter, "Total Loss(DL)"));
        String InputTotalLoss = getValueByTitle(array, headerParamter, "Input Total Loss");
        info.setInputTotalLoss("TRUE".equals(InputTotalLoss) || "true".equals(InputTotalLoss) || "1".equals(InputTotalLoss));

        String Active = getValueByTitle(array, headerParamter, "Active");
        info.setActive("TRUE".equals(Active) || "true".equals(Active) || "1".equals(Active));
        info.setActualLoadUL(getValueByTitle(array, headerParamter, "Actual Load(UL)"));
        info.setPDSCHActualLoadDL(getValueByTitle(array, headerParamter, "PDSCH Actual Load(DL)"));
        info.setNeighbourPDSCHLoad(getValueByTitle(array, headerParamter, "Neighbour PDSCH Load"));
        info.setMainPropagationModel(getValueByTitle(array, headerParamter, "Main Propagation Model"));
        info.setPCI(getValueByTitle(array, headerParamter, "PCI"));
        info.setUlEarfcn(getValueByTitle(array, headerParamter, "UlEarfcn"));
        info.setSiteEquipment(getValueByTitle(array, headerParamter, "Site Equipment"));
        info.setNumberTransmissionAntennas(getValueByTitle(array, headerParamter, "Number of Transmission Antennas"));
        if (headerParamter.get("UlBandwidth(MHz)") != null) {
            info.setUlBandwidth(getValueByTitle(array, headerParamter, "UlBandwidth(MHz)"));
        }

        if (headerParamter.get("UlBandwidth") != null) {
            info.setUlBandwidth(getValueByTitle(array, headerParamter, "UlBandwidth"));
        }

        info.setNumberReceptionAntennas(getValueByTitle(array, headerParamter, "Number of Reception Antennas"));
        info.setTotalLossUL(getValueByTitle(array, headerParamter, "Total Loss(UL)"));
        info.setMainCalculationRadius(getValueByTitle(array, headerParamter, "Main Calculation Radius"));
        if (headerParamter.containsKey("IoT(UL)")) {
            info.setIoTUL(getValueByTitle(array, headerParamter, "IoT(UL)"));
        } else if (headerParamter.containsKey("IoT(UL)(dB)")) {
            info.setIoTUL(getValueByTitle(array, headerParamter, "IoT(UL)(dB)"));
        }
        info.setPDSCHToRS(getValueByTitle(array, headerParamter, "PDSCH to RS"));
        info.setCSIToRS(getValueByTitle(array, headerParamter, "CSI to RS"));
        info.setSSIToRS(getValueByTitle(array, headerParamter, "SS to RS"));
        info.setFrameConfiguration(getValueByTitle(array, headerParamter, "Frame Configuration"));
        info.setFramepParameter(getValueByTitle(array, headerParamter, "Frame Parameter"));
        String DCSwitch = getValueByTitle(array, headerParamter, "DCSwitch");
        info.setDCSwitch("TRUE".equals(DCSwitch) || "true".equals(DCSwitch) || "1".equals(DCSwitch));

        info.setCASwitchDL(getValueByTitle(array, headerParamter, "CA Switch(DL)"));
        info.setCASwitchUL(getValueByTitle(array, headerParamter, "CA Switch(UL)"));
        info.setDigitalDowntilt(getValueByTitle(array, headerParamter, "Digital Downtilt"));
        info.setDigitalAzimuth(getValueByTitle(array, headerParamter, "Digital Azimuth"));
        info.setDSSSwitch(getValueByTitle(array, headerParamter, "DSS Switch"));
        info.setDSSShareRatio(getValueByTitle(array, headerParamter, "DSS Share Ratio"));
        info.setULCompSwitch(getValueByTitle(array, headerParamter, "UL Comp Switch"));
        info.setInterSiteCA(getValueByTitle(array, headerParamter, "Inter-site CA"));
        return info;
    }

    private static String getValueByTitle(JSONArray array, Map<String, Integer> headerMap, String title) {
        if (null == array || 0 == array.length() || TextUtils.isEmpty(title) || null == headerMap || headerMap.isEmpty()) {
            return "";
        }
        Integer index = headerMap.get(title);
        if (null == index) {
            return "";
        }
        if (index < 0 || index > (array.length() - 1)) {
            return "";
        }
        return array.optString(index);
    }


}
