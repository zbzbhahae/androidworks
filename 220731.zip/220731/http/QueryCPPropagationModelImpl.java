package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.ModelBean;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.util.ShareUtil;
import com.huawei.genexcloud.survey.util.TestUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取平台传递模型 数据
 */
public class QueryCPPropagationModelImpl extends GCPTHttpUtil {

    private static QueryCPPropagationModelImpl instance;

    public static QueryCPPropagationModelImpl getInstance() {
        synchronized (QueryCPPropagationModelImpl.class) {
            if (instance == null) {
                instance = new QueryCPPropagationModelImpl();
            }
        }
        return instance;
    }

    @Override
    protected String getUrlMessage() {
//        return "/genex/g5commonapp-service/ASPCovPredict/CPGetPropagationModelList";
        return "/genexcloud/general/showProjectIDNameList.do";
    }

    public void getPropagationModelData(String projectId, String taskId) {
        String jsonBody = null;
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("taskId", taskId);
            jsonObject.put("network", "NR");
        } catch (JSONException e) {
            GCLogger.error("http", "getPropagationModelData JSONException " + e);
        }
        post(jsonObject.toString(), new Callback(projectId, taskId));
    }

    public static class Callback extends GCCallback<Void> {

        private String taskId, projectId;

        public Callback(String projectId, String taskId) {
            this.taskId = taskId;
            this.projectId = projectId;
        }

        @Override
        public void onFailure(ErrorBean e) {
            GCLogger.error("http", "查询传播模型失败");
        }

        @Override
        public void onResponse(Void response) {

        }

        @Override
        public Void parseNetworkResponse(@NonNull String response) throws Exception {
            response = TestUtil.getPropagationModelData();
            int resultCode = -1;
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.has("resultCode")) {
                resultCode = jsonObject.optInt("resultCode");
            }

            if (resultCode != 20000) {
                return null;
            }
            List<ModelBean> modelBeanList = new ArrayList<>();
            if (!jsonObject.has("data")) {
                return null;
            }

            JSONObject dataJson =jsonObject.optJSONObject("data");

            if (dataJson.has("propagationModelList")) {
                JSONArray array = dataJson.getJSONArray("propagationModelList");
                if (array != null && array.length() > 0) {
                    for (int i = 0; i < array.length(); i++) {
                        ModelBean bean = new ModelBean();
                        bean.setProjectId(ShareUtil.readString("projectId", ""));
                        bean.setTaskId(taskId);
                        bean.setType("NR");
                        bean.setModelName(array.get(i).toString());

                        modelBeanList.add(bean);
                    }
                }

                DBManager.getInstance(BaseApplication.getAppContext()).getModelDB()
                        .delete(projectId, taskId, "NR");
                DBManager.getInstance(BaseApplication.getAppContext()).getModelDB().insert(modelBeanList);
            }
            return null;
        }
    }
}
