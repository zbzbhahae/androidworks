package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.util.ShareUtil;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 设置默认模板
 */
public class SetDefaultTemplateImpl extends CSharpHttpUtil {

    private static SetDefaultTemplateImpl instance;

    public static SetDefaultTemplateImpl getInstance() {
        if (null == instance) {
            synchronized (SetDefaultTemplateImpl.class) {
                if (null == instance) {
                    instance = new SetDefaultTemplateImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "SetDefaultTemplate";
    }

    public void setDefaultTemplate(String templateId, Callback callback) {
        String account = ShareUtil.readString(Constants.LOGIN_USER_KEY);
        Map<String, Object> body = new HashMap<>();
        body.put("Account", account);
        body.put("TemplateId", templateId);
        post(body, callback);
    }

    public static abstract class Callback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject json = new JSONObject(response);
            if (220 == json.optInt("StatusCode")) {
                return true;
            }
            return false;
        }
    }
}
