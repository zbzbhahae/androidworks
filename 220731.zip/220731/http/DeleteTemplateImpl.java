package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 删除模板
 */
public class DeleteTemplateImpl extends CSharpHttpUtil {

    private static DeleteTemplateImpl instance;

    public static DeleteTemplateImpl getInstance() {
        synchronized (DeleteTemplateImpl.class) {
            if (instance == null) {
                instance = new DeleteTemplateImpl();
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "DeleteTemplate";
    }

    public void deleteTemplate(String templateId, Callback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("TemplateId", templateId);
        post(body, callback);
    }

    public static abstract class Callback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject json = new JSONObject(response);
            if (220 == json.optInt("StatusCode")) {
                return true;
            }
            return false;
        }
    }
}
