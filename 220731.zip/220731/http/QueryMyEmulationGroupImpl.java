package com.huawei.genexcloud.survey.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.log.Module;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.util.ShareUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 获取用户的仿真任务信息 从kance后台
 */
public class QueryMyEmulationGroupImpl extends CSharpHttpUtil {

    private static QueryMyEmulationGroupImpl instance;

    public static QueryMyEmulationGroupImpl getInstance() {
        if (null == instance) {
            synchronized (QueryMyEmulationGroupImpl.class) {
                if (null == instance) {
                    instance = new QueryMyEmulationGroupImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "QueryMyEmulationGroup";
    }

    public void getMyEmulationGroup(Callback callback) {
        String account = ShareUtil.readString(Constants.LOGIN_USER_KEY);
        if (null != callback) {
            callback.userId = account;
        }
        Map<String, Object> body = new HashMap<>();
        body.put("Account", account);
        post(body, callback);
    }

    public static abstract class Callback extends GCCallback<List<EmulationEntrance>> {

        public String userId;

        @Override
        public List<EmulationEntrance> parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject json = new JSONObject(response);
            if (!json.has("JsonData")) {
                return null;
            }
            List<EmulationEntrance> emulationEntrances = new ArrayList<>();
            JSONArray array = json.optJSONArray("JsonData");
            if (array != null && array.length() > 0) {
                Gson gson = new Gson();
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    EmulationEntrance emulationEntrance = gson.fromJson(object.toString(), EmulationEntrance.class);
                    emulationEntrances.add(emulationEntrance);
                }
            }
            //更新仿真任务表
            if (emulationEntrances != null && emulationEntrances.size() > 0 && !TextUtils.isEmpty(userId)) {
                DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB()
                        .deleteByAccount(userId);
                DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB()
                        .insert(emulationEntrances);
            }
            return emulationEntrances;
        }
    }
}
