package com.huawei.genexcloud.survey.http;

import android.os.Message;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.ProjectInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.util.TestUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取用户项目id列表
 */
public class QueryCPProjectImpl extends GCPTHttpUtil {

    private static QueryCPProjectImpl instance;

    public static QueryCPProjectImpl getInstance() {
        if (null == instance) {
            synchronized (QueryCPProjectImpl.class) {
                if (null == instance) {
                    instance = new QueryCPProjectImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getUrlMessage() {
        return "/genexcloud/general/showProjectIDNameList.do";
    }

    public void getUserProjects(Callback callback) {
        postSingle(instance, "{}", callback);
    }

    public static abstract class Callback extends GCCallback<List<ProjectInfo>> {
        @Override
        public List<ProjectInfo> parseNetworkResponse(@NonNull String response) throws Exception {
            // todo
            response = TestUtil.getProjectIdData();
            List<ProjectInfo> projectInfos = new ArrayList<>();
            if (!TextUtils.isEmpty(response) && !Constants.NO_LIMIT.equals(response)) {
                JSONArray array = new JSONArray(response);
                if (array != null && array.length() > 0) {

                    for (int i = 0; i < array.length(); i++) {
                        ProjectInfo projectInfo = new ProjectInfo();
                        JSONObject jsonObject = array.getJSONObject(i);
                        if (jsonObject.has("proofDeadline")) {
                            projectInfo.setProofDeadline(jsonObject.optString("proofDeadline"));
                        }
                        if (jsonObject.has("projectId")) {
                            projectInfo.setProjectId(jsonObject.optString("projectId"));
                        }
                        if (jsonObject.has("projectName")) {
                            projectInfo.setProjectName(jsonObject.optString("projectName"));
                        }
                        if (jsonObject.has("projectManager")) {
                            projectInfo.setProjectManager(jsonObject.optString("projectManager"));
                        }

                        projectInfos.add(projectInfo);
                    }
                }
                return projectInfos;
            }
            return null;
        }
    }
}
