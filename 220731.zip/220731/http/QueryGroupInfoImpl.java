package com.huawei.genexcloud.survey.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.TaskInfo;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.http.util.HttpErrorException;
import com.huawei.genexcloud.survey.util.TestUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 查询项目下的分组信息
 */
public class QueryGroupInfoImpl extends GCPTHttpUtil {

    private static QueryGroupInfoImpl instance;

    public static QueryGroupInfoImpl getInstance() {
        synchronized (QueryGroupInfoImpl.class) {
            if (instance == null) {
                instance = new QueryGroupInfoImpl();
            }
        }
        return instance;
    }

    @Override
    public String getUrlMessage() {
//        return "/genex/g5prediction-service/ASPCovPredict/CPGroupInfoList";
        return "/genexcloud/general/showProjectIDNameList.do";
    }

    /**
     * 查询项目下的分组信息
     *
     * @param projectId
     * @param callback
     */
    public void getGroupInfoList(String projectId, GroupListCallback callback) {
        if (TextUtils.isEmpty(projectId)) {
            ErrorBean errorBean = new ErrorBean();
            errorBean.message = "无法获取项目ID";
            callback.onAfter();
            callback.onFailure(errorBean);
            return;
        }
        String jsonBody = null;
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("projectId", projectId);
            jsonBody = jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        GCLogger.error("http", "查询分组信息参数:" + jsonBody);
        postSingle(instance, getHeaders(projectId), jsonBody, callback);
    }

    public static abstract class GroupListCallback extends GCCallback<List<TaskInfo>> {
        @Override
        public List<TaskInfo> parseNetworkResponse(@NonNull String result) throws Exception {
            result = TestUtil.getGroupData();
            List<TaskInfo> groupInfos = new ArrayList<>();
            String data = "";
            if (result.contains("data")) {
                JSONObject jsonObject = new JSONObject(result);
                data = jsonObject.optString("data");
            }

            String errorMessage = "";
            JSONObject resultObject = new JSONObject(data);

            String projectId = resultObject.optString("projectId");

            String operatorId = resultObject.optString("operatorId");

            if (resultObject.has("groupInfos")) {
                JSONObject groupListObject = resultObject.getJSONObject("groupInfos");

                JSONArray groupList = groupListObject.getJSONArray("data");

                if (groupList != null && groupList.length() > 0) {
                    for (int i = 0; i < groupList.length(); i++) {
                        JSONObject groupObject = groupList.getJSONObject(i);

                        String groupId = "";
                        String groupName = "";
                        if (groupObject.has("groupId")) {
                            groupId = groupObject.getString("groupId");
                        }

                        if (groupObject.has("groupName")) {
                            groupName = groupObject.getString("groupName");
                        }
                        TaskInfo taskInfo = null;
                        if (groupObject.has("taskInfos")) {
                            JSONArray array = groupObject.getJSONArray("taskInfos");
                            JSONObject jsonObject = null;
                            if (array != null && array.length() > 0) {
                                for (int j = 0; j < array.length(); j++) {
                                    taskInfo = new TaskInfo();
                                    taskInfo.setProjectId(projectId);
                                    taskInfo.setGroupId(groupId);
                                    taskInfo.setGroupName(groupName);
                                    jsonObject = array.getJSONObject(j);

                                    if (jsonObject.has("taskId")) {
                                        taskInfo.setTaskId(jsonObject.getString("taskId"));
                                    }

                                    if (jsonObject.has("taskName")) {
                                        taskInfo.setTaskName(jsonObject.getString("taskName"));
                                    }
                                    if (jsonObject.has("createTime")) {
                                        taskInfo.setCreateTime(jsonObject.getString("createTime"));
                                    }

                                    if (jsonObject.has("createUser")) {
                                        taskInfo.setCreator(jsonObject.getString("createUser"));
                                    }

                                    taskInfo.setOperatorId(operatorId);

                                    groupInfos.add(taskInfo);
                                }
                            }
                        }
                    }
                }

                //更新任务列表
                DBManager.getInstance(BaseApplication.getAppContext()).getGroupInfoDB().deleteAll();
                DBManager.getInstance(BaseApplication.getAppContext()).getGroupInfoDB().insert(groupInfos);
            } else {
                if (resultObject.has("errorMessage")) {
                    errorMessage = resultObject.optString("errorMessage");
                }
                ErrorBean errorBean = new ErrorBean();
                errorBean.message = errorMessage;
                throw new HttpErrorException(errorBean);
            }
            return groupInfos;
        }
    }
}
