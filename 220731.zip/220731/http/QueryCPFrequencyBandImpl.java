package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.FrequencyBandInfo;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.survey.base.BaseApplication;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.util.ShareUtil;
import com.huawei.genexcloud.survey.util.TestUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 查询平台功率带宽信息
 */
public class QueryCPFrequencyBandImpl extends GCPTHttpUtil {

    private static QueryCPFrequencyBandImpl instance;

    public static QueryCPFrequencyBandImpl getInstance() {
        synchronized (QueryCPFrequencyBandImpl.class) {
            if (instance == null) {
                instance = new QueryCPFrequencyBandImpl();
            }
        }
        return instance;
    }

    @Override
    protected String getUrlMessage() {
        return "/genex/g5commonapp-service/ASPCovPredict/CPGetFrequencyBandInfo";
    }

    public void getFrequencyBand(String projectId, String taskId) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("taskId", taskId);
            jsonObject.put("network", "NR");
        } catch (JSONException e) {
            GCLogger.error("http", "getFrequencyBand 构造参数出错 " + e);
        }
        post(jsonObject.toString(), new Callback(projectId, taskId));
    }

    public static class Callback extends GCCallback<Void> {

        private String taskId, projectId;

        public Callback(String projectId, String taskId) {
            this.taskId = taskId;
            this.projectId = projectId;
        }

        @Override
        public void onFailure(ErrorBean e) {
            GCLogger.error("http", "查询平台功率带宽信息失败");
        }

        @Override
        public void onResponse(Void response) {

        }

        @Override
        public Void parseNetworkResponse(@NonNull String response) throws Exception {
            response = TestUtil.getFrequencyBandData();
            int resultCode = -1;
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.has("resultCode")) {
                resultCode = jsonObject.optInt("resultCode");
            }

            if (resultCode != 20000) {
                return null;
            }
            List<FrequencyBandInfo> modelBeanList = new ArrayList<>();
            if (!jsonObject.has("data")) {
                return null;
            }

            JSONObject dataJson = jsonObject.optJSONObject("data");

            if (dataJson.has("frequencyBandInfo")) {
                JSONArray array = dataJson.getJSONArray("frequencyBandInfo");
                if (array != null && array.length() > 0) {
                    for (int i = 0; i < array.length(); i++) {
                        FrequencyBandInfo bean = new FrequencyBandInfo();
                        bean.setProjectId(ShareUtil.readString("projectId", ""));
                        bean.setTaskId(taskId);
                        bean.setType("NR");
                        bean.setBandName(array.get(i).toString());

                        modelBeanList.add(bean);
                    }
                }

                DBManager.getInstance(BaseApplication.getAppContext()).getBandDB()
                        .delete(projectId, taskId, "NR");
                DBManager.getInstance(BaseApplication.getAppContext()).getBandDB().insert(modelBeanList);

            }
            return null;
        }
    }
}
