package com.huawei.genexcloud.survey.activity;

import android.content.Intent;
import android.graphics.BitmapFactory;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.huawei.genexcloud.framework.base.BaseActivity;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.base.IBaseResultLinstener;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.bean.RoundImage;
import com.huawei.genexcloud.framework.bean.TemplateInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.UploadStationImgUtil;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.util.ImageUtils;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.framework.util.TimeUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.views.BeamWidthView;
import com.huawei.genexcloud.survey.views.EstimationBuildingsView;
import com.huawei.genexcloud.survey.views.MacroSiteLinkView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 效果预估界面
 */
public class EffectivenessPredictionActivity extends BaseActivity implements View.OnClickListener {

    private Spinner spinner;
    private LinearLayout llContent;
    private EstimationBuildingsView buildingsView;
    private MacroSiteLinkView modelView;
    private String currentSite;
    private String currentSiteName;
    private TemplateInfo bean;
    private int type;
    private Intent intent;
    private ImageView ivToolGuide;
    private String groupId;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_effectiveness_prediction;
    }

    @Override
    protected void initView() {
        findViewById(R.id.back).setOnClickListener(this);
        findViewById(R.id.tv_power).setOnClickListener(this);
        llContent = (LinearLayout) findViewById(R.id.ll_content);
        spinner = (Spinner) findViewById(R.id.spinner_eff);
        spinner.setAdapter(getAdapter(R.array.effectiveness_rediction));
        buildingsView = new EstimationBuildingsView(this);
        modelView = new MacroSiteLinkView(this);
        ivToolGuide = (ImageView) findViewById(R.id.iv_tool_guide);
        ivToolGuide.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        intent = getIntent();
        groupId = intent.getStringExtra("groupId");
        currentSite = intent.getStringExtra("station");
        currentSiteName = intent.getStringExtra("siteName");
        type = intent.getIntExtra("type", 0); //0是网上无截图，1是有

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView tv = (TextView) view;
                tv.setTextColor(
                        ContextCompat.getColor(EffectivenessPredictionActivity.this, R.color.home_item_text_color));
                tv.setTextSize(13);
                String text = tv.getText().toString();
                tv.setText(text);
                llContent.removeAllViews();
                if (spinner.getSelectedItemPosition() == 0) {
                    llContent.addView(buildingsView.getView(groupId, currentSite, currentSiteName));
                } else if (spinner.getSelectedItemPosition() == 1) {
                    llContent.addView(modelView.getView(groupId, currentSite, currentSiteName));
                } else if (spinner.getSelectedItemPosition() == 2) {
                    llContent.addView(new BeamWidthView(EffectivenessPredictionActivity.this).getView(groupId, currentSite, currentSiteName));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        bean = DBManager.getInstance(this).getSiteTemplateDB().queryAllByTaskId(groupId, currentSite);
    }

    public ArrayAdapter getAdapter(int arrayID) {
        ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource(this, arrayID, R.layout.spinner_layout);
        arrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        return arrayAdapter;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                setResult(RESULT_OK, intent);
                this.finish();
                break;
            case R.id.tv_power:
                updatePicture();
                break;
            case R.id.iv_tool_guide:
                Intent intent = new Intent(this, SurveyFunActivity.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    private void updatePicture() {
        final List<String> imageList = new ArrayList<>();

        final List<RoundImage> images = DBManager.getInstance(EffectivenessPredictionActivity.this).getImageDBImpl()
                .queryRoundImages(groupId, currentSite + "", "Render");
        if (images == null || images.size() == 0) {
            showToast("请先计算");
            return;

        }
        createLoadingDialog(this, this, "", false);
        for (int i = 0; i < images.size(); i++) {
            String path = images.get(i).getPath() + File.separator + images.get(i).getName();
            String imageInfo = ImageUtils.bitmapToBase64(BitmapFactory.decodeFile(path));
            imageList.add(imageInfo);
        }

        final EmulationEntrance bean = new EmulationEntrance();
        bean.setAccount(SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.LOGIN_USER_KEY, ""));
        bean.setRecordtime(TimeUtil.getCurrentDate1());
        JSONObject json = new JSONObject();
        try {
            json.put("ProjectId", Constants.PROJECT_ID);
            json.put("GroupId", groupId);
            json.put("Site_ID", currentSite);
            json.put("ImgType", "ResultEstimate"); // 图片的类型 EnterStation, Station360View, ComputerRoom, TowerMastPlatfond,  ResultEstimate,
            json.put("ImgList", getImgList(imageList)); // 图片Base64列表
            if (0 == type) {
                json.put("UploadType", 0); // 存储方式，0往路径中加，1更新路劲中的图片
            } else if (1 == type) {
                json.put("UploadType", 1); // 存储方式，0往路径中加，1更新路劲中的图片
            }

        } catch (JSONException e) {
            GCLogger.error("error", e.toString());
        }
        UploadStationImgUtil.getInstance().asyncExecute(json.toString(), new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                if (resultError.startsWith("网络异常")) {
                    showToast(resultError);
                } else {
                    showToast("预估照片上传失败");
                }
                closeLoadDialog();
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                showToast("预估图上传成功");
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
                showToast("预估图上传成功");
                Intent intent = new Intent(EffectivenessPredictionActivity.this, EffectDetailsActivity.class);
                intent.putExtra("info", bean);
                intent.putExtra("siteName", currentSiteName);
                intent.putExtra("imageList", (Serializable) images);
                startActivity(intent);

                finish();
            }

        });

    }

    private JSONArray getImgList(List<String> imgList) {
        JSONArray array = new JSONArray();

        if (imgList == null || imgList.size() == 0) {
            return array;
        } else {
            for (int i = 0; i < imgList.size(); i++) {
                array.put(imgList.get(i));
            }
        }
        return array;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setResult(RESULT_OK, intent);
        this.finish();
    }
}
