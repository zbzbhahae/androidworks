package com.huawei.genexcloud.adapter;

import android.content.pm.PackageInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.apply.ApplyBean;
import com.huawei.genexcloud.apply.ApplyBean.ApplyAppBean;
import com.huawei.genexcloud.apply.CustomProgressBar;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.databinding.ListItemApplicationBinding;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.download.DownloadManager;
import com.huawei.genexcloud.http.download.DownloadState;
import com.huawei.genexcloud.http.downloader.DownloadListener;
import com.huawei.genexcloud.http.downloader.DownloadStatus;
import com.huawei.genexcloud.http.downloader.DownloadTask;
import com.huawei.genexcloud.http.downloader.SimpleDownloadListener;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.util.PathUtil;
import com.huawei.genexcloud.util.ShareDataUtil;
import com.jeremyliao.liveeventbus.LiveEventBus;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplicationAdapter extends RecyclerView.Adapter<ApplicationAdapter.MyViewHolder> {

    private List<ApplyAppBean> listData;

    public void setData(List<ApplyBean> data) {
        combineList(data);
        notifyDataSetChanged();
    }

    private void combineList(List<ApplyBean> data) {
        if (null != data && 0 != data.size()) {
            listData = new ArrayList<>();
            for (ApplyBean applyBean : data) {
                listData.addAll(applyBean.getAppList());
            }
        } else {
            listData = null;
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ListItemApplicationBinding binding = ListItemApplicationBinding
                .inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        if (0 == position) {
            // 第一条或者分类与上一条不同 则显示标题
            holder.binding.category.setVisibility(View.VISIBLE);
        } else {
            String lastCategory = listData.get(position - 1).getCategoryName();
            String categoryName = listData.get(position).getCategoryName();
            if (!lastCategory.equals(categoryName)) {
                holder.binding.category.setVisibility(View.VISIBLE);
            } else {
                holder.binding.category.setVisibility(View.GONE);
            }
        }
        ApplyAppBean bean = listData.get(position);
        holder.binding.category.setText(bean.getCategoryName());
        holder.binding.category.setText(bean.getCategoryName());

        holder.binding.contentLayout.setVisibility(View.VISIBLE);
        holder.binding.name.setText(bean.getAppName() + " " + bean.getVersion());
        holder.binding.simpleDesc.setText(bean.getSimpleDescription());
        holder.binding.icon.setImageURI(bean.getImageUrl());

        DownloadEntry entry = bean.getDownloadEntry();
        Observer<DownloadEntry> observer = new Observer<DownloadEntry>() {
            @Override
            public void onChanged(DownloadEntry downloadEntry) {
                if (null != downloadEntry && downloadEntry.getUrl().equals(entry.getUrl())) {
                    if (entry != downloadEntry) {
                        bean.setDownloadEntry(downloadEntry);
                    }
                    setView(holder, downloadEntry, bean);
                }
            }
        };

        if (null != holder.binding.getRoot().getTag()) {
            LiveEventBus.get(DownloadEntry.class).removeObserver((Observer<DownloadEntry>) holder.binding.getRoot().getTag());
        }
        holder.binding.getRoot().setTag(observer);

        LiveEventBus.get(DownloadEntry.class).observeForever(observer);
        setView(holder, entry, bean);
    }

    private void setView(MyViewHolder holder, DownloadEntry entry, ApplyAppBean bean) {
        PackageInfo info;
        switch (entry.getState()) {
            case DownloadState.STATE_IDLE:
            case DownloadState.STATE_FAILED:
                // 检查安装状态
                info = AppUtil.checkAppInstalled(holder.binding.getRoot().getContext(), bean.getPackageName());
                if (null != info && !AppUtil.checkVersionCode(info.versionName, bean.getVersion())) {
                    holder.binding.installButton.setState(CustomProgressBar.STATE_INSTALLED);
                    holder.binding.installButton.setOnClickListener(v->{
                        AppUtil.openInstalledApk(v.getContext(), bean.getPackageName());
                    });
                    GCLogger.error("view", "打开");
                } else if (null == info) {
                    // 未安装过应用 提示下载
                    holder.binding.installButton.setState(CustomProgressBar.STATE_DEFAULT);
                    holder.binding.installButton.setOnClickListener(v->{
                        DownloadManager.getInstance().download(entry);
                    });
                    GCLogger.error("view", "需要下载");
                } else {
                    // 安装了应用 需要更新
                    holder.binding.installButton.setState(CustomProgressBar.STATE_NEED_UPDATE);
                    holder.binding.installButton.setOnClickListener(v->{
                        DownloadManager.getInstance().download(entry);
                    });
                }
                break;
            case DownloadState.STATE_WAIT:
                holder.binding.installButton.setState(CustomProgressBar.STATE_DOWNLOADING);
                holder.binding.installButton.setProgress(0);
                holder.binding.installButton.setOnClickListener(v->{
                    // 加入下载 等待下载开始 点击取消
                    DownloadManager.getInstance().cancel(entry);
                });
                GCLogger.error("view", "下载连接中");
                break;
            case DownloadState.STATE_DOWNLOADING:
                holder.binding.installButton.setState(CustomProgressBar.STATE_DOWNLOADING);
                holder.binding.installButton.setProgress((int) (entry.getCurrentLength() * 1f / entry.getLength() * 100));
                holder.binding.installButton.setOnClickListener(v->{
                    // 下载中 点击取消
                    DownloadManager.getInstance().cancel(entry);
                });
                GCLogger.error("view", "下载中");
                break;
            case DownloadState.STATE_SUCCESS:
                // 检查安装状态
                info = AppUtil.checkAppInstalled(holder.binding.getRoot().getContext(), bean.getPackageName());
                if (null != info && !AppUtil.checkVersionCode(info.versionName, bean.getVersion())) {
                    holder.binding.installButton.setState(CustomProgressBar.STATE_INSTALLED);
                    holder.binding.installButton.setOnClickListener(v->{
                        // 下载完成且已安装
                        AppUtil.openInstalledApk(v.getContext(), bean.getPackageName());
                    });
                    GCLogger.error("view", "下载完成可打开");
                } else {
                    holder.binding.installButton.setState(CustomProgressBar.STATE_DOWNLOAD_FINISH);
                    holder.binding.installButton.setOnClickListener(v->{
                        // 下载完成未安装
                        AppUtil.installAPK(v.getContext(), entry.getPath());
                    });
                    GCLogger.error("view", "下载完成未安装");
                }
                break;
        }
    }

    @Override
    public int getItemCount() {
        return null == listData ? 0 : listData.size();
    }



    protected class MyViewHolder extends RecyclerView.ViewHolder {

        private ListItemApplicationBinding binding;

        public MyViewHolder(ListItemApplicationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }


}
