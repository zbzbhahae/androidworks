package com.huawei.genexcloud.http;


import androidx.annotation.NonNull;

import com.huawei.genexcloud.apply.ApplyBean;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.util.GCCallback;
import com.huawei.genexcloud.http.util.JavaHttpUtil;
import com.huawei.genexcloud.util.PathUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 主页 应用界面 获取推荐应用列表
 * (干扰排查  智能勘测  RF勘测等)
 */
public class ApplyListImpl extends JavaHttpUtil {

    private static ApplyListImpl instance;

    public static ApplyListImpl getInstance() {
        if (null == instance) {
            synchronized (QueryAllPluginListImpl.class) {
                if (null == instance) {
                    instance = new ApplyListImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "QueryAllAppInfo";
    }


    private final Object tag = new Object();

    public void getAppPluginList(ApplyListCallback callback) {
        postSingle(tag, null, callback);
    }

    public static abstract class ApplyListCallback extends GCCallback<List<ApplyBean>> {
        @Override
        public List<ApplyBean> parseNetworkResponse(@NonNull String response) throws Exception {
            List<ApplyBean> applyList = null;
            JSONObject jsonObject = new JSONObject(response);
            JSONArray dataJson = jsonObject.optJSONArray("JsonData");
            if (null != dataJson && dataJson.length() > 0) {
                applyList = new ArrayList<>();
                for (int i=0; i<dataJson.length(); i++) {
                    JSONObject applyJson = dataJson.optJSONObject(i);
                    ApplyBean applyBean = new ApplyBean();
                    applyBean.setCategoryId(applyJson.optInt("appClassId", -1));
                    applyBean.setCategoryName(applyJson.optString("appClassName", "unknown"));
                    // 无此数值显示的地方
                    applyBean.setAppNum(applyJson.optInt("appNum"));
                    JSONArray appArray = applyJson.optJSONArray("appInfos");
                    if (null != appArray && appArray.length() > 0) {
                        List<ApplyBean.ApplyAppBean> appList = new ArrayList<>();
                        for (int j=0; j<appArray.length(); j++) {
                            JSONObject appJson = appArray.optJSONObject(j);
                            ApplyBean.ApplyAppBean appBean = new ApplyBean.ApplyAppBean();
                            appBean.setAppId(appJson.optInt("appId"));
                            appBean.setAppName(appJson.optString("appName"));
                            appBean.setDownloadUrl(appJson.optString("appPlugPath"));
                            appBean.setAppSize(appJson.optDouble("appSize"));
                            appBean.setAppOwner(appJson.optString("busOwner"));
                            appBean.setDescription(appJson.optString("description"));
                            appBean.setDevOwner(appJson.optString("devOwner"));
                            appBean.setRollOutTime(appJson.optString("goliveTime"));
                            appBean.setImageUrl(PathUtil.formatDownloadPath(appJson.optString("imagePath")));
                            appBean.setPackageName(appJson.optString("packageName"));
                            appBean.setQrcodeUrl(PathUtil.formatDownloadPath(appJson.optString("qrcodePath")));
                            appBean.setSimpleDescription(appJson.optString("simpleDescription"));
                            appBean.setUpdateName(appJson.optString("updateName"));
                            appBean.setUpdateType(appJson.optInt("updateType", -1));
                            appBean.setVersion(appJson.optString("version"));
                            appBean.setCategoryName(applyBean.getCategoryName());
                            // 构建下载entry
                            DownloadEntry entry = new DownloadEntry(appBean.getDownloadUrl(),
                                    appBean.getAppName() + ".apk",
                                    PathUtil.getExternalAppFilePath()
                                            + File.separator + "apply" + File.separator + appBean.getAppName() + ".apk");
                            appBean.setDownloadEntry(entry);
                            appList.add(appBean);
                        }
                        applyBean.setAppList(appList);
                    }
                    // 计算类别下的app数量
                    if (null == applyBean.getAppList() || 0 == applyBean.getAppList().size()) {
                        applyBean.setAppNum(0);
                    } else {
                        applyBean.setAppNum(applyBean.getAppList().size());
                    }
                    applyList.add(applyBean);
                }
            }
            return applyList;
        }
    }

}
