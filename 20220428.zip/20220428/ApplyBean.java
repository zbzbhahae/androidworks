package com.huawei.genexcloud.apply;

import com.google.gson.annotations.SerializedName;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.downloader.DownloadListener;
import com.huawei.genexcloud.http.downloader.DownloadTask;

import java.io.Serializable;
import java.util.List;

/**
 * 首页 应用 推荐应用 bean
 */
public class ApplyBean{

    // app分类类别id
    @SerializedName("appClassId")
    private int categoryId;
    // app分类的名称
    @SerializedName("appClassName")
    private String categoryName;
    // 分类中的app数量
    @SerializedName("appNum")
    private int appNum;
    // 分类中的app的详细列表
    @SerializedName("appInfos")
    private List<ApplyAppBean> appList;

    public static class ApplyAppBean {
        private int appId;
        private String appName;
        private String categoryName;
        @SerializedName("appPlugPath")
        private String downloadUrl;
        @SerializedName("imagePath")
        private String imageUrl;
        // 二维码地址
        @SerializedName("qrcodePath")
        private String qrcodeUrl;
        // 文件大小 MB
        private double appSize;
        // 业务责任人
        @SerializedName("busOwner")
        private String appOwner;
        // 详细描述信息
        private String description;
        // 开发主体
        private String devOwner;
        // 上线时间
        @SerializedName("goliveTime")
        private String rollOutTime;
        private String packageName;
        private String simpleDescription;
        private String updateName;
        private int updateType;
        private String version;

        // 下载任务 缓存
        private DownloadTask downloadTask;
        // 下载监听
        private DownloadListener downloadListener;

        private DownloadEntry downloadEntry;


        public DownloadEntry getDownloadEntry() {
            return downloadEntry;
        }

        public void setDownloadEntry(DownloadEntry downloadEntry) {
            this.downloadEntry = downloadEntry;
        }

        public String getCategoryName() {
            return categoryName;
        }

        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        public DownloadTask getDownloadTask() {
            return downloadTask;
        }

        public void setDownloadTask(DownloadTask downloadTask) {
            this.downloadTask = downloadTask;
        }

        public DownloadListener getDownloadListener() {
            return downloadListener;
        }

        public void setDownloadListener(DownloadListener downloadListener) {
            this.downloadListener = downloadListener;
        }

        public int getAppId() {
            return appId;
        }

        public void setAppId(int appId) {
            this.appId = appId;
        }

        public String getAppName() {
            return appName;
        }

        public void setAppName(String appName) {
            this.appName = appName;
        }

        public String getDownloadUrl() {
            return downloadUrl;
        }

        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getQrcodeUrl() {
            return qrcodeUrl;
        }

        public void setQrcodeUrl(String qrcodeUrl) {
            this.qrcodeUrl = qrcodeUrl;
        }

        public double getAppSize() {
            return appSize;
        }

        public void setAppSize(double appSize) {
            this.appSize = appSize;
        }

        public String getAppOwner() {
            return appOwner;
        }

        public void setAppOwner(String appOwner) {
            this.appOwner = appOwner;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getDevOwner() {
            return devOwner;
        }

        public void setDevOwner(String devOwner) {
            this.devOwner = devOwner;
        }

        public String getRollOutTime() {
            return rollOutTime;
        }

        public void setRollOutTime(String rollOutTime) {
            this.rollOutTime = rollOutTime;
        }

        public String getPackageName() {
            return packageName;
        }

        public void setPackageName(String packageName) {
            this.packageName = packageName;
        }

        public String getSimpleDescription() {
            return simpleDescription;
        }

        public void setSimpleDescription(String simpleDescription) {
            this.simpleDescription = simpleDescription;
        }

        public String getUpdateName() {
            return updateName;
        }

        public void setUpdateName(String updateName) {
            this.updateName = updateName;
        }

        public int getUpdateType() {
            return updateType;
        }

        public void setUpdateType(int updateType) {
            this.updateType = updateType;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getAppNum() {
        return appNum;
    }

    public void setAppNum(int appNum) {
        this.appNum = appNum;
    }

    public List<ApplyAppBean> getAppList() {
        return appList;
    }

    public void setAppList(List<ApplyAppBean> appList) {
        this.appList = appList;
    }
}
