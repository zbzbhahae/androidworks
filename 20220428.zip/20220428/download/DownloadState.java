package com.huawei.genexcloud.http.download;

public interface DownloadState {
    // 空闲中
    int STATE_IDLE = 0;
    // 等待中、队列中
    int STATE_WAIT = 1;
    // 连接中
    int STATE_CONNECTING = 2;
    // 连接成功下载中
    int STATE_DOWNLOADING = 3;
    // 下载完成
    int STATE_SUCCESS = 4;
    // 失败
    int STATE_FAILED = 5;
    // 安装中
    int STATE_INSTALLING = 6;
    // 准备中
    int STATE_PREPARING = 7;
    // 可运行状态
    int STATE_OK = 8;

}
