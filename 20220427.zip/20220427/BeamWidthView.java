package com.huawei.genexcloud.survey.views;

import static com.huawei.genexcloud.framework.common.DataPath.DIR_RENDER;
import static com.huawei.genexcloud.framework.util.EnvironmentInfo.getProductFileDirectory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.bean.RoundImage;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.GCEnvironmentInfo;
import com.huawei.genexcloud.framework.util.ImageUtils;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.R;

import java.io.File;
import java.text.DecimalFormat;

/**
 * 计算水平 垂直 波半角
 */
public class BeamWidthView implements View.OnClickListener {
    private String groupId;
    private String groupName;
    private String siteId;
    private String siteName;
    private final Context mContext;
    private View mView;
    // 整体容器
    private LinearLayout container;

    // 左侧内容
    // 站楼距、 站高、 建筑物高、 楼宽度
    private EditText leftSiteBuildDistanceET, leftSiteHeightET, leftBuildingHeightET, leftBuildingWidthET;
    // 所需垂直波半角、 所需水平波半角
    private TextView leftVerticalBeamWidthTV, leftHorizontalBeamWidthTV;

    // 右侧内容
    // 站楼距、 站高、 建筑物高、 场景垂直博半角
    private EditText rightSiteBuildDistanceET, rightSiteHeightET, rightBuildingHeightET, rightVerticalBeamWidthET;
    // 计算结果： SSB最外层波束上扬角度、 总下倾角、 机械下倾
    private TextView ssbBeamUpAngleTV, dipAngleTV, mechanicalDipAngleTV;

    private Boolean isRightHasData;

    public BeamWidthView(Context mContext) {
        this.mContext = mContext;
    }

    private static double formatDoublePoint(EditText et) {
        double value = Double.parseDouble(et.getText().toString());
        DecimalFormat decimalFormat = new DecimalFormat("######0.0");
        String result = decimalFormat.format(value);
        return Double.parseDouble(result);
    }

    private DecimalFormat valueFormater = new DecimalFormat("#.##");
    private String getStringWithValue(double value) {
        if (Double.isInfinite(value) || Double.isNaN(value)) {
            return "-255";
        } else {
            return valueFormater.format(value);
        }
    }

    public View getView(String taskId, String siteId, String siteName) {
        this.groupId = taskId;
        groupName = DBManager.getInstance(BaseApplication.getAppContext()).getGroupInfoDB()
                .queryAllByGroupId(Constants.PROJECT_ID, groupId).get(0).getGroupName();
        this.siteId = siteId;
        this.siteName = siteName;
        init();
        return mView;
    }

    private void init() {
        mView = LayoutInflater.from(mContext).inflate(R.layout.estimation_beamwidth, null);
        //容器
        container = mView.findViewById(R.id.ll_container);

        // 左侧输入
        leftSiteBuildDistanceET = mView.findViewById(R.id.et_site_building_distance_left);
        leftSiteHeightET = mView.findViewById(R.id.et_site_height_left);
        leftBuildingHeightET = mView.findViewById(R.id.et_building_height_left);
        leftBuildingWidthET = mView.findViewById(R.id.et_building_width);
        // 左侧输出
        leftVerticalBeamWidthTV = mView.findViewById(R.id.tv_vertical_beamwidth);
        leftHorizontalBeamWidthTV = mView.findViewById(R.id.tv_horizontal_beamwidth);

        // 右侧输入
        rightSiteBuildDistanceET = mView.findViewById(R.id.et_site_building_distance_right);
        rightSiteHeightET = mView.findViewById(R.id.et_site_height_right);
        rightBuildingHeightET = mView.findViewById(R.id.et_building_height_right);
        rightVerticalBeamWidthET = mView.findViewById(R.id.et_vertical_beamwidth);
        // 右侧输出
        ssbBeamUpAngleTV = mView.findViewById(R.id.tv_ssb_beam_up_degree);
        dipAngleTV = mView.findViewById(R.id.tv_dip_angle);
        mechanicalDipAngleTV = mView.findViewById(R.id.tv_mechanical_dip_angle);

        mView.findViewById(R.id.calc_button).setOnClickListener(this);
        // 限制垂直波半角数值
        setTextListener(rightVerticalBeamWidthET);
        initView();
    }

    private void initView() {

    }

    public void clear() {
        leftSiteBuildDistanceET.setText("");
        leftSiteHeightET.setText("");
        leftBuildingHeightET.setText("");
        leftBuildingWidthET.setText("");
        rightSiteBuildDistanceET.setText("");
        rightSiteHeightET.setText("");
        rightBuildingHeightET.setText("");
        rightVerticalBeamWidthET.setText("");

        clearResult();
    }

    private void clearResult() {
        leftVerticalBeamWidthTV.setText("");
        leftHorizontalBeamWidthTV.setText("");
        ssbBeamUpAngleTV.setText("");
        dipAngleTV.setText("");
        mechanicalDipAngleTV.setText("");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.calc_button:
                if (AppUtil.isFastDoubleClick()) {
                    return;
                }
                startCal();
                break;
            default:
                break;
        }
    }

    private void startCal() {
        clearResult();
        Boolean isLeftHasData = false;
        isRightHasData = false;
        if (!TextUtils.isEmpty(leftSiteBuildDistanceET.getText().toString())
                && !TextUtils.isEmpty(leftSiteHeightET.getText().toString())
                && !TextUtils.isEmpty(leftBuildingHeightET.getText().toString())) {
            isLeftHasData = true;
        }

        if (!TextUtils.isEmpty(rightSiteBuildDistanceET.getText().toString())
                && !TextUtils.isEmpty(rightSiteHeightET.getText().toString())
                && !TextUtils.isEmpty(rightBuildingHeightET.getText().toString())
                && !TextUtils.isEmpty(rightVerticalBeamWidthET.getText().toString())) {
            isRightHasData = true;
        }

        if (isLeftHasData) {
            calcLeftData();
        }

        if (isRightHasData) {
            calcRightData();
        }

        if (!isLeftHasData && !isRightHasData) {
            showToast("请输入变量再计算");
        } else {
            getBitmap(container);
        }
    }

    private void calcLeftData() {
        double siteBuildDis = formatDoublePoint(leftSiteBuildDistanceET); // 站楼距
        double siteHeight = formatDoublePoint(leftSiteHeightET); // 站高
        double buildHeight = formatDoublePoint(leftBuildingHeightET); // 建筑物高
        double buildWidth = formatDoublePoint(leftBuildingWidthET); // 楼宽度

        double verticalBeamWidth;
        double horizontalBeamWidth;

        verticalBeamWidth = Math.toDegrees(Math.atan(siteHeight / siteBuildDis)) + Math.toDegrees(Math.atan((buildHeight - siteHeight - 3) / siteBuildDis));
        horizontalBeamWidth = Math.toDegrees(Math.atan(buildWidth / siteBuildDis / 2)) * 2;
        leftVerticalBeamWidthTV.setText(getStringWithValue(verticalBeamWidth));
        leftHorizontalBeamWidthTV.setText(getStringWithValue(horizontalBeamWidth));
    }

    private void calcRightData() {
        double siteBuildDis = formatDoublePoint(rightSiteBuildDistanceET); // 站楼距
        double siteHeight = formatDoublePoint(rightSiteHeightET); // 站高
        double buildHeight = formatDoublePoint(rightBuildingHeightET); // 建筑物高
        double verticalBeamWidth = formatDoublePoint(rightVerticalBeamWidthET); // 楼宽度

        double ssbUpAngle;
        double dipAngle;
        double mechanicalDipAngle;

        double atan = Math.atan((buildHeight - siteHeight - 3) / siteBuildDis);
        ssbUpAngle = Math.toDegrees(atan);
        dipAngle = -(ssbUpAngle - verticalBeamWidth * 0.5);
        mechanicalDipAngle = dipAngle - 6;

        ssbBeamUpAngleTV.setText(getStringWithValue(ssbUpAngle));
        dipAngleTV.setText(getStringWithValue(dipAngle));
        mechanicalDipAngleTV.setText(getStringWithValue(mechanicalDipAngle));

    }

    private void getBitmap(LinearLayout llContainer) {
        int h = dp2px(425);
        Bitmap bitmap;
        // 创建对应大小的bitmap
        bitmap = Bitmap.createBitmap(llContainer.getWidth(), llContainer.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        llContainer.draw(canvas);

        String account = SharedPreferencesUtil.getInstance(mContext).readStringValue(Constants.LOGIN_USER_KEY, "");
        String siteDir = getProductFileDirectory()
                + account + File.separator + SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.PROJECT_NAME, "")
                + File.separator + groupName + File.separator + siteName + File.separator + DIR_RENDER;

        GCEnvironmentInfo.createRenderDirector(account, groupName, siteName); //效果
        String imageName = "";

        imageName = siteName + "_" + "beam_width" + ".jpg";

        ImageUtils.getInstance(mContext).saveToSDcard(imageName, bitmap, siteDir);

        //设置照片信息
        RoundImage rfImage = new RoundImage();
        rfImage.setName(imageName);
        rfImage.setTypeName(RoundImage.TYPE_RENDER);
        rfImage.setPath(siteDir);
        rfImage.setTaskId(groupId);
        rfImage.setStationId(siteId);
        rfImage.setWhereFrom(RoundImage.FROM_RENDER);
        rfImage.setImageType(RoundImage.IMAGETYPE_NOTRF);
        DBManager.getInstance(mContext).getImageDBImpl().insertOrUpdate(rfImage);

    }

    private int dp2px(int dp) {
        return (int) (dp * (mContext.getResources().getDisplayMetrics().density) + 0.5f);
    }

    private void showToast(String str) {
        Toast.makeText(mContext, str, Toast.LENGTH_SHORT).show();
    }

    private void setTextListener(final EditText et) {
        final int max = 90;
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (start >= 0) {//从一输入就开始判断，

                    try {
                        double num = Double.parseDouble(s.toString());
                        //判断当前editText中的数字(可能一开始EditText中有数字)是否大于max
                        if (num > max) {
                            s = String.valueOf(max);//如果大于max，则内容为max
                            et.setText(s);
                            et.setSelection(s.length());

                            showToast("垂直波瓣角不能超过" + max + "°");

                        }
                    } catch (NumberFormatException e) {

                    }

                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}
