package com.huawei.genexcloud.bean;

import android.net.Uri;

import java.io.Serializable;
import java.util.List;

public class ExperienceSiteInfo implements Serializable {

    // 标点界面 1表示在首页标点；2在体验标点页面；3在感知地图;
    public static final int REQUEST_TYPE_MAIN = 1, REQUEST_TYPE_MARK = 2, REQUEST_TYPE_SENSE = 3;
    // 标点场景 0表示当前位置 1表示非当前位置
    public static final String MARK_SCENE_MY_LOCATION = "0", MARK_SCENE_NOT_MY_LOCATION = "1";
    // 标点场景 0表示室内 1表示室外
    public static final String MARK_SCENE_INDOOR = "0", MARK_SCENE_OUTDOOR  = "1";
    // 标点类型 1-6分别为 网速慢、视频卡顿、语音不佳、其他、覆盖差、游戏卡顿
    public static final int RECORD_TYPE_SPEED = 1, RECORD_TYPE_VIDEO = 2, RECORD_TYPE_VOICE = 3,
            RECORD_TYPE_OTHER = 4, RECORD_TYPE_COVER = 5, RECORD_TYPE_GAME = 6;

    private static final long serialVersionUID = 1L;
    /**
     * 记录id
     */
    private int RecordId;
    /**
     * 账号
     */
    private String Account;

    /**
     * 省
     */
    private String Province;

    /**
     * 市
     */
    private String City;

    /**
     * 地址
     */
    private String Address;

    /**
     * 纬度
     */
    private double Latitude;

    /**
     * 经度
     */
    private double Longitude;

    /**
     * 记录类型
     */
    private int RecordType;

    /**
     * 备注
     */
    private String Remark;

    /**
     * 测试类型(一键测速,网络感知等等)
     */
    private int TestType;

    /**
     * 测试id
     */
    private int UniqueID;

    private String RecordTime;

    private DeviceInfo DeviceInfo;

    private SpeedTestDetailInfo speedTestInfo;

    private NetFeelData netFeelData;

    private String DealUser;

    private String DealSuggest;

    //yyyy-mm-dd hh:mm:ss
    private String OccurTime;

    /**
     * 状态 1待处理，2处理中，3已处理
     */
    private int State;

    /**
     * 标点界面 1表示在首页标点；2在体验标点页面；3在感知地图;
     */
    private int RequestType;

    private String ChangJing; //场景：存放室内(0)室外(1)
    private String ChangJingExtra; //标点位置是否是当前位置：0（是），1（否）
    private List<String> Images;
    // 图片的uri
    private List<Uri> imageUris;

    public String getAccount() {
        return Account == null ? "" : Account;
    }

    public void setAccount(String account) {
        this.Account = account;
    }

    public int getRequestType() {
        return RequestType;
    }

    public void setRequestType(int requestType) {
        RequestType = requestType;
    }

    public String getProvince() {
        return Province == null ? "" : Province;
    }

    public void setProvince(String province) {
        this.Province = province;
    }

    public String getCityName() {
        return City == null ? "" : City;
    }

    public void setCityName(String cityName) {
        this.City = cityName;
    }

    public double getLat() {
        return Latitude;
    }

    public void setLat(double lat) {
        this.Latitude = lat;
    }

    public double getLng() {
        return Longitude;
    }

    public void setLng(double lng) {
        this.Longitude = lng;
    }

    public int getRecordType() {
        return RecordType;
    }

    public void setRecordType(int recordType) {
        this.RecordType = recordType;
    }

    public String getRemark() {
        return Remark == null ? "" : Remark;
    }

    public void setRemark(String remark) {
        this.Remark = remark;
    }

    public String getOccurTime() {
        return OccurTime;
    }

    public void setOccurTime(String occurTime) {
        OccurTime = occurTime;
    }

    public int getTestType() {
        return TestType;
    }

    public void setTestType(int testType) {
        this.TestType = testType;
    }

    public int getUniqueID() {
        return UniqueID;
    }

    public void setUniqueID(int uniqueID) {
        this.UniqueID = uniqueID;
    }

    public String getTime() {
        return RecordTime == null ? "" : RecordTime;
    }

    public void setTime(String time) {
        this.RecordTime = time;
    }

    public String getAddress() {
        return Address == null ? "" : Address;
    }

    public void setAddress(String address) {
        this.Address = address;
    }

    public DeviceInfo getDeviceInfo() {
        return DeviceInfo;
    }

    public void setDeviceInfo(DeviceInfo deviceInfo) {
        this.DeviceInfo = deviceInfo;
    }

    public SpeedTestDetailInfo getSpeedTestInfo() {
        return speedTestInfo;
    }

    public void setSpeedTestInfo(SpeedTestDetailInfo speedTestInfo) {
        this.speedTestInfo = speedTestInfo;
    }

    public NetFeelData getNetFeelData() {
        return netFeelData;
    }

    public void setNetFeelData(NetFeelData netFeelData) {
        this.netFeelData = netFeelData;
    }

    public String getDealSuggest() {
        return DealSuggest;
    }

    public void setDealSuggest(String dealSuggest) {
        this.DealSuggest = dealSuggest;
    }

    public int getState() {
        return State;
    }

    public void setState(int state) {
        this.State = state;
    }

    public String getDealUser() {
        return DealUser;
    }

    public void setDealUser(String dealUser) {
        this.DealUser = dealUser;
    }

    public int getRecordId() {
        return RecordId;
    }

    public void setRecordId(int recordId) {
        RecordId = recordId;
    }

    public String getChangJing() {
        return ChangJing;
    }

    public void setChangJing(String changJing) {
        ChangJing = changJing;
    }

    public String getChangJingExtra() {
        return ChangJingExtra;
    }

    public void setChangJingExtra(String changJingExtra) {
        ChangJingExtra = changJingExtra;
    }

    public List<String> getImgList() {
        return Images;
    }

    public void setImgList(List<String> images) {
        Images = images;
    }

    public List<Uri> getImageUris() {
        return imageUris;
    }

    public void setImageUris(List<Uri> imageUris) {
        this.imageUris = imageUris;
    }
}
