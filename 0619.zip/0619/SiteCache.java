package com.huawei.genexcloud.util.map;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.util.LruCacheMap;

import java.util.List;

/**
 * 站点信息缓存类
 */
public class SiteCache extends LruCacheMap<Integer, SiteInfo> {

    // 最多存储5000个站点
    private final static int MAX_SIZE = 5_000;
    public SiteCache() {
        super(MAX_SIZE);
    }
    @Override
    public int getItemSize(@NonNull Integer key, @NonNull SiteInfo value) {
        return 1;
    }

    public void putAll(List<SiteInfo> siteList) {
        if (null == siteList || siteList.isEmpty()) {
            return;
        }
        for (SiteInfo item : siteList) {
            put(item.getNodebId(), item);
        }
    }
}
