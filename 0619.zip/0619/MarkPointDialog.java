package com.huawei.genexcloud.dialog;

import android.app.Dialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.baidu.mapapi.model.LatLng;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.adapter.PhotoGalleryAdapter;
import com.huawei.genexcloud.base.BaseDialog;
import com.huawei.genexcloud.bean.DeviceInfo;
import com.huawei.genexcloud.bean.ExperienceSiteInfo;
import com.huawei.genexcloud.databinding.DialogMarkPointBinding;
import com.huawei.genexcloud.http.InsertSupportRecordImpl;
import com.huawei.genexcloud.http.util.CellInfoUtils;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.util.CarrierNameUtils;
import com.huawei.genexcloud.util.TimeSelector;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Request;

/**
 * 感知地图的体验标点弹窗
 */
public class MarkPointDialog extends BaseDialog implements View.OnClickListener,
        PhotoGalleryAdapter.PhotoClickListener, MarkPhotoSelectionDialog.Callback {

    private DialogMarkPointBinding binding;
    private PhotoGalleryAdapter photoAdapter;
    // 将要上传的照片
    private List<Uri> photoData;

    /********** 传入的参数 ***************/
    // 定位的当前位置
    private LatLng mLocation;
    // 地理查询的
    private String mAddress;
    // 省市
    private String province, city;
    /**
     * ...............................
     **/
    // 问题类型和问题主题的关系
    private Map<Integer, String> problemTypeMap;
    // 问题类型和图标的关系
    private Map<Integer, Integer> typeIconMap;

    // 用户选择的问题类型
    private int mType = -1;

    // 时间格式化
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    // 报告问题发生的时间
    private long timeStamp = System.currentTimeMillis();


    public MarkPointDialog(LatLng location, String address, String province, String city) {
        mLocation = location;
        mAddress = address;
        this.province = province;
        this.city = city;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogMarkPointBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onDestroy() {
        binding = null;
        super.onDestroy();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        initView();
        initData();
    }

    private void initView() {
        // 进入时隐藏第二部标点详细内容的布局
        binding.detailLayout.setVisibility(View.GONE);

        // 设置spinner的选项内容
        binding.operatorSpinner.setAdapter(getAdapter(R.array.operator_cn_list));
        binding.netTypeSpinner.setAdapter(getAdapter(R.array.network_type_list));
        binding.sceneSpinner.setAdapter(getAdapter(R.array.spinnerSince));
        binding.operatorSpinner.setSelection(0);
        binding.netTypeSpinner.setSelection(0);
        binding.sceneSpinner.setSelection(1);

        // 设置默认选择当前时间
        binding.dateTxt.setText(simpleDateFormat.format(new Date(timeStamp)));

        photoAdapter = new PhotoGalleryAdapter();
        binding.photosLayout.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false));
        binding.photosLayout.setAdapter(photoAdapter);
        photoData = new ArrayList<>();
        photoAdapter.setData(photoData);
        photoAdapter.setPhotoListener(this);

        binding.typeNet.setOnClickListener(this);
        binding.typeVideo.setOnClickListener(this);
        binding.typeVoice.setOnClickListener(this);
        binding.typeCover.setOnClickListener(this);
        binding.typeGame.setOnClickListener(this);
        binding.typeOther.setOnClickListener(this);
        binding.closeBtn.setOnClickListener(this);
        binding.dateTxt.setOnClickListener(this);
        binding.submitBtn.setOnClickListener(this);
    }

    private void initData() {
        problemTypeMap = new HashMap<>();
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_SPEED, getString(R.string.experience_site_type_network_speed_slow));
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_VIDEO, getString(R.string.experience_site_type_video_bad));
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_VOICE, getString(R.string.experience_site_type_voice_bad));
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_COVER, getString(R.string.experience_site_type_cover_bad));
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_GAME, getString(R.string.experience_site_type_game_bad));
        problemTypeMap.put(ExperienceSiteInfo.RECORD_TYPE_OTHER, getString(R.string.other));
        typeIconMap = new HashMap<>();
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_SPEED, R.drawable.icon_webpage_selected);
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_VIDEO, R.drawable.icon_video_selected);
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_VOICE, R.drawable.icon_voice_selected);
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_COVER, R.drawable.icon_coverage_selected);
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_GAME, R.drawable.icon_game_unselected);
        typeIconMap.put(ExperienceSiteInfo.RECORD_TYPE_OTHER, R.drawable.icon_rests_selected);
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.typeNet) {
            // 点击网速较慢
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_SPEED);
        } else if (v == binding.typeVideo) {
            // 点击视频卡顿
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_VIDEO);
        } else if (v == binding.typeVoice) {
            // 点击语音不佳
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_VOICE);
        } else if (v == binding.typeCover) {
            // 点击覆盖差
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_COVER);
        } else if (v == binding.typeGame) {
            // 点击游戏卡顿
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_GAME);
        } else if (v == binding.typeOther) {
            // 点击其他
            onTypeButtonClicked(ExperienceSiteInfo.RECORD_TYPE_OTHER);
        } else if (v == binding.closeBtn) {
            // 点击了详细内容右上角的叉叉
            binding.markTypeLayout.setVisibility(View.VISIBLE);
            binding.detailLayout.setVisibility(View.GONE);
        } else if (v == binding.dateTxt) {
            // 选择日期
            initDatePicker();
        } else if (v == binding.submitBtn) {
            // 提交标点请求
            commitData();
        }
    }


    /**
     * 选择了标点类型
     *
     * @param type
     */
    private void onTypeButtonClicked(int type) {
        mType = type;
        // 隐藏问题类型选择 显示问题详细内容
        binding.markTypeLayout.setVisibility(View.GONE);
        binding.detailLayout.setVisibility(View.VISIBLE);
        // 详细内容 设置标题和icon
        binding.markTypeTxt.setText(problemTypeMap.get(type));
        binding.markTypeIcon.setImageResource(typeIconMap.get(type));
        binding.addressTxt.setText(mAddress);
    }

    /**
     * 显示时间选择器
     */
    private void initDatePicker() {
        Calendar calendar = Calendar.getInstance();
        // 向前推半年时间 选择时间段只能是半年前到今天
        calendar.add(Calendar.MONTH, -6);
        long startTime = calendar.getTimeInMillis();
        TimeSelector customDatePicker = new TimeSelector(getContext(), new TimeSelector.ResultHandler() {
            @Override
            public void handle(String time) { // 回调接口，获得选中的时间
                try {
                    Date selectedDate = simpleDateFormat.parse(time);
                    timeStamp = selectedDate.getTime();
                    binding.dateTxt.setText(time);
                } catch (ParseException e) {
                    GCLogger.error(Module.ERROR, "感知地图,标点选择时间转换错误!");
                }

            }
        }, simpleDateFormat.format(new Date(startTime)), simpleDateFormat.format(new Date())); // 初始化日期格式请用：yyyy-MM-dd HH:mm，否则不能正常运行
        customDatePicker.showSpecificTime(true); // 显示时和分
        customDatePicker.setIsLoop(true); // 允许循环滚动
        customDatePicker.show(simpleDateFormat.format(new Date(timeStamp)));
    }

    /**
     * 获取spinner的adapter
     *
     * @param arrayID spinner的选项资源id
     * @return
     */
    private ArrayAdapter getAdapter(int arrayID) {
        ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource(getContext(), arrayID,
                R.layout.spinner_sumilation_selete);
        arrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        return arrayAdapter;
    }

    /**
     * 点击了添加照片
     */
    @Override
    public void onClickAdd() {
        showMsg("点击了添加照片");
        new MarkPhotoSelectionDialog().setCallback(this).show(getActivity().getSupportFragmentManager());
    }

    /**
     * 点击了删除照片
     *
     * @param position
     */
    @Override
    public void onClickDelete(int position) {
        showDeletePop(position);
    }


    /**
     * 弹出删除照片确认提示框
     */
    private void showDeletePop(final int position) {
        Dialog dialog = new Dialog(getContext(), R.style.DialogFullScreen);
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View parent = inflater.inflate(R.layout.dialog_show_address_layout, null);// 得到加载view
        Button btOk = parent.findViewById(R.id.btn_yes);
        Button btNo = parent.findViewById(R.id.btn_no);
        TextView title = parent.findViewById(R.id.tv_title);
        TextView contentView = parent.findViewById(R.id.tv_caution);
        title.setText("删除照片");
        contentView.setText("确定删除标点照片");
        // 为确认按钮添加事件,执行退出应用操作
        btOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                dialog.dismiss();// 关闭对话框
                photoData.remove(position);
                photoAdapter.notifyDataSetChanged();
            }
        });
        btNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);

        dialog.setContentView(parent);// 设置布局
        dialog.show();
    }

    //插入体验标点
    public void commitData() {
        String inputString = binding.reportInput.getText().toString().trim();
        if (TextUtils.isEmpty(inputString)) {
            showMsg("请输入备注内容");
            return;
        }
        String operator = binding.operatorSpinner.getSelectedItem().toString();
        ExperienceSiteInfo uploadInfo = new ExperienceSiteInfo();
        // 设置反馈内容
        uploadInfo.setRemark(inputString);
        // 获取手机信息
        DeviceInfo deviceInfo = CellInfoUtils.getDeviceInfo(getContext());
        // 发生问题的运营商
        deviceInfo.setNetOperator(CarrierNameUtils.getNameCode(operator));
        // 设置网络制式 2G 3G LTE NR
        deviceInfo.setNetwork(binding.netTypeSpinner.getSelectedItem().toString());
        // 设置手机信息
        uploadInfo.setDeviceInfo(deviceInfo);
        // 设置场景信息 室内 “0”  室外 “1”
        uploadInfo.setChangJing(binding.netTypeSpinner.getSelectedItemPosition() == 0 ?
                ExperienceSiteInfo.MARK_SCENE_INDOOR : ExperienceSiteInfo.MARK_SCENE_OUTDOOR);
        // 设置标点的场景位置 0表示当前位置 1表示非当前位置
        uploadInfo.setChangJingExtra(ExperienceSiteInfo.MARK_SCENE_MY_LOCATION);
        // 发生时间
        uploadInfo.setOccurTime(String.format("%s%s", binding.dateTxt.getText().toString().trim(), ":00"));
        // 标点界面 场景地图界面
        uploadInfo.setRequestType(ExperienceSiteInfo.REQUEST_TYPE_SENSE); //标点界面 1表示在首页标点；2在体验标点页面；3在感知地图;
        // recordType 标点类型
        uploadInfo.setRecordType(mType);
        uploadInfo.setProvince(province);
        uploadInfo.setCityName(city);
        // 设置当前位置的地理查询结果
        uploadInfo.setAddress(mAddress);
        //标点的经纬度
        uploadInfo.setLat(mLocation.latitude);
        uploadInfo.setLng(mLocation.longitude);
        // 设置需要上传的图片
        uploadInfo.setImageUris(photoData);

        InsertSupportRecordImpl.getInstance().queryInsertRecordInfo(uploadInfo, new InsertSupportRecordImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg("上传标点信息失败！");
            }

            @Override
            public void onResponse(String response) {
                showMsg("感谢您的反馈！");
                dismiss();
            }
        });
    }


    @Override
    public void onNoPermission() {
        showMsg("应用没有拍照权限");
    }

    @Override
    public void onError() {
        showMsg("获取图片失败");
    }

    @Override
    public void onCameraCancel() {
    }

    @Override
    public void onAlbumCancel() {
    }

    @Override
    public void onCameraReturn(Uri uri) {
        if (null != uri) {
            photoData.add(uri);
            photoAdapter.notifyDataSetChanged();
        } else {
            showMsg("获取图片失败");
        }
    }

    @Override
    public void onAlbumReturn(Uri uri) {
        if (null != uri) {
            photoData.add(uri);
            photoAdapter.notifyDataSetChanged();
        } else {
            showMsg("获取图片失败");
        }
    }
}
