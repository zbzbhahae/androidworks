package com.huawei.genexcloud.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.model.LatLng;
import com.huawei.genexcloud.bean.CityInfo;
import com.huawei.genexcloud.bean.QueryAreaResultBean;
import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.util.map.SiteCache;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * 保存临时数据信息
 */
public class CacheUtil {

    private static CacheUtil instance;
    // 用于保存地市信息的数据结构
    private final LinkedHashMap<String, List<CityInfo>> provinceCityMap;
    private final LinkedHashMap<String, CityInfo> provinceInfoMap;
    private final LinkedHashMap<String, CityInfo> cityInfoMap;
    // 用于保存polygon信息的数据结构
    private final ArrayList<PolygonOptions> polygonOptions;
    // 缓存站点数据
    private final SiteCache siteCache;

    private CacheUtil() {
        provinceCityMap = new LinkedHashMap<>();
        provinceInfoMap = new LinkedHashMap<>();
        cityInfoMap = new LinkedHashMap<>();
        polygonOptions = new ArrayList<>();
        siteCache = new SiteCache();
    }

    /**
     * 存储获取到的站点信息
     * @param siteInfos
     */
    public void saveSiteInfo(List<SiteInfo> siteInfos) {
        siteCache.putAll(siteInfos);
    }

    /**
     * 获取缓存的站点
     * @return
     */
    public List<SiteInfo> getCachedSite() {
        Map<Integer, SiteInfo> cachedSite = siteCache.snapshot();
        if (null == cachedSite || cachedSite.isEmpty()) {
            return null;
        }
        List<SiteInfo> cachedList = new ArrayList<>(cachedSite.values());
        cachedSite.clear();
        return cachedList;
    }

    public static CacheUtil getInstance() {
        if (instance == null) {
            synchronized (CacheUtil.class) {
                if (instance == null) {
                    instance = new CacheUtil();
                }
            }
        }
        return instance;
    }

    public static void clean() {
        synchronized (CacheUtil.class) {
            instance = null;
        }
    }

    /**
     * 是否已经获取到省份城市数据
     * @return
     */
    public boolean needUpdateCityInfo() {
        return (provinceCityMap.isEmpty() || provinceInfoMap.isEmpty() || cityInfoMap.isEmpty());
    }

    /**
     * 更新地市信息
     * @param cityInfoList 地市列表
     */
    public void saveProvinceInfo(@NonNull List<CityInfo> cityInfoList) {
        synchronized (CacheUtil.class) {
            provinceCityMap.clear();
            provinceInfoMap.clear();
            cityInfoMap.clear();
            for (CityInfo cityInfo: cityInfoList) {
                if (provinceCityMap.containsKey(cityInfo.province)) {
                    List<CityInfo> cityInfos = provinceCityMap.get(cityInfo.province);
                    assert cityInfos != null;
                    cityInfos.add(cityInfo);
                } else {
                    List<CityInfo> cityInfos = new ArrayList<>(Collections.singletonList(cityInfo));
                    provinceCityMap.put(cityInfo.province, cityInfos);
                }
                if (cityInfo.isCapital()) {
                    provinceInfoMap.put(cityInfo.province, cityInfo);
                }
                cityInfoMap.put(cityInfo.city, cityInfo);
            }
        }
    }

    /**
     * 获取省会信息
     * @param province
     * @return
     */
    public CityInfo getProvince(@NonNull final String province) {
        return provinceInfoMap.get(province);
    }

    /**
     * 根据城市名获取城市信息
     * @param city
     * @return
     */
    public CityInfo getCity(final String city) {
        return cityInfoMap.get(city);
    }

    /**
     * 获取所有省份信息
     * @return
     */
    public List<CityInfo> getAllProvince() {
        if (provinceInfoMap.isEmpty()) {
            return null;
        }
        List<CityInfo> list = new ArrayList<>();
        Iterator<CityInfo> iterator = provinceInfoMap.values().iterator();
        while(iterator.hasNext()) {
            list.add(iterator.next());
        }
        return list;
    }

    /**
     * 获取省份名称列表
     * @return
     */
    public List<String> getProvinceNameList() {
        if (provinceCityMap.isEmpty()) {
            return null;
        }
        ArrayList<String> list = new ArrayList<>();
        if (provinceInfoMap.isEmpty()) {
            return null;
        }
        Iterator<CityInfo> iterator = provinceInfoMap.values().iterator();
        while(iterator.hasNext()) {
            CityInfo cityInfo = iterator.next();
            if (null != cityInfo && !TextUtils.isEmpty(cityInfo.province)) {
                list.add(cityInfo.province);
            }
        }
        return list;
    }

    /**
     * 通过省份名称获取省份内城市名称列表
     * @param provinceName
     * @return
     */
    public List<String> getCityNameListByProvinceName(String provinceName) {
        if (TextUtils.isEmpty(provinceName) || needUpdateCityInfo()) {
            return null;
        }
        List<CityInfo> cityInfoList = null;
        for (Map.Entry<String, List<CityInfo>> entry : provinceCityMap.entrySet()) {
            if (entry.getKey().contains(provinceName)) {
                cityInfoList = entry.getValue();
                break;
            }
        }
        if (null == cityInfoList || cityInfoList.isEmpty()) {
            return null;
        }
        List<String> cityNameList = new ArrayList<>();
        for (CityInfo cityInfo : cityInfoList) {
            if (null != cityInfo && !TextUtils.isEmpty(cityInfo.city)) {
                cityNameList.add(cityInfo.city);
            }
        }
        return cityNameList;
    }

    /**
     * @return 判断是否存在华为区域轮廓
     */
    public boolean polygonIsEmpty() {
        return polygonOptions.isEmpty();
    }

    /**
     * 更新当前城市的华为区域边界数据
     * @param options 新的数据
     */
    public void setPolygonList(@NonNull ArrayList<PolygonOptions> options) {
        synchronized (CacheUtil.class) {
            polygonOptions.clear();
            polygonOptions.addAll(options);
        }
    }

    /**
     * @return 前城市的华为区域边界数据
     */
    public List<PolygonOptions> getPolygonList() {
        synchronized (CacheUtil.class){
            return new ArrayList<>(polygonOptions);
        }
    }

    /**
     * 清理polygon数据
     */
    public void cleanPolygonData() {
        synchronized (CacheUtil.class) {
            polygonOptions.clear();
        }
    }
}
