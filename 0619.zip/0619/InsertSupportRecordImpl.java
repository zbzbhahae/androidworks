package com.huawei.genexcloud.http;

import static com.huawei.genexcloud.common.Constant.GC_QUERY_SUCCESS;
import static com.huawei.genexcloud.http.util.ErrorBean.ERROR_PARSE_EXCEPTION;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.bean.ExperienceSiteInfo;
import com.huawei.genexcloud.bean.ResultBean;
import com.huawei.genexcloud.http.util.CellInfoUtils;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.http.util.GCCallback;
import com.huawei.genexcloud.http.util.HttpErrorException;
import com.huawei.genexcloud.http.util.JavaHttpUtil;
import com.huawei.genexcloud.http.util.ParseJsonUtils;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.util.AddrNameUtils;
import com.huawei.genexcloud.util.GzipUtils;
import com.huawei.genexcloud.util.ImageUtils;
import com.huawei.genexcloud.util.ShareDataUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 录入投诉信息(发送邮件)体验标点
 */
public class InsertSupportRecordImpl extends JavaHttpUtil {
    private static InsertSupportRecordImpl instance;

    @Override
    protected String getMessageName() {
        return "Email_InsertSupportRecordInfo";
    }

    public static InsertSupportRecordImpl getInstance() {
        if (null == instance) {
            synchronized (AppUsageActionImpl.class) {
                if (null == instance) {
                    instance = new InsertSupportRecordImpl();
                }
            }
        }
        return instance;
    }

    public void queryInsertRecordInfo(ExperienceSiteInfo info, Callback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("Account", ShareDataUtil.getUserName(BaseApplication.getAppContext()));
        body.put("Province", AddrNameUtils.getAliasProvinceName(info.getProvince()));
        body.put("City", AddrNameUtils.getAliasCityName(info.getCityName()));
        body.put("Address", info.getAddress());
        body.put("Latitude", info.getLat());
        body.put("Longitude", info.getLng());
        body.put("RecordType", info.getRecordType());
        body.put("Remark", info.getRemark());
        // 未使用 测试信息
        body.put("TestType", info.getTestType());
        // 测试相关 未使用
        body.put("UniqueID", info.getUniqueID());
        body.put("OccurTime", info.getOccurTime());
        // 标点的所在界面
        body.put("RequestType", info.getRequestType());
        // 标点场景 室内室外
        body.put("ChangJing", info.getChangJing());
        // 标点地理场景 当前位置 非当前位置
        body.put("ChangJingExtra", info.getChangJingExtra());
        // 手机信息
        body.put("DeviceInfo", CellInfoUtils.getDeviceInfoJson(info.getDeviceInfo()));
        // 上报的图片信息
        body.put("Images", getImgList(info.getImageUris()));
        postSingle(instance, body, callback);
    }

    @Override
    protected Map<String, String> buildBodyParams(String messageName, Map<String, Object> body) {
        Map<String, String> formBody = new HashMap<>();
        if (!TextUtils.isEmpty(messageName)) {
            formBody.put("messageName", messageName);
        }
        try {
            JSONObject jsonObject = new JSONObject();
            for (Map.Entry<String, Object> item : body.entrySet()) {
                String key = item.getKey();
                Object value = item.getValue();
                if (!TextUtils.isEmpty(key)) {
                    jsonObject.put(key, value);
                }
            }

            String jsonMessage = jsonObject.toString();
            jsonMessage = GzipUtils.compress(jsonMessage, GzipUtils.BASE_64);
            jsonMessage = URLEncoder.encode(jsonMessage, "UTF-8");
            formBody.put("message", jsonMessage);
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return formBody;

    }

    public static abstract class Callback extends GCCallback<String> {
        @Override
        public String parseNetworkResponse(@NonNull String response) throws Exception {
            ResultBean bean = ParseJsonUtils.fromStringToObject(response, ResultBean.class);
            if (bean == null) {
                throw new HttpErrorException(ErrorBean.make(ERROR_PARSE_EXCEPTION));
            }
            if (bean.statusCode != GC_QUERY_SUCCESS) {
                throw new HttpErrorException(new ErrorBean(bean.statusCode, bean.message, null));
            }

            if (!bean.message.equals("Success") && !bean.message.equals("success")) {
                throw new HttpErrorException(new ErrorBean(bean.statusCode, bean.message, null));
            }
            return bean.message;
        }
    }


    private JSONArray getImgList(List<Uri> imgList) {
        JSONArray array = new JSONArray();

        if (imgList == null || imgList.size() == 0) {
            return array;
        } else {
            for (int i = 0; i < imgList.size(); i++) {
                Uri uri = imgList.get(i);
                if (null == uri) {
                    continue;
                }
                String bitmapEncoded = null;
                try {
                    Bitmap bitmap = BitmapFactory.decodeStream(BaseApplication.getAppContext()
                            .getContentResolver().openInputStream(uri));
                    if (null != bitmap) {
                        bitmapEncoded = ImageUtils.bitmapToBase64(bitmap, 1024);
                    }
                } catch (FileNotFoundException e) {
                    GCLogger.error(Module.ERROR, e.toString());
                }
                if (!TextUtils.isEmpty(bitmapEncoded)) {
                    array.put(bitmapEncoded);
                }
            }
        }
        return array;
    }

}
