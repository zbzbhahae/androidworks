package com.huawei.genexcloud.util.map;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;

import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MarkerOptions.MarkerAnimateType;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.bean.ExperienceSiteInfo;
import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.bean.TypeEnum;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.widget.SiteClusterView;
import com.huawei.genexcloud.widget.SiteMapView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 厂商匹配图标、Alias名
 *
 * @author wWX405921
 */
public class SiteUtils {


    /**
     * 获得体验标点的覆盖物
     */
    public static MarkerOptions getExperienceMarkerOption(ExperienceSiteInfo info, LatLng latLng, boolean isBig) {
        return new MarkerOptions().position(latLng).icon(getBitmapDescriptor(info, isBig)).zIndex(5)
                .animateType(MarkerAnimateType.grow);
    }

    /**
     * 获取BitmapDescriptor 类型 1"网速较慢", 2"视频卡顿", 3"语音不佳", 4"其他", 5"覆盖差", 6"游戏卡顿"
     */
    public static BitmapDescriptor getBitmapDescriptor(ExperienceSiteInfo info, boolean isBig) {
        int resourceId;
        switch (info.getRecordType()) {
            case 1:
                resourceId = R.drawable.map_internet_speed;
                break;
            case 2:
                resourceId = R.drawable.map_video;
                break;
            case 3:
                resourceId = R.drawable.map_voice;
                break;
            case 4:
                resourceId = R.drawable.map_rests;
                break;
            case 5:
                resourceId = R.drawable.map_coverage;
                break;
            case 6:
                resourceId = R.drawable.map_game;
                break;
            default:
                resourceId = R.drawable.map_rests;
                break;
        }
        return BitmapDescriptorFactory.fromResource(resourceId);
    }

    private static SiteMapView cacheView;

    /**
     * 得到异厂商站点覆盖物
     */
    public static MarkerOptions getSiteDetailMarkerOption(Context context, SiteInfo incInfo) {
        if (null == context) {
            return null;
        }

        boolean isOuter = incInfo.getIndoorId() == 0;  //室外
        LatLng latLng = new LatLng(incInfo.getLat(), incInfo.getLng());

        if (null == cacheView) {
            cacheView = new SiteMapView(context.getApplicationContext());
        }
        if (isOuter) {
            int cellSize = incInfo.getBeans().size();
            Float[] cellAngles = new Float[cellSize];
            for (int i = 0; i < incInfo.getBeans().size(); i++) {
                cellAngles[i] = (float) incInfo.getBeans().get(i).getBring();
            }
            cacheView.setData(incInfo.getFRSName(), !isOuter, cellAngles);
        } else {
            cacheView.setData(incInfo.getFRSName(), !isOuter);
        }
        BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(cacheView);

        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(latLng).icon(cacheDescriptor).zIndex(5).alpha(.8f).anchor(.5f, .5f);
        return markerOption;
    }

    /**
     * 获取站点的详细marker
     * @param context 上下文
     * @param siteList 站点信息
     * @return 站点marker的集合
     */
    public static List<OverlayOptions> getSiteDetailMarkerOptions(Context context, List<SiteInfo> siteList) {
        if (null == context || null == siteList || siteList.isEmpty()) {
            return null;
        }
        List<OverlayOptions> siteOptions = new ArrayList<>();
        for (SiteInfo item : siteList) {
            boolean isOuter = item.getIndoorId() == 0;  //室外
            LatLng latLng = new LatLng(item.getLat(), item.getLng());

            if (null == cacheView) {
                cacheView = new SiteMapView(context.getApplicationContext());
            }
            if (isOuter) {
                int cellSize = item.getBeans().size();
                Float[] cellAngles = new Float[cellSize];
                for (int i = 0; i < item.getBeans().size(); i++) {
                    cellAngles[i] = (float) item.getBeans().get(i).getBring();
                }
                cacheView.setData(item.getFRSName(), !isOuter, cellAngles);
            } else {
                cacheView.setData(item.getFRSName(), !isOuter);
            }
            BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(cacheView);

            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(latLng).icon(cacheDescriptor).zIndex(5).alpha(.8f).anchor(.5f, .5f);
            Bundle bundle = new Bundle();
            bundle.putString("markerType", "incMarker");
            bundle.putSerializable("bean", item);
            markerOption.extraInfo(bundle);
            siteOptions.add(markerOption);
        }
        return siteOptions;
    }



    /**
     * 获得站点聚合marker
     *
     * @param context
     * @param location 经纬度
     * @param num 范围内站点数
     * @return
     */
    public static MarkerOptions getSiteClusterOption(Context context, LatLng location, int num) {
        if (null == context || null == location) {
            return null;
        }
        // 聚合view 只显示站点数量
        SiteClusterView siteClusterView = new SiteClusterView(context.getApplicationContext());
        siteClusterView.setSiteNumber(num);

        BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(siteClusterView);
        GCLogger.error("view", "getSiteClusterOption viewSize = " + siteClusterView.getHeight());

        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(location).icon(cacheDescriptor).zIndex(5).alpha(.8f).perspective(false).anchor(.5f, .5f);
        return markerOption;
    }

    /**
     * 获取聚合点marker
     * @param context 上下文
     * @param clusterMap 存储聚合点信息的集合
     * @return 聚合点marker集合
     */
    public static List<OverlayOptions> getSiteClusterOptions(Context context, Map<LatLng, Integer> clusterMap) {
        if (null == context || null == clusterMap || clusterMap.isEmpty()) {
            return null;
        }
        List<OverlayOptions> markerOptions = new ArrayList<>();
        for (Map.Entry<LatLng, Integer> item : clusterMap.entrySet()) {
            // 聚合view 只显示站点数量
            SiteClusterView siteClusterView = new SiteClusterView(context.getApplicationContext());
            siteClusterView.setSiteNumber(item.getValue());

            BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromView(siteClusterView);

            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(item.getKey()).icon(cacheDescriptor).zIndex(5).alpha(.8f)
                    .perspective(false).anchor(.5f, .5f);
            markerOptions.add(markerOption);
        }

        return markerOptions;
    }

    /**
     * 根据选项过滤不显示站点
     * @param fromList 站点原数据
     * @param bounds 当前地图显示的区域
     * @param isShowOuter 是否显示室外站点
     * @param isShowInner 是否显示室内站点
     * @return 过滤后需要显示的站点
     */
    public static List<SiteInfo> filterSitesByOption(List<SiteInfo> fromList, LatLngBounds bounds,
            boolean isShowOuter, boolean isShowInner, boolean isShowOtherIncSite) {
        if (null == fromList || fromList.isEmpty()) {
            return fromList;
        }
        List<SiteInfo> filteredSiteList = new ArrayList<>();
        for (SiteInfo siteInfo : fromList) {
            if (null == siteInfo || !bounds.contains(new LatLng(siteInfo.getLat(), siteInfo.getLng()))) {
                // 没有站点信息或者不在显示范围内 过滤掉
                continue;
            }
            boolean isOuterSite = siteInfo.getIndoorId() == 0;
            if ( (isOuterSite && !isShowOuter) || (!isOuterSite && !isShowInner) ) {
                // 是室外站点但不显示室外站点或者是室内站点但不显示室内站点
                continue;
            }
            if ( !isShowOtherIncSite && !"华为".equals(siteInfo.getFRSName())) {
                // 不显示异厂商站点且这个站点不是华为站点
                continue;
            }
            filteredSiteList.add(siteInfo);
        }
        return filteredSiteList;
    }


    /**
     * 将范围分成GRID_HORIZONTAL_SIZE * GRID_VERTICAL_SIZE个小格，每个小格只允许一个站点存在
     *
     * @param fromList
     * @param lbPoint
     * @param rtPoint
     * @return
     */
    // 过滤点的格子横向 纵向数量
    private static int GRID_HORIZONTAL_SIZE = 5;
    private static int GRID_VERTICAL_SIZE = 10;
    // 格子总数量
    private static int GRID_SIZE = GRID_HORIZONTAL_SIZE * GRID_VERTICAL_SIZE;

    public static List<SiteInfo> filterSitesByBounds(List<SiteInfo> fromList, LatLng lbPoint, LatLng rtPoint) {
        long startT = System.currentTimeMillis();
        if (null == fromList || fromList.size() < GRID_SIZE) {
            return fromList;
        }
        List<SiteInfo> destList = new ArrayList<>();
        double maxLat = rtPoint.latitude;
        double minLat = lbPoint.latitude;
        double maxLng = rtPoint.longitude;
        double minLng = lbPoint.longitude;

        double latDuration = maxLat - minLat;
        double lngDuration = maxLng - minLng;
        if (latDuration <= 0 || lngDuration <= 0) {
            return null;
        }

        // 存储格子中是否已经存在点 key 为格子的序列号 lng 为横左边 lat为纵坐标
        //   0   1   2   3 ... 19
        //   20  21  22  23 ...39
        //         .
        //         .
        //   380 381 382 383 ... 399
        Map<Integer, Boolean> fillCache = new HashMap<>();
        for (SiteInfo siteInfo : fromList) {
            double lat = siteInfo.getLat();
            double lng = siteInfo.getLng();
            if (lat > maxLat || lat < minLat || lng > maxLng || lng < minLng) {
                // 不在范围内
                continue;
            }
            int gridKey = getGridKey(lat - minLat, lng - minLng, latDuration, lngDuration);
            if (gridKey < 0 || gridKey > GRID_SIZE) {
                // 点不在范围内
                continue;
            }
            Boolean hasSite = fillCache.get(gridKey);
            if (null == hasSite || !hasSite) {
                fillCache.put(gridKey, true);
                destList.add(siteInfo);
            } else {
                continue;
            }
        }
        GCLogger.error("view", "过滤点耗时：" + (System.currentTimeMillis() - startT) + "   过滤后点数量:" + destList.size());
        return destList;
    }

    /**
     * 过滤站点 获得聚合信息 站点信息和该站点周围站点数量信息
     *
     * @param fromList
     * @param lbPoint
     * @param rtPoint
     * @return
     */
    public static Map<LatLng, Integer> filterSitesToClusterPoint(List<SiteInfo> fromList, LatLng lbPoint, LatLng rtPoint) {
        long startT = System.currentTimeMillis();
        if (null == fromList || fromList.isEmpty()) {
            return null;
        }
        // 存储最后返回的结果, 存放内容为格子中某站点的经纬度和该格子里面的站点数量
        Map<LatLng, Integer> resultMap = new HashMap<>();
        // 存储格子的index 和 格子里的站点数量
        Map<Integer, Integer> gridKeyNumMap = new HashMap<>();
        // 存储格子的index 和 格子里选取的某个站点的经纬度
        Map<Integer, LatLng> gridKeyPositionMap = new HashMap<>();
        double maxLat = rtPoint.latitude;
        double minLat = lbPoint.latitude;
        double maxLng = rtPoint.longitude;
        double minLng = lbPoint.longitude;

        double latDuration = maxLat - minLat;
        double lngDuration = maxLng - minLng;
        if (latDuration <= 0 || lngDuration <= 0) {
            return null;
        }

        // 存储格子中是否已经存在点 key 为格子的序列号 lng 为横左边 lat为纵坐标
        //   0   1   2   3 ... 19
        //   20  21  22  23 ...39
        //         .
        //         .
        //   380 381 382 383 ... 399
        for (SiteInfo siteInfo : fromList) {
            double lat = siteInfo.getLat();
            double lng = siteInfo.getLng();
            if (lat > maxLat || lat < minLat || lng > maxLng || lng < minLng) {
                // 不在范围内
                continue;
            }
            int gridKey = getGridKey(lat - minLat, lng - minLng, latDuration, lngDuration);
            if (gridKey < 0 || gridKey > GRID_SIZE) {
                // 点不在范围内
                continue;
            }
            Integer siteNumInGrid = gridKeyNumMap.get(gridKey);
            if (null == siteNumInGrid || 0 == siteNumInGrid) {
                // 该格子中没有放置站点
                gridKeyNumMap.put(gridKey, 1);
                // 存放格子中某点对应的经纬度
                LatLng girdLL = new LatLng(siteInfo.getLat(), siteInfo.getLng());
                gridKeyPositionMap.put(gridKey, girdLL);
            } else {
                // 格子中有站点 将站点数量+1
                gridKeyNumMap.put(gridKey, gridKeyNumMap.get(gridKey) + 1);
                continue;
            }
        }
        // 合并两个集合的数据
        for (int gridKey = 0; gridKey < (GRID_SIZE - 1); gridKey++) {
            int siteNum = gridKeyNumMap.get(gridKey) == null ? 0 : gridKeyNumMap.get(gridKey);
            if (siteNum > 0) {
                LatLng siteLatlng = gridKeyPositionMap.get(gridKey);
                resultMap.put(siteLatlng, siteNum);
            }
        }
        gridKeyNumMap.clear();
        gridKeyPositionMap.clear();
        GCLogger.error("view", "过滤点变聚合点耗时：" + (System.currentTimeMillis() - startT) + "   过滤后点数量:" + gridKeyPositionMap.size());
        return resultMap;
    }

    /**
     * 通过lat lng的差值来获取该点所在的格子序号 详见filterSites方法
     *
     * @param latDiff
     * @param lngDiff
     * @param latDuration
     * @param lngDuration
     * @return
     */
    private static int getGridKey(double latDiff, double lngDiff, double latDuration, double lngDuration) {
        if (latDiff < 0 || lngDiff < 0 || latDuration <= 0 || lngDuration <= 0) {
            return -1;
        }
        int xIndex = (int) (lngDiff / lngDuration * GRID_HORIZONTAL_SIZE);
        int yIndex = (int) (latDiff / latDuration * GRID_VERTICAL_SIZE);
        int key = xIndex + yIndex * GRID_HORIZONTAL_SIZE;
        return key;
    }

    /**
     * 根据缩放等级进行过滤
     *
     * @param fromList
     * @param zoomLevel
     * @return
     */
    // 用来过滤不同缩放级别下要显示的站点密度
    private static final long[] precisions = new long[]{
            10L, 10L, 10L, 10L, 10L,  // 0 ~ 4
            10L, 10L, 10L, 10L, 10L,  // 5 ~ 9
            10L, 100L, 100L, 100L, 100L, // 10 ~ 14
            1000L, 10000L, 10000000000L, 1000000000000L, 1000000000000L, // 15 ~ 19
            10000000000000L, 100000000000000L // 20 ~ 21
    };

    public static List<SiteInfo> filterSiteByZoomLevel(List<SiteInfo> fromList, float zoomLevel) {
        long startT = System.currentTimeMillis();
        if (null == fromList || fromList.isEmpty()) {
            return fromList;
        }
        List<SiteInfo> destList = new ArrayList<>();
        Map<String, Integer> cacheMap = new HashMap<>();
        long filterNumber = precisions[getFilterIndex(zoomLevel)];
        for (SiteInfo site : fromList) {
            long latL = (long) (site.getLat() * filterNumber);
            long lngL = (long) (site.getLng() * filterNumber);
            String key = String.format("%s_%s", latL, lngL);
            if (cacheMap.containsKey(key)) {
                cacheMap.put(key, cacheMap.get(key) + 1);
            } else {
                cacheMap.put(key, 1);
                destList.add(site);
            }
        }
        cacheMap.clear();
        GCLogger.error("view", "过滤点耗时：" + (System.currentTimeMillis() - startT) + "   过滤后点数量:" + destList.size());
        return destList;
    }

    /**
     * 通过缩放等级计算经纬度保留的精度保留小数点后几位
     *
     * @param zoomLevel 14~21  16以下即可显示全部精度
     * @return
     */
    private static int getFilterIndex(float zoomLevel) {
        int zoomInt = (int) (zoomLevel + 0.5);
        if (zoomInt < 0 || zoomInt > precisions.length - 1) {
            return precisions.length - 1;
        }
        return zoomInt;
    }

    /**
     * 获得厂商的别名称
     *
     * @param incText
     * @return
     */
    public static String getAliasIncName(String incText) {
        Resources r = BaseApplication.getAppContext().getResources();
        String simpleText = "unknown";
        if (incText.equals(r.getString(R.string.https_impl_huawei))) {
            simpleText = r.getString(R.string.https_impl_huawei);
        } else if (incText.equals(r.getString(R.string.https_impl_zte))) {
            simpleText = "Z///";
        } else if (incText.equals(r.getString(R.string.https_impl_bell))) {
            simpleText = "B///";
        } else if (incText.equals(r.getString(R.string.https_impl_datang))) {
            simpleText = "D///";
        } else if (incText.equals(r.getString(R.string.https_impl_ericsson))) {
            simpleText = "E///";
        } else if (incText.equals(r.getString(R.string.https_impl_nuoxi))) {
            simpleText = "N///";
        } else if (incText.equals(r.getString(R.string.https_impl_fenghuo))) {
            simpleText = "F///";
        } else if (incText.equals(r.getString(R.string.https_impl_putian))) {
            simpleText = "P///";
        } else if (incText.equals(r.getString(R.string.https_impl_alang))) {
            simpleText = "A///";
        }
        return simpleText;
    }

    /**
     * 设置地图标记物的状态
     *
     * @param markers 对应的markerList集合
     * @param status  对应的状态[SHOW/HIDE/CLEAR]
     */
    public static void setMapMarkerStatus(List<Marker> markers, TypeEnum.MarkerStatus status) {
        if (markers != null && markers.size() != 0) {
            try {
                for (Marker marker : markers) {
                    switch (status) {
                        case SHOW:
                            marker.setVisible(true);
                            break;
                        case HIDE:
                            marker.setVisible(false);
                            break;
                        case CLEAR:
                            marker.remove();
                            break;
                    }
                    marker = null;
                }
            } catch (Exception e) {
                GCLogger.error(Module.GENEX_CLOUD, e.toString());
            }
        }
        if (status == TypeEnum.MarkerStatus.CLEAR && markers != null) {
            markers.clear();
            markers = null;
        }
    }

    /**
     * 设置地图标记物的状态
     */
    public static void setMapMarkerStatus(List<Marker> markers, TypeEnum.MarkerStatus status, boolean isShowOtherSite) {
        if (markers != null && markers.size() != 0) {
            try {
                for (Marker marker : markers) {
                    switch (status) {
                        case SHOW:
                            if (!isShowOtherSite) {
                                SiteInfo info = (SiteInfo) marker.getExtraInfo().getSerializable("bean");
                                marker.setVisible("华为".equals(info.getFRSName()));
                            } else {
                                marker.setVisible(true);
                            }
                            break;
                        case HIDE:
                            marker.setVisible(false);
                            break;
                        case CLEAR:
                            marker.remove();
                            break;
                    }
                    marker = null;
                }
            } catch (Exception e) {
                GCLogger.error("exception", e.toString());
            }
        }
        if (status == TypeEnum.MarkerStatus.CLEAR && markers != null) {
            markers.clear();
            markers = null;
        }
    }

    /**
     * 得到rsrp颜色
     *
     * @param rsrpValue 值
     * @return
     */
    public static int getRsrpColor(int rsrpValue) {
        int color = Color.TRANSPARENT;
        if (rsrpValue == 0) {
            //无效值field
            return 0xffff0000;
        }
        if (rsrpValue >= -95) {
            color = 0xff008000;
        } else if (rsrpValue >= -100 && rsrpValue < -95) {
            color = 0xff00ff00;
        } else if (rsrpValue >= -105 && rsrpValue < -100) {
            color = 0xff00b0f0;
        } else if (rsrpValue >= -110 && rsrpValue < -105) {
            color = 0xff002060;
        } else if (rsrpValue >= -115 && rsrpValue < -110) {
            color = 0xffffff00;
        } else if (rsrpValue >= -120 && rsrpValue < -115) {
            color = 0xffff00ff;
        } else {
            color = 0xffff0000;
        }
        return color;
    }

    /**
     * 得到rsrp颜色
     *
     * @param rsrpValue 值
     * @return
     */
    public static int getMRRsrpColor(int rsrpValue) {
        int color = Color.TRANSPARENT;
        if (rsrpValue == 0) {
            //无效值field
            return Color.TRANSPARENT;
        }
        if (rsrpValue >= -80) {
            color = Color.parseColor("#d28181d7");
        } else if (rsrpValue >= -90 && rsrpValue < -80) {
            color = Color.parseColor("#d24b8de4");
        } else if (rsrpValue >= -100 && rsrpValue < -90) {
            color = Color.parseColor("#d288c218");
        } else if (rsrpValue >= -110 && rsrpValue < -100) {
            color = Color.parseColor("#d2f87f38");
        } else if (rsrpValue >= -150 && rsrpValue < -110) {
            color = Color.parseColor("#d2fe0000");
        } else {
            color = Color.TRANSPARENT;
        }
        return color;
    }

    /**
     * 得到用户颜色
     *
     * @param user       值
     * @param middleUser 中值
     * @return
     */
    public static int getMRUserColor(int user, int middleUser) {
        int color = Color.TRANSPARENT;
        if (user == 0) {
            //无效值field
            return Color.parseColor("#d24b8de4");
        }
        if (user <= middleUser - middleUser / 2) {
            color = Color.parseColor("#d24b8de4");
        } else if (user <= middleUser) {
            color = Color.parseColor("#d288c218");
        } else if (user <= middleUser + middleUser / 2) {
            color = Color.parseColor("#d2f87f38");
        } else {
            color = Color.parseColor("#d2fe0000");
        }
        return color;
    }

    /**
     * 得到流量颜色
     *
     * @param flow       值
     * @param middleFlow 中值
     * @return
     */
    public static int getMRFlowColor(double flow, double middleFlow) {
        int color = Color.TRANSPARENT;
        if (flow == 0) {
            //无效值field
            return Color.parseColor("#d24b8de4");
        }
        if (flow < middleFlow) {
            color = Color.parseColor("#d288c218");
        } else {
            color = Color.parseColor("#d2f87f38");
        }
        if (flow <= middleFlow - middleFlow / 2) {
            color = Color.parseColor("#d24b8de4");
        } else if (flow <= middleFlow) {
            color = Color.parseColor("#d288c218");
        } else if (flow <= middleFlow + middleFlow / 2) {
            color = Color.parseColor("#d2f87f38");
        } else {
            color = Color.parseColor("#d2fe0000");
        }

        return color;
    }

    /**
     * 得到rsrp颜色<亮>
     *
     * @param rsrpValue 值
     * @return
     */
    public static int getRsrpGroupColor(int rsrpValue) {
        int color = Color.TRANSPARENT;
        if (rsrpValue < -115) {
            color = 0xffff0000;
        } else if (rsrpValue >= -115 && rsrpValue < -100) {
            color = 0xffffff00;
        } else {
            color = 0xff008000;
        }
        return color;
    }

    /**
     * 得到sinr颜色
     *
     * @param sinrValue 值
     * @return
     */
    public static int getSinrColor(int sinrValue) {
        int color = Color.TRANSPARENT;
        if (sinrValue >= 20) {
            color = 0xff008000;
        } else if (sinrValue >= 15 && sinrValue < 20) {
            color = 0xff00ff00;
        } else if (sinrValue >= 10 && sinrValue < 15) {
            color = 0xff00b0f0;
        } else if (sinrValue >= 5 && sinrValue < 10) {
            color = 0xff002060;
        } else if (sinrValue >= 0 && sinrValue < 5) {
            color = 0xffffff00;
        } else if (sinrValue >= -5 && sinrValue < 0) {
            color = 0xffff00ff;
        } else {//<-5
            color = 0xffff0000;
        }
        return color;
    }

}
