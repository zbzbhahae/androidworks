package com.huawei.genexcloud.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * 多个站点合并 显示圈圈
 */
public class SiteClusterView extends View {

    private final int COLOR_FILL = 0xFFFF0000;
    private final int COLOR_BORDER = 0xFFFFFF00;
    private final int COLOR_NUMBER = 0xFFFFFFFF;

    // 默认view大小20dp
    private final float defaultViewSize = dp2px(30);
    private final float maxViewSize = dp2px(50);
    // 30个为最大size 根据num数量来确定view大小
    private final float maxSizeNum = 30;

    private int width, height;

    // 圆的半径
    private float mRadius;
    // 圆的填充颜色 圈颜色
    private int fillColor = COLOR_FILL;
    private int borderColor = COLOR_BORDER;
    private int numberColor = COLOR_NUMBER;

    private float borderSize = sp2px(2);
    private float numberSize = sp2px(12);
    // 圆圈画笔 数字画笔
    private Paint circlePaint, textPaint;
    // 文字的baseLine 和高度
    private float textBaseLine = 0, textHeight = 0;

    // 站点数量
    private int mNumber = 0;


    private void init() {
        circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        circlePaint.setColor(borderColor);
        circlePaint.setStrokeWidth(borderSize);
        circlePaint.setStyle(Paint.Style.STROKE);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(numberColor);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextSize(numberSize);

        Paint.FontMetricsInt fmi = textPaint.getFontMetricsInt();
        textBaseLine = 0.5f * (fmi.descent - fmi.ascent) - fmi.descent;

    }

    public SiteClusterView(Context context) {
        super(context);
        init();
    }

    public SiteClusterView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SiteClusterView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private float dp2px(float dp) {
        return getResources().getDisplayMetrics().density * dp;
    }

    private float sp2px(float sp) {
        return getResources().getDisplayMetrics().scaledDensity * sp;
    }

    /**
     * 设置站点数量
     * @param number
     */
    public void setSiteNumber(int number) {
        mNumber = number;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        float mSize = defaultViewSize + (maxViewSize - defaultViewSize) * (mNumber * 1f / maxSizeNum);
        float numberTextWidth = textPaint.measureText(String.valueOf(mNumber));
        if (numberTextWidth > mSize) {
            mSize = numberSize + dp2px(4); // 左右各2dp空间
        }
        int mSizeInt = (int)(mSize + 0.5f);
        width = mSizeInt;
        height = mSizeInt;
        mRadius = mSizeInt * 0.5f;
        setMeasuredDimension(mSizeInt, mSizeInt);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawCircle(canvas);
        drawCircleBorder(canvas);
        drawNumber(canvas);
    }

    private void drawCircle(Canvas canvas) {
        circlePaint.setStyle(Paint.Style.FILL);
        circlePaint.setColor(fillColor);
        canvas.drawCircle(width * 0.5f, height * 0.5f, mRadius, circlePaint);
    }

    private void drawCircleBorder(Canvas canvas) {
        circlePaint.setStyle(Paint.Style.STROKE);
        circlePaint.setColor(borderColor);
        canvas.drawCircle(width * 0.5f, height * 0.5f, mRadius, circlePaint);
    }

    private void drawNumber(Canvas canvas) {
        float textWidth = textPaint.measureText(String.valueOf(mNumber));

        float startX = (width - textWidth) * 0.5f;
        float startY = 0.5f * height + textBaseLine;
        canvas.drawText(String.valueOf(mNumber), startX, startY, textPaint);
    }
}
