package com.huawei.genexcloud.fragment;

import static com.huawei.genexcloud.util.BdMapGridParamUtils.OutDirection.NAN;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.HeatMap;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.baidu.mapapi.navi.BaiduMapAppNotSupportNaviException;
import com.baidu.mapapi.navi.BaiduMapNavigation;
import com.baidu.mapapi.navi.NaviParaOption;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.district.DistrictResult;
import com.baidu.mapapi.search.district.DistrictSearch;
import com.baidu.mapapi.search.district.DistrictSearchOption;
import com.baidu.mapapi.search.district.OnGetDistricSearchResultListener;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.sug.SuggestionResult;
import com.baidu.mapapi.utils.SpatialRelationUtil;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.BaseActivity;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.base.BaseFragment;
import com.huawei.genexcloud.bean.CityGrideDataBean;
import com.huawei.genexcloud.bean.CityGrideSiteResp;
import com.huawei.genexcloud.bean.CityInfo;
import com.huawei.genexcloud.bean.ExperienceSiteInfo;
import com.huawei.genexcloud.bean.Gps;
import com.huawei.genexcloud.bean.GpsBounds;
import com.huawei.genexcloud.bean.PolygonBean;
import com.huawei.genexcloud.bean.QueryAreaSiteBean;
import com.huawei.genexcloud.bean.ReqMapDataBean;
import com.huawei.genexcloud.bean.SearchSiteBean;
import com.huawei.genexcloud.bean.SenseMapControllerBean;
import com.huawei.genexcloud.bean.SiteBaseBean;
import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.bean.TypeEnum;
import com.huawei.genexcloud.common.Constant;
import com.huawei.genexcloud.database.AppDatabase;
import com.huawei.genexcloud.database.Constants;
import com.huawei.genexcloud.database.HeatMapData;
import com.huawei.genexcloud.database.HeatMapDataDao;
import com.huawei.genexcloud.database.NPOData;
import com.huawei.genexcloud.database.NPODataDao;
import com.huawei.genexcloud.databinding.PageHomeBinding;
import com.huawei.genexcloud.dialog.CannotComplainDialog;
import com.huawei.genexcloud.dialog.InstalledDialog;
import com.huawei.genexcloud.dialog.MarkPointDialog;
import com.huawei.genexcloud.dialog.SearchResultDilog;
import com.huawei.genexcloud.dialog.SenseMapRightToolsDialog;
import com.huawei.genexcloud.http.InsertSupportRecordImpl;
import com.huawei.genexcloud.http.QueryExperienceSiteListImpl;
import com.huawei.genexcloud.http.SearchSiteInfoImpl;
import com.huawei.genexcloud.http.sensemap.QueryPolygonForHWImpl;
import com.huawei.genexcloud.http.sensemap.QueryProvinceHeatmapInfoImpl;
import com.huawei.genexcloud.http.sensemap.QueryProvinceSiteSummaryImpl;
import com.huawei.genexcloud.http.sensemap.QuerySiteInfoImpl;
import com.huawei.genexcloud.http.util.CellInfoUtils;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.util.AddrNameUtils;
import com.huawei.genexcloud.util.AppPermissionUtil;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.util.BaiduSuggestSearchUtil;
import com.huawei.genexcloud.util.BdMapGridParamUtils;
import com.huawei.genexcloud.util.CacheUtil;
import com.huawei.genexcloud.util.CarrierNameUtils;
import com.huawei.genexcloud.util.DeviceUtil;
import com.huawei.genexcloud.util.Formatter;
import com.huawei.genexcloud.util.GeoUtils;
import com.huawei.genexcloud.util.PositionUtils;
import com.huawei.genexcloud.util.SenceMapTextUtils;
import com.huawei.genexcloud.util.ShareDataUtil;
import com.huawei.genexcloud.util.map.MapUtil;
import com.huawei.genexcloud.util.map.SiteUtils;
import com.huawei.genexcloud.viewmodel.MainSharedDataViewModel;
import com.huawei.genexcloud.widget.AddSiteTypeView;
import com.huawei.genexcloud.widget.SiteDetailView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import okhttp3.Request;

public class SenseMapController implements View.OnClickListener,
        AddSiteTypeView.CommitListener {

    private static final int NOT_IN_POLYGON = -1; // 中心点不在polygon范围内
    private static final int IN_POLYGON_NO_SITE = 0; // 中心点在polygon范围内，但是没有站点

    private BaseFragment homePage;
    private PageHomeBinding binding;
    private BaiduMap mBaiduMap;
    private boolean firstLocation = true;
    private LocationClient locationClient;
    // 记录进入页面默认信息
    private String myProvinceName, myCityName;
    private LatLng myLocationLatLng;
    private final ArrayList<Overlay> polygonOverlay = new ArrayList<>();
    private final SenseMapControllerBean controllerBean = new SenseMapControllerBean();
    private boolean mapIsExpanded = false; // 地图是否展开
    // 侧边栏回调接口
    private final SenseMapRightToolsDialog.DataChangedCallback rightToolsCallback =
            new SenseMapRightToolsDialog.DataChangedCallback() {
                @Override
                public void onMapTypeChanged(int type) {
                    if (mBaiduMap != null) {
                        mBaiduMap.setMapType(type);
                    }
                    GCLogger.error("map", "onMapTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onSiteTypeChanged(int type) {
                    setSiteShowType();
                    GCLogger.error("map", "onSiteTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onMarkTypeChanged(int type) {
                    onExperienceClick(controllerBean.isShowMarkType());
                    GCLogger.error("map", "onMarkTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onSiteStatusChanged(boolean checked) {
                    onSiteClick(checked);
                    GCLogger.error("map", "onSiteStatusChanged:" + checked);
                }

                @Override
                public void onPatternStatusChanged(boolean checked) {
                    onOtherSiteClick(checked);
                    GCLogger.error("map", "onPatternStatusChanged:" + checked);
                }

                /**
                 * 改变了信号显示开关
                 * @param checked
                 */
                @Override
                public boolean onSignalStatusChanged(boolean checked) {
                    GCLogger.error("map", "onSignalStatusChanged:" + checked);
                    return onSignalClick(checked);
                }

                @Override
                public void onHWDensityStatusChanged(boolean checked) {
                    onHwDensityClick(checked);
                    GCLogger.error("map", "onHWDensityStatusChanged:" + checked);
                }
            };

    private static final int INDEX_INC_SITE = 0, INDEX_EXPERIENCE = 1;
    private static final float DEFAULT_ZOOM = 18.0f;
    private static final float MAX_ZOOM = 21f;
    private static final float MIN_ZOOM = 5f;
    private static final float BORDER_ZOOM = 14.0f;
    private static final int SELECT_OPERATOR = 9999;
    private static final int SELECT_PHOTO = 999;
    private static final int CREAM = 1001;
    private BDLocation sl;
    private LatLng currentMapCenterLatLng;
    private boolean isClearMarker = false;
    // 保存当前滑动详情信息<影响到下次打开是恢复还是重置>
    private boolean isSaveBottomScrollInfo = false;
    // 地图覆盖物
    private Overlay districPolyLine;
    private List<LatLng> provincePolyLineList;
    private SiteDetailView siteDetailView;
    private String selCity = "";
    private String selOper = "";
    private String selProvince = "";
    private final CopyOnWriteArrayList<Marker> outerSiteMarkers = new CopyOnWriteArrayList<>();// 室外站点
    private final CopyOnWriteArrayList<Marker> innerSiteMarkers = new CopyOnWriteArrayList<>();// 室内站点
    private SearchResultDilog searchResultDialog;
    private final ArrayList<Marker> experienceMarkers = new ArrayList<>();
    private boolean isShow4g = false;
    private String cnCarrier;// 当前运营商
    private String enCarrier;
    private LatLng clickedSiteLatLng;
    private boolean isShowedScaleInfo;
    private String provinceName;  // 当前省
    private String cityName; // 当前市名
    // 基站
    private boolean isCanComplain = true;
    private InfoWindow clickMarkerIndicator;
    private final List<SiteInfo> siteResultList = new ArrayList<>();
    private final List<SiteInfo> siteResultListAll = new ArrayList<>();
    // 选中的基站信息
    private SiteBaseBean searchSiteInfo = null;
    private QueryAreaSiteBean currentAreaSiteBean;
    private boolean IS_PROVINCE_ZOOM = false;  // 省的鸟瞰
    private DistrictSearch districtSearch;
    // 热力图相关   表示当前热力图的唯一标识，防止频繁更新热力图 key由创建热力图时的province operator和netType构成
    // 如果更新数据时，热力图所属信息与当前一致，则不更新
    private String heatMapKey;
    private HeatMap huaweiIncHeatmap;

    private boolean isFirstFinishStatus = true;
    private String preExperienceCity;
    private String preExperienceNetOper;
    private float preZoom;
    private int openTag = -1;
    private boolean isFirstEnter = true;
    private boolean isMapMove = false;
    private LatLngBounds currentBounds;
    private float currentZoom;
    private boolean isDrawingSite = false;
    private boolean isSiteClickOpen = true;
    private ArrayList<ExperienceSiteInfo> experienceList = new ArrayList<>();
    @SuppressLint("HandlerLeak")
    private final Handler delayHandler = new Handler();
    private final float CLUSTER_ZOOM = 16;

    // 定位回调
    private MyLocationListener locationListener;
    // MainActivity 共享数据内容 包含感知地图的省市选择信息
    private MainSharedDataViewModel viewModel;
    // 省市选择状态
    private MainSharedDataViewModel.SenseMapStatus senseMapStatus;
    // 是否拥有npo权限， npo权限可以查看全省热力图，可以切换地市
    private boolean hasNpoPermission = false;
    // 定位位置的geo搜索结果 标点功能需要
    private String mAddress;

    private GeoCoder mSearch;
    private final TextView.OnEditorActionListener myEditActionListener = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            if (i == EditorInfo.IME_ACTION_SEARCH) {
                String inputStr = binding.smSearchEdit.getText().toString().trim();
                if (TextUtils.isEmpty(inputStr) && homePage != null) {
                    homePage.showMsg("请输入搜索内容");
                    return true;
                }

                searchAreaSite(inputStr);
            }
            return true;
        }
    };

    public void initMap(BaseFragment homePage, PageHomeBinding binding) {
        this.homePage = homePage;
        this.binding = binding;

        initView(); // 初始化控件
        initData(); // 初始化数据内容
        // TODO 相关权限控制
        initPermission();// 初始化权限<涉及右侧工具栏>
        initDistrictSearch();// 初始化行政编码
        initBaiduMap();// 初始化地图
        iniSiteDetailView();// 初始化底部滑动
    }

    public void onResume() {
        binding.mapView.onResume();
        locationClient.start();
    }

    public void onPause() {
        binding.mapView.onPause();
        locationClient.stop();
    }

    public void onDestroy() {
        GeoUtils.getInstance().destroySelf();
        delayHandler.removeCallbacksAndMessages(null);
        BaiduSuggestSearchUtil.getInstance().onDestroy();
        // 取消定位服务
        if (null != locationClient) {
            locationClient.stop();
            if (null != locationListener) {
                locationClient.unRegisterLocationListener(locationListener);
            }
        }
        binding.mapView.onDestroy();
        if (mBaiduMap != null) {
            mBaiduMap.clear();
        }
        mBaiduMap = null;
        binding = null;
        homePage = null;
    }

    /**
     * 地图在主界面被展开和收起时调用。用来管理界面显示
     * @param expanded
     */
    public void onMainScrollerChanged(boolean expanded) {
        if (expanded == mapIsExpanded) {
            return;
        }

        mapIsExpanded = expanded;
        resetPolygon();
        if (mapIsExpanded) {
            GCLogger.error(Module.GENEX_CLOUD, "地图展开");
        } else {
            // 如果有其他弹窗状态，需要恢复
            GCLogger.error(Module.GENEX_CLOUD, "地图收起");
        }

    }

    private final QuerySiteInfoImpl.Callback onSiteInfoResult  = new QuerySiteInfoImpl.Callback() {
        @Override
        public void onFailure(ErrorBean e) {
            // TODO
        }

        @Override
        public void onResponse(List<SiteInfo> response) {
            if (null == response) {
                siteResultList.clear();
                return;
            }
            if (siteResultListAll.size() > 0) {
                siteResultList.clear();
                boolean isOneMore = false;
                for (SiteInfo info : response) {
                    for (SiteInfo allInfo : siteResultListAll) {
                        if (info.getNodebId() == allInfo.getNodebId()) {
                            // AllList 列表中存在改站点
                            isOneMore = true;
                            break;
                        }
                    }
                    if (!isOneMore) {
                        siteResultList.add(info);
                    }
                }
                // 缓存的点多于1500个
                if ((siteResultListAll.size() + siteResultList.size()) > 1500) {
                    GCLogger.error("map", "集合大小超限制了开始清理 siteResultListAll:"
                            + siteResultListAll.size() + "    siteResultList:" + siteResultList.size());
                    siteResultListAll.clear();
                    isClearMarker = true;
                }
                siteResultListAll.addAll(response);
            } else {
                siteResultListAll.addAll(response);
            }
            CacheUtil.getInstance().saveSiteInfo(response);
            drawBaiduMapOverlays(INDEX_INC_SITE, response);
        }
    };

    private void showSearchResultDialog() {
        if (searchResultDialog != null) {
            searchResultDialog.show();
        }
    }

    /**
     * 绘制百度地图覆盖物
     */
    @SuppressWarnings("unchecked")
    private <T> void drawBaiduMapOverlays(int type, List<T> list) {
        List<SiteInfo> siteInfos = new ArrayList<>();
        // 按钮控制
        if (!controllerBean.isShowSite()) {
            return;
        }
        switch (type) {
            case INDEX_INC_SITE:
                // 绘制站点
                if (isClearMarker) {
                    clearExistIncSiteMarkers();
                }
                if (currentZoom < BORDER_ZOOM) {
                    return;
                }
                isDrawingSite = true;
                siteInfos = (List<SiteInfo>) list;
                isMapMove = false;
                drawSite2(siteInfos);
                isClearMarker = false;
                isDrawingSite = false;
                break;
            case INDEX_EXPERIENCE:
                // 绘制体验标点
                experienceList = (ArrayList<ExperienceSiteInfo>) list;
                LatLng latLng;
                for (ExperienceSiteInfo exInfo : experienceList) {
                    if (controllerBean.isShowMarkType(exInfo.getRecordType())) {
                        latLng = new LatLng(exInfo.getLat(), exInfo.getLng());
                        MarkerOptions exMarkerOption = SiteUtils.getExperienceMarkerOption(exInfo, latLng, false);

                        Bundle bundle = new Bundle();
                        bundle.putSerializable("info", exInfo);
                        bundle.putString("markerType", "feelPointMarker");
                        exMarkerOption.extraInfo(bundle);

                        Marker exMarker = (Marker) mBaiduMap.addOverlay(exMarkerOption);
                        exMarker.setToTop();
                        experienceMarkers.add(exMarker);
                    }
                }
                break;
        }
    }

    /**
     * 显示站点密度，绘制省份轮廓
     *
     * @param pointList 轮廓线
     */
    private void drawProvincePolygonLine(List<LatLng> pointList) {
        if (districPolyLine != null) {
            districPolyLine.remove();
        }
        clearHuaweiHeatMap();
        //有的城市size为0
        if (pointList == null || pointList.size() < 2) {
            return;
        }
        this.provincePolyLineList = pointList;
        drawDistrictPolyLines(provincePolyLineList);
        setBaiduMapZoomToProvince(provincePolyLineList);
    }

    private CopyOnWriteArrayList<Overlay> detailSiteList = new CopyOnWriteArrayList<>();
    private CopyOnWriteArrayList<Overlay> clusterSiteList = new CopyOnWriteArrayList<>();
    private void drawSite2(List<SiteInfo> siteList) {
        // 移除地图上之前绘制的站点信息
        mBaiduMap.removeOverLays(detailSiteList);
        mBaiduMap.removeOverLays(clusterSiteList);
        detailSiteList.clear();
        clusterSiteList.clear();
        if (null == siteList || siteList.isEmpty()) {
            return;
        }
        // 获取当前地图缩放等级和视野范围
        MapStatus mapStatus = mBaiduMap.getMapStatus();
        float zoom = mapStatus.zoom;
        LatLngBounds bound = mapStatus.bound;
        // 查看设置 是否显示站点 室内 室外 站点
        boolean isShowSite = controllerBean.isShowSite();
        boolean isShowOuter = controllerBean.isShowOutdoorSite();
        boolean isShowInner = controllerBean.isShowIndoorSite();
        // 是否显示异厂商站点
        boolean isShowOtherIncSite = controllerBean.isShowPatternSite();
        // 是否是正在显示站点密度
        boolean isShowDensity = controllerBean.isShowHWSiteDensity();
        if (!isShowSite || (!isShowOuter && !isShowInner) || isShowDensity) {
            // 不显示站点
            return;
        }
        // 拷贝一份siteList
        List<SiteInfo> siteCopyList = new ArrayList<>();
        siteCopyList.addAll(siteList);
        // 先过滤不显示的站点
        List<SiteInfo> filteredSiteList = SiteUtils.filterSitesByOption(
                siteCopyList, bound, isShowOuter, isShowInner, isShowOtherIncSite);
        if (null == filteredSiteList || filteredSiteList.isEmpty()) {
            return;
        }
        if (zoom < CLUSTER_ZOOM) {
            // 缩放等级在 BORDER_ZOOM 和 CLUSTER_ZOOM 之间 显示站点聚合
            // 获得聚合点
            Map<LatLng, Integer> clusterMap = SiteUtils
                    .filterSitesToClusterPoint(filteredSiteList, bound.southwest, bound.northeast);
            List<OverlayOptions> markerOptions = SiteUtils.getSiteClusterOptions(requireContext(), clusterMap);
            // 地图上添加站点
            List<Overlay> addedOverlays = mBaiduMap.addOverlays(markerOptions);
            if (null != addedOverlays) {
                clusterSiteList.addAll(addedOverlays);
            }
        } else {
            List<OverlayOptions> markerOptions = SiteUtils.getSiteDetailMarkerOptions(requireContext(), filteredSiteList);
            // 添加站点marker到地图
            List<Overlay> addedOverlays = mBaiduMap.addOverlays(markerOptions);
            if (null != addedOverlays) {
                detailSiteList.addAll(addedOverlays);
            }
        }
        for (SiteInfo siteInfo : siteCopyList) {
            if (searchSiteInfo != null && searchSiteInfo.getLat() == siteInfo.getLat()
                    && searchSiteInfo.getNodebId() == siteInfo.getNodebId()
                    && searchSiteInfo.getLng() == siteInfo.getLng()) {
                showWindowInfo(siteInfo);
            }
        }
    }

    /**
     * 绘制站点
     *
     * @param siteInfos
     */
    private void drawSite(List<SiteInfo> siteInfos) {
        if (null == siteInfos || siteInfos.isEmpty()) {
            return;
        }
        long startT = System.currentTimeMillis();
        // 防止在绘制过程中地图变化导致绘制不一致的问题
        float mapZoom = currentZoom;
        List<OverlayOptions> markerOptions = new ArrayList<>();
        if (mapZoom < CLUSTER_ZOOM) {
            // 显示站点数量 不显示站点详细内容
            Map<LatLng, Integer> siteClustermap = SiteUtils
                    .filterSitesToClusterPoint(siteInfos, currentBounds.southwest, currentBounds.northeast);
            if (null != siteClustermap && !siteClustermap.isEmpty()) {
                for (Map.Entry<LatLng, Integer> item : siteClustermap.entrySet()) {
                    GCLogger.error("view", "准备生成聚合点");
                    MarkerOptions markerOption = SiteUtils.getSiteClusterOption(requireContext(), item.getKey(), item.getValue());
                    if (null != markerOption) {
                        markerOptions.add(markerOption);
                    }
                }
            }
        } else {
            // 对站点进行过滤
            List<SiteInfo> filteredSites = SiteUtils.filterSiteByZoomLevel(siteInfos, mapZoom);

            for (SiteInfo siteInfo : filteredSites) {
                MarkerOptions markerOption;
                markerOption = SiteUtils.getSiteDetailMarkerOption(requireContext(), siteInfo);
                if (null == markerOption) {
                    continue;
                }

                Bundle bundle = new Bundle();
                bundle.putString("markerType", "incMarker");
                bundle.putSerializable("bean", siteInfo);
                markerOption.extraInfo(bundle);
                if (isMapMove) {
                    isDrawingSite = false;
                    return;
                }
                if (siteInfo.getIndoorId() == 0) {
                    if (controllerBean.isShowOutdoorSite() && !controllerBean.isShowPatternSite()) {
                        markerOption.visible("华为".equals(siteInfo.getFRSName()));
                    } else {
                        markerOption.visible(controllerBean.isShowOutdoorSite());
                    }
                } else {
                    if (controllerBean.isShowIndoorSite() && !controllerBean.isShowPatternSite()) {
                        markerOption.visible("华为".equals(siteInfo.getFRSName()));
                    } else {
                        markerOption.visible(controllerBean.isShowIndoorSite());
                    }
                }
                markerOptions.add(markerOption);
                if (searchSiteInfo != null && searchSiteInfo.getLat() == siteInfo.getLat() && searchSiteInfo.getNodebId() == siteInfo.getNodebId()
                        && searchSiteInfo.getLng() == siteInfo.getLng()) {
                    showWindowInfo(siteInfo);
                }
            }
        }
        // 点整体添加 不单独添加
        List<Overlay> overlays = mBaiduMap.addOverlays(markerOptions);
        if (null != overlays && !overlays.isEmpty()) {
            for (Overlay overlay : overlays) {
                if (overlay instanceof Marker) {
                    outerSiteMarkers.add((Marker) overlay);
                    ((Marker) overlay).setToTop();
                }
            }
        }
        GCLogger.error("map", "绘制站点用时 : " + (System.currentTimeMillis() - startT) + " ms 总站点数 : " + siteInfos.size());
    }

    //显示泡泡信息
    private void showWindowInfo(SiteInfo siteInfo) {
        if (null == siteInfo) {
            return;
        }
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromResource(R.drawable.pop_marker_big_red);
        // 给当前点击的站点经纬度赋值
        clickedSiteLatLng = new LatLng(siteInfo.getLat(), siteInfo.getLng());
        // 添加marker点击指示器
        clickMarkerIndicator = new InfoWindow(bitmapDescriptor, clickedSiteLatLng, 0, null);
        mBaiduMap.showInfoWindow(clickMarkerIndicator);
        siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.NORMAL_SITE, siteInfo, isShow4g);
        siteDetailView.tvStationDistance.setText("距您" + SenceMapTextUtils.getDistanceText(myLocationLatLng, clickedSiteLatLng));
    }

    /**
     * 在地图上绘制华为区域边界
     */
    private void drawPolygon() {
        for (PolygonOptions options : CacheUtil.getInstance().getPolygonList()) {
            polygonOverlay.add(mBaiduMap.addOverlay(options));
        }
    }

    /**
     * 重置华为站点区域边界
     */
    private void resetPolygon() {
        if (!polygonOverlay.isEmpty()) {
            mBaiduMap.removeOverLays(polygonOverlay);
            polygonOverlay.clear();
        }

        binding.statusBarPadding.setBackgroundColor(Color.TRANSPARENT);
        binding.polygonTips.setVisibility(View.GONE);
        CacheUtil.getInstance().cleanPolygonData();
        if (!controllerBean.isShowHWSiteDensity() && mapIsExpanded) {
            // 发送polygon请求
            QueryPolygonForHWImpl.getInstance().query(
                    cityName,
                    enCarrier,
                    (isShow4g ? "4G" : "5G"),
                    new QueryPolygonForHWImpl.Callback() {
                        @Override
                        public void onFailure(ErrorBean e) {

                        }

                        @Override
                        public void onResponse(ArrayList<PolygonBean> polygons) {
                            onPolygonReceived(polygons);
                        }
                    });
        }
    }

    /**
     * 接收到Polygon轮廓信息，将轮廓画在地图上并且请求轮廓内的站点数据
     *
     * @param polygons 轮廓列表
     */
    public void onPolygonReceived(List<PolygonBean> polygons) {
        ArrayList<PolygonOptions> polygonOptions = new ArrayList<>();
        for (PolygonBean bean : polygons) {
            PolygonOptions options = new PolygonOptions()
                    .points(bean.getPolygonList())
                    .fillColor(0x33FFEB99)
                    .stroke(new Stroke(4, 0xAA009933));
            polygonOptions.add(options);
        }
        CacheUtil.getInstance().setPolygonList(polygonOptions);
        drawPolygon();
        requestPolygonSites();
    }

    /**
     * 请求中心点两公里内华为区域站点
     */
    private void requestPolygonSites() {
        // 站点密度开关打开了，不显示polygon，因此不再请求数据
        if (controllerBean.isShowHWSiteDensity() ||
            !mapIsExpanded) {
            return;
        }
        // 首先判断中心点是否落在多边形内
        PolygonOptions currentPolygon = null;
        for (PolygonOptions options: CacheUtil.getInstance().getPolygonList()) {
            if (SpatialRelationUtil.isPolygonContainsPoint(
                    options.getPoints(), currentMapCenterLatLng)) {
                currentPolygon = options;
                break;
            }
        }

        // 当前地市运营商没有polygon区域数据
        if (currentPolygon == null) {
            setPolygonTips(NOT_IN_POLYGON);
            return;
        }

        Gps gps = PositionUtils.bd09_To_Gps84(currentMapCenterLatLng.latitude, currentMapCenterLatLng.longitude);
        double r = 0.02; // 两公里范围
        LatLng northEast = new LatLng(gps.getWgLat() + r, gps.getWgLon() + r);
        LatLng southWest = new LatLng(gps.getWgLat() - r, gps.getWgLon() - r);
        QuerySiteInfoImpl.getPolyIns().querySiteInfo(
                northEast, southWest,
                provinceName, enCarrier,
                isShow4g ? "4G" : "5G",
                new QuerySiteInfoImpl.Callback() {
                    @Override
                    public void onFailure(ErrorBean e) {

                    }

                    @Override
                    public void onResponse(List<SiteInfo> siteInfos) {
                        checkSiteInPolygon(siteInfos);
                    }
                });
    }

    /**
     * 判断当前位置是否在多边形内站点周围内，并且周围两公里是否有华为站点；当前不支持多边形重叠的情况
     * @param siteList 站点列表
     */
    private void checkSiteInPolygon(List<SiteInfo> siteList) {
        if (CacheUtil.getInstance().polygonIsEmpty()) {
            return;
        }

        // 首先判断中心点是否落在多边形内
        PolygonOptions currentPolygon = null;
        for (PolygonOptions options : CacheUtil.getInstance().getPolygonList()) {
            if (SpatialRelationUtil.isPolygonContainsPoint(options.getPoints(), currentMapCenterLatLng)) {
                currentPolygon = options;
                break;
            }
        }

        long time1 = System.currentTimeMillis();
        int polygonStatus = NOT_IN_POLYGON;
        // 中心点在多边形内
        if (currentPolygon != null) {
            polygonStatus = IN_POLYGON_NO_SITE;
            // 检查当前点周围2公里范围内是否有华为站点
            for (SiteInfo siteInfo: siteList) {
                LatLng latLng = new LatLng(siteInfo.getLat(), siteInfo.getLng());

                if (!siteInfo.getFRSName().equals("华为") ||
                    !SpatialRelationUtil.isCircleContainsPoint(
                            currentMapCenterLatLng, 2000, latLng)){
                    continue;
                }

                if (SpatialRelationUtil.isPolygonContainsPoint(currentPolygon.getPoints(), latLng)) {
                    long time2 = System.currentTimeMillis();
                    ++polygonStatus;
                }
            }

            long time2 = System.currentTimeMillis();
            GCLogger.error(Module.GENEX_CLOUD, "检查polygon站点用时 " + (time2 - time1) + "ms");
        }

        setPolygonTips(polygonStatus);
    }

    /**
     * 设置2公里范围类华为区域提示信息
     * @param status 状态
     */
    private void setPolygonTips(int status) {
        binding.polygonTips.setVisibility(View.VISIBLE);
        binding.statusBarPadding.setBackgroundColor(Color.parseColor("#F8E0E0"));
        switch (status) {
            case NOT_IN_POLYGON:
                binding.polygonTipIcon.setBackgroundResource(R.drawable.icon_no_polygon);
                binding.polygonTipTxt.setText("当前区域为非华为区域");
                break;
            case IN_POLYGON_NO_SITE:
                binding.polygonTipIcon.setBackgroundResource(R.drawable.icon_polygon_no_site);
                binding.polygonTipTxt.setText("当前区域为华为区域：2公里内无华为站点");
                break;
            default:
                binding.polygonTipIcon.setBackgroundResource(R.drawable.icon_polygon_site);
                binding.polygonTipTxt.setText(String.format("当前区域为华为区域：2公里内有%d个站点", status));
                break;
        }
    }

    /**
     * 缩放到省
     */
    private void zoomToProvince(boolean isProvinceZoom) {
        if (isProvinceZoom) {
            binding.stationTypeTips.setVisibility(View.GONE);
            binding.signalStrengthLayout.setVisibility(View.GONE);
            SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
            SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);

            // 弹出三段拉
            delayHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    siteDetailView.setVisibility(View.VISIBLE);
                    siteDetailView.scrollToShow();
                }
            }, 300);// 延迟为了避免被drawer的监听关闭三段拉
        } else {
            if (districPolyLine != null) {
                districPolyLine.remove();
            }

            binding.stationTypeTips.setVisibility(controllerBean.isShowSite() ? View.VISIBLE : View.GONE);
            showSignalViewVisiable(controllerBean.isShowSignal());
            // 改变地址选择文字
            provinceName = myProvinceName;
            cityName = myCityName;
        }
    }

    /**
     * 画本省的地理围栏
     *
     * @param polylineList 边界的list集合
     */
    private void drawDistrictPolyLines(List<LatLng> polylineList) {
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.color(Color.parseColor("#000000")).points(polylineList).width(3);
        districPolyLine = mBaiduMap.addOverlay(polylineOptions);
    }

    /**
     * 初始化权限<相关view>
     */
    private void initPermission() {

    }

    public void initView() {
        // 地图控件
        binding.smSearchEdit.setOnEditorActionListener(myEditActionListener);
        binding.smMarkBtn.setOnClickListener(this);
        binding.zoomOutBtn.setOnClickListener(this);
        binding.zoomInBtn.setOnClickListener(this);
        binding.smCityOperator.setOnClickListener(this);
        binding.outSiteTip.setOnClickListener(this);
        binding.innerSiteTip.setOnClickListener(this);
        binding.smMapLayerBtn.setOnClickListener(this);
        binding.networkSwitchBtn.setOnClickListener(this);
        binding.smPositionBtn.setOnClickListener(this);

        // 初始化侧滑
        setSiteShowType();
    }


    private void initData() {
        // 获取用户的热力图权限
        hasNpoPermission = checkNPOPermission();

        if (!hasNpoPermission) {
            // 没有npo权限 不能切换省市
            binding.smCityOperator.setClickable(false);
        } else {
            binding.smCityOperator.setClickable(true);
        }

        // MainActivity中共享的数据
        viewModel = new ViewModelProvider((ViewModelStoreOwner) requireActivity()).get(MainSharedDataViewModel.class);
        if (null != viewModel.getSenseMapStatus()) {
            senseMapStatus = viewModel.getSenseMapStatus();
        } else {
            senseMapStatus = new MainSharedDataViewModel.SenseMapStatus();
        }
        viewModel.getStatusLiveData().observe(homePage.getViewLifecycleOwner(), status -> {
            if (null == status) {
                return;
            }
            senseMapStatus = status;
            // 处理界面数据和刷新网络数据
            selectOperatorAndCity(status);
        });
    }

    /**
     * 查看用户是否有npo权限或者6的插件权限，改信息关联热力图、站点密度查看和侧边栏的展示内容
     *
     * @return
     */
    private boolean checkNPOPermission() {
        // 查看是否有npo数据 npo数据库中是否包含本用户账号
        AppDatabase database = AppDatabase.getInstance(BaseApplication.getAppContext());
        NPODataDao npoDataDao = database.npoDataDao();
        List<NPOData> userNpoList = npoDataDao.queryNPOListByAccount(ShareDataUtil.getUserName(requireContext()));
        if (null != userNpoList && !userNpoList.isEmpty()) {
            return true;
        }

        String pluginPermissions = ShareDataUtil.getPluginPermissions(requireContext());
        if (!TextUtils.isEmpty(pluginPermissions)) {
            String[] permissionItems = pluginPermissions.split(",");
            if (null == permissionItems || permissionItems.length == 0) {
                return false;
            }
            for (String permissionItem : permissionItems) {
                if (String.valueOf(Constants.PLUGIN_PERMISSION_6).equals(permissionItem)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 初始化站点详情view(上拉三段)
     */
    private void iniSiteDetailView() {
        siteDetailView = new SiteDetailView(requireContext());
        binding.frameLayout.addView(siteDetailView);
        siteDetailView.setOnMeasureDisClickListener(new SiteDetailView.OnMeasureDisClickListener() {
            @Override
            public void onClick(TextView tv) {
                tv.setText(SenceMapTextUtils.getDistanceText(myLocationLatLng, clickedSiteLatLng));
            }
        });
        siteDetailView.setOnNaviBtnClickListener(new SiteDetailView.OnNaviBtnClickListener() {
            @Override
            public void onClick() {
                startNavigation(clickedSiteLatLng);
            }
        });
        siteDetailView.setOnSlideCloseListener(new SiteDetailView.OnSlideCloseListener() {
            @Override
            public void onClose() {
                mBaiduMap.hideInfoWindow();
            }
        });
    }

    /**
     * 站点开关
     * @param isOpen
     */
    private void onSiteClick(boolean isOpen) {
        if (isOpen) {
            binding.outSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            binding.innerSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));

            binding.stationTypeTips.setVisibility(View.VISIBLE);
            if (controllerBean.isShowHWSiteDensity()) {
                resetHuaweiPattern();
            } else {
                findSiteDataByPramas();
            }
        } else {
            // 关闭
            binding.stationTypeTips.setVisibility(View.GONE);
            isMapMove = true;
            clearExistIncSiteMarkers();
            clearHuaweiHeatMap();
        }
    }

    /**
     * 开关异厂商
     * @param isOpen
     */
    private void onOtherSiteClick(boolean isOpen) {
        // 重新绘制站点
        drawBaiduMapOverlays(INDEX_INC_SITE, CacheUtil.getInstance().getCachedSite());
    }

    private void findSiteDataByPramas() {
        siteResultListAll.clear();
        querySiteOrHeatPoint(currentAreaSiteBean, currentBounds, currentZoom);
    }

    /**
     * 是否显示体验标点的开关
     *
     * @param isOpen
     */
    private void onExperienceClick(boolean isOpen) {
        if (isOpen) {
            // 打开
            if (controllerBean.isShowHWSiteDensity()) {
                resetHuaweiPattern();
            }
            queryExperienceSite(provinceName, cityName, enCarrier);
        } else {
            // 关闭
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.HIDE);
        }
    }

    /**
     * 打开或者关闭信号显示
     *
     * @param isOpen
     */
    private PhoneStateListener phoneStateListener;

    private boolean onSignalClick(boolean isOpen) {
        GCLogger.error(Module.ERROR, "onSignalClick : " + isOpen);
        // 获取手机卡的运营商信息
        String simCardOperator = DeviceUtil.getSimOperator(requireContext().getApplicationContext());
        String currentOperator = enCarrier;

        if (isOpen && (TextUtils.isEmpty(simCardOperator) || !simCardOperator.equalsIgnoreCase(enCarrier))) {
            // 要打开监听且 选择的运营商和sim卡不符合
            return false;
        }

        TelephonyManager manager = (TelephonyManager) BaseApplication.getAppContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        if (isOpen) {
            // 检查是否有读取手机信息的权限
            if (ActivityCompat.checkSelfPermission(BaseApplication.getAppContext(),
                    Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                homePage.requestPermissions(new AppPermissionUtil.PermissionResultCallback() {
                    @Override
                    public String[] getRequestedPermission() {
                        return new String[]{Manifest.permission.READ_PHONE_STATE};
                    }

                    @Override
                    public void onPermissionResult(Map<String, Boolean> result) {
                        if (null == result || result.isEmpty() || !result.get(Manifest.permission.READ_PHONE_STATE)) {
                            // 没有授权
                            showMsg("无权限读取信号强度信息");
                            return;
                        } else {
                            // 成功获取授权
                            if (isOpen) {
                                if (controllerBean.isShowHWSiteDensity()) {
                                    resetHuaweiPattern();
                                }
                            }
                            showSignalViewVisiable(isOpen);
                            startListeningSignal();
                        }
                    }
                });
            } else {
                // 有权限
                showSignalViewVisiable(isOpen);
                startListeningSignal();
            }
        } else {
            showSignalViewVisiable(isOpen);
            if (null != phoneStateListener) {
                GCLogger.error("view", "取消监听信号");
                manager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            }
        }
        return true;
    }

    /**
     * 开启信号强度监听
     */
    private void startListeningSignal() {
        if (null != phoneStateListener) {
            // 正在监听
            return;
        }
        TelephonyManager manager = (TelephonyManager) BaseApplication.getAppContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onSignalStrengthsChanged(SignalStrength signalStrength) {
                if (null == signalStrength) {
                    return;
                }
                // 解析信号强度信息
                Map<String, Integer> signalData = CellInfoUtils.getSignalStrengthInfo(signalStrength, getNetWorkType());
                if (null != signalData) {
                    Integer rsrp = signalData.get(CellInfoUtils.VALUE_RSRP);
                    Integer sinr = signalData.get(CellInfoUtils.VALUE_SINR);
                    if (null == rsrp || CellInfoUtils.VALUE_INVALID == rsrp) {
                        binding.siteviewRsrpTv.setText("无");
                    } else {
                        binding.siteviewRsrpTv.setText(String.valueOf(rsrp));
                    }
                    if (null == sinr || CellInfoUtils.VALUE_INVALID == rsrp) {
                        binding.siteviewSnrTv.setText("-");
                    } else {
                        binding.siteviewSnrTv.setText(String.valueOf(sinr));
                    }
                }
            }
        };
        manager.listen(phoneStateListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
    }

    /**
     * 停止手机信号强度监听
     */
    private void stopListeningSignal() {
        if (null != phoneStateListener) {
            TelephonyManager manager = (TelephonyManager) BaseApplication.getAppContext()
                    .getSystemService(Context.TELEPHONY_SERVICE);
            manager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            phoneStateListener = null;
        }
    }

    /**
     * 华为站点密度开关
     *
     * @param isOpen
     */
    private void onHwDensityClick(boolean isOpen) {
        resetPolygon();
        if (isOpen) {
            showSiteDensity();
        } else {
            resetHuaweiPattern();
            closeBottomDetailView();
        }
    }

    private void resetHuaweiPattern() {
        controllerBean.enableHWSiteDensity(false);
        if (null != myProvinceName) {
            selProvince = myProvinceName.replaceAll("省", "");
        }
        if (null != myCityName) {
            selCity = myCityName.replaceAll("市", "");
        }
        cityName = selCity;
        provinceName = selProvince;
        binding.smCityOperator.setText(selCity + "/" + selOper);
        // 回退自己位置
        closeHuaweiPatternButton();
        //打开站点按钮，显示室分布局
        controllerBean.enableSite(true);
        binding.stationTypeTips.setVisibility(View.VISIBLE);
        resetMapStatus(myLocationLatLng, DEFAULT_ZOOM);
    }

    /**
     * 显示站点密度
     */
    private void showSiteDensity() {
        // 关于底部详情
        isSaveBottomScrollInfo = true;
        siteDetailView.setSlideOutEnable(false); // 让scrolllayout不可以划出
        // 关闭其他功能对应布局
        binding.smPositionBtn.setVisibility(View.GONE);
        binding.smMarkBtn.setVisibility(View.GONE);
        binding.expPointMarker.setVisibility(View.GONE);
        // 开始请求
        startDistrictSearch(provinceName);
        requestHwCityGrideData(provinceName, enCarrier);
    }

    /**
     * 影藏站点密度
     */
    private void hideSiteDensity() {
        // 开启其他功能对应布局
        binding.smPositionBtn.setVisibility(View.VISIBLE);
        binding.smMarkBtn.setVisibility(View.VISIBLE);
    }

    /**
     * 清空(隐藏)地图当前覆盖物
     */
    private void clearAllMarkers() {
        SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.HIDE);
    }

    /**
     * 关闭底部滑动控件
     */
    private void closeBottomDetailView() {
        if (siteDetailView != null) {
            siteDetailView.closeScrollLayout(isSaveBottomScrollInfo);
        }
        if (clickMarkerIndicator != null) {
            mBaiduMap.hideInfoWindow();
            clickMarkerIndicator = null;
        }
    }

    /**
     * 是否当前运营商
     */
    private boolean isMyCarrier() {
        return CarrierNameUtils.isMyCarrier(requireContext(), enCarrier);
    }

    /**
     * 关闭华为格局按钮
     */
    private void closeHuaweiPatternButton() {
        isSaveBottomScrollInfo = false;
        siteDetailView.setSlideOutEnable(true);
        binding.smPositionBtn.setVisibility(View.VISIBLE);
        binding.smMarkBtn.setVisibility(View.VISIBLE);
        if (controllerBean.isShowHWSiteDensity()) {
            GCLogger.error(Module.GENEX_CLOUD, "站点密度关闭了" + myLocationLatLng.toString());
            resetMapStatus(currentMapCenterLatLng, DEFAULT_ZOOM);
        }
        controllerBean.enablePatternSite(false);
        zoomToProvince(false);
        IS_PROVINCE_ZOOM = false;
        // 关闭华为格局图标
        clearHuaweiHeatMap();
    }

    /**
     * 清除厂商云图
     */
    private void clearHuaweiHeatMap() {
        if (huaweiIncHeatmap != null) {
            huaweiIncHeatmap.removeHeatMap();
            huaweiIncHeatmap = null;
        }
    }

    /**
     * 查询地址信息
     *
     * @param latlng 地图当前的中点
     */
    private void geoLatLngAddress(LatLng latlng, final int flag) {

        GeoUtils.getInstance().setOnReceiveGeoResult(new GeoUtils.OnReceiveGeoResult() {
            @Override
            public void onSuccess(ReverseGeoCodeResult result) {
                onReceiveGeoResult(result, flag);
            }
        });
        // TODO 地理位置查询的作用
        GeoUtils.getInstance().startGeo(latlng);
    }

    /**
     * 处理geo的回调结果
     *
     * @param result
     */
    private void onReceiveGeoResult(ReverseGeoCodeResult result, int flag) {

        if (flag == 0) {
            String province = result.getAddressDetail().province;
            String city = result.getAddressDetail().city;

            if (!province.contains(provinceName) && !city.contains(cityName)) {
                provinceName = AddrNameUtils.getAliasProvinceName(province);
                cityName = AddrNameUtils.getAliasCityName(city);
                // 重设记录索引
                resetAddrText(city, cnCarrier);
            }

            if (IS_PROVINCE_ZOOM) {
                startDistrictSearch(provinceName);
                requestHwCityGrideData(provinceName, enCarrier);
            }
        } else if (flag == 1) {
            // 搜索定位到的位置信息
            String address = result.getAddressDetail().province + result.getAddressDetail().city
                    + result.getAddressDetail().district + result.getAddressDetail().street
                    + result.getAddressDetail().streetNumber;
            mAddress = address;
        }
        String address = result.getAddressDetail().province + result.getAddressDetail().city
                + result.getAddressDetail().district + result.getAddressDetail().street
                + result.getAddressDetail().streetNumber;
        GCLogger.error(Module.ERROR, "GEO SEARCH onReceiveGeoResult : " + address);
    }

    /**
     * 请求网络上地图的覆盖物信息
     */
    private void requestMapOverlayFromNet() {
        if (controllerBean.isShowMarkType()) {
            queryExperienceSite(provinceName, cityName, enCarrier);
        }
    }

    /**
     * 初始化百度地图
     */
    private void initBaiduMap() {
        mBaiduMap = binding.mapView.getMap();

        // 初始化地图
        MapUtil.initBaiduMap(binding.mapView, null, onMapStatusChangeListener, onMapClickListener, onMarkerClickListener);
        MapUtil.setMapZoomLevel(mBaiduMap, DEFAULT_ZOOM);

        // 初始化定位服务
        locationClient = MapUtil.createLocationClient(requireContext());
        locationListener = new MyLocationListener();
        locationClient.registerLocationListener(locationListener);


        mSearch = GeoCoder.newInstance();

        mSearch.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {

            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
                if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
                    return;
                }
                GCLogger.debug(Module.GENEX_CLOUD, result.getAddress());
                String address = result.getAddressDetail().district + result.getAddressDetail().street
                        + result.getAddressDetail().streetNumber;
            }

            @Override
            public void onGetGeoCodeResult(GeoCodeResult result) {

            }
        });
    }

    /***************************************************************百度地图 START 各种回调************************************************************/
    /**
     * 地图移动 状态改变
     */
    private final BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener = new BaiduMap.OnMapStatusChangeListener() {
        public void onMapStatusChangeStart(MapStatus mapStatus) {}
        public void onMapStatusChangeStart(MapStatus mapStatus, int i) {}
        public void onMapStatusChange(MapStatus mapStatus) {}
        public void onMapStatusChangeFinish(MapStatus mapStatus) {
            onMapChange(mapStatus);
        }
    };

    /**
     * 地图点击事件回调
     */
    private final BaiduMap.OnMapClickListener onMapClickListener = new BaiduMap.OnMapClickListener() {
        public void onMapClick(LatLng latLng) {
            // 点击地图 如果不是省级缩放 则隐藏站点信息窗口
            if (!IS_PROVINCE_ZOOM) {
                closeBottomDetailView();
            }
            if (binding.addBgView.getVisibility() == View.VISIBLE) {
                binding.addBgView.setVisibility(View.GONE);
            }
        }

        @Override
        public void onMapPoiClick(MapPoi mapPoi) {
        }
    };

    /**
     * marker点击事件回调
     */
    private final BaiduMap.OnMarkerClickListener onMarkerClickListener = new BaiduMap.OnMarkerClickListener() {
        @Override
        public boolean onMarkerClick(Marker marker) {
            if (binding.addBgView.getVisibility() == View.VISIBLE) {
                binding.addBgView.setVisibility(View.GONE);
            }
            // 显示信息
            if (marker != null) {
                if (marker.getExtraInfo() != null && marker.isVisible()) {
                    // marker有bundle信息且显示
                    String markerType = marker.getExtraInfo().getString("markerType");
                    if ("incMarker".equals(markerType)) {
                        SiteInfo siteInfo = (SiteInfo) marker.getExtraInfo().getSerializable("bean");
                        showWindowInfo(siteInfo);
                    }
                    if ("feelPointMarker".equals(markerType)) {
                        ExperienceSiteInfo exInfo = (ExperienceSiteInfo) marker.getExtraInfo()
                                .getSerializable("info");
                        push(new RecordDetailFragment(exInfo, false));
                    }
                }
            }
            return true;
        }
    };

    /***************************************************************百度地图  END  各种回调************************************************************/
    /***************************************************************百度地图 START 各种能力************************************************************/
    /**
     * 定位服务的回调
     */
    private class MyLocationListener extends BDAbstractLocationListener {
        @Override
        public void onReceiveLocation(BDLocation bdLocation) {
            // 接收到定位信息
            if (null == bdLocation || null == binding || null == binding.mapView) {
                return;
            }
            GCLogger.error(Module.ERROR, "定位信息回调:" + bdLocation.toString());

            int locType = bdLocation.getLocType();
            if (locType == BDLocation.TypeCriteriaException || locType == BDLocation.TypeNone
                    || bdLocation.getLatitude() == 4.9E-324 || bdLocation.getLongitude() == 4.9E-324) {
                // 无效的定位信息
                return;
            }

            MyLocationData locData = new MyLocationData.Builder().accuracy(bdLocation.getRadius())
                    .direction(bdLocation.getDirection())
                    .latitude(bdLocation.getLatitude())
                    .longitude(bdLocation.getLongitude()).build();

            mBaiduMap.setMyLocationData(locData);

            // 我的省份城市信息 只获取一次有效数据
            if (!TextUtils.isEmpty(bdLocation.getProvince()) && !TextUtils.isEmpty(bdLocation.getCity())
                    && null == myProvinceName && null == myCityName) {
                myProvinceName = bdLocation.getProvince();
                myCityName = bdLocation.getCity();
                // 将城市信息设置到左上角文字
                binding.city.setText(bdLocation.getCity());

                initAddressText();
            }
            // 第一次有效定位 移动地图到当前位置
            if (firstLocation) {
                firstLocation = false;
                // 搜索定位的地理位置
                geoLatLngAddress(new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude()), 1);
                LatLng ll = new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude());
                MapStatus.Builder builder = new MapStatus.Builder();
                builder.target(ll).zoom(DEFAULT_ZOOM);
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
                resetPolygon();
            }
            // 更新我的位置 经纬度
            myLocationLatLng = new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude());
            ShareDataUtil.updateLAT(BaseApplication.getAppContext(), bdLocation.getLatitude() + "");
            ShareDataUtil.updateLNG(BaseApplication.getAppContext(), bdLocation.getLongitude() + "");
        }
    }

    /***************************************************************百度地图  END  各种能力************************************************************/

    private LatLngBounds lastSiteDataBound = null;
    private void onMapChange(MapStatus ms) {
        float zoom = ms.zoom;
        LatLngBounds bounds = ms.bound;
        boolean isShowDensity = controllerBean.isShowHWSiteDensity();
        // 封装边界 运营商参数
        currentAreaSiteBean = getCurrentMapAreaSiteBean(ms.bound, zoom, 0);
        if (!isShowDensity && zoom < BORDER_ZOOM) {
            // 热力图level
            querySiteOrHeatPoint(currentAreaSiteBean, bounds, zoom);
        } else if (!isShowDensity) {
            // 站点level
            if (null == lastSiteDataBound ||
                    !(bounds.contains(lastSiteDataBound.northeast)
                            && bounds.contains(lastSiteDataBound.southwest))) {
                // 获取站点数据
                if (controllerBean.isShowSite()) {
                    querySiteOrHeatPoint(currentAreaSiteBean, bounds, zoom);
                }
            } else {
                // 新的边界在之前获取数据的边界之内 不需要重新请求数据
                drawBaiduMapOverlays(INDEX_INC_SITE, CacheUtil.getInstance().getCachedSite());
            }
        }

        // 更新地图的状态属性 地图经纬度范围、地图缩放等级和地图中心点经纬度
        currentBounds = ms.bound;
        currentZoom = ms.zoom;
        currentMapCenterLatLng = ms.target;

        //请求ATU/体验标点等
        requestMapOverlayFromNet();

        // 标点按钮 "亮"和"灭"  定位点在屏幕范围内则亮，不再则灭
        if (PositionUtils.isInScreenInner(ms.bound, myLocationLatLng)) {
            binding.smMarkBtn.setTextColor(Color.parseColor("#6FBAFF"));
            Drawable imageDrawable = requireContext().getDrawable(R.drawable.icon_punctuation_selected);
            imageDrawable.setBounds(0, 0, imageDrawable.getIntrinsicWidth(), imageDrawable.getIntrinsicHeight());
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    imageDrawable,
                    null, null);
        } else {
            binding.addBgView.setVisibility(View.GONE);
            binding.smMarkBtn.setTextColor(Color.parseColor("#666666"));
            Drawable imageDrawable = requireContext().getDrawable(R.drawable.icon_punctuation_unselected);
            imageDrawable.setBounds(0, 0, imageDrawable.getIntrinsicWidth(), imageDrawable.getIntrinsicHeight());
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    imageDrawable,
                    null, null);
        }
        if (ms.zoom < 11) {
            preZoom = ms.zoom;
        }
        // 获取polygon数据
        requestPolygonSites();
    }

    private void mapChange(MapStatus ms) {
        // 地图状态改变结束，当前图层信息
        GCLogger.error("map", "地图移动结束 位置: " + ms.target.latitude + " , "
                + ms.target.longitude + "  地图缩放等级: " + ms.zoom + " 省份: " + provinceName + " 城市: "
                + cityName + "  我定位到的省份: " + myProvinceName + " 定位到的城市: " + myCityName);
        float zoom = ms.zoom;
        currentAreaSiteBean = getCurrentMapAreaSiteBean(ms.bound, zoom, 0);

        if (zoom < BORDER_ZOOM) {
//            if (isDrawingSite) {
//                return;
//            }
            if (openTag == -1) {
                isFirstEnter = true;
            }
            isMapMove = true;
            siteResultListAll.clear();
            querySiteOrHeatPoint(currentAreaSiteBean, currentBounds, zoom);
        } else {
            if (currentZoom > ms.zoom) {
                if (openTag == -1) {
                    isFirstEnter = true;
                }
                siteResultListAll.clear();
                isMapMove = true;
                clearExistIncSiteMarkers();
            }
            // 封装边界及参数
            if (BdMapGridParamUtils.getOutDirection(ms.bound, currentMapCenterLatLng, ms.target) == NAN) {
                // 封装边界及参数
                isMapMove = true;
                if (isFirstEnter) {
                    GCLogger.debug(Module.GENEX_CLOUD, "------------第一次请求---------");
                    isFirstEnter = false;
                    if (controllerBean.isShowSite()) {
                        // 查询异厂商<站点开关+室分/宏站开关>
                        isClearMarker = true;
                        querySiteOrHeatPoint(currentAreaSiteBean, ms.bound, zoom);
                    }
                }
            } else {
                if (controllerBean.isShowSite()) {
                    // 查询异厂商<站点开关+室分/宏站开关>
                    querySiteOrHeatPoint(currentAreaSiteBean, ms.bound, zoom);
                }
            }
        }
        // 更新地图的状态属性 地图经纬度范围、地图缩放等级和地图中心点经纬度
        currentBounds = ms.bound;
        currentZoom = ms.zoom;
        currentMapCenterLatLng = ms.target;

        //请求ATU/体验标点等
        requestMapOverlayFromNet();

        // 标点按钮 "亮"和"灭"  定位点在屏幕范围内则亮，不再则灭
        if (PositionUtils.isInScreenInner(ms.bound, myLocationLatLng)) {
            binding.smMarkBtn.setTextColor(Color.parseColor("#6FBAFF"));
            Drawable imageDrawable = requireContext().getDrawable(R.drawable.icon_punctuation_selected);
            imageDrawable.setBounds(0, 0, imageDrawable.getIntrinsicWidth(), imageDrawable.getIntrinsicHeight());
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    imageDrawable,
                    null, null);
        } else {
            binding.addBgView.setVisibility(View.GONE);
            binding.smMarkBtn.setTextColor(Color.parseColor("#666666"));
            Drawable imageDrawable = requireContext().getDrawable(R.drawable.icon_punctuation_unselected);
            imageDrawable.setBounds(0, 0, imageDrawable.getIntrinsicWidth(), imageDrawable.getIntrinsicHeight());
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    imageDrawable,
                    null, null);
        }
        if (ms.zoom < 11) {
            preZoom = ms.zoom;
        }

//        if (preZoom < 11 && ms.zoom >= 11 && !isFirstFinishStatus && controllerBean.isShowHWSiteDensity()) {
//            geoLatLngAddress(currentMapCenterLatLng, 0);//0代表以前代码，zhengchang正常逻辑
//            preZoom = ms.zoom;
//        } else {
//            geoLatLngAddress(currentMapCenterLatLng, 1); //1拖动地图，动态显示地址
//        }
        isFirstFinishStatus = false;
        requestPolygonSites();
    }

    /**
     * 当前显示屏幕的东西南北角
     */
    private QueryAreaSiteBean getCurrentMapAreaSiteBean(LatLngBounds latLngBounds, float zoom, int type) {
        QueryAreaSiteBean areaSiteBean = new QueryAreaSiteBean();
        GpsBounds gpsBounds = PositionUtils.bd_09_mapBound_to_gps_84_mapBound(
                latLngBounds.northeast, latLngBounds.southwest);
        areaSiteBean.setLUpLat(gpsBounds.getNorthWestLat());
        areaSiteBean.setLUpLng(gpsBounds.getNorthWestLng());
        areaSiteBean.setRDnLat(gpsBounds.getSouthEastLat());
        areaSiteBean.setRDnLng(gpsBounds.getSouthEastLng());
        areaSiteBean.setNetOper(enCarrier);
        areaSiteBean.setZoom(zoom);
        return areaSiteBean;
    }

    /**
     * 初始化行政搜索
     */
    private void initDistrictSearch() {
        districtSearch = DistrictSearch.newInstance();
        districtSearch.setOnDistrictSearchListener(new OnGetDistricSearchResultListener() {

            @Override
            public void onGetDistrictResult(DistrictResult districResult) {
                List<LatLng> polylines;
                if (districResult != null && districResult.getPolylines() != null) {  // 边界数据
                    if (districResult.getCityName().contains("海南")) {  // 海南边界特殊有断层<来自web测试>
                        polylines = districResult.getPolylines().get(2);
                    } else {
                        polylines = districResult.getPolylines().get(0);
                    }
                    if (controllerBean.isShowHWSiteDensity()) {
                        // 绘制省边界折线
                        drawProvincePolygonLine(polylines);
                    }

                    MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(districResult.centerPt);
                    mBaiduMap.animateMapStatus(u);
                    if (controllerBean.isShowHWSiteDensity()) {
                        requestHeatMapServer(provinceName, enCarrier);
                    }
                } else {
                    homePage.showMsg("暂未获得边界数据，稍后再试！");
                }
            }
        });
    }

    /**
     * 搜索行政区域区域
     *
     * @param districtName 行政名称
     */
    private void startDistrictSearch(String districtName) {
        DistrictSearchOption option = new DistrictSearchOption();
        // 找到全称
        districtName = AddrNameUtils.getFullProvinceName(requireContext(), districtName);
        option.cityName(districtName);
        // 请求边界数据画图<异步>，并缩放地图
        districtSearch.searchDistrict(option);
        zoomToProvince(true);
    }

    /**
     * 设置缩放级别到省
     */
    private void setBaiduMapZoomToProvince(List<LatLng> list) {
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (LatLng latLng : list) {
            boundsBuilder.include(latLng);
        }
        LatLngBounds bounds = boundsBuilder.build();
        mBaiduMap.setMapStatus(MapStatusUpdateFactory.newLatLngBounds(bounds));
    }

    /**
     * 查询异厂商站点
     */
    private void querySiteOrHeatPoint(QueryAreaSiteBean siteBean, LatLngBounds bounds, float zoom) {
        GCLogger.error(Module.ERROR, "querySiteOrHeatPoint");
        if (siteBean == null || bounds == null) {
            return;
        }
        if (siteBean.getZoom() >= BORDER_ZOOM) {
            clearHuaweiHeatMap();
            String netType = getNetWorkType();
            QuerySiteInfoImpl.getInstance().querySiteInfo(
                    bounds.northeast, bounds.southwest,
                    provinceName, enCarrier, netType, onSiteInfoResult);
        } else {
            // 小于14级，画热力图
            if (!isShowedScaleInfo) {
                showMsg("请放大查看站点具体信息！");
                isShowedScaleInfo = true;
            }
            requestHeatMapServer(provinceName, enCarrier);
        }
    }

    public void initAddressText() {
        enCarrier = DeviceUtil.getSimOperator(requireContext());
        if (enCarrier.equals("NONE")) {
            enCarrier = "CNTC";
        }
        cnCarrier = CarrierNameUtils.getCnName(requireContext(), enCarrier, "");
        provinceName = myProvinceName;
        cityName = myCityName;
        selProvince = provinceName.replaceAll("省", "");
        selCity = cityName.replaceAll("市", "");
        selOper = cnCarrier;
        resetAddrText(cityName, cnCarrier);
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        if (AppUtil.isFastDoubleClick()) {
            return;
        }

        switch (v.getId()) {
            case R.id.sm_mark_btn:
                // 点击了右侧工具栏中的 "体验标点" 按钮 关闭站点详情
                closeBottomDetailView();
                if (TextUtils.isEmpty(myProvinceName) || TextUtils.isEmpty(myCityName) || null == myLocationLatLng) {
                    // 没有定位到当前信息
                    showMsg("无法获取您的位置!");
                    return;
                }
                // 判断定位地址是否在屏幕内
                boolean isMyLocationInScreen = mBaiduMap.getMapStatus().bound.contains(myLocationLatLng);
                if (isMyLocationInScreen) {
                    // 移动到当前位置
                    setMyLocationAsCurrent();
                    // 打开 标点dialog
                    showMarkExpPointDialog();
                } else {
                    // 打开标点位置提示 (您当前位置不在屏幕内)
                    showCannotComplainDialog();
                }
                break;
            case R.id.zoom_in_btn:
                this.mBaiduMap.setMapStatus(MapStatusUpdateFactory.zoomTo(this.mBaiduMap.getMapStatus().zoom + 1));
                controlZoomShow(this.mBaiduMap.getMapStatus());//改变缩放按钮
                break;
            case R.id.zoom_out_btn:
                this.mBaiduMap.setMapStatus(MapStatusUpdateFactory.zoomTo(this.mBaiduMap.getMapStatus().zoom - 1));
                controlZoomShow(this.mBaiduMap.getMapStatus());//改变缩放按钮
                break;
            case R.id.sm_city_operator:
                selectCityAndOpera();
                break;
            case R.id.inner_site_tip:
                // 改变室分显示
                controllerBean.setShowIndoorSite(!controllerBean.isShowIndoorSite());
                setSiteShowType();
                break;
            case R.id.out_site_tip:
                // 改变宏站显示
                controllerBean.setShowOutdoorSite(!controllerBean.isShowOutdoorSite());
                setSiteShowType();
                break;
            case R.id.sm_map_layer_btn:
                // 打开右边侧滑
                binding.addBgView.setVisibility(View.GONE);
                SenseMapRightToolsDialog rightToolsDialog = new SenseMapRightToolsDialog(
                        controllerBean, rightToolsCallback, hasNpoPermission);
                rightToolsDialog.show(getChildFragmentManager(), SenseMapRightToolsDialog.class.getName());
                break;
            // 点击定位
            case R.id.sm_position_btn:
                if (myLocationLatLng == null || currentMapCenterLatLng == null) {
                    return;
                }
                selProvince = myProvinceName.replaceAll("省", "");
                selCity = myCityName.replaceAll("市", "");
                cityName = selCity;
                provinceName = selProvince;
                binding.smCityOperator.setText(selCity + "/" + selOper);
                boolean isMyPosition = num4P(currentMapCenterLatLng.latitude) == num4P(myLocationLatLng.latitude)
                        && num4P(currentMapCenterLatLng.longitude) == num4P(myLocationLatLng.longitude);
                if (!isMyPosition) {
                    resetMapStatus(currentMapCenterLatLng = myLocationLatLng, DEFAULT_ZOOM);
                }
                break;

            case R.id.network_switch_btn:
                if (isDrawingSite) {
                    return;
                }
                if (controllerBean.isShowHWSiteDensity()) {
                    showMsg("该模式不支持显示站点,请先切换为站点");
                    return;
                }

                isMapMove = true;
                if (!isShow4g) {
                    binding.networkSwitchBtn.setText("4G");
                } else {
                    binding.networkSwitchBtn.setText("5G");
                }
                isShow4g = !isShow4g;
                siteResultListAll.clear();
                clearExistIncSiteMarkers();
                closeBottomDetailView();
                binding.stationTypeTips.setVisibility(View.VISIBLE);
                if (!isSiteClickOpen) {
                    binding.stationTypeTips.setVisibility(View.GONE);
                }
                clearHuaweiHeatMap();
                querySiteOrHeatPoint(currentAreaSiteBean, currentBounds, currentZoom);
                resetPolygon();
                break;
            default:
                break;
        }

    }

    /**
     * 不能上报对话框
     */
    private void showCannotComplainDialog() {
        CannotComplainDialog cannotComplainDialog = new CannotComplainDialog(new CannotComplainDialog.OnDialogClickListener() {
            @Override
            public void onSureClick() {
                // 确认继续标点, 将屏幕挪动到用户的定位点
                setMyLocationAsCurrent();
                // 显示标点界面
                showMarkExpPointDialog();
            }
        });
        cannotComplainDialog.show(getChildFragmentManager(), CannotComplainDialog.class.getName());
    }

    /**
     * 将当前位置的信息设置到界面上
     */
    private void setMyLocationAsCurrent() {
        resetMapStatus(currentMapCenterLatLng = myLocationLatLng, DEFAULT_ZOOM);
        provinceName = myProvinceName;
        // 3.回退省市
        resetAddrText(cityName = myCityName, cnCarrier);
    }

    /**
     * 显示标点的弹框
     */
    private void showMarkExpPointDialog() {
        Activity act = requireActivity();
        if (null != act && act instanceof BaseActivity) {
            MarkPointDialog dialog = new MarkPointDialog(myLocationLatLng, mAddress, myProvinceName, myCityName);
            dialog.show(((BaseActivity) act).getSupportFragmentManager(), "mark");
        }
    }

    private void controlZoomShow(MapStatus mapStatus1) {
        //获取当前地图状态
        float zoom = this.mBaiduMap.getMapStatus().zoom;
        //如果当前状态大于等于地图的最大状态，则放大按钮则失效
        binding.zoomInBtn.setEnabled(!(zoom >= 19));

        //如果当前状态小于等于地图的最小状态，则缩小按钮失效
        binding.zoomOutBtn.setEnabled(!(zoom <= 12));
        mapChange(mapStatus1);
    }

    /**
     * 选择新的省份地市
     */
    private void selectCityAndOpera() {
        push(new SenseMapCitySelectFragment(provinceName, cityName, cnCarrier, controllerBean.isShowHWSiteDensity()));
    }

    //选择城市后
    private void selectOperatorAndCity(MainSharedDataViewModel.SenseMapStatus senseMapStatus) {
        // sim卡的运营商
        String simCardOperator = DeviceUtil.getSimOperator(requireContext());
        // 如果修改了运营商 且正在监听手机信号强度
        if (controllerBean.isShowSignal() && !TextUtils.isEmpty(simCardOperator)) {
            // 改变了运营商 不显示信号信息
            if (null != cnCarrier && !cnCarrier.equalsIgnoreCase(senseMapStatus.operatorName)) {
                if (simCardOperator.equalsIgnoreCase(CarrierNameUtils.getNameCode(senseMapStatus.operatorName))) {
                    // 与手机sim卡运营商一致 开始监听信号强度
                    startListeningSignal();
                    showSignalViewVisiable(true);
                } else {
                    // 停止信号强度监听
                    stopListeningSignal();
                    showSignalViewVisiable(false);
                }
            }
        }
        provinceName = senseMapStatus.provinceName;
        cityName = senseMapStatus.cityName;
        cnCarrier = senseMapStatus.operatorName;

        enCarrier = CarrierNameUtils.getEnName(requireContext(), selOper, "");

        currentMapCenterLatLng = new LatLng(senseMapStatus.locationDefaultLat, senseMapStatus.locationDefaultLng);
        resetPolygon();
        if (controllerBean.isShowHWSiteDensity()) {
            binding.smCityOperator.setText(provinceName + "/" + cnCarrier);
            resetMapStatus(currentMapCenterLatLng, currentZoom);
            onHwDensityClick(controllerBean.isShowHWSiteDensity());
        } else {
            binding.smCityOperator.setText(cityName + "/" + cnCarrier);
            if (myProvinceName.contains(provinceName) && myCityName.contains(cityName)) {
                currentMapCenterLatLng = myLocationLatLng;
            }
            resetMapStatus(currentMapCenterLatLng, DEFAULT_ZOOM);
            // 重新获取数据
            isFirstEnter = true;
            mapChange(mBaiduMap.getMapStatus());
        }
    }

    private void changeOper() {
        if (currentAreaSiteBean != null) {
            currentAreaSiteBean.setNetOper(enCarrier);
            isMapMove = true;
            if (controllerBean.isShowSite()) {
                // 查询异厂商<站点开关+室分/宏站开关>
                if (controllerBean.isShowOutdoorSite() | controllerBean.isShowIndoorSite() | !isShow4g) {
                    siteResultListAll.clear();
                    isClearMarker = true;
                    mBaiduMap.clear();
                    querySiteOrHeatPoint(currentAreaSiteBean, currentBounds, currentZoom);
                }
            }
            requestMapOverlayFromNet();

        }
        // 1.1华为热力图
        if (controllerBean.isShowHWSiteDensity()) {// 省鸟瞰打开，继续鸟瞰
            requestHeatMapServer(provinceName, enCarrier);
            requestHwCityGrideData(provinceName, enCarrier);
        }
    }


    /**
     * 根据经纬度和zoom改变地图
     */
    private void resetMapStatus(LatLng latLng, float zoom) {
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLngZoom(latLng, zoom));
    }


    /**
     * 设置站点模式<室内和宏站>,非对立关系
     */
    private void setSiteShowType() {
        if (controllerBean.isShowOutdoorSite()) {
            binding.outSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            SiteUtils.setMapMarkerStatus(outerSiteMarkers,
                    TypeEnum.MarkerStatus.SHOW, controllerBean.isShowPatternSite());
        } else {
            binding.outSiteTip.setTextColor(Color.parseColor("#666666"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        }

        if (controllerBean.isShowIndoorSite()) {
            binding.innerSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            SiteUtils.setMapMarkerStatus(innerSiteMarkers,
                    TypeEnum.MarkerStatus.SHOW, controllerBean.isShowPatternSite());
        } else {
            binding.innerSiteTip.setTextColor(Color.parseColor("#666666"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        }

    }

    /**
     * 查询体验标点
     */
    private void queryExperienceSite(String province, String cityName, String netOperator) {
        if (TextUtils.isEmpty(province) || TextUtils.isEmpty(cityName) || TextUtils.isEmpty(netOperator)) {
            showMsg("查询体验标点参数错误，存在空值");
            return;
        }
        boolean isEmpty = experienceMarkers.size() == 0;
        if (!cityName.equals(preExperienceCity) || !netOperator.equals(preExperienceNetOper) || isEmpty) {
            // 和上次请求不同,或为空marker
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.CLEAR);
            requestExperienceServer(province, cityName, netOperator);
        } else {
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.CLEAR);
            LatLng latLng;
            for (ExperienceSiteInfo exInfo : experienceList) {
                if (controllerBean.isShowMarkType(exInfo.getRecordType())) {
                    latLng = new LatLng(exInfo.getLat(), exInfo.getLng());
                    MarkerOptions exMarkerOption = SiteUtils.getExperienceMarkerOption(exInfo, latLng, false);

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("info", exInfo);
                    bundle.putString("markerType", "feelPointMarker");
                    exMarkerOption.extraInfo(bundle);

                    Marker exMarker = (Marker) mBaiduMap.addOverlay(exMarkerOption);
                    exMarker.setToTop();
                    experienceMarkers.add(exMarker);
                }
            }
        }
    }

    //设置信号控件的显示状态
    private void showSignalViewVisiable(boolean isVisiable) {
        if (isVisiable) {
            binding.signalStrengthLayout.setVisibility(View.VISIBLE);
            binding.siteviewRsrpTv.setVisibility(View.VISIBLE);
            binding.siteviewSnrTv.setVisibility(View.VISIBLE);
            binding.siteviewRsrpTv.setAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.show_alpha));
            binding.siteviewSnrTv.setAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.show_alpha));
        } else {
            binding.signalStrengthLayout.setVisibility(View.GONE);
        }
    }


    @SuppressWarnings("deprecation")
    private void startNavigation(LatLng distLatLng) {
        if (distLatLng != null && myLocationLatLng != null) {
            if (AppUtil.checkAppInstalled(requireContext(), "com.baidu.BaiduMap") == null) {
                NaviParaOption naviParaOption = new NaviParaOption();
                naviParaOption.startPoint(myLocationLatLng);
                naviParaOption.endPoint(distLatLng);
                try {
                    BaiduMapNavigation.setSupportWebNavi(true);
                    boolean isSuccess = BaiduMapNavigation.openBaiduMapNavi(naviParaOption, requireContext());
                    if (!isSuccess) {
                        new InstalledDialog().show(getChildFragmentManager(), "");
                    }
                } catch (BaiduMapAppNotSupportNaviException e) {
                    GCLogger.error(Module.GENEX_CLOUD, "open GPS navigation Exception:" + e.toString());
                    new InstalledDialog().show(getChildFragmentManager(), "");
                }
            } else {
                new InstalledDialog().show(getChildFragmentManager(), "");
            }

        } else {
            showMsg("请确认选择了正确的起点和终点！");
        }
    }

    private void createSearchDialog() {

        if (searchResultDialog == null) {
            searchResultDialog = new SearchResultDilog(requireContext());
            searchResultDialog.setOnPoiItemSelectListener(new SearchResultDilog.OnPoiItemSelectListener() {
                @Override
                public void onSelect(SuggestionResult.SuggestionInfo bean) {
                    resetMapStatus(bean.pt, DEFAULT_ZOOM);
                    showMsg("已为您移至" + bean.key);
                }
            });
            searchResultDialog.setOnSiteItemSelectListener(new SearchResultDilog.OnSiteItemSelectListener() {
                @Override
                public void onSelect(SiteBaseBean bean) {
                    searchSiteInfo = bean;
                    resetMapStatus(new LatLng(bean.getLat(), bean.getLng()), DEFAULT_ZOOM);
                }
            });
        }

        searchResultDialog.setPoiDataList(null, null);
        searchResultDialog.setSiteDataList(null, null);
    }

    /**
     * 清空所有站点marker
     */
    private void clearExistIncSiteMarkers() {
        if (clickMarkerIndicator != null) {
            mBaiduMap.hideInfoWindow();
        }
        mBaiduMap.removeOverLays(detailSiteList);
        mBaiduMap.removeOverLays(clusterSiteList);
        SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.CLEAR);
        SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.CLEAR);
    }

    // 设置省市文本
    private void resetAddrText(String city, String netOper) {
        if (!TextUtils.isEmpty(city) && binding.smCityOperator != null) {
            city = AddrNameUtils.getFullCityName(city);
            binding.smCityOperator.setText(city.replaceAll("市", "") + "/" + netOper);
        }
    }


    // 搜索站点
    private void searchAreaSite(final String search) {
        SearchSiteBean bean = new SearchSiteBean();
        Gps gps = PositionUtils.bd09_To_Gps84(currentMapCenterLatLng.latitude, currentMapCenterLatLng.longitude);
        bean.setLUpLat(gps.getWgLat());
        bean.setLUpLng(gps.getWgLon());
        if (TextUtils.isEmpty(search)) {
            bean.setSearch(AddrNameUtils.getAliasCityName(myCityName));
        } else {
            bean.setSearch(search);
        }
        bean.setNetOper(enCarrier);
        bean.setCurrCity(cityName);
        bean.setNetworkType(getNetWorkType());
        searchSiteInfo = null;// 搜索即重置成员变量
        createSearchDialog();
        SearchSiteInfoImpl.getInstance().querySiteInfo(bean, new SearchSiteInfoImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg("未找到相关基站");
            }

            @Override
            public void onResponse(Map<String, List> map) {
                List<SuggestionResult.SuggestionInfo> baiduBeans = map.get(SearchSiteInfoImpl.KEY_BAIDU);
                List<SiteBaseBean> siteBeans = map.get(SearchSiteInfoImpl.KEY_SITE);
                boolean isHasBaidu = baiduBeans != null && baiduBeans.size() > 0;
                boolean isHasSite = null != siteBeans && siteBeans.size() > 0;
                if (isHasBaidu || isHasSite) {
                    if (isHasBaidu) {
                        searchResultDialog.setPoiDataList(baiduBeans, binding.smSearchEdit.getText().toString());
                    } else {
                        String baiduEmptyStr = String.format("未找到有关 %s 的地理信息", binding.smSearchEdit.getText().toString());
                        showMsg(baiduEmptyStr);
                    }
                    if (isHasSite) {
                        searchResultDialog.setSiteDataList(siteBeans, binding.smSearchEdit.getText().toString());
                    } else {
                        showMsg("未找到相关基站");
                    }
                    showSearchResultDialog();
                } else {
                    showMsg("未找到相关基站");
                }
            }
        });
    }

    // 请求体验标点
    private void requestExperienceServer(String province, String cityName, String netOperator) {
        QueryExperienceSiteListImpl.getInstance().getExperienceSiteList(province, cityName, netOperator, new QueryExperienceSiteListImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
            }

            @Override
            public void onResponse(List<ExperienceSiteInfo> response) {
                drawBaiduMapOverlays(INDEX_EXPERIENCE, (ArrayList<ExperienceSiteInfo>) response);
            }
        });

        preExperienceCity = cityName;
        preExperienceNetOper = netOperator;
    }

    /**
     * 请求华为热力图
     */
    private void requestHeatMapServer(String province, String operatorEn) {
        if (!hasNpoPermission) {
            // 没有npo权限 不能查看热力图
            return;
        }
        GCLogger.error("map", "requestHeatMapServer : province: " + province + " operator : " + operatorEn);
        CityInfo info = CacheUtil.getInstance().getProvince(province);
        if (info == null) {
            return;
        }

        // 拼接当前需要显示的热力图的参数 用来对比之前显示的热力图参数是否相同，如果相同，则不用更新热力图
        String heatMapParamKey = String.format("%s_%s_%s", province, operatorEn, getNetWorkType());
        if (null != heatMapKey && heatMapKey.equals(heatMapParamKey) && null != huaweiIncHeatmap) {
            return;
        }

        long startT = System.currentTimeMillis();
        AppDatabase database = AppDatabase.getInstance(BaseApplication.getAppContext());
        HeatMapDataDao heatMapDataDao = database.heatMapDataDao();

        List<HeatMapData> heatMapDataList = heatMapDataDao.queryLatLngList(province, operatorEn, getNetWorkType());
        if (heatMapDataList != null && heatMapDataList.size() > 0) {
            List<LatLng> latLngList = new ArrayList<>();
            for (HeatMapData data : heatMapDataList) {
                latLngList.add(new LatLng(data.lat, data.lng));
            }
            clearExistIncSiteMarkers();
            clearHuaweiHeatMap();
            heatMapKey = heatMapParamKey;
            GCLogger.error("map", "读取热力图点用时 : " + (System.currentTimeMillis() - startT) + " ms  数量 ：" + latLngList.size());
            mBaiduMap.addHeatMap(huaweiIncHeatmap = new HeatMap.Builder().data(latLngList).build());
            return;
        }

        // 3.请求网络
        ReqMapDataBean heatReqBean = new ReqMapDataBean();
        heatReqBean.setSpell(info.proSpell);
        heatReqBean.setNetOperator(operatorEn);
        heatReqBean.setProvince(province);
        heatReqBean.setNetWorkType(getNetWorkType());
        QueryProvinceHeatmapInfoImpl.getInstance().querySiteInfo(new QueryProvinceHeatmapInfoImpl.Callback(heatReqBean) {
            @Override
            public void onFailure(ErrorBean e) {
                if ((null != e && e.errorCode == ErrorBean.ERROR_CANCELED)) {
                    return;
                }
                showMsg("暂无数据，请稍后再试！");
            }

            @Override
            public void onResponse(List<LatLng> response) {
                clearExistIncSiteMarkers();
                clearHuaweiHeatMap();
                heatMapKey = heatMapParamKey;
                mBaiduMap.addHeatMap(huaweiIncHeatmap = new HeatMap.Builder().data(response).build());
            }
        });
    }

    /**
     * 获取当前选择的网络制式
     *
     * @return
     */
    private String getNetWorkType() {
        return isShow4g ? Constant.NET_TYPE_4G : Constant.NET_TYPE_5G;
    }

    /**
     * 请求华为市站点数量
     */
    private void requestHwCityGrideData(String province, String netOper) {

        siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE, new CityGrideDataBean(province, null, false), isShow4g);

        QueryAreaSiteBean reqBean = new QueryAreaSiteBean();
        reqBean.setProvince(province);
        reqBean.setNetOper(netOper);
        reqBean.setNetWorkType(getNetWorkType());

        QueryProvinceSiteSummaryImpl.getInstance().querySiteNum(reqBean, new QueryProvinceSiteSummaryImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE,
                        new CityGrideDataBean(provinceName, null, true), isShow4g);
            }

            @Override
            public void onResponse(List<CityGrideSiteResp> response) {
                siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE,
                        new CityGrideDataBean(provinceName, (ArrayList<CityGrideSiteResp>) response, false), isShow4g);
            }
        });
    }

    //取四位数字方法
    private double num4P(double source) {
        return Formatter.formatDouble4Point(source);
    }

    //插入体验标点
    @Override
    public void commitData(ExperienceSiteInfo experienceSiteInfo) {
        experienceSiteInfo.setProvince(provinceName.replace("省", ""));
        experienceSiteInfo.setCityName(selCity.replace("市", ""));
        //标点的经纬度
        if (currentMapCenterLatLng != null) {
            experienceSiteInfo.setLat(currentMapCenterLatLng.latitude);
            experienceSiteInfo.setLng(currentMapCenterLatLng.longitude);
        } else {
            showMsg("没有位置信息");
            return;
        }

        InsertSupportRecordImpl.getInstance().queryInsertRecordInfo(experienceSiteInfo, new InsertSupportRecordImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg("上传标点信息失败！");
            }

            @Override
            public void onResponse(String response) {
                showMsg("感谢您的反馈！");
                if (binding.expPointMarker.getVisibility() == View.VISIBLE) {
                    queryExperienceSite(provinceName, cityName, enCarrier);
                }
                binding.addBgView.setVisibility(View.GONE);
            }
        });
    }

    private Context requireContext() {
        if (homePage != null) {
            return homePage.requireContext();
        }
        return null;
    }

    private Activity requireActivity() {
        if (homePage != null) {
            return homePage.requireActivity();
        }
        return null;
    }

    private void showMsg(final String message) {
        if (homePage != null) {
            homePage.showMsg(message);
        }
    }

    private FragmentManager getChildFragmentManager() {
        if (homePage != null) {
            return homePage.getChildFragmentManager();
        }
        return null;
    }

    /**
     * 切换fragment
     */
    private void push(Fragment fragment) {
        if (homePage != null) {
            homePage.push(fragment);
        }
    }

    /**
     * 显示loading Dialog
     */
    private void showLoadingDialog() {
        if (homePage != null) {
            homePage.showLoadingDialog();
        }
    }

    /**
     * 隐藏loading Dialog
     */
    private void dismissLoadingDialog() {
        if (homePage != null) {
            homePage.dismissLoadingDialog();
        }
    }


}
