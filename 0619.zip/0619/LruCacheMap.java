package com.huawei.genexcloud.util;

import androidx.annotation.NonNull;
import androidx.collection.LruCache;

import java.util.List;
import java.util.Map;

/**
 * lru算法缓存
 * @param <K>
 * @param <V>
 */
public abstract class LruCacheMap<K, V> extends LruCache<K, V> {

    // 默认大小
    private static final int DEFAULT_SIZE = 1024;
    // 设置每个item元素的大小
    private int mItemSize = 1;

    public LruCacheMap() {
        super(DEFAULT_SIZE);
    }
    /**
     * @param maxSize for caches that do not override {@link #sizeOf}, this is
     *                the maximum number of entries in the cache. For all other caches,
     *                this is the maximum sum of the sizes of the entries in this cache.
     */
    public LruCacheMap(int maxSize) {
        super(maxSize);
    }

    public LruCacheMap(int maxSize, int itemSize) {
        super(maxSize);
        mItemSize = itemSize;
    }

    public abstract int getItemSize(@NonNull K key, @NonNull V value);
    public void setItemSize(int size) {
        if (size <= 0) {
            throw new IllegalArgumentException("item size can not less than 1");
        }
        mItemSize = size;
    }

    @Override
    protected int sizeOf(@NonNull K key, @NonNull V value) {
        return getItemSize(key, value);
    }
}
