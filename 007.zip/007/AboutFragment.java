package com.huawei.genexcloud.survey.fragment.setting;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.huawei.genexcloud.httplib.ErrorBean;
import com.huawei.genexcloud.survey.base.BasicFragment;
import com.huawei.genexcloud.survey.bean.AppUpdateVersionBean;
import com.huawei.genexcloud.survey.databinding.FragmentAboutBinding;
import com.huawei.genexcloud.survey.dialog.UpdateDialog;
import com.huawei.genexcloud.survey.http.gcpt.QueryAppUpdateImpl;
import com.huawei.genexcloud.survey.util.AppUtil;

import okhttp3.Request;

/**
 * 关于app
 */
public class AboutFragment extends BasicFragment {
    private FragmentAboutBinding binding;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAboutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        binding.titleLayout.title.setText("关于勘测APP");
        binding.titleLayout.leftButton.setOnClickListener(v->{
            backPressed();
        });
        binding.titleLayout.rightButton.setVisibility(View.GONE);
        binding.contactLayout.setOnClickListener(v->{
            actPush(new ContactFragment());
        });
        binding.checkVersion.setOnClickListener(v->{
            checkUpdate();
        });
    }

    private void initData() {
        binding.versionName.setText("版本号:" + AppUtil.getVersionName(getContext()));
        binding.newVersion.setText("");
    }

    /**
     * 检查升级
     */
    private void checkUpdate() {
        QueryAppUpdateImpl.getInstance().checkUpdate(new QueryAppUpdateImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean errorBean) {
                binding.newVersion.setText("检查升级失败");
            }

            @Override
            public void onResponse(AppUpdateVersionBean appUpdateVersionBean) {
                if (null == appUpdateVersionBean) {
                    binding.newVersion.setText("检查升级失败");
                } else {
                    if (appUpdateVersionBean.versionCode > AppUtil.getVersionCode(getContext()) - 10) {
                        // 有升级信息
                        binding.newVersion.setText("有新版本：" + appUpdateVersionBean.versionName);
                        UpdateDialog dialog = new UpdateDialog();
                        Bundle b = new Bundle();
                        b.putParcelable("updateData", appUpdateVersionBean);
                        dialog.setArguments(b);
                        dialog.setOnDismissListener(dialog1 -> {
                            if (appUpdateVersionBean.level == AppUpdateVersionBean.UPDATE_FORCE && null != getActivity()) {
                                getActivity().finish();
                            }
                        });
                        dialog.show(getChildFragmentManager(), "UpdateDialog");
                    } else {
                        // 已是最新版本
                        binding.newVersion.setText("当前已是最新版本");
                    }
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
