package com.huawei.genexcloud.survey.dialog;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.survey.adapter.UpdateDescriptionAdapter;
import com.huawei.genexcloud.survey.bean.AppUpdateVersionBean;
import com.huawei.genexcloud.survey.databinding.DialogUpdateBinding;

/**
 * 升级弹窗
 */
public class UpdateDialog extends BaseDialog {

    private DialogUpdateBinding binding;
    private UpdateDescriptionAdapter adapter;
    private AppUpdateVersionBean updateData;

    private DialogInterface.OnDismissListener OnDismissListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (null != bundle) {
            updateData = bundle.getParcelable("updateData");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogUpdateBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }
    private void initView() {
        binding.descriptionList.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new UpdateDescriptionAdapter();
        binding.descriptionList.setAdapter(adapter);
    }

    private void initData() {
        if (null == updateData) {
            dismissAllowingStateLoss();
            showMsg("升级信息有误");
            return;
        }
        String updateDescription = updateData.description;
        if (!TextUtils.isEmpty(updateDescription)) {
            String[] descriptions = updateDescription.split("&");
            adapter.setData(descriptions);
        }
        binding.title.setText("有新版本：" + updateData.versionName);
        binding.cancel.setOnClickListener(v->{
            dismissAllowingStateLoss();
        });
        binding.confirm.setOnClickListener(v->{
            downLoadApk(updateData.path);
        });
        switch (updateData.level) {
            case AppUpdateVersionBean.UPDATE_FORCE:
                binding.confirm.setVisibility(View.VISIBLE);
                binding.cancel.setVisibility(View.GONE);
                binding.buttonGap.setVisibility(View.GONE);
                break;
            case AppUpdateVersionBean.UPDATE_NORMAL:
            case AppUpdateVersionBean.UPDATE_WEAK:
            default:
                binding.confirm.setVisibility(View.VISIBLE);
                binding.cancel.setVisibility(View.VISIBLE);
                binding.buttonGap.setVisibility(View.VISIBLE);
                break;
        }
        if (updateData.level == AppUpdateVersionBean.UPDATE_FORCE) {
            getDialog().setCancelable(false);
        } else {
            getDialog().setCancelable(true);
        }
        if (null != OnDismissListener && null != getDialog()) {
            getDialog().setOnDismissListener(OnDismissListener);
        }
    }

    /**
     * 设置取消监听
     * @param OnDismissListener
     */
    public void setOnDismissListener(DialogInterface.OnDismissListener OnDismissListener) {
        this.OnDismissListener = OnDismissListener;
    }
    /**
     * 启动下载
     * @param path
     */
    private void downLoadApk(String path) {

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}
