package com.huawei.genexcloud.survey.http.gcpt;

import android.text.TextUtils;

import com.huawei.genexcloud.httplib.GCCallback;
import com.huawei.genexcloud.survey.BaseApplication;
import com.huawei.genexcloud.survey.bean.AppUpdateVersionBean;
import com.huawei.genexcloud.survey.http.util.GCPTHttpUtil;
import com.huawei.genexcloud.survey.util.AppUtil;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 检查app升级信息
 */
public class QueryAppUpdateImpl extends GCPTHttpUtil {

    private static QueryAppUpdateImpl instance;

    public static QueryAppUpdateImpl getInstance() {
        if (null == instance) {
            synchronized (QueryAppUpdateImpl.class) {
                if (null == instance) {
                    instance = new QueryAppUpdateImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getUrlMessage() {
        return "/genex/mobileinfomgmt-service/kance/queryAppVersion";
    }

    public void checkUpdate(Callback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("VersionCode", 40);
        body.put("Ver", "1.4.0");
        postSingle(instance, body, callback);
    }

    public static abstract class Callback extends GCCallback<AppUpdateVersionBean> {
        @Override
        public AppUpdateVersionBean parseNetworkResponse(String s) throws Exception {
            JSONObject json = new JSONObject(s);
            JSONObject dataJson = json.optJSONObject("JsonData");
            AppUpdateVersionBean updateInfo = new AppUpdateVersionBean();
            updateInfo.versionName = dataJson.optString("Version");
            updateInfo.description = dataJson.optString("VersionDescription");
            updateInfo.level = dataJson.optInt("Level");
            updateInfo.path = dataJson.optString("AppPath");
            updateInfo.versionCode = dataJson.optInt("VersionCode");
            if (!TextUtils.isEmpty(updateInfo.versionName) && !TextUtils.isEmpty(updateInfo.path)) {
                return updateInfo;
            }
            return null;
        }
    }
}
