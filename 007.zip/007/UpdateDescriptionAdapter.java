package com.huawei.genexcloud.survey.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.survey.databinding.ItemUpdateDescriptionBinding;

/**
 * 升级提示中的描述信息item
 */
public class UpdateDescriptionAdapter extends RecyclerView.Adapter<UpdateDescriptionAdapter.Holder> {
    private String[] data;
    public void setData(String[] data) {
        this.data = data;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemUpdateDescriptionBinding binding = ItemUpdateDescriptionBinding
                .inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new Holder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        String content = data[position];
        holder.binding.content.setText(content);
    }

    @Override
    public int getItemCount() {
        return null == data? 0:data.length;
    }

    protected class Holder extends RecyclerView.ViewHolder {
        public ItemUpdateDescriptionBinding binding;
        public Holder(@NonNull ItemUpdateDescriptionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
