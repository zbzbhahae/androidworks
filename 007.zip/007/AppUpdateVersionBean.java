package com.huawei.genexcloud.survey.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

public class AppUpdateVersionBean implements Parcelable {
    public static final int UPDATE_FORCE = 1;
    public static final int UPDATE_NORMAL = 2;
    public static final int UPDATE_WEAK = 3;

    @SerializedName("VersionCode")
    public int versionCode;
    @SerializedName("Version")
    public String versionName;
    @SerializedName("VersionDescription")
    public String description;
    // 下载地址
    @SerializedName("AppPath")
    public String path;
    // 升级类型 1:强制升级 2:建议升级 3:弱升级
    @SerializedName("Level")
    public int level;

    protected AppUpdateVersionBean(Parcel in) {
        versionCode = in.readInt();
        versionName = in.readString();
        description = in.readString();
        path = in.readString();
        level = in.readInt();
    }

    public AppUpdateVersionBean() {}

    public static final Creator<AppUpdateVersionBean> CREATOR = new Creator<AppUpdateVersionBean>() {
        @Override
        public AppUpdateVersionBean createFromParcel(Parcel in) {
            return new AppUpdateVersionBean(in);
        }

        @Override
        public AppUpdateVersionBean[] newArray(int size) {
            return new AppUpdateVersionBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(versionCode);
        dest.writeString(versionName);
        dest.writeString(description);
        dest.writeString(path);
        dest.writeInt(level);
    }

    /**
     * 是否是有效的升级信息
     * @return
     */
    public boolean isAvailable() {
        if (versionCode <= 0 || TextUtils.isEmpty(path) || TextUtils.isEmpty(versionName)) {
            return false;
        }
        return true;
    }
}