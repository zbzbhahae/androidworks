package com.huawei.genexcloud.scene.bean;

import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

import java.util.Iterator;
import java.util.List;

/**
 * Created by jWX556709 on 2020/11/14. 5G质量
 */

public class ResultBean {
    private String operator;

    private List<Quota> quotaList; //指标列表
    private List<String> batchList; //指标横坐标列表
    private List<QuotaType> quotaTypes; //指标类型

    private String scenesAnalizeDesc;//场景分析的文字内容

    //场景分析相关
    private List<String> scenesIndicatorNames;//场景分析的指标名称list
    private List<String> scenesTypeNames;//场景分析的具体场景,现在只有医院场景
    private List<ScenesBean> scenesData;//场景分析的具体数据
    private String scenesDesc;//场景分析的描述信息
    private String indicatorDesc; // 三元十三维指标的描述信息


    public String getIndicatorDesc() {
        return indicatorDesc;
    }

    public void setIndicatorDesc(String indicatorDesc) {
        this.indicatorDesc = indicatorDesc;
    }

    public String getScenesDesc() {
        return scenesDesc;
    }

    public void setScenesDesc(String scenesDesc) {
        this.scenesDesc = scenesDesc;
    }

    public List<String> getScenesIndicatorNames() {
        return scenesIndicatorNames;
    }

    public void setScenesIndicatorNames(List<String> scenesIndicatorNames) {
        this.scenesIndicatorNames = scenesIndicatorNames;
    }

    public List<String> getScenesTypeNames() {
        return scenesTypeNames;
    }

    public void setScenesTypeNames(List<String> scenesTypeNames) {
        this.scenesTypeNames = scenesTypeNames;
    }

    public List<ScenesBean> getScenesData() {
        return scenesData;
    }

    public void setScenesData(List<ScenesBean> scenesData) {
        this.scenesData = scenesData;
    }

    public String getScenesAnalizeDesc() {
        return scenesAnalizeDesc;
    }

    public void setScenesAnalizeDesc(String scenesAnalizeDesc) {
        this.scenesAnalizeDesc = scenesAnalizeDesc;
    }

    @Override
    public String toString() {
        return "ResultBean{" + "operator='" + operator + '\'' + ", quotaList=" + quotaList + ", batchList=" + batchList
                + '}';
    }

    public List<QuotaType> getQuotaTypes() {
        return quotaTypes;
    }

    public void setQuotaTypes(List<QuotaType> quotaTypes) {
        this.quotaTypes = quotaTypes;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public List<Quota> getQuotaList() {
        return quotaList;
    }

    public void setQuotaList(List<Quota> quotaList) {
        this.quotaList = quotaList;
    }

    public List<String> getBatchList() {
        return batchList;
    }

    public void setBatchList(List<String> batchList) {
        this.batchList = batchList;
    }

    /**
     * 全国界面下的场景分析bean
     */
    public static class ScenesBean {
        public double valueUsedToOrder;//用来排序的值,不想写12个比较器

        @Deprecated
        private String province;
        private String city;


        @SerializedName("scenario")
        private String scenesType;//场景类型名称  比如  医院
        @SerializedName("scenarioName")
        private String scenesLocaleName;//场景地点 比如xxx医院
        // 场景的具体指标项及其数据
        private List<SceneIndicatorBean> indicators;
        // 场景指标的关系数据bean 具体场景可能因为数据问题而不全
        private List<SceneIndicatorBean> indicatorRelations;

        public List<SceneIndicatorBean> getIndicatorRelations() {
            return indicatorRelations;
        }

        public void setIndicatorRelations(List<SceneIndicatorBean> indicatorRelations) {
            this.indicatorRelations = indicatorRelations;
        }

        public List<SceneIndicatorBean> getIndicators() {
            return indicators;
        }

        public void setIndicators(List<SceneIndicatorBean> indicators) {
            this.indicators = indicators;
        }

        public String getScenesType() {
            return scenesType;
        }

        public void setScenesType(String scenesType) {
            this.scenesType = scenesType;
        }

        public String getScenesLocaleName() {
            return scenesLocaleName;
        }

        public void setScenesLocaleName(String scenesLocaleName) {
            this.scenesLocaleName = scenesLocaleName;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }
    }

    public class Quota {
        private String quotaName; //指标名
        private String quotaUnit; //指标单位
        private double relativeRatio; //环比
        private List<Double> difBatchVaule;
        private boolean isForward;
        private boolean isOpen = false;
        private double sameMonthRatio; //同比

        public double getSameMonthRatio() {
            return sameMonthRatio;
        }

        public void setSameMonthRatio(double sameMonthRatio) {
            this.sameMonthRatio = sameMonthRatio;
        }

        public boolean isOpen() {
            return isOpen;
        }

        public void setOpen(boolean open) {
            isOpen = open;
        }

        public String getQuotaName() {
            return quotaName;
        }

        public void setQuotaName(String quotaName) {
            this.quotaName = quotaName;
        }

        public String getQuotaUnit() {
            return quotaUnit;
        }

        public void setQuotaUnit(String quotaUnit) {
            this.quotaUnit = quotaUnit;
        }

        public double getRelativeRatio() {
            return relativeRatio;
        }

        public void setRelativeRatio(double relativeRatio) {
            this.relativeRatio = relativeRatio;
        }

        public List<Double> getDifBatchVaule() {
            return difBatchVaule;
        }

        public void setDifBatchVaule(List<Double> difBatchVaule) {
            this.difBatchVaule = difBatchVaule;
        }

        public boolean isForward() {
            return isForward;
        }

        public void setForward(boolean forward) {
            isForward = forward;
        }

        @Override
        public String toString() {
            return "Quota{" +
                    "quotaName='" + quotaName + '\'' +
                    ", quotaUnit='" + quotaUnit + '\'' +
                    ", relativeRatio=" + relativeRatio +
                    ", difBatchVaule=" + difBatchVaule +
                    ", isForward=" + isForward +
                    ", isOpen=" + isOpen +
                    ", sameMonthRatio=" + sameMonthRatio +
                    '}';
        }

        public boolean isAvailable() {
            if (TextUtils.isEmpty(getQuotaName()) || null == getDifBatchVaule() || 0 == getDifBatchVaule().size()) {
                return false;
            }
            return true;
        }
    }

    public class QuotaType {
        private String typeName;
        @SerializedName("quota")
        private List<Quota> quotas;

        @Override
        public String toString() {
            return "QuotaType{" +
                    "typeName='" + typeName + '\'' +
                    ", quotas=" + quotas +
                    '}';
        }

        public String getTypeName() {
            return typeName;
        }

        public void setTypeName(String typeName) {
            this.typeName = typeName;
        }

        public List<Quota> getQuotas() {
            return quotas;
        }

        public void setQuotas(List<Quota> quotas) {
            this.quotas = quotas;
        }


        public boolean isAvailable() {
            if (TextUtils.isEmpty(getTypeName()) || null == getQuotas() || 0 == getQuotas().size()) {
                return false;
            }
            //检查指标是否有问题 不合格的移除
            Iterator<Quota> iterator = getQuotas().iterator();
            while (iterator.hasNext()) {
                Quota next = iterator.next();
                if (null == next || !next.isAvailable()) {
                    iterator.remove();
                }
            }
            return true;
        }
    }


}
