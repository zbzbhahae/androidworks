package com.huawei.genexcloud.scene.http.util;

/**
 * Created by zWX1094027 on 2021/9/14.
 */

public class ErrorBean {

    public static final int ERROR_LOGIN = 1;             //登录cookie过时
    public static final int ERROR_EXCEPTION = 2;     //发生异常
    public static final int ERROR_EMPTY = 3;         //访问成功但返回内容为空
    public static final int ERROR_CANCELED = 4;      //请求被取消
    public static final int ERROR_NETWORK = 5;       //网络错误
    public static final int ERROR_TIMEOUT = 6;       //请求超时
    public static final int ERROR_NOT_JSON = 7;      //返回数据不是json字符串或者其中没有message和statuscode
    public static final int ERROR_NOT_SUCCESS = 8;      //responsecode不是200
    public static final int ERROR_PARSE_EXCEPTION = 9;      //解析返回数据失败
    public static final int ERROR_NETWORK_SERVER = 10;   //请求能通，但是返回错误代码 如405 不是200
    public static final int ERROR_NO_PERMISSION = 11; // 没有权限


    public String message;
    public int errorCode;
    public Exception exception;

    public ErrorBean() {
    }

    public ErrorBean(int errorCode, String message, Exception exception) {
        this.message = message;
        this.errorCode = errorCode;
        this.exception = exception;
    }

    /**
     * 生成错误信息  方便统一管理
     *
     * @param errorCode 错误码
     * @return
     */
    public static ErrorBean make(int errorCode) {
        return make(errorCode, null);
    }

    /**
     * 生成错误信息  方便统一管理
     *
     * @param errorCode 错误码
     * @param e 异常
     * @return
     */
    public static ErrorBean make(int errorCode, Exception e) {
        switch (errorCode) {
            case ERROR_LOGIN:
                return new ErrorBean(errorCode, "登录过期", e);
            case ERROR_EXCEPTION:
                return new ErrorBean(errorCode, "发生错误", e);
            case ERROR_EMPTY:
                return new ErrorBean(errorCode, "无内容", e);
            case ERROR_CANCELED:
                return new ErrorBean(errorCode, "请求取消", e);
            case ERROR_NETWORK:
                return new ErrorBean(errorCode, "网络异常，请检查网络", e);
            case ERROR_TIMEOUT:
                return new ErrorBean(errorCode, "请求超时", e);
            case ERROR_NOT_JSON:
                return new ErrorBean(errorCode, "返回数据不标准", e);
            case ERROR_NOT_SUCCESS:
                return new ErrorBean(errorCode, "访问失败", e);
            case ERROR_PARSE_EXCEPTION:
                return new ErrorBean(errorCode, "解析数据失败", e);
            case ERROR_NETWORK_SERVER:
                return new ErrorBean(errorCode, "访问服务器失败", e);
            case ERROR_NO_PERMISSION:
                return new ErrorBean(errorCode, "没有权限", e);
            default:
        }
        return new ErrorBean(errorCode, "未知错误", e);
    }

    @Override
    public String toString() {
        String result = "ErrorBean{" +
                "message='" + message + '\'' +
                ", errorCode=" + errorCode;
        if (null == exception) {
            result += "}";
        } else {
            result += exception.toString() + '}';
        }
        return result;
    }
}
