package com.huawei.genexcloud.scene.http.util;

import com.huawei.genexcloud.scene.BuildConfig;
import com.huawei.genexcloud.scene.provider.GCHttpUtil;

import java.util.Map;

public abstract class CSharpHttpUtil extends GCHttpUtil {

    private static String url;

    static {
        if (BuildConfig.DEBUG) {
            url = BuildConfig.HOST_GC_ADDRESS + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile_test";
        } else {
            url = BuildConfig.HOST_GC_ADDRESS + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile";
        }
    }

    /**
     * 发送post请求
     * @param body 访问参数的集合
     * @param callBack 结果回调
     */
    protected void post(final Map<String, Object> body, final GCCallback callBack) {
        GCHttpUtil.post(null, url, getHeaders(), buildBodyParams(getMessageName(), body), callBack);
    }

    /**
     * 发送单一post请求，只会同时存在一个相同tag的请求
     * @param tag post请求的标识
     * @param body 访问参数的集合
     * @param callBack 结果回调
     */
    protected void postSingle(Object tag, final Map<String, Object> body, final GCCallback callBack) {
        if (null != tag) {
            OkHttpManager.cancel(tag);
        }
        GCHttpUtil.post(tag, url, getHeaders(), buildBodyParams(getMessageName(), body), callBack);
    }

    /**
     * 获取messageName
     * @return
     */
    protected abstract String getMessageName();
}
