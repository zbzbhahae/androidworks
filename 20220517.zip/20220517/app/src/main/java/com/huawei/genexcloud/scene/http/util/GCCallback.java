package com.huawei.genexcloud.scene.http.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.scene.logger.GCLogger;

import java.net.URLDecoder;

import okhttp3.FormBody;
import okhttp3.Response;

public abstract class GCCallback<T> extends AbsCallback<T> {

    @Override
    public T parseNetworkResponse(@NonNull Response response) throws Exception {
        String result = response.body().string();

        GCLogger.error("http", "返回信息:[" + result + "]");
        GCLogger.error("http", "访问url:[" + response.request().url().toString() + "]");
        if (response.request().body() instanceof FormBody) {
            FormBody temBody = (FormBody) response.request().body();
            StringBuffer sb = new StringBuffer();
            for (int i=0; i<temBody.size(); i++) {
                sb.append("[key:" + temBody.encodedName(i) + " , value:" + URLDecoder.decode(temBody.encodedValue(i), "utf-8") + " \r\n");
            }
            GCLogger.error("http", "访问参数:[" + sb.toString() + "]");
        }



        if (TextUtils.isEmpty(result)) { //访问无返回内容
            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_EMPTY, null);
            throw new HttpErrorException(errorBean);
        }
        //如果返回的是一个html信息 (登录网址) 表示登录cookie token过期了 需要重新登录
        if (result.contains("<!DOCTYPE HTML")) {
            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_LOGIN, null);
            throw new HttpErrorException(errorBean);
        }
        //返回值是json数据
        if (isJsonData(result)) { // json数据或者json数组
            T o = parseNetworkResponse(result);
            return o;
        } else {//不是json字符串或者json数组
            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_NOT_JSON, null);
            throw new HttpErrorException(errorBean);
        }
    }


    public abstract T parseNetworkResponse(@NonNull String response) throws Exception;

    /**
     * 判断一段字符串是否是json数据
     *
     * @param result
     * @return
     */
    private static boolean isJsonData(String result) {
        if (TextUtils.isEmpty(result)) {
            return false;
        }
        if ( (result.startsWith("{") && result.endsWith("}"))
                || (result.startsWith("[") && result.endsWith("]")) ) {
            return true;
        }
        return false;
    }
}


