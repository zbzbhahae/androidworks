package com.huawei.genexcloud.scene.common;

import android.text.TextUtils;

import com.huawei.genexcloud.scene.App;
import com.huawei.genexcloud.scene.BuildConfig;
import com.huawei.genexcloud.scene.provider.CommonProviderUtils;
import com.huawei.genexcloud.scene.provider.PlugApkInfomationBean;
import com.huawei.genexcloud.scene.provider.PublicShareDataBean;

/**
 * Created by lWX348305 on 2019/2/25.
 */

public class Constants {
    public static final String LOGIN_USER_KEY = "userid";
    // 服务器返回版本号
    public static final String VERSION = "version";
    //是否上传CRASH日志标记
    public static final String IS_UPLOAD_CRASH = "is_upload_crash";
    //CRASH日志名称
    public static final String CRASH_LOG_FILE_NAME = "crash_log";
    // 保存位置信息
    public static final String CURRENT_CITY = "currCity";
    public static final String CURRENT_LAT = "currLat";
    public static final String CURRENT_LNG = "currLng";
    public static final String CURRENT_PROVINCE = "currentProvince";
    public static final String USER_LIMIT = "userLimit";

    public static final String CURRENT_CENTERLAT = "currCenterLat";
    public static final String CURRENT_CENTERLNG = "currCenterLng";

    public static final String IS_FIRST_ENTER_SPEED = "isFirstEnterSpeed";

    public static final String EXPIRE_COOKIE = "com.huawei.genexcloud.expire";
    /**
     * 网络质量（网络洞察）
     */
    public static final int AUTH_TYPE_DOGNCHA = 4;
    /**
     * 网络经营（业务洞察）
     */
    public static final int AUTH_TYPE_JINGYING = 7;
    /**
     * 精品网风险预警（网络画像）
     */
    public static final int AUTH_TYPE_HUAXIANG = 1;
    /**
     * 精品网运营
     */
    public static final int AUTH_TYPE_YUNYING = 8;
    /**
     * 网络档案
     */
    public static final int AUTH_TYPE_DANGAN = 9;
    /**
     * 5G质量
     */
    public static final int AUTH_TYPE_NR = 4;
    /**
     * 北京纬度
     */
    public static final double LAT_BEIJING = 39.914835383312145;
    /**
     * 北京经度
     */
    public static final double LNG_BEIJING = 116.40400661871865;

    public static final String CSFToken = "CSFToken";
    public static final String UU_ID = "uuid";
    public static final String SESSION_ID = "sessionId";
    public static String boardCastCity = "start_getCityHttp";
    public static String boardCastAll = "start_getHttp";
    // 正式域名
    public static String HOST_ADDRESS = BuildConfig.HOST_GC_ADDRESS;

    public static String FILE_DOWNLOAD_ADDRESS = HOST_ADDRESS + "/mobileinfomgmtapps/downLoadFileAction?";

    /**
     * C#服务
     */
    public static String HOST_ADDRESS_OFFICIAL_C = HOST_ADDRESS + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile";

    /**
     * JAVA通用服务
     */
    public static String HOST_ADDRESS_OFFICIAL_JAVA = HOST_ADDRESS
            + "/mobileinfomgmtapps/getlinuxAction?endPoint=mobile_java";

    /**
     * 4G网络质量
     */
    public static String HOST_ADDRESS_RNAC_INSIGHTASSESS = HOST_ADDRESS_OFFICIAL_JAVA;

    /**
     * 精品网运营
     */
    public static String HOST_ADDRESS_ANDROID_TOPQUALITY = HOST_ADDRESS
            + "/mobileinfomgmtapps/getlinuxAction?endPoint=Android_TopQuality";

    /**
     * 5G规建维
     */
    public static String HOST_ADDRESS_ANDROID_STRUCTURE = HOST_ADDRESS
            + "/mobileinfomgmtapps/getlinuxAction?endPoint=Android_structure";

    public static String HOST_ADDRESS_IROAD_MAP = HOST_ADDRESS + "/agileinsightreportofchina";

    /**
     * 获取插件服务器地址
     *
     * @param
     * @return
     */
    public static void initUrl() {
        PublicShareDataBean shareDataBean = CommonProviderUtils.queryByKey(App.getAppContext(),
                "modelName");
        PlugApkInfomationBean bean = null;
        if (null != shareDataBean && !TextUtils.isEmpty(shareDataBean.getName())) {
            bean = CommonProviderUtils.queryUrlByModelName(App.getAppContext(), shareDataBean.getName());
        }

        if (null != bean) {
            HOST_ADDRESS = bean.getDomainUrl();
            HOST_ADDRESS_OFFICIAL_C = bean.getDotNetUrl();
            HOST_ADDRESS_OFFICIAL_JAVA = bean.getJavaUrl();
            FILE_DOWNLOAD_ADDRESS = bean.getDownLoadUrl();
        } else {
            HOST_ADDRESS_OFFICIAL_C = HOST_ADDRESS + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile_test";
            HOST_ADDRESS_OFFICIAL_JAVA = HOST_ADDRESS + "/mobileinfomgmtapps/getlinuxAction?endPoint=mobile_java_test";
            FILE_DOWNLOAD_ADDRESS = HOST_ADDRESS + "/mobileinfomgmtapps/downLoadFileAction?Url=downLoad_test";
        }
    }

    /*********************自定义权限************************************/
    public static final String PERMISSION_BROADCAST = "com.huawei.genexcloud.permission.broadcast";

    /***********************插件静态字段******************************/
    public static final String TYPE_4G = "4G";
    public static final String TYPE_5G = "5G";

}
