package com.huawei.genexcloud.scene.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public final class SharedPreferencesUtil {
    private static SharedPreferencesUtil instance;
    private SharedPreferences sharedPreferences = null;

    private SharedPreferencesUtil(Context context) {
        initSharedPreferences(context);

    }

    public static SharedPreferencesUtil getInstance(Context context) {
        if (null == instance) {
            instance = new SharedPreferencesUtil(context);
        }
        return instance;
    }

    public void initSharedPreferences(Context context) {
        sharedPreferences = context.getSharedPreferences("GCSharedPreferences", Context.MODE_MULTI_PROCESS);
    }

    public SharedPreferences getSharedPreferences() {

        return sharedPreferences;
    }

    /**
     * 保存键值
     *
     * @param key
     * @param value
     */
    public void saveStringValue(String key, String value) {
        if (sharedPreferences == null) {
            return;
        }

        Editor edit = sharedPreferences.edit();
        edit.putString(key, value);
        edit.commit();
    }

    /**
     * 获取String值
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public String readStringValue(String key, String defaultValue) {
        if (sharedPreferences == null) {
            return defaultValue;
        }
        return sharedPreferences.getString(key, defaultValue);
    }

    /**
     * 保存键值 Boolean型
     *
     * @param key
     * @param value
     */
    public void saveBooleanValue(String key, boolean value) {
        if (sharedPreferences == null) {
            return;
        }

        Editor edit = sharedPreferences.edit();
        edit.putBoolean(key, value);
        edit.commit();
    }

    /**
     * 获取boolean值
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public boolean readBooleanValue(String key, boolean defaultValue) {
        if (sharedPreferences == null) {
            return defaultValue;
        }

        return sharedPreferences.getBoolean(key, defaultValue);
    }

    /**
     * 保存键值 Int
     *
     * @param key
     * @param value
     */
    public void saveIntValue(String key, int value) {
        if (sharedPreferences == null) {
            return;
        }

        Editor edit = sharedPreferences.edit();
        edit.putInt(key, value);
        edit.commit();
    }

    /**
     * 获取float值
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public int readIntValue(String key, int defaultValue) {
        if (sharedPreferences == null) {
            return defaultValue;
        }

        return sharedPreferences.getInt(key, defaultValue);
    }

    /**
     * 保存键值 Float
     *
     * @param key
     * @param value
     */
    public void saveFloatValue(String key, Float value) {
        if (sharedPreferences == null) {
            return;
        }

        Editor edit = sharedPreferences.edit();
        edit.putFloat(key, value);
        edit.commit();
    }

    /**
     * 获取Float值
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public Float readFloatValue(String key, Float defaultValue) {
        if (sharedPreferences == null) {
            return defaultValue;
        }

        return sharedPreferences.getFloat(key, defaultValue);
    }

    /**
     * 保存键值 Long
     *
     * @param key
     * @param value
     */
    public void saveLongValue(String key, Long value) {
        if (sharedPreferences == null) {
            return;
        }

        Editor edit = sharedPreferences.edit();
        edit.putLong(key, value);
        edit.commit();
    }

    /**
     * 获取Long值
     *
     * @param key
     * @param defaultValue
     * @return
     */
    public Long readLongValue(String key, Long defaultValue) {
        if (sharedPreferences == null) {
            return defaultValue;
        }

        return sharedPreferences.getLong(key, defaultValue);
    }

    /**
     * 删除键值
     *
     * @param key
     **/
    public void deleteValue(String key) {

        if (sharedPreferences.contains(key)) {
            Editor edit = sharedPreferences.edit();
            edit.remove(key);
            edit.commit();
        }
    }
}
