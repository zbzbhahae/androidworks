package com.huawei.genexcloud.scene.provider;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.scene.App;
import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.util.AbsCallback;
import com.huawei.genexcloud.scene.http.util.ErrorBean;
import com.huawei.genexcloud.scene.http.util.GCCallback;
import com.huawei.genexcloud.scene.http.util.HttpErrorException;
import com.huawei.genexcloud.scene.http.util.OkHttpManager;

import org.json.JSONObject;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by zWX1094027 on 2021/9/15.
 */

public class GCHttpUtil {

    private static final Handler handler = new Handler(Looper.getMainLooper());

    protected static void post(String url, Map<String, String> headers, final Map<String, String> body,
                            final GCCallback callBack) {
        post(null, url,headers, body, callBack);
    }

    /**
     * 发送请求时会取消上一个同tag的请求
     * @param tag 访问标识
     * @param url 访问地址
     * @param headers 访问请求头
     * @param body 请求体内容
     * @param callBack
     */
    protected static void postSingle(Object tag, String url, Map<String, String> headers, final Map<String, String> body,
                                  final GCCallback callBack) {
        if (null != tag) {
            OkHttpManager.cancel(tag);
        }
        post(tag, url, headers, body, callBack);
    }


    /**
     * 发送post请求
     */
    protected static<T> void post(Object tag, String url, Map<String, String> headers,
                            final Map<String, String> body,
                            final GCCallback<T> callBack) {
        Request preparedRequest = OkHttpManager.buildPostRequest(tag, url, headers, null, body);
        if (null != callBack) {
            callBack.onBefore(preparedRequest);
        }
        OkHttpManager.post(preparedRequest, new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                ErrorBean errorBean;
                //可能是网络无链接 请求被cancel导致的socket关闭等
                if (e instanceof UnknownHostException) { // 服务器地址问题或者无网络都会触发
                    errorBean = ErrorBean.make(ErrorBean.ERROR_NETWORK, e); //网络访问失败
                } else if (e instanceof SocketTimeoutException) {
                    errorBean = ErrorBean.make(ErrorBean.ERROR_TIMEOUT, e); //连接超时
                } else {
                    errorBean = ErrorBean.make(ErrorBean.ERROR_EXCEPTION, e);
                }
                sendFailure(callBack, handler, errorBean);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        try {
                            T t = callBack.parseNetworkResponse(response);
                            sendSuccess(callBack, handler, t);
                        } catch (HttpErrorException e) {
                            ErrorBean eb = e.getErrorBean();
                            if (null != eb && eb.errorCode == ErrorBean.ERROR_LOGIN) {
                                // 发送登录过期的广播
                                sendBroadcast();
                            }
                            sendFailure(callBack, handler, eb);
                        } catch (Exception e) {
                            //解析数据失败
                            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_PARSE_EXCEPTION, e);
                            sendFailure(callBack, handler, errorBean);
                        }
                    } else { // OKHttp判断的访问是否成功为false
                        ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_NETWORK_SERVER, null);
                        sendFailure(callBack, handler, errorBean);
                    }
                } catch (Exception e) {
                    ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_EXCEPTION, e);
                    sendFailure(callBack, handler, errorBean);
                }
            }
        });
    }


    /**
     * 发送登录过期的广播
     * // TODO
     */
    private static void sendBroadcast() {

    }




    /**
     * 将网络访问失败信息回调到主线程
     *
     * @param callBack
     * @param h
     * @param failure
     */
    private static void sendFailure(final AbsCallback callBack,
                                    Handler h, final ErrorBean failure) {
        if (null != callBack) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    callBack.onFailure(failure);
                    callBack.onAfter();
                }
            });
        }
    }


    private static <T> void sendSuccess(final AbsCallback callBack
            , Handler h, final T result) {
        if (null != callBack) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    callBack.onResponse(result);
                    callBack.onAfter();
                }
            });
        }
    }


    /**
     * 将参数 map转换成 message 和 messageName两个参数的 map
     * @param body
     * @return
     */
    protected Map<String, String> buildBodyParams(String messageName, Map<String, Object> body) {
        Map<String, String> formBody = new HashMap<>();
        if (!TextUtils.isEmpty(messageName)) {
            formBody.put("messageName", messageName);
        }
        if (null == body || 0 == body.size()) {
            formBody.put("message", "{}");
        } else {
            try {
                JSONObject jsonObject = new JSONObject();
                for (Map.Entry<String, Object> item : body.entrySet()) {
                    String key = item.getKey();
                    Object value = item.getValue();
                    if (!TextUtils.isEmpty(key) && null != value) {
                        jsonObject.put(key, value);
                    }
                }
                String jsonMessage = jsonObject.toString();
                if (!TextUtils.isEmpty(jsonMessage)) {
                    formBody.put("message", jsonMessage);
                } else {
                    formBody.put("message", "{}");
                }
            } catch (Exception e) {
                Log.e("error", e.toString());
            }
        }
        return formBody;
    }

    /**
     * 获取请求头
     * @return
     */
    protected Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();

        String sid = IPCUtils.getDataToDB(App.getAppContext(), Constants.UU_ID);
        String csrf = IPCUtils.getDataToDB(App.getAppContext(), Constants.CSFToken);

        if (!TextUtils.isEmpty(sid)) {
            headers.put("Cookie", sid);
        }
        if (!TextUtils.isEmpty(csrf)) {
            headers.put("X-CSRF-TOKEN", csrf);
        }
        headers.put("Content-Type", "application/x-www-form-urlencoded");
        return headers;
    }
}
