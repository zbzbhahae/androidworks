package com.huawei.genexcloud.scene.bean;

/**
 * 场景分析中的指标数据类
 */
public class SceneIndicatorBean {
    // 指标中文名
    public String enName;
    // 指标英文名 (用于解析数据)
    public String cnName;
    // 指标数值
    public double value;
    // 是否是正向指标
    public boolean isPositive;
    // 指标的单位
    public String unit;
}
