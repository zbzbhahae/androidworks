package com.huawei.genexcloud.scene.provider;

import java.io.Serializable;

/**
 * Created by lWX419034 on 2017/5/12.
 * <p>
 * 网络请求获取apk所有信息
 */

public class PlugApkInfomationBean implements Serializable {
    /**
     * 模块名称
     */
    public String ModelName;
    /**
     * 版本号
     */
    public int VersionCode;
    /**
     * 版本名称
     */
    public String VersionName;
    /**
     * 包名：com.huawei.genexcloud.ModuleName
     */
    public String PackageName;
    /**
     * 启动类名：com.huawei.genexcloud.business.insight.ui.MainActivity
     */
    public String ClassName;
    //域名
    public String DomainUrl;
    //Java部分地址
    public String JavaUrl;
    //DotNet部分地址
    public String DotNetUrl;
    //下载图片文件地址
    public String DownLoadUrl;
    /**
     * AppPlugPath:文件上传的路径
     */
    public String AppPlugPath;
    /**
     * 升级类型：1.强制升级,2.选择升级
     */
    public int UpdateType;
    /**
     * 升级类型名称：强制升级(type 1),选择升级(type 2)等
     */
    public String UpdateName;
    /**
     * URL : 下载链接 包括apk和对应图标icon的下载链接
     */
    public String Url;
    /**
     * 比较后本地模块是否升级 1 ：需要升级 2 ： 不需要升级 0 : 尚未比较过，或者第一次下载
     */
    public String ImageUrl;
    public int CompareUpdate;
    public double FileSize;
    public double ImageSize;
    public int AuthorityFlag;
    public int Position;
    public int VersionCode_ser;
    public int IsShow;
    public int IsLocal;

    public int UserLimit;

    public String getDownLoadUrl() {
        return DownLoadUrl;
    }

    public void setDownLoadUrl(String downLoadUrl) {

        DownLoadUrl = downLoadUrl;
    }

    public String getDotNetUrl() {

        return DotNetUrl;
    }

    public void setDotNetUrl(String dotNetUrl) {
        DotNetUrl = dotNetUrl;
    }

    public String getJavaUrl() {
        return JavaUrl;
    }

    public void setJavaUrl(String javaUrl) {
        JavaUrl = javaUrl;
    }

    public String getDomainUrl() {
        return DomainUrl;
    }

    public void setDomainUrl(String domainUrl) {
        DomainUrl = domainUrl;
    }

    public int getUserLimit() {

        return UserLimit;
    }

    public void setUserLimit(int userLimit) {
        UserLimit = userLimit;
    }

    public double getImageSize() {
        return ImageSize;
    }

    public void setImageSize(double imageSize) {
        ImageSize = imageSize;
    }

    public double getFileSize() {

        return FileSize;
    }

    public void setFileSize(double fileSize) {
        FileSize = fileSize;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        ImageUrl = imageUrl;
    }

    public int getCompareUpdate() {

        return CompareUpdate;
    }

    public void setCompareUpdate(int compareUpdate) {
        CompareUpdate = compareUpdate;
    }

    public String getPackageName() {

        return PackageName;
    }

    public void setPackageName(String packageName) {
        PackageName = packageName;
    }

    public String getModelName() {
        return ModelName;
    }

    public void setModelName(String ModelName) {
        this.ModelName = ModelName;
    }

    public int getVersionCode() {
        return VersionCode;
    }

    public void setVersionCode(int VersionCode) {
        this.VersionCode = VersionCode;
    }

    public String getVersionName() {
        return VersionName;
    }

    public void setVersionName(String VersionName) {
        this.VersionName = VersionName;
    }

    public String getAppPlugPath() {
        return AppPlugPath;
    }

    public void setAppPlugPath(String AppPlugPath) {
        this.AppPlugPath = AppPlugPath;
    }

    public int getUpdateType() {
        return UpdateType;
    }

    public void setUpdateType(int UpdateType) {
        this.UpdateType = UpdateType;
    }

    public String getUpdateName() {
        return UpdateName;
    }

    public void setUpdateName(String UpdateName) {
        this.UpdateName = UpdateName;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String Url) {
        this.Url = Url;
    }

    public String getClassName() {
        return ClassName;
    }

    public void setClassName(String className) {
        ClassName = className;
    }

    public int getAuthorityFlag() {
        return AuthorityFlag;
    }

    public void setAuthorityFlag(int authorityFlag) {
        AuthorityFlag = authorityFlag;
    }

    public int getPosition() {
        return Position;
    }

    public void setPosition(int position) {
        Position = position;
    }

    public int getVersionCode_ser() {
        return VersionCode_ser;
    }

    public void setVersionCode_ser(int versionCode_ser) {
        VersionCode_ser = versionCode_ser;
    }

    public int getIsShow() {
        return IsShow;
    }

    public void setIsShow(int isShow) {
        IsShow = isShow;
    }

    public int getIsLocal() {
        return IsLocal;
    }

    public void setIsLocal(int isLocal) {
        IsLocal = isLocal;
    }

    @Override
    public String toString() {
        return "PlugApkInfomationBean{" + "ModelName='" + ModelName + '\'' + ", VersionCode=" + VersionCode
                + ", VersionName='" + VersionName + '\'' + ", PackageName='" + PackageName + '\'' + ", ClassName='"
                + ClassName + '\'' + ", DomainUrl='" + DomainUrl + '\'' + ", JavaUrl='" + JavaUrl + '\'' + ", DotNetUrl='"
                + DotNetUrl + '\'' + ", DownLoadUrl='" + DownLoadUrl + '\'' + ", AppPlugPath='" + AppPlugPath + '\''
                + ", UpdateType=" + UpdateType + ", UpdateName='" + UpdateName + '\'' + ", Url='" + Url + '\''
                + ", ImageUrl='" + ImageUrl + '\'' + ", CompareUpdate=" + CompareUpdate + ", FileSize=" + FileSize
                + ", ImageSize=" + ImageSize + ", AuthorityFlag=" + AuthorityFlag + ", Position=" + Position
                + ", VersionCode_ser=" + VersionCode_ser + ", IsShow=" + IsShow + ", IsLocal=" + IsLocal + ", UserLimit="
                + UserLimit + '}';
    }
}
