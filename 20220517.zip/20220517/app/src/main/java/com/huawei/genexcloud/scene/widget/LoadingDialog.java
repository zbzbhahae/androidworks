package com.huawei.genexcloud.scene.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatDialog;

import com.huawei.genexcloud.scene.R;

/**
 * Created by zWX1094027 on 2021/10/25.
 */

public class LoadingDialog extends AppCompatDialog {

    private TextView messageTV;
    private ImageView loadingIV;
    private Animation anim;

    public LoadingDialog(Context context) {
        this(context, null, true);
    }

    public LoadingDialog(Context context, String message, boolean cancelable) {
        super(context, R.style.loding_dialog);
        init(context, message, cancelable);
    }

    private void init(Context context, String message, boolean cancelable) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View contentView = inflater.inflate(R.layout.dialog_loading, null);// 得到加载view
        // xml中的ImageView
        // 给ImageView添加无限旋转的动画
        anim = AnimationUtils.loadAnimation(context, R.anim.loading);
        loadingIV = contentView.findViewById(R.id.login_progressbar);
        messageTV = contentView.findViewById(R.id.login_title);
        messageTV.setText(message);

        // dialog透明
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.8f;
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        getWindow().setAttributes(lp);
        setContentView(contentView);// 设置布局
        setCancelable(cancelable);// 不可以用“返回键”取消
    }

    public void setMessage(String message) {
        messageTV.setText(message);
    }

    public void setCancelable(boolean cancelable) {
        super.setCancelable(cancelable);
    }

    @Override
    public void show() {
        loadingIV.startAnimation(anim);
        super.show();
    }
}
