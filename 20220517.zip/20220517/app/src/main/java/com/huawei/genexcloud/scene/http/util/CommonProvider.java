package com.huawei.genexcloud.scene.http.util;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * <p>
 * 定义共享的数据库信息
 */

public class CommonProvider {

    public static final String AUTHORITY = "com.huawei.genexcloud.contentrovider";

    // 这个是每个Provider的标识，在Manifest中使用

    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.huawei.genexcloud";

    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.huawei.genexcloud";

    public static final class GenexCloudColumns implements BaseColumns {
        // CONTENT_URI跟数据库的表关联，最后根据CONTENT_URI来查询对应的表
        //如何将所有的本地数据表名进行遍历与加载出来
        //将所有的共享表名和共享的url
        public static final String TABLE_NAME = "T_PublicShareData";
        public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/publicsharedata");
        //进行动态列表查询

        public static final String TABLE_NAME1 = "T_NpoAuthority";
        public static final Uri CONTENT_URI1 = Uri.parse("content://" + AUTHORITY + "/npoauthority");

        //进行动态列表查询
        public static final String PROVICE_TABLE_NAME = "T_Province";
        public static final Uri PROVICE_CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/province");

        //进行共享插件化apk库
        public static final String PLUG_APK_TABLE_NAME = "T_PlugApkInfo";
        public static final Uri PLUG_APK_CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/plugapk");
        //插件化模块名称
        public static final String PLUG_APK_MODEL_NAME = "ModelName";
        public static final String PLUG_APK_DOMAIN_URL = "DomainUrl";
        public static final String PLUG_APK_JAVA_URL = "JavaUrl";
        public static final String PLUG_APK_DOT_NET_URL = "DotNetUrl";
        public static final String PLUG_APK_PACKAGENAME = "PackageName";
        public static final String PLUG_APK_CLASSNAME = "ClassName";
        public static final String PLUG_APK_DOWNLOAD_URL = "DownLoadUrl";
        public static final String PLUG_APK_VERSIONNAME = "VersionName";

        public static final String PROVINCE_INFO = "province";
        // 简拼
        public static final String PROVINCE_SIMPLE = "simpleSpell";
        // 英文拼写
        public static final String PROVINCE_SPELL = "spell";
        ;
        //key
        public static final String KEY = "key";
        //值
        public static final String NAME = "name";
        public static final String USERID = "userid";//登录账号键
        public static final String USERLIMIT = "userLimit";//权限键
        public static final String CURRENT_LAT = "currLat";
        public static final String CURRENT_LNG = "currLng";

        //运营商
        public static final String NETOPER = "netOper";
        //省
        public static final String PROVICE = "province";
        //市
        public static final String CITYNAME = "city";
        //npo姓名
        public static final String NPONAME = "npoName";
        //账号
        public static final String ACCOUNT = "account";
        //电话
        public static final String TELEPHONE = "telephone";
        //共享各市列表
        public static final String CITY_TABLE_NAME = "T_City";
        public static final Uri CITY_CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/city");
        public static final String CITY_CITYNAME = "cityName";
        public static final String CITY_PROVINCE = "province";
        public static final String CITY_SPELL = "spell";
        public static final String PROVINCE_CITY = "city";

        //共享案例搜索表

        public static final String CASE_TABLE_NAME = "T_CaseSearchResult";
        public static final Uri CASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/caseSearch");
        //标题
        public static final String CASE_TITLE = "title";
        //内容
        public static final String CASE_CONTENT = "subTitle";
        //浏览次数
        public static final String CASE_NUMBER = "count";
        //搜所的url
        public static final String CASE_URL = "url";
        //更新时间
        public static final String CASE_UPDATE_TIME = "updateTime";
        //总数
        public static final String CASE_TOTAL = "total";

    }

}
