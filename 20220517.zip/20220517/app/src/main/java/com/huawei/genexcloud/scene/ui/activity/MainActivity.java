package com.huawei.genexcloud.scene.ui.activity;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.ui.fragment.NationSceneFragment;

public class MainActivity extends BaseActivity {

    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showLoadingDialog();
        countUseInfo("a", "b", "c");

        initView();
    }

    private void initView() {
        container = find(R.id.container);

        switchTo(new NationSceneFragment());
    }

    @Override
    protected int getFragmentContainerId() {
        return R.id.container;
    }
}
