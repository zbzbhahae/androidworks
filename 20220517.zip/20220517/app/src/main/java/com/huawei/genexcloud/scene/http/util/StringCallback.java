package com.huawei.genexcloud.scene.http.util;

import androidx.annotation.NonNull;

public abstract class StringCallback extends GCCallback<String> {
    @Override
    public String parseNetworkResponse(@NonNull String response) throws Exception {
        return response;
    }
}
