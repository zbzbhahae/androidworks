package com.huawei.genexcloud.scene.http.util;

import android.text.TextUtils;


import com.huawei.genexcloud.scene.logger.GCLogger;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES加密算法
 */
public class AES256 {

    public static final String RANDYV = "1@huawei";

    // AES加密密钥 256 位
    private static final byte[] AESKEYSTRING_256 = {102, -107, -28, 127, -25, -111, -119, 15, -48, 121, -119, -59, -31,
            -24, -101, 31, 113, 29, 127, 67, -112, -8, 32, 93, -116, 67, -54, 111, 118, -43, 68, 41};

    private static AES256 instance256 = null;

    private AES256() {
    }

    public static synchronized AES256 getInstance_256() {
        if (null == instance256) {
            instance256 = new AES256();
        }

        return instance256;
    }

    /**
     * 将二进制转换成16进制
     *
     * @param buf
     * @return String
     */
    public String parseByte2HexStr(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    /**
     * 将16进制转换为二进制
     *
     * @param hexStr
     * @return byte[]
     */
    public byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }

        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }

    /**
     * 去掉后边的补全字符'\0'
     *
     * @param original
     * @return
     */
    private byte[] trimPadding(byte[] original) {
        int loc = -1;
        for (int j = 0; j < original.length; j++) {
            if (original[j] == '\0') {
                loc = j;
                break;
            }
        }
        if (loc == -1) {
            return original;
        }

        return copyOfRange(original, 0, loc);
    }

    /**
     * byte[]拷贝类
     *
     * @param original
     * @param from
     * @param to
     * @return copy
     */
    public byte[] copyOfRange(byte[] original, int from, int to) {
        int newLength = to - from;
        if (newLength < 0) {
            throw new IllegalArgumentException(from + " > " + to);
        }
        byte[] copy = new byte[newLength];
        System.arraycopy(original, from, copy, 0, Math.min(original.length - from, newLength));
        return copy;
    }

    public String encryptStr(String randIv, String code) {
        if (checkString(randIv, code)) {
            return "";
        }
        StringBuffer bufferIV = new StringBuffer(randIv);
        bufferIV.append(randIv);
        SecretKeySpec skeySpec = new SecretKeySpec(AESKEYSTRING_256, "AES");
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(bufferIV.toString().getBytes(StandardCharsets.UTF_8));
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
            byte[] encrypted = cipher.doFinal(code.getBytes(StandardCharsets.UTF_8));
            return parseByte2HexStr(encrypted);
        } catch (InvalidAlgorithmParameterException e) {
            GCLogger.error("error",
                    "[AES256]" + "encryptStr is InvalidAlgorithmParameterException:" + e.toString());
        } catch (Exception e) {
            GCLogger.error("error", "[AES256]" + "encryptStr is other Exception:" + e.toString());
        }
        return "";
    }

    public String decryptStr(String randIv, String code) {
        if (checkString(randIv, code)) {
            return "";
        }
        byte[] inputArray = parseHexStr2Byte(code);
        if (null == inputArray) {
            return "";
        }

        SecretKeySpec skeySpec = new SecretKeySpec(AESKEYSTRING_256, "AES");
        StringBuffer bufferIV = new StringBuffer(randIv);
        bufferIV.append(randIv);
        byte[] original = null;
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(bufferIV.toString().getBytes(StandardCharsets.UTF_8));
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            original = cipher.doFinal(inputArray);
            return new String(trimPadding(original), StandardCharsets.UTF_8);
        } catch (InvalidAlgorithmParameterException e) {
            GCLogger.error("error",
                    "[AES256]" + "decryptStr is InvalidAlgorithmParameterException:" + e.toString());
        } catch (Exception e) {
            GCLogger.error("error", "[AES256]" + "decryptStr is other Exception:" + e.toString());
        }
        return "";
    }

    private boolean checkString(String randIv, String strIn) {
        if (TextUtils.isEmpty(randIv) || TextUtils.isEmpty(strIn)) {
            GCLogger.error("error",
                    "[AES256]" + "IlegalInputParameters ----" + "randIv =" + randIv + " String = " + strIn);
            return true;
        }
        if (randIv.length() == 8) {
            return false;
        }
        return true;
    }
}
