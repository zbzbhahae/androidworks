package com.huawei.genexcloud.scene.http.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.huawei.genexcloud.scene.logger.GCLogger;

import java.util.ArrayList;
import java.util.List;

/***
 * @author yWX419033
 */
public class ParseJsonUtils {

    private static final Gson gson = new Gson();
    private static final GsonBuilder gsb = new GsonBuilder();

    // 传入json字符串，和相应的bean类，返回解析后的bean
    public static <T> T fromStringToObject(final String jsonString, Class<T> clazz) {
        try {
            return gsb.create().fromJson(jsonString, clazz);
        } catch (JsonParseException err) {
            GCLogger.error("error", err.toString());
            return null;
        }
    }

    // 使用Gson进行解析json数组对象
    public static <T> List<T> fromStringToList(final String jsonString, Class<T> clazz) {
        List<T> list = new ArrayList<T>();
        try {
            JsonArray arry = JsonParser.parseString(jsonString).getAsJsonArray();
            for (JsonElement jsonElement : arry) {
                list.add(gson.fromJson(jsonElement, clazz));
            }
        } catch (JsonParseException err) {
            GCLogger.error("error", err.toString());
        }
        return list;
    }

    // 使用Gson组装json
    public static <T> String toJson(Object src) {
        return gsb.create().toJson(src);
    }
}
