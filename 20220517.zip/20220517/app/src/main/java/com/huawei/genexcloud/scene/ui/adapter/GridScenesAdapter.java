package com.huawei.genexcloud.scene.ui.adapter;

/**
 * Created by zWX1094027 on 2021/9/26.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.bean.ResultBean;
import com.huawei.genexcloud.scene.bean.SceneIndicatorBean;
import com.huawei.genexcloud.scene.logger.GCLogger;
import com.huawei.genexcloud.scene.utils.DensityUtil;

import java.util.List;


public class GridScenesAdapter extends RecyclerView.Adapter<GridScenesAdapter.ViewHolder> {

    private List<ResultBean.ScenesBean> data;
    private String mNetType;


    public void setData(List<ResultBean.ScenesBean> data, String netType) {
        this.data = data;
        mNetType = netType;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_scene_grid, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        List<SceneIndicatorBean> relations = data.get(0).getIndicatorRelations();
        if (null == relations || 0 == relations.size()) {
            holder.contentTxt.setTextColor(0xFF666666);
            holder.contentTxt.setText("");
            return;
        }
        int index = position % (relations.size() + 1);
        int indexY = position / (relations.size() + 1);
        if (indexY == 0) {
            holder.contentTxt.setBackgroundColor(0xFFE0EDFA);
            // 表头

            // 分割线第一行的覆盖问题
            GridLayoutManager.LayoutParams params = (GridLayoutManager.LayoutParams) holder.itemView.getLayoutParams();
            params.topMargin = DensityUtil.dp2px(holder.itemView.getContext(), 1);
            if (index == 0) {
                params.leftMargin = DensityUtil.dp2px(holder.itemView.getContext(), 1);
                params.rightMargin = 0;
            } else if (index == (1 + relations.size())) {
                params.leftMargin = 0;
                params.rightMargin = DensityUtil.dp2px(holder.itemView.getContext(), 1);

            } else {
                params.leftMargin = 0;
                params.rightMargin = 0;
            }
            holder.itemView.setLayoutParams(params);

            if (index == 0) {
                // 表头第一个 显示场景名称
                holder.contentTxt.setText("场景名称");
            } else {
                String title = relations.get(index - 1).cnName;
                holder.contentTxt.setText(title);
            }
        } else {
            // 分割线第一行的覆盖问题
            GridLayoutManager.LayoutParams params = (GridLayoutManager.LayoutParams) holder.itemView.getLayoutParams();
            params.topMargin = 0;
            params.leftMargin = 0;
            params.rightMargin = 0;
            holder.itemView.setLayoutParams(params);

            ResultBean.ScenesBean bean = data.get(indexY - 1);
            if (0 == index) {
                holder.contentTxt.setTextColor(0xFF999999);
                holder.contentTxt.setText(bean.getScenesLocaleName());
            } else {
                holder.contentTxt.setTextColor(0xFF666666);
                String currentIndicatorName = relations.get(index - 1).cnName;
                boolean isPositive = true;
                boolean isPercentageValue = true;
                double currentIndicatorValue = -255;
                for (SceneIndicatorBean item : bean.getIndicators()) {
                    if (currentIndicatorName.equals(item.cnName)) {
                        currentIndicatorValue = item.value;
                        isPositive = item.isPositive;
                        isPercentageValue = "%".equals(item.unit);
                        break;
                    }
                }
                holder.contentTxt.setText(getValueText(currentIndicatorValue, isPercentageValue));
            }
        }




    }

    /**
     * 0-1的数字获得百分比形式
     *
     * @param value
     * @return
     */
    private String getValueText(String value, boolean isPercentageValue) {
        try {
            if(isPercentageValue) {
                double percentageValue = Double.parseDouble(value) * 100;
                return String.format("%.2f", percentageValue) + "%";
            } else {
                return String.format("%.2f", Double.parseDouble(value));
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        return value;
    }
    private String getValueText(double value, boolean isPercentageValue) {
        try {
            if (-255 == value) {
                return "-";
            }
            if(isPercentageValue) {
                return String.format("%.2f", value * 100) + "%";
            } else {
                return String.format("%.2f", value);
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        return "-";
    }

    @Override
    public int getItemCount() {
        if (null == data || data.size() == 0) {
            return 0;
        }
        int indicatorCount = null == data.get(0).getIndicatorRelations() ? 0 : data.get(0).getIndicatorRelations().size();
        // 没有指标关系 表示无指标数据
        if (indicatorCount == 0) {
            return 0;
        }
        // gridview item数量为 (场景数量 + 1(标题栏)) * (场景的指标数量 + 1(场景名称))
        return (data.size() + 1) * (indicatorCount + 1);
    }

    protected class ViewHolder extends RecyclerView.ViewHolder {
        private TextView contentTxt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            contentTxt = (TextView) itemView;
        }
    }
}