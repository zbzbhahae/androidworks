package com.huawei.genexcloud.scene.logger.logtype;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.huawei.genexcloud.scene.logger.GCLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * 文件log日志
 */
public class FileLog {

    private static final String FILE_PREFIX = "ZLLog_";
    private static final String FILE_FORMAT = ".log";

    public static void printFile(String tag, File targetDirectory, @Nullable String fileName, String headString,
                                 String msg) {

        fileName = (fileName == null) ? getFileName() : fileName;
        if (save(tag, targetDirectory, fileName, msg)) {
            Log.d(tag, headString + " save log success ! location is >>>" + targetDirectory.getAbsolutePath()
                    + File.separator + fileName);
        } else {
            Log.e(tag, headString + "save log fails !");
        }
    }

    private static boolean save(String tag, File dic, @NonNull String fileName, String msg) {

        File file = new File(dic, fileName);

        if (file != null && !file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                GCLogger.error("exception", e.toString());
            }
        }

        StringBuffer buffer = new StringBuffer();
        buffer.append("\n");
        buffer.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + ":" + tag + "==");
        buffer.append(msg);
        buffer.append("\n");
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true)));
            out.write(buffer.toString());

            return true;
        } catch (FileNotFoundException e) {
            GCLogger.error("exception", e.toString());
            return false;
        } catch (UnsupportedEncodingException e) {
            GCLogger.error("exception", e.toString());
            return false;
        } catch (IOException e) {
            GCLogger.error("exception", e.toString());
            return false;
        } catch (Exception e) {
            GCLogger.error("exception", e.toString());
            return false;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                GCLogger.error("exception", e.toString());
            }
        }
    }

    private static String getFileName() {
        Random random = new Random();
        return FILE_PREFIX + Long.toString(System.currentTimeMillis() + random.nextInt(10000)).substring(4)
                + FILE_FORMAT;
    }
}
