package com.huawei.genexcloud.scene.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.view.View;

import androidx.fragment.app.Fragment;

import com.huawei.genexcloud.scene.ui.activity.BaseActivity;

public class BaseFragment extends Fragment {

    /**
     * 从rootView上find控件
     *
     * @param id
     * @param <T>
     * @return
     */
    protected <T extends View> T find(int id) {
        if (null != getView()) {
            return (T) getView().findViewById(id);
        }
        return null;
    }

    public void switchTo(Fragment fragment) {
        Activity attachedAct = getActivity();
        if (null != attachedAct && attachedAct instanceof BaseActivity) {
            ((BaseActivity) attachedAct).switchTo(fragment);
        }
    }

    public void push(Fragment fragment) {
        Activity attachedAct = getActivity();
        if (null != attachedAct && attachedAct instanceof BaseActivity) {
            ((BaseActivity) attachedAct).push(fragment);
        }
    }

    public void showMsg(final String msg) {
        Activity attachedAct = getActivity();
        if (null != attachedAct && attachedAct instanceof BaseActivity) {
            ((BaseActivity) attachedAct).showMsg(msg);
        }
    }

    public Context getApplicationContext() {
        Activity attachedAct = getActivity();
        if (null != attachedAct) {
            return requireActivity().getApplicationContext();
        } else {
            return null;
        }
    }

    public void backPressed() {
        Activity attachedAct = getActivity();
        if (null != attachedAct) {
            attachedAct.onBackPressed();
        }
    }

    public void finishActivity() {
        Activity attachedAct = getActivity();
        if (null != attachedAct) {
            requireActivity().finish();
        }
    }

    public void showLoadingDialog() {
        Activity attachedAct = getActivity();
        if (null != attachedAct && attachedAct instanceof BaseActivity) {
            ((BaseActivity) attachedAct).showLoadingDialog();
        }
    }

    public void dismissLoadingDialog() {
        Activity attachedAct = getActivity();
        if (null != attachedAct && attachedAct instanceof BaseActivity) {
            ((BaseActivity) attachedAct).dismissLoadingDialog();
        }
    }

}
