package com.huawei.genexcloud.scene.http;

import com.huawei.genexcloud.scene.http.util.JavaHttpUtil;

public class QuerySceneDataImpl extends JavaHttpUtil {
    @Override
    protected String getMessageName() {
        return null;
    }
}
