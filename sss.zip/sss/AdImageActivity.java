package com.huawei.genexcloud.main;

import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import com.huawei.framework.ui.photoview.PhotoView;
import com.huawei.genexcloud.BaseActivity;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.framework.utils.Formatter;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * 展示首页广告中详细图片内容的activity
 */
public class AdImageActivity extends BaseActivity {

    private ViewPager pager;
    private SamplePagerAdapter adapter;

    // 广告图片内容
    private List<String> advlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_image);

        initView();
        initData();
        initIntentTrance();
    }

    @Override
    public void initView() {
        pager = findViewById(R.id.ad_image_pager);
        // 返回按钮
        findViewById(R.id.ad_image_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        adapter = new SamplePagerAdapter();
        pager.setAdapter(adapter);
    }

    @Override
    public void initData() {
        advlist = getIntent().getStringArrayListExtra("advlist");
        if(null == advlist || advlist.size() == 0) {
            // 没有图片内容 返回
            return;
        }
        // 构造图片地址
        List<String> imageUrls = new ArrayList<>();
        for(int i=0; i<advlist.size(); i++) {
            if(!TextUtils.isEmpty(advlist.get(i))) {
                imageUrls.add(Formatter.formatImagePath(advlist.get(i)));
            }
        }
        adapter.setData(imageUrls);
    }

    @Override
    public void initIntentTrance() {

    }


    static class SamplePagerAdapter extends PagerAdapter {

        private List<String> imageUrls;

        public void setData(List<String> imageUrls) {
            this.imageUrls = imageUrls;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return null == imageUrls? 0 : imageUrls.size();
        }

        @Override
        public View instantiateItem(ViewGroup container, int position) {
            PhotoView photoView = new PhotoView(container.getContext());
            photoView.setScaleType(ImageView.ScaleType.FIT_START); // 修改过photoview attacher的FIT_Start逻辑
            String url = imageUrls.get(position);

            Picasso.with(container.getContext()).load(url).into(photoView);
            container.addView(photoView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            return photoView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

    }
}
