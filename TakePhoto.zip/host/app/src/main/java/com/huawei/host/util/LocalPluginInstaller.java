package com.huawei.host.util;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.qihoo360.replugin.RePlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class LocalPluginInstaller {

    public static void install(Context context, String assetsFullName) {

        try {
            InputStream is = context.getAssets().open(assetsFullName);
            File f = new File(context.getFilesDir() + "/plugin.apk");

            if (f.exists()) {
                long fileSize = f.length();
                f.delete();
            }
            FileOutputStream fos = new FileOutputStream(f);
            f.createNewFile();
            byte[] buffer = new byte[1024];
            int length = -1;
            while ( (length = is.read(buffer)) != -1) {
                fos.write(buffer, 0, length);
            }
            fos.flush();
            fos.close();
            is.close();
            RePlugin.install(f.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean openPlugin(Context context, String packageName, String className, Bundle extras) {
        try {
            Intent in = new Intent();
            in.setComponent(RePlugin.createComponentName(packageName, className));
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (null != extras) {
                in.putExtras(extras);
            }
            return RePlugin.startActivity(context, in);
        } catch (Exception e) {
            return false;
        }
    }
}
