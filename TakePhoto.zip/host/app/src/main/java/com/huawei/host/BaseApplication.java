package com.huawei.host;

import android.app.Application;
import android.content.Context;

import com.qihoo360.replugin.RePlugin;
import com.qihoo360.replugin.RePluginApplication;

public class BaseApplication extends RePluginApplication {

    private static BaseApplication context;


    public static BaseApplication getAppContext() {
        return context;
    }


    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }
}
