package com.huawei.host.act;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.viewbinding.ViewBinding;

import com.huawei.host.R;
import com.huawei.host.databinding.ActivityMainBinding;
import com.huawei.host.util.LocalPluginInstaller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityMainBinding binding;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.photo.setOnClickListener(this);
        binding.plugin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == binding.photo) {
            if(checkCameraPermission()) {
                takePhoto();
            }
        } else if (v == binding.plugin) {
            LocalPluginInstaller.install(this, "plugin.apk");
            LocalPluginInstaller.openPlugin(this, "com.huawei.plugin", "com.huawei.plugin.act.MainActivity", null);
        }
    }

    private boolean checkCameraPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
            return false;
        }
        return true;
    }

    private void takePhoto() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            file = createImageFile();
            // Continue only if the File was successfully created
            if (file != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.huawei.host.fileprovider",
                        file);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, 2);
            }
        }
    }

    private File file;
    private File createImageFile() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = sdf.format(new Date());
        String fileName = time + ".jpg";
        String path = getFilesDir().getAbsolutePath();
        return new File(path + "/" + fileName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            Bitmap b = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (null != b) {
                binding.image.setImageBitmap(b);
            }
        }
    }
}
