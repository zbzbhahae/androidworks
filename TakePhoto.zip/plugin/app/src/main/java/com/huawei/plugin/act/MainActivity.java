package com.huawei.plugin.act;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.huawei.plugin.R;
import com.huawei.plugin.provider.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button photo;
    private ImageView image;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        photo = findViewById(R.id.photo);
        image = findViewById(R.id.image);
        photo.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == photo) {
            if(checkCameraPermission()) {
                takePhoto();
            }
        }
    }

    private boolean checkCameraPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
            return false;
        }
        return true;
    }

    private void takePhoto() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            file = createImageFile();
            // Continue only if the File was successfully created
            if (file != null) {
//                Uri photoURI = FileProvider.getUriForFile(this,
//                        "com.huawei.host.fileprovider",
//                        file);
                Uri photoURI = FileProvider.getUriForFile(this, "com.huawei.host.fileprovider", file);
                p("拍照uri ： " + photoURI.toString());
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, 2);
            }
        }
    }

    private File file;
    private File createImageFile() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = sdf.format(new Date());
        String fileName = time + ".jpg";
        String path = getFilesDir().getAbsolutePath();
        return new File(path + "/" + fileName);
    }

    private void p(String s) {
        Log.e("photo", s);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            p("拍照返回成功 : " + (null == data? "null":data.toString()));
            Bitmap b = BitmapFactory.decodeFile(file.getAbsolutePath());
            p("拍照文件存在吗？" + file.exists());
            if (null != b) {
                image.setImageBitmap(b);
            }
        }
    }
}
