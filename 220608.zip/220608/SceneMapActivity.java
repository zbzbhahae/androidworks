package com.huawei.genexcloud.main.sencemap;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.HeatMap;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.district.DistrictResult;
import com.baidu.mapapi.search.district.DistrictSearch;
import com.baidu.mapapi.search.district.DistrictSearchOption;
import com.baidu.mapapi.search.district.OnGetDistricSearchResultListener;
import com.huawei.framework.listener.MyOrientationListener;
import com.huawei.framework.log.GCLogger;
import com.huawei.framework.utils.AppUtil;
import com.huawei.framework.utils.SystemUIUtil;
import com.huawei.genexcloud.BaseActivity;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.bean.QueryAreaSiteBean;
import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.databinding.ActivitySceneMapBinding;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.main.sencemap.http.QueryProvinceSiteInfoImpl;
import com.huawei.genexcloud.main.sencemap.http.QuerySiteInfoImpl;
import com.huawei.genexcloud.main.sencemap.util.MapUtil;
import com.huawei.genexcloud.main.sencemap.util.SiteUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class SceneMapActivity extends BaseActivity implements View.OnClickListener {

    private ActivitySceneMapBinding binding;
    // 是否有npo权限
    private boolean hasNopLimit = false;
    // 我也不知道是啥
    private boolean hasDiffLimit = false;
    // 也不知道是啥
    private int openTag = -1;

    // 运营商网络类型
    private final String TYPE_4G = "4G";
    private final String TYPE_5G = "5G";
    private String mNetType = TYPE_4G;

    private BaiduMap mBaiduMap;
    // 用于获取手机陀螺仪旋转角度，显示地图上自己的定位信息
    private MyOrientationListener myOrientationListener;

    // 用于访问网络接口的参数 省份 城市
    private String province, city;
    // 运营商
    private String operator = "CNTC";
    // 网络类型
    private String netType = "4G";


    // 地图移动状态标记
    private boolean isMapMove = false;
    // 是否正在绘制marker
    private boolean isDrawingMarker = false;

    private List<SiteInfo> siteQueryResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 处理传入参数
        initIntentTrance();
        // 设置窗口无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        SystemUIUtil.fullScreenNotStatuBar(this);

        binding = ActivitySceneMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initView();
        initData();
    }

    private void polygon() {
        try {
            InputStream is = getAssets().open("data/shanxi.txt");
            byte[] buffer = new byte[1024];
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int length = -1;
            while ((length = is.read(buffer)) != -1) {
                baos.write(buffer, 0, length);
            }
            String content = new String(baos.toByteArray());
            JSONObject json = new JSONObject(content);
            JSONArray features = json.optJSONArray("features");
            JSONObject ff = features.optJSONObject(0);
            JSONObject geo = ff.optJSONObject("geometry");
            JSONArray coor = geo.optJSONArray("coordinates");
            List<List<LatLng>> data = new ArrayList<>();
            for (int i=0; i<coor.length(); i++) {
                JSONArray itemA = coor.optJSONArray(i);
                JSONArray a = itemA.optJSONArray(0);
                List<LatLng> itemList = new ArrayList<>();
                for (int j=0; j<a.length(); j++) {
                    JSONArray item = a.optJSONArray(j);
                    double lng = item.optDouble(0);
                    double lat = item.optDouble(1);
                    itemList.add(new LatLng(lat, lng));
                }
                data.add(itemList);
            }

            for (List<LatLng> polyline : data) {
                OverlayOptions ooPolyline = new PolylineOptions().width(1).points(polyline).dottedLine(true).color(0x6600FF00);
                mBaiduMap.addOverlay(ooPolyline);
                OverlayOptions ooPolygon = new PolygonOptions().points(polyline).stroke(new Stroke(0, 0x6600FF88))
                        .fillColor(0xAAFFFF00);
                mBaiduMap.addOverlay(ooPolygon);
            }
        } catch (Exception e) {

        }
    }

    /**
     * 处理传入的intent的数据
     */
    public void initIntentTrance() {
        Intent intent = getIntent();
        if (intent != null) {
            //跨进程传入的数据
            hasNopLimit = intent.getBooleanExtra("hasNpo", false);//通过6 控制  或npo
            hasDiffLimit = intent.getBooleanExtra("hasDiff", false);  //通过1 控制
            openTag = intent.getIntExtra("openTag", -1);
        }
    }

    @Override
    public void initView() {
        MapUtil.initBaiduMap(binding.baiduMap, onMapLoadedCallback,
                onMapStatusChangeListener, onMapClickListener, onMarkerClickListener);
        mBaiduMap = binding.baiduMap.getMap();
        binding.operatorTypeImage.setOnClickListener(this);
        binding.locationButton.setOnClickListener(this);
    }

    @Override
    public void initData() {
        // 监听手机陀螺仪方向
        initOrientationListener();
        // 绘制marker的子线程
        initBackgroundHandler();
    }

    /**
     * 陀螺仪获取手机方向数据
     */
    private void initOrientationListener() {
        myOrientationListener = new MyOrientationListener(getApplicationContext());
        myOrientationListener.setOnOrientationListener(direction -> {
            if (myLocationData != null) {
                MyLocationData locData = new MyLocationData.Builder().accuracy(myLocationData.accuracy)
                        .direction(direction).latitude(myLocationData.latitude)
                        .longitude(myLocationData.longitude).build();
                mBaiduMap.setMyLocationData(locData);
            }
        });
        myOrientationListener.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        binding.baiduMap.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        binding.baiduMap.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        myOrientationListener.stop();
        binding.baiduMap.getMap().setMyLocationEnabled(false);
        // 停止定位
        MapUtil.stopLocation(myLocationListener);
        binding.baiduMap.onDestroy();
    }

    /**
     * 点击事件
     * @param v
     */
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.operatorTypeImage) {
            // 点击了4G 5G选项
            if (TYPE_4G.equals(mNetType)) {
                mNetType = TYPE_5G;
                binding.operatorTypeImage.setImageResource(R.drawable.icon_5g);
            } else {
                mNetType = TYPE_4G;
                binding.operatorTypeImage.setImageResource(R.drawable.icon_4g);
            }
            // 网络类型改变 去更新数据或界面
            onNetTypeChanged();
//        } else if (v == binding.indoorLayout) {

        } else if (v == binding.locationButton) {
            // 点击定位按钮
            mBaiduMap.setMyLocationData(myLocationData);
        }
    }

    /**
     * 只需要进入时定位到当前位置一次
     */
    private boolean hasMovedToMyPosition = false;
    // 存储当前位置信息
    private MyLocationData myLocationData = null;
    /** 百度定位信息回调 **/
    private BDAbstractLocationListener myLocationListener = new BDAbstractLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation bdLocation) {
            // 接收到定位信息
            if (null == bdLocation || null == binding || null == binding.baiduMap) {
                return;
            }
            int locType = bdLocation.getLocType();
            if (locType == BDLocation.TypeCriteriaException || locType == BDLocation.TypeNone
                    || bdLocation.getLatitude() == 4.9E-324 || bdLocation.getLongitude() == 4.9E-324) {
                // 无效的定位信息
                return;
            }

            myLocationData = new MyLocationData.Builder()
                    .accuracy(bdLocation.getRadius())
                    .direction(bdLocation.getDirection())
                    .latitude(bdLocation.getLatitude()).longitude(bdLocation.getLongitude())
                    .build();


            GCLogger.error("map", "接收到定位消息: 位置: " + (province + "  " + city) + "  direction:" + bdLocation.getDirection() + "  " + bdLocation);
            if (hasMovedToMyPosition && null != myLocationData) {
                // 已经自动移动到自身位置过 只更新位置信息
                return;
            }
            mBaiduMap.setMyLocationData(myLocationData);
            MapUtil.setMapZoomLevel(mBaiduMap, MapUtil.DEFAULT_ZOOM_LEVEL);

            String province = bdLocation.getProvince();
            String city = bdLocation.getCity();
            if (!TextUtils.isEmpty(province) && !TextUtils.isEmpty(city)
                    && TextUtils.isEmpty(SceneMapActivity.this.province)
                    && TextUtils.isEmpty(SceneMapActivity.this.city)) {
                // 获取到定位的省份城市信息 且没有选择新的省份城市信息
                SceneMapActivity.this.province = province;
                SceneMapActivity.this.city = city;
                // 去获取站点
                getSiteInfo(province, city);
            }

            // 拿到定位信息后 可以点击定位按钮
            binding.locationButton.setVisibility(View.VISIBLE);
            hasMovedToMyPosition = true;
        }
    };
    /** 地图加载完毕事件 **/
    private BaiduMap.OnMapLoadedCallback onMapLoadedCallback = new BaiduMap.OnMapLoadedCallback() {
        @Override
        public void onMapLoaded() {

            // 地图加载完毕 开启定位
            MapUtil.startLocation(SceneMapActivity.this, myLocationListener);

        }
    };
    /** 地图状态改变事件 **/
    private BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener = new BaiduMap.OnMapStatusChangeListener() {
        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus) {
            isMapMove = true;
        }

        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus, int i) {
            isMapMove = true;
        }

        @Override
        public void onMapStatusChange(MapStatus mapStatus) {

        }

        @Override
        public void onMapStatusChangeFinish(MapStatus mapStatus) {
            isMapMove = false;
            getSiteInfo(province, city);
            sendDrawSiteMessage(siteQueryResult);
            polygon();

        }
    };
    /** 地图点击事件 **/
    private BaiduMap.OnMapClickListener onMapClickListener = new BaiduMap.OnMapClickListener() {
        @Override
        public void onMapClick(LatLng latLng) {

        }

        @Override
        public void onMapPoiClick(MapPoi mapPoi) {

        }
    };
    /** 地图上marker点击事件 **/
    private BaiduMap.OnMarkerClickListener onMarkerClickListener = new BaiduMap.OnMarkerClickListener() {
        @Override
        public boolean onMarkerClick(Marker marker) {
            return false;
        }
    };

    /**
     * 网络类型改变 由4G->5G 或者 5G->4G 改变后会调用此方法
     */
    private void onNetTypeChanged() {
        DistrictSearch districtSearch = DistrictSearch.newInstance();
        DistrictSearchOption option = new DistrictSearchOption();
        option.mCityName = "北京市";
        option.mDistrictName = "海淀";
        districtSearch.setOnDistrictSearchListener(new OnGetDistricSearchResultListener() {
            @Override
            public void onGetDistrictResult(DistrictResult districtResult) {
                mBaiduMap.clear();
                if (districtResult == null) {
                    return;
                }
                if (districtResult.error == SearchResult.ERRORNO.NO_ERROR) {
                    List<List<LatLng>> polyLines = districtResult.getPolylines();
                    if (polyLines == null) {
                        return;
                    }
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    for (List<LatLng> polyline : polyLines) {
                        OverlayOptions ooPolyline = new PolylineOptions().width(10).points(polyline).dottedLine(true).color(0xAA00FF00);
                        mBaiduMap.addOverlay(ooPolyline);
                        OverlayOptions ooPolygon = new PolygonOptions().points(polyline).stroke(new Stroke(5, 0xAA00FF88))
                                .fillColor(0xAAFFFF00);
                        mBaiduMap.addOverlay(ooPolygon);
                        for (LatLng latLng : polyline) {
                            builder.include(latLng);
                        }
                    }
                    mBaiduMap.setMapStatus(MapStatusUpdateFactory.newLatLngBounds(builder.build()));
                }
            }
        });
        districtSearch.searchDistrict(option);
    }


    /**
     * 获取站点信息
     * @param province
     * @param city
     */
    private void getSiteInfo(String province, String city) {
        if (TextUtils.isEmpty(province) || TextUtils.isEmpty(city)) {
            GCLogger.error("error", "省份或城市信息为空");
            return;
        }
        LatLngBounds mapBounds = mBaiduMap.getMapStatus().bound;
        double leftTopLat = mapBounds.northeast.latitude;
        double leftTopLng = mapBounds.southwest.longitude;
        double rightBottomLat = mapBounds.southwest.latitude;
        double rightBottomLng = mapBounds.northeast.longitude;

        QueryAreaSiteBean queryBean = new QueryAreaSiteBean();
        queryBean.setLUpLat(leftTopLat);
        queryBean.setLUpLng(leftTopLng);
        queryBean.setRDnLat(rightBottomLat);
        queryBean.setRDnLng(rightBottomLng);
        queryBean.setProvince(province);
        queryBean.setCity(city);
        queryBean.setNetOper(operator);
        queryBean.setNetWorkType(netType);
        QuerySiteInfoImpl.getInstance().querySiteInfo(queryBean, new QuerySiteInfoImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                int a = 1;
                int c = a++;
            }

            @Override
            public void onResponse(List<SiteInfo> response) {
                siteQueryResult = response;
                sendDrawSiteMessage(response);
            }
        });
    }

    /**
     * 获取省份热力图信息
     */
    private void getHeatMapInfo(String province, String operator, String netType) {
        QueryProvinceSiteInfoImpl.getInstance().querySiteInfo(province, operator, netType, new QueryProvinceSiteInfoImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                GCLogger.error("error", "热力图获取失败:" + e.message);
            }

            @Override
            public void onResponse(List<LatLng> response) {
                if (null == response || response.isEmpty()) {
                    return;
                }

            }
        });

    }




    private HandlerThread handlerThread = new HandlerThread("background");
    private BackgroundHandler handler;
    private HeatMap heatMap;
    private final int MESSAGE_DRAW_SITE = 1, MESSAGE_DRAW_POLYGON = 2, MESSAGE_DRAW_HEATMAP = 3;
    final class BackgroundHandler extends Handler {
        public BackgroundHandler(Looper looper) {
            super(looper);
        }
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case MESSAGE_DRAW_SITE:
                    // 绘制站点
                    List<SiteInfo> siteList = (List<SiteInfo>) msg.obj;
                    drawSite(siteList);
                    break;
                case MESSAGE_DRAW_POLYGON:
                    // 绘制多边形
                    break;
                case MESSAGE_DRAW_HEATMAP:
                    // 绘制热力图

                    break;
            }
        }
    }

    /**
     * 发送后台绘制marker信息
     * @param siteList
     */
    private void sendDrawSiteMessage(List<SiteInfo> siteList) {
        if (null == siteList || siteList.isEmpty()) {
            return;
        }
        Message message = handler.obtainMessage();
        message.what = MESSAGE_DRAW_SITE;
        message.obj = siteList;
        handler.sendMessage(message);
    }

    /**
     * 发送后台绘制热力图信息
     * @param siteList
     */
    private void sendDrawHeatMapMessage(List<LatLng> siteList) {
        if (null == siteList || siteList.isEmpty()) {
            return;
        }
        Message message = handler.obtainMessage();
        message.what = MESSAGE_DRAW_HEATMAP;
        message.obj = siteList;
        handler.sendMessage(message);
    }

    private void initBackgroundHandler() {
        handlerThread.start();
        handler = new BackgroundHandler(handlerThread.getLooper());
    }



    /**
     * 过滤绘制站点
     * @param siteInfos
     */
    private void drawSite(List<SiteInfo> siteInfos) {
        mBaiduMap.clear();
        if (null == siteInfos || siteInfos.isEmpty()) {
            return;
        }
        float zoomLevel = mBaiduMap.getMapStatus().zoom;
        // 对站点进行过滤
        List<SiteInfo> filteredSites = SiteUtils.filterSites2(siteInfos, zoomLevel);
        long startT = System.currentTimeMillis();
        List<OverlayOptions> markerOptions = new ArrayList<>();
        for (SiteInfo siteInfo : filteredSites) {
            MarkerOptions markerOption;
            Marker marker;
            markerOption = SiteUtils.getSiteMarkerOption(SceneMapActivity.this, mBaiduMap, siteInfo);

            Bundle bundle = new Bundle();
            bundle.putString("markerType", "incMarker");
            bundle.putSerializable("bean", siteInfo);
            markerOption.extraInfo(bundle);
            if (isMapMove) {
                isDrawingMarker = false;
                return;
            }
            markerOptions.add(markerOption);
        }
        mBaiduMap.addOverlays(markerOptions);
    }

    /**
     * 绘制热力图
     * @param siteList
     */
    private void drawHeatMap(List<LatLng> siteList) {

    }

}
