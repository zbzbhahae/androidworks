package com.huawei.genexcloud.netwoekstructure.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.netwoekstructure.R;

import java.util.List;

/**
 * 城市 三个达标率的图表
 */
public class CityAchieveAdapter extends RecyclerView.Adapter<CityAchieveAdapter.ViewHolder> {

    private List<Object> data;

    public void setData(List<Object> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_city_achieve, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        if (0 == position) {
            // 表头
            h.itemView.setBackgroundResource(R.drawable.shape_blue_solid_stroke);
            h.cityName.setText("城市");
            h.totalAchieve.setText("总体达标率");
            h.planAchieve.setText("规划达标率");
            h.performanceAchieve.setText("性能达标率");
        } else {
            h.itemView.setBackground(null);
            h.cityName.setText("西安");
            h.totalAchieve.setText("56.34%");
            h.planAchieve.setText("56.34%");
            h.performanceAchieve.setText("56.34%");
        }
    }

    @Override
    public int getItemCount() {
        if (null == data || data.size() == 0) {
            return 0;
        }
        // 包含表头
        return data.size() + 1;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView cityName, totalAchieve, planAchieve, performanceAchieve;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cityName = itemView.findViewById(R.id.item_achieve_city);
            totalAchieve = itemView.findViewById(R.id.item_achieve_total);
            planAchieve = itemView.findViewById(R.id.item_achieve_plan);
            performanceAchieve = itemView.findViewById(R.id.item_achieve_performance);
        }
    }
}
