package com.huawei.genexcloud.netwoekstructure.activity.controller;

import android.content.Context;
import android.content.Intent;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.huawei.genexcloud.netwoekstructure.R;
import com.huawei.genexcloud.netwoekstructure.activity.ImageDetailActivity;
import com.huawei.genexcloud.netwoekstructure.adapter.CityAchieveAdapter;
import com.huawei.genexcloud.netwoekstructure.adapter.ImagePagerAdapter;
import com.huawei.genexcloud.netwoekstructure.bean.NameValueData;
import com.huawei.genexcloud.netwoekstructure.bean.ProvinceBean;
import com.huawei.genexcloud.netwoekstructure.utils.AppUtil;
import com.huawei.genexcloud.netwoekstructure.utils.PopupWindowUtils;
import com.huawei.genexcloud.netwoekstructure.widget.HorizontalRoundListBar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 全省视角下的 场景部分
 */
public class ProvinceSceneController extends BaseController implements View.OnClickListener {

    private TextView descTv; // 口碑场景概述
    private View descLayout; // 口碑场景概述的layout

    private RecyclerView achieveTable; // 达标率图表
    private CityAchieveAdapter achieveAdapter; // 达标率适配器

    private RadioButton achieveRb, indicatorRb; // 场景达标率 和 场景指标 数据展示切换按钮
    // 总体、规划和性能达标率
    private RadioButton totalAchieveRb, planAchieveRb, performanceRb;
    private RadioGroup achieveGroup; // 达标率 RadioButton的外层RadioGroup

    // 当前选择的场景显示
    private TextView sceneTv;
    private View sceneChooseLayout; // 选择场景点击使用

    private TextView indicatorSelectionTv; // 场景指标下的 场景具体指标显示
    private View indicatorSelectionLayout; // 场景指标下的 具体指标layout 用于点击选择指标

    private RecyclerView sceneList; // 显示场景主数据的list

    private TextView expandTv; // 展开全部 的文字显示
    private ImageView expandIv; // 箭头向下向上
    private View expandLayout; // 展开全部的layout

    private String selectedIndicatorName; // 选中的指标名称
    private ProvinceBean dataBean;
    private OnScenePageStateChangedListener listener;

    private LineChart lineChart;

    public ProvinceSceneController(Context context) {
        super(context);
    }

    @Override
    protected View getRootView(Context context) {
        return LayoutInflater.from(context).inflate(R.layout.controller_province_scene, null, false);
    }

    @Override
    protected void initViews(Context context) {
        descTv = find(R.id.province_scene_desc);
        descLayout = find(R.id.province_scene_desc_layout);

        achieveTable = find(R.id.province_scene_achieve_table);

        achieveRb = find(R.id.province_scene_scene_achieve);
        indicatorRb = find(R.id.province_scene_scene_indicator);

        totalAchieveRb = find(R.id.province_scene_total_achieve);
        planAchieveRb = find(R.id.province_scene_plan_achieve);
        performanceRb = find(R.id.province_scene_performance_achieve);
        achieveGroup = find(R.id.province_scene_achieve_group);

        sceneTv = find(R.id.province_scene_choose_text);
        sceneChooseLayout = find(R.id.province_scene_choose_layout);

        indicatorSelectionTv = find(R.id.province_scene_indicator_choose);
        indicatorSelectionLayout = find(R.id.province_scene_indicator_layout);

        sceneList = find(R.id.province_scene_indicator_list);

        expandTv = find(R.id.province_scene_expand_text);
        expandIv = find(R.id.province_scene_expand_image);
        expandLayout = find(R.id.province_scene_expand_layout);

        lineChart = find(R.id.lineChart);
        List<Entry> values = new ArrayList<>();
        for (int i=0; i<20; i+=2) {
            values.add(new Entry(i, (float) (Math.random() * 10)));
        }
        LineDataSet set1 = new LineDataSet(values, "set1");
        set1.disableDashedLine();
        set1.setColor(0xFFFF0000);
        set1.setCircleColor(0xFF000000);
        set1.setCircleHoleColor(0xFFF0F0FF);
        set1.setCircleRadius(5);
        set1.setDrawCircles(true);
        set1.setDrawCircleHole(true);
        set1.setDrawValues(true);
        set1.setDrawFilled(true);
        set1.setLabel(null);
        List<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(set1);
        LineData data = new LineData(dataSets);
        lineChart.setData(data);
        lineChart.setClipToOutline(true);
        lineChart.setDescription(null);
        lineChart.setDrawGridBackground(false);
        lineChart.getAxisLeft().setDrawGridLines(false);
        lineChart.getAxisRight().setEnabled(false);
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        lineChart.setScaleYEnabled(false);
        lineChart.getXAxis().setDrawGridLines(false);
        lineChart.getXAxis().setAvoidFirstLastClipping(true);
        lineChart.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "第" + (int)value + "月";
            }
        });
        lineChart.getLegend().setEnabled(false);

    }

    @Override
    protected void initData() {
        sceneChooseLayout.setOnClickListener(this);
        indicatorSelectionLayout.setOnClickListener(this);

        achieveTable.setLayoutManager(new LinearLayoutManager(weakContext.get()));
        achieveAdapter = new CityAchieveAdapter();
        achieveAdapter.setData(Arrays.asList(new Object(), new Object()));
        achieveTable.setAdapter(achieveAdapter);

        dataBean = new ProvinceBean();
        dataBean.setIndicatorNameList(Arrays.asList("MR覆盖率", "5G倒流比", "CQI优良率"));
//        indicatorLayout.setOnClickListener(this);
//
//        // 解决viewpager滑动冲突
//        imagePager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            @Override
//            public void onPageScrolled(int i, float v, int i1) {
//            }
//
//            @Override
//            public void onPageSelected(int i) {
//                if (null != dataBean && null != dataBean.getMapList()) {
//                    List<ProvinceBean.SceneMap> mapList = dataBean.getMapList();
//                    if (i >= 0 && mapList.size() > 0 && i < mapList.size()) {
//                        ProvinceBean.SceneMap mapData = mapList.get(i);
//                        if (!TextUtils.isEmpty(mapData.getCityName())) {
//                            distributionSubTitleTxt.setText(mapData.getCityName() + "口碑场景分布");
//                        } else {
//                            distributionSubTitleTxt.setText("口碑场景分布");
//                        }
//                    }
//                }
//                if (null != listener) {
//                    listener.onPageScrollStateChanged(ViewPager.SCROLL_STATE_IDLE);
//                }
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int i) {
//                if (null != listener) {
//                    listener.onPageScrollStateChanged(i);
//                }
//            }
//        });
//
//        // 点击图片 去图片详情界面
//        adapter.setOnImageClickListener(new ImagePagerAdapter.OnImageClickListener() {
//            @Override
//            public void onClick(ImageView view, String url) {
//                if (AppUtil.isFastDoubleClick()) {
//                    return;
//                }
//                if (!TextUtils.isEmpty(url) && isContextAvailable()) {
//                    Intent i = new Intent(weakContext.get(), ImageDetailActivity.class);
//                    i.putExtra("imageUrl", url);
//                    weakContext.get().startActivity(i);
//                }
//            }
//        });
//
//        expandLayout.setOnClickListener(this);
    }

    public void setScenePageListener(OnScenePageStateChangedListener listener) {
        this.listener = listener;
    }

    /**
     * 初始化view状态
     */
    @Override
    public void initViewState() {
//        mainTitleTxt.setVisibility(View.GONE);
//
//        noImageTxt.setVisibility(View.GONE);
//        distributionImageLayout.setVisibility(View.GONE);
//        distributionTitleLayout.setVisibility(View.GONE);
//
//        noSceneTxt.setVisibility(View.GONE);
//        indicatorTxt.setText("");
//        indicatorLayout.setVisibility(View.GONE);
//        indicatorTitleLayout.setVisibility(View.GONE);
//        indicatorHintLayout.setVisibility(View.GONE);
//        chartView.setVisibility(View.GONE);
//        expandLayout.setVisibility(View.GONE);
//        noSceneTxt.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.province_scene_indicator_layout:
                showChooseIndicatorPopWindow();
                break;
            case R.id.province_scene_expand_layout:
                onExpandLayoutClicked();
                break;
        }
    }

    /**
     * 点击了展开全部或者收起全部后调用的方法
     */
    private void onExpandLayoutClicked() {
//        chartView.setShowAll(!chartView.getShowAll());
//        if (chartView.getShowAll()) {
//            expandTxt.setText("收起全部");
//            expandIv.setImageResource(R.drawable.icon_arrow_up);
//        } else {
//            expandTxt.setText("展开全部");
//            expandIv.setImageResource(R.drawable.icon_arrow_down);
//        }
    }

    /**
     * 选择指标
     */
    private void showChooseIndicatorPopWindow() {
        if (!isContextAvailable()) {
            return;
        }
        if (null == dataBean || null == dataBean.getIndicatorNameList() || 1 >= dataBean.getIndicatorNameList().size()) {
            return; // 无可用指标
        }
        int index = -1;
        // 寻找当前选中的指标名称在列表中的位置
        index = dataBean.getIndicatorNameList().indexOf(selectedIndicatorName);
        PopupWindowUtils.createListPopWindow(weakContext.get(), dataBean.getIndicatorNameList(), index,
                indicatorSelectionLayout, new PopupWindowUtils.OnListItemSelected() {
                    @Override
                    public void onDismiss() {
                    }

                    @Override
                    public void onSelected(String content, int position) {
                        if (TextUtils.equals(selectedIndicatorName, content)) {
                            return;
                        } else {
                            selectedIndicatorName = content;
                            setSceneListData(dataBean);
                        }
                    }
                });
    }

    @Override
    public void setNoData(String message) {
//        if (TextUtils.isEmpty(message)) {
//            noSceneTxt.setVisibility(View.GONE);
//            noImageTxt.setVisibility(View.GONE);
//
//            mainTitleTxt.setVisibility(View.GONE);
//            distributionImageLayout.setVisibility(View.GONE);
//            distributionTitleLayout.setVisibility(View.GONE);
//
//            indicatorTxt.setText("");
//            indicatorLayout.setVisibility(View.GONE);
//            indicatorTitleLayout.setVisibility(View.GONE);
//            indicatorHintLayout.setVisibility(View.GONE);
//            chartView.setVisibility(View.GONE);
//            expandLayout.setVisibility(View.GONE);
//            noSceneTxt.setVisibility(View.GONE);
//        } else {
//            noSceneTxt.setVisibility(View.VISIBLE);
//            noImageTxt.setVisibility(View.VISIBLE);
//            noSceneTxt.setText(message);
//            noImageTxt.setText(message);
//
//            mainTitleTxt.setVisibility(View.VISIBLE);
//            distributionImageLayout.setVisibility(View.GONE);
//            distributionTitleLayout.setVisibility(View.GONE);
//
//            indicatorTxt.setText("");
//            indicatorLayout.setVisibility(View.GONE);
//            indicatorTitleLayout.setVisibility(View.GONE);
//            indicatorHintLayout.setVisibility(View.GONE);
//            chartView.setVisibility(View.GONE);
//            expandLayout.setVisibility(View.GONE);
//            noSceneTxt.setVisibility(View.GONE);
//        }
//        adapter.setData(null);
//        chartView.setData(null);
    }

    /**
     * 设置数据
     *
     * @param data
     */
    public void setData(ProvinceBean data) {
//        dataBean = data;
//        if (null == data) {
//            setNoData(null);
//            return;
//        }
//
//        // 设置口碑场景图片信息
//        setDistributionData(data);
//        setSceneListData(data);
//        // 是否显示口碑场景 主标题
//        if ((null != data.getMapList() && data.getMapList().size() > 0)
//                || (null != data.getIndicatorNameList() && data.getIndicatorNameList().size() > 0)) {
//            // 显示
//            mainTitleTxt.setVisibility(View.VISIBLE);
//        } else {
//            mainTitleTxt.setVisibility(View.GONE);
//        }
    }

    /**
     * 设置场景分布地图数据
     *
     * @param data
     */
    private void setDistributionData(ProvinceBean data) {
//        if (null == data || null == data.getMapList() || 0 == data.getMapList().size()) {
//            noImageTxt.setVisibility(View.GONE);
//            distributionImageLayout.setVisibility(View.GONE);
//            distributionTitleLayout.setVisibility(View.GONE);
//        } else {
//            noImageTxt.setVisibility(View.GONE);
//            distributionImageLayout.setVisibility(View.VISIBLE);
//            adapter.setData(data.getMapList());
//            distributionTitleLayout.setVisibility(View.VISIBLE);
//            distributionSubTitleTxt.setText(data.getMapList().get(0).getCityName() + "口碑场景分布");
//        }
    }

    /**
     * 将数据排序，组装设置到图表上
     *
     * @param data
     */
    private void setSceneListData(ProvinceBean data) {
//        if (null == data) {
//            setNoData(null);
//            return;
//        }
//        if (null == data.getScenario() || 0 == data.getScenario().size()
//                || null == data.getIndicatorNameList() || 0 == data.getIndicatorNameList().size()) { // 没有场景数据
//            indicatorTxt.setText("");
//            indicatorLayout.setVisibility(View.GONE);
//            indicatorTitleLayout.setVisibility(View.GONE);
//            indicatorHintLayout.setVisibility(View.GONE);
//            chartView.setVisibility(View.GONE);
//            expandLayout.setVisibility(View.GONE);
//            noSceneTxt.setVisibility(View.GONE);
//        } else { // 有场景信息
//            if (TextUtils.isEmpty(selectedIndicatorName) || !data.getIndicatorNameList().contains(selectedIndicatorName)) {
//                selectedIndicatorName = data.getIndicatorNameList().get(0);
//            }
//            List<NameValueData> chartData = data.getIndicatorDataWithIndicatorName(selectedIndicatorName);
//            if (null == chartData || 0 == chartData.size()) { // 竟然没有数据？ 不可能
//                indicatorTxt.setText("");
//                indicatorLayout.setVisibility(View.GONE);
//                indicatorTitleLayout.setVisibility(View.GONE);
//                indicatorHintLayout.setVisibility(View.GONE);
//                chartView.setVisibility(View.GONE);
//                expandLayout.setVisibility(View.GONE);
//                noSceneTxt.setVisibility(View.GONE);
//            } else {
//                indicatorTxt.setText(selectedIndicatorName);
//                List<String> nameList = new ArrayList<>();
//                List<Double> valueLilst = new ArrayList<>();
//                for (int i = 0; i < chartData.size(); i++) {
//                    nameList.add(chartData.get(i).getName());
//                    valueLilst.add(chartData.get(i).getValue());
//                }
//                chartView.setData(nameList, valueLilst, data.isNeedReverseChart(selectedIndicatorName),
//                        data.isPercetageValue(selectedIndicatorName));
//                indicatorLayout.setVisibility(View.VISIBLE);
//                indicatorTitleLayout.setVisibility(View.VISIBLE);
//                indicatorHintLayout.setVisibility(View.VISIBLE);
//                chartView.setVisibility(View.VISIBLE);
//                noSceneTxt.setVisibility(View.GONE);
//                if (nameList.size() > 10) {
//                    expandLayout.setVisibility(View.VISIBLE);
//                } else {
//                    expandLayout.setVisibility(View.GONE);
//                }
//            }
//
//        }
    }

    /**
     * 解决refreshLayout与viewpager的滑动冲突
     */
    public interface OnScenePageStateChangedListener {
        void onPageScrollStateChanged(int state);
    }

}
