package com.huawei.genexcloud.fragment;

import static com.huawei.genexcloud.util.BdMapGridParamUtils.OutDirection.NAN;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.HeatMap;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.baidu.mapapi.navi.BaiduMapAppNotSupportNaviException;
import com.baidu.mapapi.navi.BaiduMapNavigation;
import com.baidu.mapapi.navi.NaviParaOption;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.district.DistrictResult;
import com.baidu.mapapi.search.district.DistrictSearch;
import com.baidu.mapapi.search.district.DistrictSearchOption;
import com.baidu.mapapi.search.district.OnGetDistricSearchResultListener;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.sug.SuggestionResult;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.base.BaseFragment;
import com.huawei.genexcloud.bean.CityGrideDataBean;
import com.huawei.genexcloud.bean.CityGrideSiteResp;
import com.huawei.genexcloud.bean.CityInfo;
import com.huawei.genexcloud.bean.ExperienceSiteInfo;
import com.huawei.genexcloud.bean.Gps;
import com.huawei.genexcloud.bean.GpsBounds;
import com.huawei.genexcloud.bean.QueryAreaResultBean;
import com.huawei.genexcloud.bean.QueryAreaSiteBean;
import com.huawei.genexcloud.bean.ReqMapDataBean;
import com.huawei.genexcloud.bean.SearchSiteBean;
import com.huawei.genexcloud.bean.SenseMapControllerBean;
import com.huawei.genexcloud.bean.SiteBaseBean;
import com.huawei.genexcloud.bean.SiteInfo;
import com.huawei.genexcloud.bean.TypeEnum;
import com.huawei.genexcloud.database.AppDatabase;
import com.huawei.genexcloud.database.HeatMapData;
import com.huawei.genexcloud.database.HeatMapDataDao;
import com.huawei.genexcloud.databinding.PageHomeBinding;
import com.huawei.genexcloud.dialog.CannotComplainDialog;
import com.huawei.genexcloud.dialog.InstalledDialog;
import com.huawei.genexcloud.dialog.SearchResultDilog;
import com.huawei.genexcloud.dialog.SenseMapRightToolsDialog;
import com.huawei.genexcloud.http.InsertSupportRecordImpl;
import com.huawei.genexcloud.http.QueryCitySiteNumImpl;
import com.huawei.genexcloud.http.QueryExperienceSiteListImpl;
import com.huawei.genexcloud.http.QueryProvinceSiteInfoImpl;
import com.huawei.genexcloud.http.SearchSiteInfoImpl;
import com.huawei.genexcloud.http.util.CellInfoUtils;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.util.AddrNameUtils;
import com.huawei.genexcloud.util.AppPermissionUtil;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.util.BaiduSuggestSearchUtil;
import com.huawei.genexcloud.util.BdMapGridParamUtils;
import com.huawei.genexcloud.util.CacheUtil;
import com.huawei.genexcloud.util.CarrierNameUtils;
import com.huawei.genexcloud.util.DeviceUtil;
import com.huawei.genexcloud.util.DrawSiteMarkersUtils;
import com.huawei.genexcloud.util.Formatter;
import com.huawei.genexcloud.util.GeoUtils;
import com.huawei.genexcloud.util.PositionUtils;
import com.huawei.genexcloud.util.SenceMapTextUtils;
import com.huawei.genexcloud.util.ShareDataUtil;
import com.huawei.genexcloud.util.SiteInfoTransUtil;
import com.huawei.genexcloud.util.map.SiteUtils;
import com.huawei.genexcloud.util.map.MapUtil;
import com.huawei.genexcloud.viewmodel.MainSharedDataViewModel;
import com.huawei.genexcloud.widget.AddSiteTypeView;
import com.huawei.genexcloud.widget.SiteDetailView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import okhttp3.Request;

public class SenseMapController implements View.OnClickListener,
        DrawSiteMarkersUtils.OnSiteResultReceivedListener,
        AddSiteTypeView.CommitListener, AddSiteTypeView.OnPhotoTypeSelectedListener {

    private BaseFragment homePage;
    private PageHomeBinding binding;
    private BaiduMap mBaiduMap;
    private boolean firstLocation = true;
    private LocationClient locationClient;
    // 记录进入页面默认信息
    private String myProvinceName, myCityName;
    private LatLng myLocationLatLng;
    private final SenseMapControllerBean controllerBean = new SenseMapControllerBean();
    // 侧边栏回调接口
    private final SenseMapRightToolsDialog.DataChangedCallback rightToolsCallback =
            new SenseMapRightToolsDialog.DataChangedCallback() {
                @Override
                public void onMapTypeChanged(int type) {
                    if (mBaiduMap != null) {
                        mBaiduMap.setMapType(type);
                    }
                    GCLogger.error("map", "onMapTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onSiteTypeChanged(int type) {
                    setSiteShowType();
                    GCLogger.error("map", "onSiteTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onMarkTypeChanged(int type) {
                    onExperienceClick(controllerBean.isShowMarkType());
                    GCLogger.error("map", "onMarkTypeChanged:" + Integer.toHexString(type));
                }

                @Override
                public void onSiteStatusChanged(boolean checked) {
                    onSiteClick(checked);
                    GCLogger.error("map", "onSiteStatusChanged:" + checked);
                }

                @Override
                public void onPatternStatusChanged(boolean checked) {
                    onOtherSiteClick(checked);
                    GCLogger.error("map", "onPatternStatusChanged:" + checked);
                }

                /**
                 * 改变了信号显示开关
                 * @param checked
                 */
                @Override
                public void onSignalStatusChanged(boolean checked) {
                    onSignalClick(checked);
                    GCLogger.error("map", "onSignalStatusChanged:" + checked);
                }

                @Override
                public void onHWDensityStatusChanged(boolean checked) {
                    onHwDensityClick(checked);
                    GCLogger.error("map", "onHWDensityStatusChanged:" + checked);
                }
            };

    private static final int INDEX_INC_SITE = 0, INDEX_EXPERIENCE = 1, INDEX_SIGNAL = 2, INDEX_HUAWEI = 3;
    private static final float DEFAULT_ZOOM = 18.0f;
    private static final float MAX_ZOOM = 21f;
    private static final float MIN_ZOOM = 5f;
    private static final float BORDER_ZOOM = 14.0f;
    private static final int SELECT_OPERATOR = 9999;
    private static final int SELECT_PHOTO = 999;
    private static final int CREAM = 1001;
    private BDLocation sl;
    private LatLng currentMapCenterLatLng;
    private boolean isClearMarker = false;
    // 保存当前滑动详情信息<影响到下次打开是恢复还是重置>
    private boolean isSaveBottomScrollInfo = false;
    // 地图覆盖物
    private Overlay districPolyLine;
    private List<LatLng> provincePolyLineList;
    private SiteDetailView siteDetailView;
    private MapStatusUpdate baiduMsu;
    private String selCity = "";
    private String selOper = "";
    private String selProvince = "";
    private int cityIndex = -1;
    private int opeartorIndex = -1;
    private int provinceIndex = -1;
    private final CopyOnWriteArrayList<Marker> outerSiteMarkers = new CopyOnWriteArrayList<>();// 室外站点
    private final CopyOnWriteArrayList<Marker> innerSiteMarkers = new CopyOnWriteArrayList<>();// 室内站点
    private SearchResultDilog searchResultDialog;
    private final ArrayList<Marker> experienceMarkers = new ArrayList<>();
    private boolean isShow4g = false;
    private String cnCarrier;// 当前运营商
    private String enCarrier;
    private LatLng clickedSiteLatLng;
    private boolean isShowedScaleInfo;
    private String provinceName;  // 当前省
    private String cityName; // 当前市名
    // 基站
    private List<SiteInfo> stationInfoList = new ArrayList<>();
    private List<ExperienceSiteInfo> signSuggestionList = new ArrayList<>();
    private final MyLocationConfiguration.LocationMode mCurrentMode = MyLocationConfiguration.LocationMode.NORMAL;
    private boolean isCanComplain = true;
    private final BitmapDescriptor mCurrentMarker = BitmapDescriptorFactory.fromResource(R.drawable.mark_navi_locate);
    private float mCurrentAccracy = 0.0f;
    //    private ReceiveBroadCast mBroadcastReceiver;
    private InfoWindow clickMarkerIndicator;
    private final ArrayList<QueryAreaResultBean> siteResultList = new ArrayList<>();
    private final ArrayList<QueryAreaResultBean> siteResultListAll = new ArrayList<>();
    // 选中的基站信息
    private SiteBaseBean searchSiteInfo = null;
    private QueryAreaSiteBean currentAreaSiteBean;
    private boolean IS_PROVINCE_ZOOM = false;  // 省的鸟瞰
    private DistrictSearch districtSearch;
    private HeatMap huaweiIncHeatmap;
    private boolean isFirstFinishStatus = true;
    private String preExperienceCity;
    private String preExperienceNetOper;
    private float preZoom;
    private int openTag = -1;
    private boolean isFirstEnter = true;
    private boolean isMapMove = false;
    private LatLngBounds currentBounds;
    private float currentZoom;
    private boolean isScaleEnable = false;
    private boolean isDrawingSite = false;
    private boolean isSiteClickOpen = true;
    private boolean isSignalClickOpen = false;
    private AddSiteTypeView addSiteTypeView;
    private ArrayList<ExperienceSiteInfo> experienceList = new ArrayList<>();
    @SuppressLint("HandlerLeak")
    private final Handler delayHandler = new Handler();

    // 定位回调
    private MyLocationListener locationListener;
    // MainActivity 共享数据内容 包含感知地图的省市选择信息
    private MainSharedDataViewModel viewModel;
    // 省市选择状态
    private MainSharedDataViewModel.SenseMapStatus senseMapStatus;

    private GeoCoder mSearch;
    private final TextView.OnEditorActionListener myEditActionListener = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            if (i == EditorInfo.IME_ACTION_SEARCH) {
                String inputStr = binding.smSearchEdit.getText().toString().trim();
                if (TextUtils.isEmpty(inputStr) && homePage != null) {
                    homePage.showMsg("请输入搜索内容");
                    return true;
                }

                searchAreaSite(inputStr);
            }
            return true;
        }
    };

    public void initMap(BaseFragment homePage, PageHomeBinding binding) {
        this.homePage = homePage;
        this.binding = binding;

        initView(); // 初始化控件
        initData(); // 初始化数据内容
        // TODO 相关权限控制
        initPermission();// 初始化权限<涉及右侧工具栏>
        initDistricSearch();// 初始化行政编码
        initBaiduMap();// 初始化地图
        iniSiteDetailView();// 初始化底部滑动

        DrawSiteMarkersUtils.getInstance().setOnSiteResultReceivedListener(this);
        // TODO 这里使用viewModel传输数据
        /*
        mBroadcastReceiver = new ReceiveBroadCast();  // 注册广播
        IntentFilter myIntentFilter = new IntentFilter();
        registerReceiver(mBroadcastReceiver, myIntentFilter, Constants.PERMISSION_BROADCAST, null);
         */
    }

    public void onResume() {
        binding.mapView.onResume();
        locationClient.start();
    }

    public void onPause() {
        binding.mapView.onPause();
        locationClient.stop();
    }

    public void onDestroy() {
        GeoUtils.getInstance().destroySelf();
        delayHandler.removeCallbacksAndMessages(null);
        BaiduSuggestSearchUtil.getInstance().onDestroy();
        // 取消定位服务
        if (null != locationClient) {
            locationClient.stop();
            if (null != locationListener) {
                locationClient.unRegisterLocationListener(locationListener);
            }
        }
        binding.mapView.onDestroy();
        if (mBaiduMap != null) {
            mBaiduMap.clear();
        }
        mBaiduMap = null;
        binding = null;
        homePage = null;
    }

    @Override
    public void onResultReceived(List<QueryAreaResultBean> list, boolean isClearList) {
        List<QueryAreaResultBean> myList = new ArrayList();
        if (siteResultListAll.size() > 0) {
            siteResultList.clear();
            boolean isOneMore = false;
            for (QueryAreaResultBean info : list) {
                for (QueryAreaResultBean bean : siteResultListAll) {
                    if (bean.getNodebId() == info.getNodebId()) {
                        isOneMore = true;
                    }
                }
                if (!isOneMore) {
                    siteResultList.add(info);
                }
                isOneMore = false;
            }
            if ((siteResultListAll.size() + siteResultList.size()) > 1500) {
                GCLogger.error(Module.GENEX_CLOUD, "集合大小超限制了开始清理" + "siteResultListAll" + siteResultListAll.size() + "siteResultList" + siteResultList.size());
                siteResultListAll.clear();
                siteResultListAll.addAll(list);
                isClearMarker = true;
                myList = list;
            } else {
                siteResultListAll.addAll(siteResultList);
                myList = siteResultList;
            }
        } else {
            siteResultListAll.addAll(list);
            myList = list;
        }
        drawBaiduMapOverlays(INDEX_INC_SITE, myList);
        GCLogger.error(Module.GENEX_CLOUD, "4g 画点了  收到大小==" + myList.size() + "isClearMarker" + isClearMarker);
    }

    private void showSearchResultDialog() {
        if (searchResultDialog != null) {
            searchResultDialog.show();
        }
    }

    /**
     * 绘制百度地图覆盖物
     */
    @SuppressWarnings("unchecked")
    private <T> void drawBaiduMapOverlays(int type, List<T> list) {
        List<SiteInfo> siteInfos = new ArrayList<>();
        // 按钮控制
        if (!controllerBean.isShowSite()) {
            return;
        }
        switch (type) {
            case INDEX_INC_SITE:
                // 绘制站点
                if (isClearMarker) {
                    clearExistIncSiteMarkers();
                }
                if (currentZoom < BORDER_ZOOM) {
                    return;
                }
                isDrawingSite = true;
                siteInfos = SiteInfoTransUtil.transformSiteInfos((List<QueryAreaResultBean>) list);
                GCLogger.error(Module.GENEX_CLOUD, "开始画了 + 4g infos size = " + siteInfos.size() + "   " + list);
                isMapMove = false;
                drawSite(siteInfos);
                GCLogger.error(Module.GENEX_CLOUD, "4g 画点完了 + size = " + siteInfos.size() + ";outerSiteMarkers="
                        + outerSiteMarkers.size() + ";innerSiteMarkers=" + innerSiteMarkers.size());
                isClearMarker = false;
                isDrawingSite = false;
                break;
            case INDEX_EXPERIENCE:
                // 绘制体验标点
                experienceList = (ArrayList<ExperienceSiteInfo>) list;
                LatLng latLng;
                for (ExperienceSiteInfo exInfo : experienceList) {
                    if (controllerBean.isShowMarkType(exInfo.getRecordType())) {
                        latLng = new LatLng(exInfo.getLat(), exInfo.getLng());
                        MarkerOptions exMarkerOption = SiteUtils.getExperienceMarkerOption(exInfo, latLng, false);

                        Bundle bundle = new Bundle();
                        bundle.putSerializable("info", exInfo);
                        bundle.putString("markerType", "feelPointMarker");
                        exMarkerOption.extraInfo(bundle);

                        Marker exMarker = (Marker) mBaiduMap.addOverlay(exMarkerOption);
                        exMarker.setToTop();
                        experienceMarkers.add(exMarker);
                    }
                }
                break;
            case INDEX_HUAWEI:
                // 绘制华为云图
                if (districPolyLine != null) {
                    districPolyLine.remove();
                }
                clearHuaweiHeatMap();
                //有的城市size为0
                if (list == null || list.size() < 2) {
                    return;
                }
                drawDistricPolyLines(this.provincePolyLineList = (List<LatLng>) list);
                if (isScaleEnable) {
                    setBaiduMapZoomToProvince(provincePolyLineList);
                }
                break;
        }
    }

    //绘制站点
    private void drawSite(List<SiteInfo> siteInfos) {
        if (null == siteInfos || siteInfos.isEmpty()) {
            return;
        }
        // 对站点进行过滤
        List<SiteInfo> filteredSites = SiteUtils.filterSites2(siteInfos, currentZoom);
        long startT = System.currentTimeMillis();
        List<OverlayOptions> markerOptions = new ArrayList<>();
        for (SiteInfo siteInfo : filteredSites) {
            MarkerOptions markerOption;
            Marker marker;
            markerOption = SiteUtils.getIncSiteMarkerOption(requireContext(), mBaiduMap, siteInfo);

            Bundle bundle = new Bundle();
            bundle.putString("markerType", "incMarker");
            bundle.putSerializable("bean", siteInfo);
            markerOption.extraInfo(bundle);
            if (isMapMove) {
                isDrawingSite = false;
                return;
            }
            if (siteInfo.getIndoorId() == 0) {
                if (controllerBean.isShowOutdoorSite() && !controllerBean.isShowPatternSite()) {
                    markerOption.visible("华为".equals(siteInfo.getmFRSName()));
                } else {
                    markerOption.visible(controllerBean.isShowOutdoorSite());
                }
            } else {
                if (controllerBean.isShowIndoorSite() && !controllerBean.isShowPatternSite()) {
                    markerOption.visible("华为".equals(siteInfo.getmFRSName()));
                } else {
                    markerOption.visible(controllerBean.isShowIndoorSite());
                }
            }
            markerOptions.add(markerOption);
            if (searchSiteInfo != null && searchSiteInfo.getLat() == siteInfo.getLat() && searchSiteInfo.getNodebId() == siteInfo.getNodebId()
                    && searchSiteInfo.getLng() == siteInfo.getLng()) {
                showWindowInfo(siteInfo);
            }
        }
        // 点整体添加 不单独添加
        List<Overlay> overlays = mBaiduMap.addOverlays(markerOptions);
        if (null != overlays && !overlays.isEmpty()) {
            for (Overlay overlay : overlays) {
                if (overlay instanceof Marker) {
                    outerSiteMarkers.add((Marker) overlay);
                    ((Marker) overlay).setToTop();
                }
            }
        }
    }

    //显示泡泡信息
    private void showWindowInfo(SiteInfo siteInfo) {
        if (null == siteInfo) {
            return;
        }
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromResource(R.drawable.pop_marker_big_red);
        LatLng siteLL = new LatLng(siteInfo.getLat(), siteInfo.getLng());
//        clickMarkerIndicator = new InfoWindow(bitmapDescriptor, clickedSiteLatLng, 0, null);
        clickMarkerIndicator = new InfoWindow(bitmapDescriptor, siteLL, 0, null);
        mBaiduMap.showInfoWindow(clickMarkerIndicator);
        siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.NORMAL_SITE, siteInfo, isShow4g);
        siteDetailView.tvStationDistance.setText("距您" + SenceMapTextUtils.getDistanceText(myLocationLatLng, clickedSiteLatLng));
    }

    /**
     * 缩放到省
     */
    private void zoomToProvince(boolean isProvinceZoom) {
        if (isProvinceZoom) {
            binding.stationTypeTips.setVisibility(View.GONE);
            binding.signalStrengthLayout.setVisibility(View.GONE);
            SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
            SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);

            // 弹出三段拉
            delayHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    siteDetailView.setVisibility(View.VISIBLE);
                    siteDetailView.scrollToShow();
                }
            }, 300);// 延迟为了避免被drawer的监听关闭三段拉
        } else {
            if (districPolyLine != null) {
                districPolyLine.remove();
            }

            binding.stationTypeTips.setVisibility(controllerBean.isShowSite()? View.VISIBLE: View.GONE);
            showSignalViewVisiable(controllerBean.isShowSignal());
            // 改变地址选择文字
            provinceName = myProvinceName;
            cityName = myCityName;
        }
    }

    /**
     * 画本省的地理围栏
     *
     * @param polylineList 边界的list集合
     */
    private void drawDistricPolyLines(List<LatLng> polylineList) {
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.color(Color.parseColor("#000000")).points(polylineList).width(3);
        districPolyLine = mBaiduMap.addOverlay(polylineOptions);
    }

    /**
     * 初始化权限<相关view>
     */
    private void initPermission() {

    }

    public void initView() {
        // 地图控件
        binding.smSearchEdit.setOnEditorActionListener(myEditActionListener);
        binding.smMarkBtn.setOnClickListener(this);
        binding.zoomOutBtn.setOnClickListener(this);
        binding.zoomInBtn.setOnClickListener(this);
        binding.smCityOperator.setOnClickListener(this);
        binding.outSiteTip.setOnClickListener(this);
        binding.innerSiteTip.setOnClickListener(this);
        binding.smMapLayerBtn.setOnClickListener(this);
        binding.networkSwitchBtn.setOnClickListener(this);
        binding.smPositionBtn.setOnClickListener(this);

        // 初始化侧滑
        setSiteShowType();
        addSiteTypeView = new AddSiteTypeView(requireContext(), requireActivity());
        addSiteTypeView.setCommitListrener(this);
        addSiteTypeView.setOnPhotoTypeSelectedListener(this);
    }


    private void initData() {
        viewModel = new ViewModelProvider((ViewModelStoreOwner) requireActivity()).get(MainSharedDataViewModel.class);
        if (null != viewModel.getSenseMapStatus()) {
            senseMapStatus = viewModel.getSenseMapStatus();
        } else {
            senseMapStatus = new MainSharedDataViewModel.SenseMapStatus();
        }
    }

    /**
     * 初始化站点详情view(上拉三段)
     */
    private void iniSiteDetailView() {
        siteDetailView = new SiteDetailView(requireContext());
        binding.frameLayout.addView(siteDetailView);
        siteDetailView.setOnMeasureDisClickListener(new SiteDetailView.OnMeasureDisClickListener() {
            @Override
            public void onClick(TextView tv) {
                tv.setText(SenceMapTextUtils.getDistanceText(myLocationLatLng, clickedSiteLatLng));
            }
        });
        siteDetailView.setOnNaviBtnClickListener(new SiteDetailView.OnNaviBtnClickListener() {
            @Override
            public void onClick() {
                startNavigation(clickedSiteLatLng);
            }
        });
        siteDetailView.setOnSlideCloseListener(new SiteDetailView.OnSlideCloseListener() {
            @Override
            public void onClose() {
                mBaiduMap.hideInfoWindow();
            }
        });
    }

    // 站点
    private void onSiteClick(boolean isOpen) {
        if (isOpen) {
            binding.outSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            binding.innerSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));

            binding.stationTypeTips.setVisibility(View.VISIBLE);
            if (controllerBean.isShowHWSiteDensity()) {
                resetHuaweiPattern();
            } else {
                findSiteDataByPramas();
            }
        } else {
            // 关闭
            binding.stationTypeTips.setVisibility(View.GONE);
            isMapMove = true;
            clearExistIncSiteMarkers();
            clearHuaweiHeatMap();
        }
    }

    private void onOtherSiteClick(boolean isOpen) {
        if (controllerBean.isShowOutdoorSite()) {
            SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.SHOW, isOpen);
        }
        if (controllerBean.isShowIndoorSite()) {
            SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.SHOW, isOpen);
        }
    }

    private void findSiteDataByPramas() {
        siteResultListAll.clear();
        queryIncSite(currentAreaSiteBean, currentBounds, currentZoom);
    }

    // 体验标点
    private void onExperienceClick(boolean isOpen) {
        if (isOpen) {
            // 打开
            if (controllerBean.isShowHWSiteDensity()) {
                resetHuaweiPattern();
            }
            queryExperienceSite(provinceName, cityName, enCarrier);
        } else {
            // 关闭
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.HIDE);
        }
    }

    /**
     * 打开或者关闭信号显示
     * @param isOpen
     */
    private PhoneStateListener phoneStateListener;
    private void onSignalClick(boolean isOpen) {
        TelephonyManager manager = (TelephonyManager) BaseApplication.getAppContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        if (isOpen) {
            // 检查是否有权限
            if (ActivityCompat.checkSelfPermission(BaseApplication.getAppContext(),
                    Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                homePage.requestPermissions(new AppPermissionUtil.PermissionResultCallback() {
                    @Override
                    public String[] getRequestedPermission() {
                        return new String[]{Manifest.permission.READ_PHONE_STATE};
                    }

                    @Override
                    public void onPermissionResult(Map<String, Boolean> result) {
                        if (null == result || result.isEmpty() || !result.get(Manifest.permission.READ_PHONE_STATE)) {
                            // 没有授权
                            showMsg("无权限读取信号强度信息");
                            return;
                        } else {
                            // 成功获取授权
                            if (isOpen) {
                                if (controllerBean.isShowHWSiteDensity()) {
                                    resetHuaweiPattern();
                                }
                            }
                            showSignalViewVisiable(isOpen);
                            startListeningSignal(manager);
                        }
                    }
                });
            } else {
                // 有权限
                showSignalViewVisiable(isOpen);
                startListeningSignal(manager);
            }
        } else {
            showSignalViewVisiable(isOpen);
            if (null != phoneStateListener) {
                GCLogger.error("view", "取消监听信号");
                manager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            }
        }
    }

    /**
     * 开启信号强度监听
     * @param manager
     */
    private void startListeningSignal(TelephonyManager manager) {
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onSignalStrengthsChanged(SignalStrength signalStrength) {
                if (null == signalStrength) {
                    return;
                }
                // 解析信号强度信息
                Map<String, Integer> signalData = CellInfoUtils.getSignalStrengthInfo(signalStrength);
                if (null != signalData) {
                    Integer rsrp = signalData.get(CellInfoUtils.VALUE_RSRP);
                    Integer sinr = signalData.get(CellInfoUtils.VALUE_SINR);
                    if (null == rsrp || CellInfoUtils.VALUE_INVALID == rsrp) {
                        binding.siteviewRsrpTv.setText("无");
                    } else {
                        binding.siteviewRsrpTv.setText(String.valueOf(rsrp));
                    }
                    if (null == sinr || CellInfoUtils.VALUE_INVALID == rsrp) {
                        binding.siteviewSnrTv.setText("-");
                    } else {
                        binding.siteviewSnrTv.setText(String.valueOf(sinr));
                    }
                }
            }
        };
        manager.listen(phoneStateListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
    }

    // 华为格局
    private void onHwDensityClick(boolean isOpen) {
        if (isOpen) {
            showSiteDensity();
        } else {
            resetHuaweiPattern();
        }
    }

    private void resetHuaweiPattern() {
        controllerBean.enableHWSiteDensity(false);
        if (null != myProvinceName) {
            selProvince = myProvinceName.replaceAll("省", "");
        }
        if (null != myCityName) {
            selCity = myCityName.replaceAll("市", "");
        }
        cityName = selCity;
        provinceName = selProvince;
        binding.smCityOperator.setText(selCity + "/" + selOper);
        // 回退自己位置
        isScaleEnable = false;
        closeHuaweiPatternButton();
        //打开站点按钮，显示室分布局
        controllerBean.enableSite(true);
        binding.stationTypeTips.setVisibility(View.VISIBLE);
        resetMapStatus(myLocationLatLng, DEFAULT_ZOOM);
    }

    /**
     * 显示站点密度
     */
    private void showSiteDensity() {
        // 关于底部详情
        isSaveBottomScrollInfo = true;
        siteDetailView.setSlideOutEnable(false); // 让scrolllayout不可以划出
        // 关闭其他功能对应布局
        binding.smPositionBtn.setVisibility(View.GONE);
        binding.smMarkBtn.setVisibility(View.GONE);
        binding.expPointMarker.setVisibility(View.GONE);
        // 开始请求
        isScaleEnable = true;
        startDistrictSearch(provinceName);
        requestHwCityGrideData(provinceName, enCarrier);
    }

    /**
     * 影藏站点密度
     */
    private void hideSiteDensity() {
        // 开启其他功能对应布局
        binding.smPositionBtn.setVisibility(View.VISIBLE);
        binding.smMarkBtn.setVisibility(View.VISIBLE);
    }

    /**
     * 清空(隐藏)地图当前覆盖物
     */
    private void clearAllMarkers() {
        SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.HIDE);
    }

    /**
     * 关闭底部滑动控件
     */
    private void closeBottomDetailView() {
        if (siteDetailView != null) {
            siteDetailView.closeScrollLayout(isSaveBottomScrollInfo);
        }
        if (clickMarkerIndicator != null) {
            mBaiduMap.hideInfoWindow();
            clickMarkerIndicator = null;
        }
    }

    /**
     * 是否当前运营商
     */
    private boolean isMyCarrier() {
        return CarrierNameUtils.isMyCarrier(requireContext(), enCarrier);
    }

    /**
     * 关闭华为格局按钮
     */
    private void closeHuaweiPatternButton() {
        isSaveBottomScrollInfo = false;
        siteDetailView.setSlideOutEnable(true);
        binding.smPositionBtn.setVisibility(View.VISIBLE);
        binding.smMarkBtn.setVisibility(View.VISIBLE);
        if (controllerBean.isShowHWSiteDensity()) {
            GCLogger.error(Module.GENEX_CLOUD, "站点密度关闭了" + myLocationLatLng.toString());
            resetMapStatus(currentMapCenterLatLng, DEFAULT_ZOOM);
        }
        controllerBean.enablePatternSite(false);
        zoomToProvince(false);
        IS_PROVINCE_ZOOM = false;
        // 关闭华为格局图标
        clearHuaweiHeatMap();
    }

    /**
     * 清除厂商云图
     */
    private void clearHuaweiHeatMap() {
        if (huaweiIncHeatmap != null) {
            huaweiIncHeatmap.removeHeatMap();
        }
    }

    /**
     * 查询地址信息
     *
     * @param latlng 地图当前的中点
     */
    private void geoLatLngAddress(LatLng latlng, final int flag) {

        GeoUtils.getInstance().setOnReceiveGeoResult(new GeoUtils.OnReceiveGeoResult() {
            @Override
            public void onSuccess(ReverseGeoCodeResult result) {
                onReceiveGeoResult(result, flag);
            }
        });
        GeoUtils.getInstance().startGeo(latlng);
    }

    /**
     * 处理geo的回调结果
     *
     * @param result
     */
    private void onReceiveGeoResult(ReverseGeoCodeResult result, int flag) {

        if (flag == 0) {
            String province = result.getAddressDetail().province;
            String city = result.getAddressDetail().city;

            if (!province.contains(provinceName) && !city.contains(cityName)) {
                provinceName = AddrNameUtils.getAliasProvinceName(homePage.requireContext(), province, "");
                cityName = AddrNameUtils.getAliasCityName(homePage.requireContext(), city);
                // 重设记录索引
                resetAddrText(city, cnCarrier);
            }

            if (IS_PROVINCE_ZOOM) {
                isScaleEnable = false;
                startDistrictSearch(provinceName);
                requestHwCityGrideData(provinceName, enCarrier);
            }
        }
        String address = result.getAddressDetail().province + result.getAddressDetail().city
                + result.getAddressDetail().district + result.getAddressDetail().street
                + result.getAddressDetail().streetNumber;
        if (addSiteTypeView != null && !TextUtils.isEmpty(address)) {
            addSiteTypeView.setAddress(address);
        }
    }

    /**
     * 请求网络上地图的覆盖物信息
     */
    private void requestMapOverlayFromNet() {
        if (controllerBean.isShowMarkType()) {
            queryExperienceSite(provinceName, cityName, enCarrier);
        }
    }

    /**
     * 初始化百度地图
     */
    private void initBaiduMap() {
        mBaiduMap = binding.mapView.getMap();

        // 初始化地图
        MapUtil.initBaiduMap(binding.mapView, null, onMapStatusChangeListener, onMapClickListener, onMarkerClickListener);
        MapUtil.setMapZoomLevel(mBaiduMap, DEFAULT_ZOOM);

        // 初始化定位服务
        locationClient = MapUtil.createLocationClient(requireContext());
        locationListener = new MyLocationListener();
        locationClient.registerLocationListener(locationListener);


        mSearch = GeoCoder.newInstance();

        mSearch.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {

            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
                if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
                    return;
                }
                GCLogger.debug(Module.GENEX_CLOUD, result.getAddress());
                String address = result.getAddressDetail().district + result.getAddressDetail().street
                        + result.getAddressDetail().streetNumber;
                if (addSiteTypeView != null && !TextUtils.isEmpty(address)) {
                    addSiteTypeView.setAddress(address);
                }
            }
            @Override
            public void onGetGeoCodeResult(GeoCodeResult result) {

            }
        });

        DrawSiteMarkersUtils.getInstance().init(requireContext(), provinceName, enCarrier);
    }

    /***************************************************************百度地图 START 各种回调************************************************************/
    /**
     * 地图移动 状态改变
     */
    private BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener = new BaiduMap.OnMapStatusChangeListener() {
        public void onMapStatusChangeStart(MapStatus mapStatus) {}
        public void onMapStatusChangeStart(MapStatus mapStatus, int i) {}
        public void onMapStatusChange(MapStatus mapStatus) {}
        public void onMapStatusChangeFinish(MapStatus mapStatus) {
            mapChange(mapStatus);
        }
    };

    /**
     * 地图点击事件回调
     */
    private BaiduMap.OnMapClickListener onMapClickListener = new BaiduMap.OnMapClickListener() {
        public void onMapClick(LatLng latLng) {
            // 点击地图 如果不是省级缩放 则隐藏站点信息窗口
            if (!IS_PROVINCE_ZOOM) {
                closeBottomDetailView();
            }
            if (binding.addBgView.getVisibility() == View.VISIBLE) {
                binding.addBgView.setVisibility(View.GONE);
            }
        }
        @Override
        public void onMapPoiClick(MapPoi mapPoi) {}
    };

    /**
     * marker点击事件回调
     */
    private BaiduMap.OnMarkerClickListener onMarkerClickListener = new BaiduMap.OnMarkerClickListener() {
        @Override
        public boolean onMarkerClick(Marker marker) {
            if (binding.addBgView.getVisibility() == View.VISIBLE) {
                binding.addBgView.setVisibility(View.GONE);
            }
            // 显示信息
            if (marker != null) {
                if (marker.getExtraInfo() != null && marker.isVisible()) {
                    // marker有bundle信息且显示
                    String markerType = marker.getExtraInfo().getString("markerType");
                    if ("incMarker".equals(markerType)) {
                        SiteInfo siteInfo = (SiteInfo) marker.getExtraInfo().getSerializable("bean");
                        clickedSiteLatLng = new LatLng(siteInfo.getLat(), siteInfo.getLng());
                        showWindowInfo(siteInfo);
                    }
                    if ("feelPointMarker".equals(markerType)) {
                        ExperienceSiteInfo exInfo = (ExperienceSiteInfo) marker.getExtraInfo()
                                .getSerializable("info");
                        push(new RecordDetailFragment(exInfo, false));
                    }
                }
            }
            return true;
        }
    };
    /***************************************************************百度地图  END  各种回调************************************************************/
    /***************************************************************百度地图 START 各种能力************************************************************/
    private class MyLocationListener extends BDAbstractLocationListener {
        @Override
        public void onReceiveLocation(BDLocation bdLocation) {
            // 接收到定位信息
            if (null == bdLocation || null == binding || null == binding.mapView) {
                return;
            }
            int locType = bdLocation.getLocType();
            if (locType == BDLocation.TypeCriteriaException || locType == BDLocation.TypeNone
                    || bdLocation.getLatitude() == 4.9E-324 || bdLocation.getLongitude() == 4.9E-324) {
                // 无效的定位信息
                return;
            }

            MyLocationData locData = new MyLocationData.Builder().accuracy(bdLocation.getRadius())
                    .direction(bdLocation.getDirection())
                    .latitude(bdLocation.getLatitude())
                    .longitude(bdLocation.getLongitude()).build();

            mBaiduMap.setMyLocationData(locData);

            // 我的省份城市信息 只获取一次有效数据
            if (!TextUtils.isEmpty(bdLocation.getProvince()) && !TextUtils.isEmpty(bdLocation.getCity())
                    && null == myProvinceName && null == myCityName) {
                myProvinceName = bdLocation.getProvince();
                myCityName = bdLocation.getCity();
                // 将城市信息设置到左上角文字
                binding.city.setText(bdLocation.getCity());

                initAddressText();
            }
            // 第一次有效定位 移动地图到当前位置
            if (firstLocation) {
                firstLocation = false;
                LatLng ll = new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude());
                MapStatus.Builder builder = new MapStatus.Builder();
                builder.target(ll).zoom(DEFAULT_ZOOM);
                mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
            }
            // 更新我的位置 经纬度
            myLocationLatLng = new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude());
            ShareDataUtil.updateLAT(BaseApplication.getAppContext(), bdLocation.getLatitude() + "");
            ShareDataUtil.updateLNG(BaseApplication.getAppContext(), bdLocation.getLongitude() + "");
        }
    }
    /***************************************************************百度地图  END  各种能力************************************************************/

    private void mapChange(MapStatus ms) {
        // 地图状态改变结束，当前图层信息
        Log.i(Module.GENEX_CLOUD, "------------动了---------");
        float zoom = ms.zoom;
        currentAreaSiteBean = getCurrentMapAreaSiteBean(ms.bound, zoom, 0);

        if (zoom < BORDER_ZOOM) {
            if (isDrawingSite) {
                return;
            }
            if (openTag == -1) {
                isFirstEnter = true;
            }
            isMapMove = true;
            siteResultListAll.clear();
            clearExistIncSiteMarkers();
        } else {
            if (currentZoom > ms.zoom) {
                if (openTag == -1) {
                    isFirstEnter = true;
                }
                siteResultListAll.clear();
                isMapMove = true;
                clearExistIncSiteMarkers();
            }
            // 封装边界及参数
            Log.i(Module.GENEX_CLOUD, "------------currentAreaSiteBean---------" + currentAreaSiteBean);
            if (BdMapGridParamUtils.getOutDirection(ms.bound, currentMapCenterLatLng, ms.target) == NAN) {
                // 封装边界及参数
                isMapMove = true;
                if (isFirstEnter) {
                    GCLogger.debug(Module.GENEX_CLOUD, "------------第一次请求---------");
                    isFirstEnter = false;
                    if (controllerBean.isShowSite()) {
                        // 查询异厂商<站点开关+室分/宏站开关>
                        isClearMarker = true;
                        queryIncSite(currentAreaSiteBean, ms.bound, zoom);
                    }
                }
            } else {
                if (controllerBean.isShowSite()) {
                    // 查询异厂商<站点开关+室分/宏站开关>
                    queryIncSite(currentAreaSiteBean, ms.bound, zoom);
                }
            }
        }

        currentBounds = ms.bound;
        currentZoom = ms.zoom;
        currentMapCenterLatLng = ms.target;

        //请求ATU/体验标点等
        requestMapOverlayFromNet();

        if (PositionUtils.isInScreenInner(ms.bound, myLocationLatLng)) {
            isCanComplain = true;
            binding.smMarkBtn.setTextColor(Color.parseColor("#6FBAFF"));
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    requireContext().getDrawable(R.drawable.icon_punctuation_selected),
                    null, null);
        } else {
            isCanComplain = false;
            binding.addBgView.setVisibility(View.GONE);
            binding.smMarkBtn.setTextColor(Color.parseColor("#666666"));
            binding.smMarkBtn.setCompoundDrawables(
                    null,
                    requireContext().getDrawable(R.drawable.icon_punctuation_unselected),
                    null, null);
        }
        if (ms.zoom < 11) {
            preZoom = ms.zoom;
        }

        if (preZoom < 11 && ms.zoom >= 11 && !isFirstFinishStatus && controllerBean.isShowHWSiteDensity()) {
            geoLatLngAddress(currentMapCenterLatLng, 0);//0代表以前代码，zhengchang正常逻辑
            preZoom = ms.zoom;
        } else {
            geoLatLngAddress(currentMapCenterLatLng, 1); //1拖动地图，动态显示地址
        }
        isFirstFinishStatus = false;
    }

    /**
     * 当前显示屏幕的东西南北角
     */
    private QueryAreaSiteBean getCurrentMapAreaSiteBean(LatLngBounds latLngBounds, float zoom, int type) {
        QueryAreaSiteBean areaSiteBean = new QueryAreaSiteBean();
        GpsBounds gpsBounds = PositionUtils.bd_09_mapBound_to_gps_84_mapBound(latLngBounds);
        areaSiteBean.setLUpLat(gpsBounds.getNorthWestLat());
        areaSiteBean.setLUpLng(gpsBounds.getNorthWestLng());
        areaSiteBean.setRDnLat(gpsBounds.getSouthEastLat());
        areaSiteBean.setRDnLng(gpsBounds.getSouthEastLng());
        areaSiteBean.setNetOper(enCarrier);
        areaSiteBean.setZoom(zoom);
        GCLogger.error(Module.GENEX_CLOUD, areaSiteBean.toString());
        return areaSiteBean;
    }

    /**
     * 初始化行政搜索
     */
    private void initDistricSearch() {
        districtSearch = DistrictSearch.newInstance();
        districtSearch.setOnDistrictSearchListener(new OnGetDistricSearchResultListener() {

            @Override
            public void onGetDistrictResult(DistrictResult districResult) {
                List<LatLng> polylines;
                if (districResult != null && districResult.getPolylines() != null) {  // 边界数据
                    if (districResult.getCityName().contains("海南")) {  // 海南边界特殊有断层<来自web测试>
                        polylines = districResult.getPolylines().get(2);
                    } else {
                        polylines = districResult.getPolylines().get(0);
                    }
                    if (controllerBean.isShowHWSiteDensity()) {
                        drawBaiduMapOverlays(INDEX_HUAWEI, polylines);// 绘制省边界折线
                    }

                    MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(districResult.centerPt);
                    mBaiduMap.animateMapStatus(u);
                    if (controllerBean.isShowHWSiteDensity()) {
                        requestHeatMapServer(provinceName, enCarrier);
                    }
                } else {
                    homePage.showMsg("暂未获得边界数据，稍后再试！");
                }
            }
        });
    }

    /**
     * 搜索行政区域区域
     * @param districtName 行政名称
     */
    private void startDistrictSearch(String districtName) {
        DistrictSearchOption option = new DistrictSearchOption();
        // 找到全称
        districtName = AddrNameUtils.getFullProvinceName(requireContext(), districtName);
        option.cityName(districtName);
        // 请求边界数据画图<异步>，并缩放地图
        districtSearch.searchDistrict(option);
        zoomToProvince(true);
    }

    /**
     * 设置缩放级别到省
     */
    private void setBaiduMapZoomToProvince(List<LatLng> list) {
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (LatLng latLng : list) {
            boundsBuilder.include(latLng);
        }
        LatLngBounds bounds = boundsBuilder.build();
        mBaiduMap.setMapStatus(MapStatusUpdateFactory.newLatLngBounds(bounds));
    }

    /**
     * 查询异厂商站点
     */
    private void queryIncSite(QueryAreaSiteBean siteBean, LatLngBounds bounds, float zoom) {
        if (siteBean == null || bounds == null) {
            return;
        }
        if (siteBean.getZoom() >= BORDER_ZOOM) {
            clearHuaweiHeatMap();
            GCLogger.error(Module.GENEX_CLOUD, "请求了");
            DrawSiteMarkersUtils.getInstance().querySite(bounds, zoom, provinceName, enCarrier, isShow4g);
        } else {
            // 小于17级，画热力图
            if (!isShowedScaleInfo) {
                showMsg("请放大查看站点具体信息！");
                isShowedScaleInfo = true;
            }
            clearExistIncSiteMarkers();
            clearHuaweiHeatMap();
            requestHeatMapServer(provinceName, enCarrier);
        }
    }

    public void initAddressText() {
        enCarrier = DeviceUtil.getSimOperator(requireContext());
        if (enCarrier.equals("NONE")) {
            enCarrier = "CNTC";
        }
        cnCarrier = CarrierNameUtils.getCnName(requireContext(), enCarrier, "");
        provinceName = myProvinceName;
        cityName = myCityName;
        selProvince = provinceName.replaceAll("省", "");
        selCity = cityName.replaceAll("市", "");
        selOper = cnCarrier;
        resetAddrText(cityName, cnCarrier);
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        if (AppUtil.isFastDoubleClick()) {
            return;
        }

        switch (v.getId()) {
            case R.id.sm_mark_btn:
                closeBottomDetailView();
                // 投诉按钮
                if (null != myProvinceName) {
                    selProvince = myProvinceName.replaceAll("省", "");
                }
                if (null != myCityName) {
                    selCity = myCityName.replaceAll("市", "");
                }
                cityName = selCity;
                provinceName = selProvince;
                binding.smCityOperator.setText(selCity + "/" + selOper);
                if (isCanComplain) {
                    binding.addBgView.setVisibility(View.VISIBLE);
                    binding.rlContainerSurvey.removeAllViews();
                    binding.rlContainerSurvey.addView(addSiteTypeView.getView());
                    addSiteTypeView.recordType = -1;
                } else {
                    showCannotComplainDialog();
                }
                break;
            case R.id.zoom_in_btn:
                this.mBaiduMap.setMapStatus(MapStatusUpdateFactory.zoomTo(this.mBaiduMap.getMapStatus().zoom + 1));
                controlZoomShow(this.mBaiduMap.getMapStatus());//改变缩放按钮
                break;
            case R.id.zoom_out_btn:
                this.mBaiduMap.setMapStatus(MapStatusUpdateFactory.zoomTo(this.mBaiduMap.getMapStatus().zoom - 1));
                controlZoomShow(this.mBaiduMap.getMapStatus());//改变缩放按钮
                break;
            case R.id.sm_city_operator:
                selectCityAndOpera();
                break;
            case R.id.inner_site_tip:
                // 改变室分显示
                controllerBean.setShowIndoorSite(!controllerBean.isShowIndoorSite());
                setSiteShowType();
                break;
            case R.id.out_site_tip:
                // 改变宏站显示
                controllerBean.setShowOutdoorSite(!controllerBean.isShowOutdoorSite());
                setSiteShowType();
                break;
            case R.id.sm_map_layer_btn:
                // 打开右边侧滑
                binding.addBgView.setVisibility(View.GONE);
                SenseMapRightToolsDialog rightToolsDialog = new SenseMapRightToolsDialog(controllerBean, rightToolsCallback);
                rightToolsDialog.show(getChildFragmentManager(), SenseMapRightToolsDialog.class.getName());
                break;
            // 点击定位
            case R.id.sm_position_btn:
                if (myLocationLatLng == null || currentMapCenterLatLng == null) {
                    return;
                }
                selProvince = myProvinceName.replaceAll("省", "");
                selCity = myCityName.replaceAll("市", "");
                cityName = selCity;
                provinceName = selProvince;
                binding.smCityOperator.setText(selCity + "/" + selOper);
                boolean isMyPosition = num4P(currentMapCenterLatLng.latitude) == num4P(myLocationLatLng.latitude)
                        && num4P(currentMapCenterLatLng.longitude) == num4P(myLocationLatLng.longitude);
                if (!isMyPosition) {
                    resetMapStatus(currentMapCenterLatLng = myLocationLatLng, DEFAULT_ZOOM);
                }
                break;

            case R.id.network_switch_btn:
                if (AppUtil.isFastDoubleClick() || isDrawingSite) {
                    return;
                }
                if (isScaleEnable) {
                    showMsg("该模式不支持显示站点,请先切换为站点");
                    return;
                }

                isMapMove = true;
                if (!isShow4g) {
                    binding.networkSwitchBtn.setText("4G");
                } else {
                    binding.networkSwitchBtn.setText("5G");
                }
                isShow4g = !isShow4g;
                siteResultListAll.clear();
                clearExistIncSiteMarkers();
                closeBottomDetailView();
                binding.stationTypeTips.setVisibility(View.VISIBLE);
                if (!isSiteClickOpen) {
                    binding.stationTypeTips.setVisibility(View.GONE);
                }
                clearHuaweiHeatMap();
                queryIncSite(currentAreaSiteBean, currentBounds, currentZoom);
                break;
            default:
                break;
        }

    }

    private void controlZoomShow(MapStatus mapStatus1) {
        //获取当前地图状态
        float zoom = this.mBaiduMap.getMapStatus().zoom;
        //如果当前状态大于等于地图的最大状态，则放大按钮则失效
        binding.zoomInBtn.setEnabled(!(zoom >= 19));

        //如果当前状态小于等于地图的最小状态，则缩小按钮失效
        binding.zoomOutBtn.setEnabled(!(zoom <= 12));
        mapChange(mapStatus1);
    }

    /**
     * 选择新的省份地市
     */
    private void selectCityAndOpera() {
        push(new SenseMapCitySelectFragment(selProvince, selCity, selOper, controllerBean.isShowHWSiteDensity()));
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == RESULT_OK) {
//            switch (requestCode) {
//                case SELECT_OPERATOR:
//                    if (data != null) {
//                        selectOperatorAndCity(data);
//                    }
//                    break;
//                case SELECT_PHOTO:
//                    if (data != null) {
//                        addSiteTypeView.showBitmap(data);
//                    }
//                    break;
//                case CREAM:
//                    addSiteTypeView.showBitmap(null);
//                    break;
//            }
//        }
//    }

    //选择城市后
    private void selectOperatorAndCity(Intent data) {
        selProvince = data.getStringExtra("province");
        selCity = data.getStringExtra("city");

        selOper = data.getStringExtra("netOperator");
        provinceIndex = data.getIntExtra("provinceIndex", -1);
        opeartorIndex = data.getIntExtra("opeartorIndex", -1);
        cityIndex = data.getIntExtra("cityIndex", -1);
        enCarrier = CarrierNameUtils.getEnName(requireContext(), selOper, "");
        if (isSignalClickOpen && !selOper.equals(cnCarrier)) {
            controllerBean.enableSignal(false);
            showSignalViewVisiable(controllerBean.isShowSignal());
        }

        if (!isMyCarrier()) {
            showSignalViewVisiable(false);
        }
        boolean isLastCity = false;
        if (cityName.equals(selCity) && provinceName.equals(selProvince)) {
            isLastCity = true;
        }
        cnCarrier = selOper;
        provinceName = selProvince;
        cityName = selCity;
        double lat = data.getDoubleExtra("lat", 0);
        double lng = data.getDoubleExtra("lng", 0);

        currentMapCenterLatLng = new LatLng(lat, lng);

        if (controllerBean.isShowHWSiteDensity()) {
            binding.smCityOperator.setText(selProvince + "/" + selOper);
            resetMapStatus(currentMapCenterLatLng, currentZoom);
            onHwDensityClick(controllerBean.isShowHWSiteDensity());
        } else {
            binding.smCityOperator.setText(selCity + "/" + selOper);
            if (myProvinceName.contains(provinceName) && myCityName.contains(cityName)) {
                currentMapCenterLatLng = myLocationLatLng;
            }
            resetMapStatus(currentMapCenterLatLng, DEFAULT_ZOOM);

            if (isLastCity) {
                changeOper();
            } else {
                isFirstEnter = true;
                mapChange(mBaiduMap.getMapStatus());
            }
        }
    }

    private void changeOper() {
        if (currentAreaSiteBean != null) {
            currentAreaSiteBean.setNetOper(enCarrier);
            isMapMove = true;
            if (controllerBean.isShowSite()) {
                // 查询异厂商<站点开关+室分/宏站开关>
                if (controllerBean.isShowOutdoorSite() | controllerBean.isShowIndoorSite() | !isShow4g) {
                    siteResultListAll.clear();
                    isClearMarker = true;
                    mBaiduMap.clear();
                    queryIncSite(currentAreaSiteBean, currentBounds, currentZoom);
                }
            }
            requestMapOverlayFromNet();

        }
        // 1.1华为热力图
        if (controllerBean.isShowHWSiteDensity()) {// 省鸟瞰打开，继续鸟瞰
            requestHeatMapServer(provinceName, enCarrier);
            requestHwCityGrideData(provinceName, enCarrier);
        }
    }


    /**
     * 根据经纬度和zoom改变地图
     */
    private void resetMapStatus(LatLng latLng, float zoom) {
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    /**
     * 不能上报对话框
     */
    private void showCannotComplainDialog() {
        CannotComplainDialog cannotComplainDialog = new CannotComplainDialog(new CannotComplainDialog.OnDialogClickListener() {
            @Override
            public void onSureClick() {
                // 2.恢复地图到所在位置
                resetMapStatus(currentMapCenterLatLng = myLocationLatLng, DEFAULT_ZOOM);
                // 3.回退省市
                resetAddrText(cityName = myCityName, cnCarrier);
                isCanComplain = true;
                binding.rlContainerSurvey.removeAllViews();
                binding.rlContainerSurvey.addView(addSiteTypeView.getView());
                addSiteTypeView.recordType = -1;
                delayHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        binding.addBgView.setVisibility(View.VISIBLE); // 4.延迟弹上报窗
                    }
                }, 1000);
            }
        });
        cannotComplainDialog.show(getChildFragmentManager(), CannotComplainDialog.class.getName());
    }

    /**
     * 设置站点模式<室内和宏站>,非对立关系
     */
    private void setSiteShowType() {
        if (controllerBean.isShowOutdoorSite()) {
            binding.outSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            SiteUtils.setMapMarkerStatus(outerSiteMarkers,
                    TypeEnum.MarkerStatus.SHOW, controllerBean.isShowPatternSite());
        } else {
            binding.outSiteTip.setTextColor(Color.parseColor("#666666"));
            binding.outSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        }

        if (controllerBean.isShowIndoorSite()) {
            binding.innerSiteTip.setTextColor(Color.parseColor("#6FBAFF"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            SiteUtils.setMapMarkerStatus(innerSiteMarkers,
                    TypeEnum.MarkerStatus.SHOW, controllerBean.isShowPatternSite());
        } else {
            binding.innerSiteTip.setTextColor(Color.parseColor("#666666"));
            binding.innerSiteTip.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.HIDE);
        }

    }

    /**
     * 查询体验标点
     */
    private void queryExperienceSite(String province, String cityName, String netOperator) {
        if (TextUtils.isEmpty(province) || TextUtils.isEmpty(cityName) || TextUtils.isEmpty(netOperator)) {
            showMsg("查询体验标点参数错误，存在空值");
            return;
        }
        boolean isEmpty = experienceMarkers.size() == 0;
        if (!cityName.equals(preExperienceCity) || !netOperator.equals(preExperienceNetOper) || isEmpty) {
            // 和上次请求不同,或为空marker
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.CLEAR);
            requestExperienceServer(province, cityName, netOperator);
        } else {
            SiteUtils.setMapMarkerStatus(experienceMarkers, TypeEnum.MarkerStatus.CLEAR);
            LatLng latLng;
            for (ExperienceSiteInfo exInfo : experienceList) {
                if (controllerBean.isShowMarkType(exInfo.getRecordType())) {
                    latLng = new LatLng(exInfo.getLat(), exInfo.getLng());
                    MarkerOptions exMarkerOption = SiteUtils.getExperienceMarkerOption(exInfo, latLng, false);

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("info", exInfo);
                    bundle.putString("markerType", "feelPointMarker");
                    exMarkerOption.extraInfo(bundle);

                    Marker exMarker = (Marker) mBaiduMap.addOverlay(exMarkerOption);
                    exMarker.setToTop();
                    experienceMarkers.add(exMarker);
                }
            }
        }
    }

    //设置信号控件的显示状态
    private void showSignalViewVisiable(boolean isVisiable) {
        if (isVisiable) {
            binding.signalStrengthLayout.setVisibility(View.VISIBLE);
            binding.siteviewRsrpTv.setVisibility(View.VISIBLE);
            binding.siteviewSnrTv.setVisibility(View.VISIBLE);
            binding.siteviewRsrpTv.setAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.show_alpha));
            binding.siteviewSnrTv.setAnimation(AnimationUtils.loadAnimation(requireContext(), R.anim.show_alpha));
        } else {
            binding.signalStrengthLayout.setVisibility(View.GONE);
        }
    }


    @SuppressWarnings("deprecation")
    private void startNavigation(LatLng distLatLng) {
        if (distLatLng != null && myLocationLatLng != null) {
            if (AppUtil.checkAppInstalled(requireContext(), "com.baidu.BaiduMap") == null) {
                NaviParaOption naviParaOption = new NaviParaOption();
                naviParaOption.startPoint(myLocationLatLng);
                naviParaOption.endPoint(distLatLng);
                try {
                    BaiduMapNavigation.setSupportWebNavi(true);
                    boolean isSuccess = BaiduMapNavigation.openBaiduMapNavi(naviParaOption, requireContext());
                    if (!isSuccess) {
                        new InstalledDialog().show(getChildFragmentManager(), "");
                    }
                } catch (BaiduMapAppNotSupportNaviException e) {
                    GCLogger.error(Module.GENEX_CLOUD, "open GPS navigation Exception:" + e.toString());
                    new InstalledDialog().show(getChildFragmentManager(), "");
                }
            } else {
                new InstalledDialog().show(getChildFragmentManager(), "");
            }

        } else {
            showMsg("请确认选择了正确的起点和终点！");
        }
    }

    private void createSearchDialog() {

        if (searchResultDialog == null) {
            searchResultDialog = new SearchResultDilog(requireContext());
            searchResultDialog.setOnPoiItemSelectListener(new SearchResultDilog.OnPoiItemSelectListener() {
                @Override
                public void onSelect(SuggestionResult.SuggestionInfo bean) {
                    resetMapStatus(bean.pt, DEFAULT_ZOOM);
                    showMsg("已为您移至" + bean.key);
                }
            });
            searchResultDialog.setOnSiteItemSelectListener(new SearchResultDilog.OnSiteItemSelectListener() {
                @Override
                public void onSelect(SiteBaseBean bean) {
                    searchSiteInfo = bean;
                    resetMapStatus(new LatLng(bean.getLat(), bean.getLng()), DEFAULT_ZOOM);
                }
            });
        }

        searchResultDialog.setPoiDataList(null, null);
        searchResultDialog.setSiteDataList(null, null);
    }

    /**
     * 清空所有站点marker
     */
    private void clearExistIncSiteMarkers() {
        if (clickMarkerIndicator != null) {
            mBaiduMap.hideInfoWindow();
        }
        SiteUtils.setMapMarkerStatus(innerSiteMarkers, TypeEnum.MarkerStatus.CLEAR);
        SiteUtils.setMapMarkerStatus(outerSiteMarkers, TypeEnum.MarkerStatus.CLEAR);
    }

    // 设置省市文本
    private void resetAddrText(String city, String netOper) {
        if (!TextUtils.isEmpty(city) && binding.smCityOperator != null) {
            city = AddrNameUtils.getFullCityName(requireContext(), city);
            binding.smCityOperator.setText(city.replaceAll("市", "") + "/" + netOper);
        }
    }


    // 搜索站点
    private void searchAreaSite(final String search) {
        SearchSiteBean bean = new SearchSiteBean();
        Gps gps = PositionUtils.bd09_To_Gps84(currentMapCenterLatLng.latitude, currentMapCenterLatLng.longitude);
        bean.setLUpLat(gps.getWgLat());
        bean.setLUpLng(gps.getWgLon());
        if (TextUtils.isEmpty(search)) {
            bean.setSearch(AddrNameUtils.getAliasCityName(requireContext(), myCityName));
        } else {
            bean.setSearch(search);
        }
        bean.setNetOper(enCarrier);
        bean.setCurrCity(cityName);
        bean.setNetworkType(getNetWorkType());
        searchSiteInfo = null;// 搜索即重置成员变量
        createSearchDialog();
        SearchSiteInfoImpl.getInstance().querySiteInfo(bean, new SearchSiteInfoImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg("未找到相关基站");
            }

            @Override
            public void onResponse(Map<String, List> map) {
                List<SuggestionResult.SuggestionInfo> baiduBeans = map.get(SearchSiteInfoImpl.KEY_BAIDU);
                List<SiteBaseBean> siteBeans = map.get(SearchSiteInfoImpl.KEY_SITE);
                boolean isHasBaidu = baiduBeans != null && baiduBeans.size() > 0;
                boolean isHasSite = null != siteBeans && siteBeans.size() > 0;
                if (isHasBaidu || isHasSite) {
                    if (isHasBaidu) {
                        searchResultDialog.setPoiDataList(baiduBeans, binding.smSearchEdit.getText().toString());
                    } else {
                        String baiduEmptyStr = String.format("未找到有关 %s 的地理信息", binding.smSearchEdit.getText().toString());
                        showMsg(baiduEmptyStr);
                    }
                    if (isHasSite) {
                        searchResultDialog.setSiteDataList(siteBeans, binding.smSearchEdit.getText().toString());
                    } else {
                        showMsg("未找到相关基站");
                    }
                    showSearchResultDialog();
                } else {
                    showMsg("未找到相关基站");
                }
            }
        });
    }

    // 请求体验标点
    private void requestExperienceServer(String province, String cityName, String netOperator) {
        QueryExperienceSiteListImpl.getInstance().getExperienceSiteList(province, cityName, netOperator, new QueryExperienceSiteListImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {}

            @Override
            public void onResponse(List<ExperienceSiteInfo> response) {
                drawBaiduMapOverlays(INDEX_EXPERIENCE, (ArrayList<ExperienceSiteInfo>) response);
            }
        });

        preExperienceCity = cityName;
        preExperienceNetOper = netOperator;
    }

    /**
     * 请求华为热力图
     */
    private void requestHeatMapServer(String province, String operatorEn) {
        CityInfo info = CacheUtil.getInstance().getProvince(province);
        if (info == null) {
            return;
        }

        AppDatabase database = AppDatabase.getInstance(BaseApplication.getAppContext());
        HeatMapDataDao heatMapDataDao = database.heatMapDataDao();
        if (huaweiIncHeatmap != null) {
            huaweiIncHeatmap.removeHeatMap();
        }

        List<HeatMapData> heatMapDataList = heatMapDataDao.queryLatLngList(province, operatorEn, getNetWorkType());
        if (heatMapDataList != null && heatMapDataList.size() > 0) {
            List<LatLng> latLngList = new ArrayList<>();
            for (HeatMapData data : heatMapDataList) {
                latLngList.add(new LatLng(data.lat, data.lng));
            }
            mBaiduMap.addHeatMap(huaweiIncHeatmap = new HeatMap.Builder().data(latLngList).build());
            return;
        }

        // 3.请求网络
        ReqMapDataBean heatReqBean = new ReqMapDataBean();
        heatReqBean.setSpell(info.proSpell);
        heatReqBean.setNetOperator(operatorEn);
        heatReqBean.setProvince(province);
        heatReqBean.setNetWorkType(getNetWorkType());
        QueryProvinceSiteInfoImpl.getInstance().querySiteInfo(heatReqBean, new QueryProvinceSiteInfoImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                showMsg("暂无数据，请稍后再试！");
            }

            @Override
            public void onResponse(List<LatLng> response) {
                mBaiduMap.addHeatMap(huaweiIncHeatmap = new HeatMap.Builder().data(response).build());
            }
        });
    }

    private String getNetWorkType() {
        return isShow4g ? "4G" : "5G";
    }

    /**
     * 请求华为市站点数量
     */
    private void requestHwCityGrideData(String province, String netOper) {

        siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE, new CityGrideDataBean(province, null, false), isShow4g);

        QueryAreaSiteBean reqBean = new QueryAreaSiteBean();
        reqBean.setProvince(province);
        reqBean.setNetOper(netOper);
        reqBean.setNetWorkType(getNetWorkType());

        QueryCitySiteNumImpl.getInstance().querySiteNum(reqBean, new QueryCitySiteNumImpl.Callback() {
            @Override
            public void onFailure(ErrorBean e) {
                siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE,
                        new CityGrideDataBean(provinceName, null, true), isShow4g);
            }

            @Override
            public void onResponse(List<CityGrideSiteResp> response) {
                siteDetailView.setCurrentSiteType(TypeEnum.SiteDetailType.CITY_GRIDE,
                        new CityGrideDataBean(provinceName, (ArrayList<CityGrideSiteResp>) response, false), isShow4g);
            }
        });
    }

    //取四位数字方法
    private double num4P(double source) {
        return Formatter.formatDouble4Point(source);
    }

    //插入体验标点
    @Override
    public void commitData(ExperienceSiteInfo experienceSiteInfo) {
        experienceSiteInfo.setProvince(provinceName.replace("省", ""));
        experienceSiteInfo.setCityName(selCity.replace("市", ""));
        //标点的经纬度
        if (currentMapCenterLatLng != null) {
            experienceSiteInfo.setLat(currentMapCenterLatLng.latitude);
            experienceSiteInfo.setLng(currentMapCenterLatLng.longitude);
        } else {
            showMsg("没有位置信息");
            return;
        }

        InsertSupportRecordImpl.getInstance().queryInsertRecordInfo(experienceSiteInfo, new InsertSupportRecordImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg("上传标点信息失败！");
            }
            @Override
            public void onResponse(String response) {
                showMsg("感谢您的反馈！");
                if (binding.expPointMarker.getVisibility() == View.VISIBLE) {
                    queryExperienceSite(provinceName, cityName, enCarrier);
                }
                binding.addBgView.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void selectPhotoType(int type, Intent intent) {
//        if (type == 0) { //从相册中选择
//            startActivityForResult(intent, SELECT_PHOTO);//跳转，传递打开相册请求码
//        } else if (type == 1) {
//            startActivityForResult(intent, CREAM);
//        }
    }

    private Context requireContext() {
        if (homePage != null) {
            return homePage.requireContext();
        }
        return null;
    }

    private Activity requireActivity() {
        if (homePage != null) {
            return homePage.requireActivity();
        }
        return null;
    }

    private void showMsg(final String message) {
        if (homePage != null) {
            homePage.showMsg(message);
        }
    }

    private FragmentManager getChildFragmentManager() {
        if (homePage != null) {
            return homePage.getChildFragmentManager();
        }
        return null;
    }

    /**
     * 切换fragment
     */
    private void push(Fragment fragment) {
        if (homePage != null) {
            homePage.push(fragment);
        }
    }

    /**
     * 显示loading Dialog
     */
    private void showLoadingDialog() {
        if (homePage != null) {
            homePage.showLoadingDialog();
        }
    }

    /**
     * 隐藏loading Dialog
     */
    private void dismissLoadingDialog() {
        if (homePage != null) {
            homePage.dismissLoadingDialog();
        }
    }


}
