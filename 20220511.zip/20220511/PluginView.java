package com.huawei.genexcloud.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.Observer;

import com.huawei.genexcloud.bean.PluginBean;
import com.huawei.genexcloud.bean.PluginBeanWrapper;
import com.huawei.genexcloud.http.download.DownloadEntry;

import com.huawei.genexcloud.databinding.PluginViewBinding;
import com.huawei.genexcloud.http.download.DownloadState;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.plugin.GCPluginManager;
import com.huawei.genexcloud.util.AppUtil;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.qihoo360.replugin.model.PluginInfo;

/**
 * 主页 插件视图  图表、文字、进度条
 */
public class PluginView extends CardView {

    private PluginViewBinding binding;
    private boolean pluginInstalled = false;
    private boolean pluginNeedUpdate = false;
    private PluginBeanWrapper wrapper;
    // 插件各种事件监听
    private PluginActionListener listener;

    public PluginView(@NonNull Context context) {
        this(context, null);
    }

    public PluginView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PluginView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        binding = PluginViewBinding.inflate(LayoutInflater.from(getContext()), this);
    }

    /**
     * 绑定插件数据
     * @param wrapper
     */
    public void setPluginBean(PluginBeanWrapper wrapper) {
        this.wrapper = wrapper;
        if (null == wrapper || null == wrapper.pluginBean) {
            binding.icon.setImageBitmap(null);
            binding.name.setText("");
            binding.tag.setVisibility(View.GONE);
            binding.progress.setVisibility(View.GONE);
        } else {
            binding.icon.setImageURI(wrapper.pluginBean.getPluginImagePath());
            binding.name.setText(wrapper.pluginBean.showName);
            binding.tag.setVisibility(View.GONE);
            binding.progress.setVisibility(View.GONE);
        }
        bindPluginState(wrapper);
        // 设置点击事件
        setClickAction(wrapper);
    }

    /**
     * 绑定插件数据状态
     * @param wrapper
     */
    private void bindPluginState(PluginBeanWrapper wrapper) {
        if (null == wrapper || null == wrapper.pluginBean) {
            return;
        }
        PluginBean plugin = wrapper.pluginBean;
        String packageName = plugin.packageName;
        String startActivity = plugin.startActivity;

        // 是否安装
        pluginInstalled = GCPluginManager.isPluginInstalled(packageName);
        // 是否需要升级
        pluginNeedUpdate = GCPluginManager.needUpdate(plugin);

        binding.icon.setImageURI(wrapper.pluginBean.getPluginImagePath());
        binding.name.setText(wrapper.pluginBean.showName);
        binding.progress.setVisibility(View.GONE);

        if (!pluginInstalled) {
            binding.tag.setText("未安装");
            binding.tag.setVisibility(View.VISIBLE);
        } else if (pluginNeedUpdate) {
            // 需要升级
            binding.tag.setText("更新");
            binding.tag.setVisibility(View.VISIBLE);
        } else {
            binding.tag.setVisibility(View.GONE);
        }

        // 如果未安装或者需要升级 需要监听下载事件
        if (!pluginInstalled || pluginNeedUpdate) {
            LiveEventBus.get(DownloadEntry.class).observeForever(entry -> {
                if (isSameTarget(wrapper, entry) && null != getContext()) {
                    // 是该view绑定的插件信息的下载状态更新
                    updateState(entry);
                }
            });
        }
    }

    /**
     * 设置插件事件监听
     * @param pluginActionListener
     */
    public void setPluginActionListener(PluginActionListener pluginActionListener) {
        this.listener = pluginActionListener;
        GCLogger.error("view", "pluginview  设置listener ：" + listener);
    }

    private void updateState(DownloadEntry entry) {
        if (null == entry) {
            return;
        }
        binding.progress.setVisibility(View.GONE);
        // 根据下载状态更新界面
        switch (entry.getState()) {
            case DownloadState.STATE_IDLE:
                // 未进行下载任务 界面无修改
                break;
            case DownloadState.STATE_WAIT:
                // 下载链接中 显示进度条
                binding.progress.setVisibility(View.VISIBLE);
                binding.progress.setMax(100);
                binding.progress.setProgress(0);
                binding.tag.setVisibility(View.VISIBLE);
                binding.tag.setText("连接中");
                break;
            case DownloadState.STATE_DOWNLOADING:
                // 下载中
                binding.progress.setVisibility(View.VISIBLE);
                binding.progress.setMax((int) entry.getLength());
                binding.progress.setProgress((int) entry.getCurrentLength());
                binding.tag.setVisibility(View.VISIBLE);
                binding.tag.setText("下载中");
                break;
            case DownloadState.STATE_FAILED:
                // 下载失败
                binding.progress.setVisibility(View.GONE);
                if (!pluginInstalled) {
                    binding.tag.setVisibility(View.VISIBLE);
                    binding.tag.setText("未安装");
                } else if (pluginNeedUpdate) {
                    binding.tag.setVisibility(View.VISIBLE);
                    binding.tag.setText("升级");
                } else {
                    binding.tag.setVisibility(View.GONE);
                }
                if (null != listener) {
                    listener.onDownloadFailed(wrapper);
                }
                break;
            case DownloadState.STATE_SUCCESS:
                // 下载成功
                if (null != listener) {
                    listener.onDownloadSuccess(wrapper);
                }
                binding.progress.setVisibility(View.GONE);
                PluginInfo pluginInfo = GCPluginManager.installPlugin(wrapper);
                if (null != pluginInfo) {
                    // 安装成功
                    if (null != listener) {
                        listener.onInstallCompleted(wrapper);
                    }
                    pluginInstalled = true;
                    pluginNeedUpdate = false;
                    binding.tag.setVisibility(View.GONE);
                    entry.setState(DownloadState.STATE_OK);
                } else {
                    // 安装失败
                    if (null != listener) {
                        listener.onInstallFailed(wrapper);
                    }
                    if (!pluginInstalled) {
                        binding.tag.setVisibility(View.VISIBLE);
                        binding.tag.setText("未安装");
                    } else if (pluginNeedUpdate) {
                        binding.tag.setVisibility(View.VISIBLE);
                        binding.tag.setText("升级");
                    } else {
                        binding.tag.setVisibility(View.GONE);
                    }
                    entry.setState(DownloadState.STATE_IDLE);
                }
                break;
            case DownloadState.STATE_OK:
                binding.progress.setVisibility(View.GONE);
                break;
        }
    }


    /**
     * 设置点击事件
     * @param wrapper
     */
    private void setClickAction(PluginBeanWrapper wrapper) {
        setOnClickListener(v -> {
            if (AppUtil.isFastDoubleClick()) {
                return;
            }
            if (null == wrapper) {
                return;
            }
            // 点击了未绑定具体插件信息的view 主页是点击了更多插件
            if (null == wrapper.pluginBean) {
                if (null != listener) {
                    listener.onMorePlugin();
                }
                return;
            }
            if (pluginInstalled && !pluginNeedUpdate) {
                // 已安装切无需升级 点击打开
                if (null != listener) {
                    listener.onOpenPlugin(wrapper);
                }
            } else if (!pluginInstalled) {
                // 未安装 需要判断是否在下载
                if (null != wrapper && null != listener && null != wrapper.getDownloadEntry()) {
                    switch (wrapper.getDownloadEntry().getState()) {
                        case DownloadState.STATE_IDLE:
                        case DownloadState.STATE_FAILED:
                        case DownloadState.STATE_SUCCESS:
                        case DownloadState.STATE_OK:
                            // 插件没有在下载中 需要发出下载插件事件
                            if (null != listener) {
                                listener.onNeedInstall(wrapper);
                            }
                            break;
                        case DownloadState.STATE_WAIT:
                        case DownloadState.STATE_DOWNLOADING:
                            // TODO 插件下载中 点击事件待定义
                            break;
                    }
                } else {
                    GCLogger.error("error", "未绑定插件信息");
                }
            } else if (pluginNeedUpdate) {
                // 插件需要升级 依然要判断插件是否下载中
                switch (wrapper.getDownloadEntry().getState()) {
                    case DownloadState.STATE_IDLE:
                    case DownloadState.STATE_FAILED:
                    case DownloadState.STATE_SUCCESS:
                    case DownloadState.STATE_OK:
                        // 插件没有在下载中 需要发出下载插件事件
                        if (null != listener) {
                            listener.onNeedUpdate(wrapper);
                        }
                        break;
                    case DownloadState.STATE_WAIT:
                    case DownloadState.STATE_DOWNLOADING:
                        // TODO 插件下载中 点击事件待定义
                        break;
                }
            }
        });
    }

    /**
     * 判断下载中的插件是否是当前插件
     * @param wrapper  当前插件
     * @param entry 下载中的插件
     * @return
     */
    private boolean isSameTarget(PluginBeanWrapper wrapper, DownloadEntry entry) {
        if (null == wrapper || null == wrapper.pluginBean) {
            return false;
        }
        DownloadEntry localEntry = wrapper.getDownloadEntry();
        if (null == localEntry || null == entry) {
            return false;
        }
        if (null == localEntry.getUrl() || !localEntry.getUrl().equals(entry.getUrl())) {
            return false;
        }
        if (localEntry != entry) {
            wrapper.setDownloadEntry(entry);
        }
        return true;
    }

    public interface PluginActionListener {
        // 插件未安装时的点击事件
        void onNeedInstall(PluginBeanWrapper wrapper);
        // 插件需升级时点击事件
        void onNeedUpdate(PluginBeanWrapper wrapper);
        // 下载成功事件
        void onDownloadSuccess(PluginBeanWrapper wrapper);
        // 下载失败事件
        void onDownloadFailed(PluginBeanWrapper wrapper);
        // 安装插件成功事件
        void onInstallCompleted(PluginBeanWrapper wrapper);
        // 安装插件失败事件
        void onInstallFailed(PluginBeanWrapper wrapper);
        // 打开插件事件
        void onOpenPlugin(PluginBeanWrapper wrapper);
        // 更多插件  选项点击
        void onMorePlugin();
    }
}
