package com.huawei.genexcloud.permission.dialog;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.databinding.ItemPopMenuBinding;
import com.huawei.genexcloud.databinding.PopMenuBinding;

import java.util.List;

public class SpinnerPopWindow extends PopupWindow {

    private List<String> options;
    private String selectedOption;

    private PopMenuBinding binding;
    private SpinnerAdapter adapter;
    private OnMenuItemSelectedListener onMenuItemSelectedListener;

    public SpinnerPopWindow(Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        binding = PopMenuBinding.inflate(LayoutInflater.from(context));
        adapter = new SpinnerAdapter();
        adapter.setData(options, null);

        binding.list.setLayoutManager(new LinearLayoutManager(context));
        binding.list.setAdapter(adapter);

        setContentView(binding.getRoot());
        setBackgroundDrawable(new ColorDrawable(0x33000000));

        setOutsideTouchable(false);
    }

    public void setOptions(List<String> options) {
        this.options = options;
        adapter.setData(options, selectedOption);
    }

    public void setSelectedOption(String selectedOption) {
        this.selectedOption = selectedOption;
        adapter.setData(options, selectedOption);
    }

    public void setOnMenuItemSelectedListener(OnMenuItemSelectedListener onMenuItemSelectedListener) {
        this.onMenuItemSelectedListener = onMenuItemSelectedListener;
        adapter.setMenuSelectedListener(onMenuItemSelectedListener);
    }


    /**
     * 下拉选择菜单的list适配器
     */
    private class SpinnerAdapter extends RecyclerView.Adapter<SpinnerAdapter.ViewHolder> {

        private final int colorUnselected = 0xFF1C1C1C;
        private final int colorSelected = 0xFF4F7AFD;


        private List<String> data;
        private String selected;

        private OnMenuItemSelectedListener onMenuItemSelectedListener;

        public void setData(List<String> data, String selected) {
            this.data = data;
            this.selected = selected;
            notifyDataSetChanged();
        }

        public void setMenuSelectedListener(OnMenuItemSelectedListener onMenuItemSelectedListener) {
            this.onMenuItemSelectedListener = onMenuItemSelectedListener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemPopMenuBinding binding = ItemPopMenuBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new ViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String currentItem = data.get(position);
            holder.binding.text.setText(currentItem);
            if (!TextUtils.isEmpty(selected) && selected.equals(currentItem)) {
                holder.binding.text.setTextColor(colorSelected);
            } else {
                holder.binding.text.setTextColor(colorUnselected);
            }
            holder.binding.getRoot().setOnClickListener(v-> {
                if (null != onMenuItemSelectedListener) {
                    onMenuItemSelectedListener.onSelected(currentItem);
                    // TODO
                    dismiss();
                }
            });
        }

        @Override
        public int getItemCount() {
            return null == data? 0 : data.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            private ItemPopMenuBinding binding;
            private TextView textView;

            public ViewHolder(@NonNull ItemPopMenuBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }

    public interface OnMenuItemSelectedListener {
        void onSelected(String menuContent);
    }
}
