package com.huawei.genexcloud.base;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDex;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.backends.okhttp3.OkHttpImagePipelineConfigFactory;
import com.huawei.genexcloud.http.util.OkHttpManager;
import com.huawei.genexcloud.util.CrashHandler;
import com.huawei.genexcloud.util.PathUtil;
import com.huawei.genexcloud.widget.refresh.LoadingHeader;
import com.qihoo360.replugin.RePluginApplication;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.scwang.smart.refresh.layout.api.RefreshFooter;
import com.scwang.smart.refresh.layout.api.RefreshHeader;
import com.scwang.smart.refresh.layout.api.RefreshLayout;
import com.scwang.smart.refresh.layout.listener.DefaultRefreshFooterCreator;
import com.scwang.smart.refresh.layout.listener.DefaultRefreshHeaderCreator;
import com.tencent.mmkv.MMKV;

public class BaseApplication extends RePluginApplication {

    private static BaseApplication instance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = BaseApplication.this;
        initCrashHandler();
        initHttpManager();
        initMMKV();
        initFresco();
        initGlobalRefreshHeaderFooter();
        PathUtil.init(this);
    }

    public static BaseApplication getAppContext() {
        return instance;
    }

    private void initCrashHandler() {
        PathUtil.init(getApplicationContext());
        CrashHandler.getInstance().init(getApplicationContext());
    }

    private void initHttpManager() {
        OkHttpManager.initClient(getApplicationContext());
    }

    private void initMMKV() {
        MMKV.initialize(this);
    }

    private void initFresco() {
        Fresco.initialize(this, OkHttpImagePipelineConfigFactory.newBuilder(this, OkHttpManager.getImageClient(this)).build());
    }

    private void initGlobalRefreshHeaderFooter() {
        SmartRefreshLayout.setDefaultRefreshHeaderCreator(new DefaultRefreshHeaderCreator() {
            @NonNull
            @Override
            public RefreshHeader createRefreshHeader(@NonNull Context context, @NonNull RefreshLayout layout) {
                return new LoadingHeader(context);
            }
        });
        SmartRefreshLayout.setDefaultRefreshFooterCreator(new DefaultRefreshFooterCreator() {
            @NonNull
            @Override
            public RefreshFooter createRefreshFooter(@NonNull Context context, @NonNull RefreshLayout layout) {
                return new ClassicsFooter(context);
            }
        });
    }
}
