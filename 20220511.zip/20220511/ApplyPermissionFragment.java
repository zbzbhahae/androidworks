package com.huawei.genexcloud.fragment;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.huawei.genexcloud.BuildConfig;
import com.huawei.genexcloud.base.AutoNavFragment;
import com.huawei.genexcloud.databinding.FragmentPermissionApplyBinding;
import com.huawei.genexcloud.http.ApplyGCPermission;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.permission.common.PermissionConstants;
import com.huawei.genexcloud.util.ShareDataUtil;

import okhttp3.Request;

public class ApplyPermissionFragment extends AutoNavFragment implements View.OnClickListener {

    private FragmentPermissionApplyBinding binding;
    // 短信发送结果广播接收器
    private SendStatusReceiver sendStatusReceiver;
    // 用户账户
    private String account;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPermissionApplyBinding.inflate(getLayoutInflater(), container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView();
        initData();
    }

    private void initView() {

    }
    private void initData() {
        account = ShareDataUtil.getUserName(getContext());

        // 接受短信发送结果的广播
        sendStatusReceiver = new SendStatusReceiver();
        IntentFilter sendFilter = new IntentFilter();
        sendFilter.addAction("SENT_SMS_ACTION");
        getContext().registerReceiver(sendStatusReceiver, sendFilter);

        binding.messageSwitch.setChecked(false);
        binding.accountInput.setText(account);

        binding.back.setOnClickListener(this);
        binding.applyPermissionBtn.setOnClickListener(this);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if (null != sendStatusReceiver && null != getContext()) {
            getContext().unregisterReceiver(sendStatusReceiver);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == binding.back) {
            backPressed();
        } else if (v == binding.applyPermissionBtn) {
            goApplyGCPermission();
        }
    }

    /**
     * 去申请GC权限
     */
    private void goApplyGCPermission() {
        String name = binding.nameInput.getText().toString().trim();
        String phoneNumber = binding.phoneInput.getText().toString().trim();
        String reason = binding.reasonInput.getText().toString().trim();

        if (TextUtils.isEmpty(account)) {
            showMsg("无法获取账号信息!");
            return;
        } else if (TextUtils.isEmpty(name)) {
            showMsg("请输入姓名!");
            return;
        } else if (TextUtils.isEmpty(phoneNumber) || !TextUtils.isDigitsOnly(phoneNumber)) {
            showMsg("请输入正确的电话号码!");
            return;
        } else if (TextUtils.isEmpty(reason)) {
            showMsg("请输入申请理由!");
            return;
        }

        if (binding.messageSwitch.isChecked()) {
            // 需要发送短信 检查权限
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                // 未授权 去授权
                // TODO 电话号码网络获取
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.SEND_SMS}, 100);
                return;
            } else {
                // 授权过 发送短信
                sendTextMessageToAdmin(account, name);
            }
        }
        // 发送申请权限的请求
        ApplyGCPermission.getInstance().applyPermission(name, phoneNumber, reason, PermissionConstants.MODEL_ID_GC, new ApplyGCPermission.GCApplyCallback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onResponse(Boolean response) {
                // TODO 申请权限成功后处理逻辑
                if (response) {
                    showMsg("申请成功！");
//                    // 申请操作成功
//                    backPressed();
                }
            }
        });

    }

    /**
     * 给管理员发送短信
     * @param account
     * @param name
     */
    private void sendTextMessageToAdmin(String account, String name) {
        SmsManager smsManager = SmsManager.getDefault();
        Intent sentIntent = new Intent("SENT_SMS_ACTION");
        PendingIntent pi = PendingIntent.getBroadcast( getContext(), 0, sentIntent, 0);
        // 需要上级查询是否发过申请，未申请过需要管理员的联系方式
        try {
            smsManager.sendTextMessage(BuildConfig.ADMIN_NUMBER, null, name + "(工号" + account + ")"
                    + "申请GENEXCloud APP使用权限，请及时审批。谢谢！", pi, null);
        } catch (Exception e) {
            showMsg("短信发送失败，请检查后重试");
            GCLogger.error("error", "sendTextMessage Exception E=" + e.toString());
        }
    }

    class SendStatusReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (getResultCode() == Activity.RESULT_OK) {
                // 短信发送成功
                showMsg("短信发送成功");
            } else {
                // 短信发送失败
                showMsg("短信发送失败");
            }
        }
    }
}
