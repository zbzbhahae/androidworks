package com.huawei.genexcloud.page;

import static com.huawei.genexcloud.common.SharePreferenceKey.FIRST_LOGIN_KEY;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.transition.TransitionInflater;
import androidx.viewpager2.widget.ViewPager2;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.adapter.AdvBannerAdapter;
import com.huawei.genexcloud.adapter.InformationAdapter;
import com.huawei.genexcloud.adapter.MainPluginViewAdapter;
import com.huawei.genexcloud.base.BaseActivity;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.base.BaseFragment;
import com.huawei.genexcloud.bean.AdvBean;
import com.huawei.genexcloud.bean.AdvListResultBean;
import com.huawei.genexcloud.bean.AppUpdateVersionBean;
import com.huawei.genexcloud.bean.InformationBean;
import com.huawei.genexcloud.bean.PluginBeanWrapper;
import com.huawei.genexcloud.bean.PluginResultBean;
import com.huawei.genexcloud.bean.PluginBean;
import com.huawei.genexcloud.databinding.PageHomeBinding;
import com.huawei.genexcloud.dialog.AgreementConsentDialog;
import com.huawei.genexcloud.dialog.ApkUpdateDialog;
import com.huawei.genexcloud.dialog.ConfirmCancelDialog;
import com.huawei.genexcloud.fragment.PluginManageFragment;
import com.huawei.genexcloud.fragment.SearchFragment;
import com.huawei.genexcloud.fragment.TodoListFragment;
import com.huawei.genexcloud.http.QueryAllPluginListImpl;
import com.huawei.genexcloud.http.QueryAdvertisementListImpl;
import com.huawei.genexcloud.http.QueryAppVersionImpl;
import com.huawei.genexcloud.http.QueryLocationImpl;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.logger.Module;
import com.huawei.genexcloud.plugin.GCPluginManager;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.util.CrashHandler;
import com.huawei.genexcloud.util.ShareDataUtil;
import com.huawei.genexcloud.util.SharedPreferenceUtil;
import com.huawei.genexcloud.widget.PluginView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomePage extends BaseFragment implements View.OnClickListener {

    private PageHomeBinding binding;
    private MainPluginViewAdapter pluginViewAdapter;
    private AdvBannerAdapter bannerAdapter;
    private InformationAdapter informationAdapter;
    private int currentIndicatorPos = 0;
    private final int DELAY_SECONDS = 5000;
    private LocationManager locationManager;

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            locationManager.removeUpdates(locationListener);
            GCLogger.error(Module.GENEX_CLOUD, "经度：" + location.getLongitude() + " 纬度：" + location.getLatitude());
            ShareDataUtil.updateLAT(getApplicationContext(), location.getLatitude() + "");
            ShareDataUtil.updateLNG(getApplicationContext(), location.getLongitude() + "");
            QueryLocationImpl.getInstance().getLocation(location.getLongitude(), location.getLatitude(), new QueryLocationImpl.Callback() {

                @Override
                public void onFailure(ErrorBean e) {
                    binding.city.setText("未知区域");
                }

                @Override
                public void onResponse(String response) {
                    binding.city.setText(response);
                }
            });
        }
    };

    private final Runnable bannerLoop = new Runnable() {
        @Override
        public void run() {
            ViewPager2 banner = binding.banner;
            if (banner.getCurrentItem() < bannerAdapter.getItemCount() - 1) {
                banner.setCurrentItem(banner.getCurrentItem() + 1);
                banner.postDelayed(this, DELAY_SECONDS);
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = PageHomeBinding.inflate(getLayoutInflater(), container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initSkeletonDiagram();
        binding.searchLayout.setOnClickListener(this);
        binding.upcomingBtn.setOnClickListener(this);

        // 第一次使用App，弹出法律声明和隐私政策对话框，用户同意后加载数据
        if (SharedPreferenceUtil.readBool(FIRST_LOGIN_KEY, true)) {
            SharedPreferenceUtil.save(FIRST_LOGIN_KEY, false);
            AgreementConsentDialog dialog = new AgreementConsentDialog(new AgreementConsentDialog.Callback() {
                @Override
                public void run() {
                    initData();
                }
            });
            dialog.show(getChildFragmentManager(), "AgreementConsentDialog");
        } else {
            initData();
        }
    }

    // 设置骨架图
    private void initSkeletonDiagram() {
        initPluginSkeletonDiagram();
        initAdvBannerSkeletonDiagram();
        initInformationSkeletonDiagram();
    }

    // 设置插件骨架图
    private void initPluginSkeletonDiagram() {
        pluginViewAdapter = new MainPluginViewAdapter();
        binding.pluginList.setLayoutManager(new GridLayoutManager(requireContext(), 4));
        binding.pluginList.setAdapter(pluginViewAdapter);
        ArrayList<PluginBeanWrapper> pluginWrappers = new ArrayList<>();
        for (int i = 0; i < 8; ++i) {
            pluginWrappers.add(null);
        }

        pluginViewAdapter.setPluginActionListener(pluginActionListener);
        pluginViewAdapter.setData(pluginWrappers);
    }

    private void initData() {
        requestLocationPermission(new BaseActivity.GrantedPermissionCallback() {
            @Override
            public void run() {
                getLocation();
            }
        });
        loadData();
    }

    // 设置广告骨架图
    private void initAdvBannerSkeletonDiagram() {
        binding.banner.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentIndicatorPos = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                if (state == ViewPager2.SCROLL_STATE_IDLE && bannerAdapter.getItemCount() >= 3) {
                    if (currentIndicatorPos == 0) {
                        binding.banner.setCurrentItem(bannerAdapter.getItemCount() - 2, false);
                    } else if (currentIndicatorPos == bannerAdapter.getItemCount() - 1) {
                        binding.banner.setCurrentItem(1, false);
                    }
                }
            }
        });

        requireView().getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
            @Override
            public void onWindowFocusChanged(boolean hasFocus) {
                if (hasFocus) {
                    binding.banner.postDelayed(bannerLoop, DELAY_SECONDS);
                } else {
                    binding.banner.removeCallbacks(bannerLoop);
                }
            }
        });

        binding.banner.getChildAt(0).setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        binding.banner.removeCallbacks(bannerLoop);
                        break;
                    case MotionEvent.ACTION_UP:
                        binding.banner.postDelayed(bannerLoop, DELAY_SECONDS);
                        break;
                }
                return false;
            }
        });

        ArrayList<AdvBean> advBeans = new ArrayList<>();
        advBeans.add(null);
        bannerAdapter = new AdvBannerAdapter(this, advBeans);
        binding.banner.setAdapter(bannerAdapter);
        binding.indicator.setVisibility(View.INVISIBLE);
    }

    // 设置知识&方案骨架图
    private void initInformationSkeletonDiagram() {
        binding.refreshIcon.setVisibility(View.INVISIBLE);
        binding.refreshTxt.setVisibility(View.INVISIBLE);
        binding.refreshBtn.setBackgroundResource(R.color.skeleton);

        binding.infoTitle.setText("");
        binding.infoTitle.setBackgroundResource(R.color.skeleton);

        binding.infoList.setLayoutManager(new LinearLayoutManager(getContext()));
        informationAdapter = new InformationAdapter();
        binding.infoList.setAdapter(informationAdapter);
        ArrayList<InformationBean> infoList = new ArrayList<>();
        for (int i = 0; i < 3; ++i) {
            infoList.add(null);
        }
        informationAdapter.setInfos(infoList);
    }

    private void loadData() {
        checkVersion();
        getMyPluginList();
        getBannerList();
        getKnowledgeAndPlanList();
    }

    private void resetAdvBanner(List<AdvBean> advList) {
        if (advList != null && !advList.isEmpty()) {
            binding.banner.removeCallbacks(bannerLoop);
            bannerAdapter.resetAdvList(advList);
            binding.indicator.setViewPager(binding.banner,
                    bannerAdapter.getItemCount() - 2);
            binding.indicator.setVisibility(View.VISIBLE);
            binding.banner.post(bannerLoop);
        }
    }

    // 检查版本更新
    private void checkVersion() {
        QueryAppVersionImpl.getInstance().getUpdateVersionInfo(new QueryAppVersionImpl.Callback() {
            @Override
            public void onResponse(AppUpdateVersionBean response) {
                // 版本高，提示升级
                if (response.versionCode > AppUtil.getVersionCode(requireContext())) {
                    ApkUpdateDialog dialog = new ApkUpdateDialog(response);
                    dialog.show(getChildFragmentManager(), "ApkUpdateDialog");
                }
            }

            @Override
            public void onFailure(ErrorBean e) {
            }
        });
    }

    // 获取当前插件信息
    private void getMyPluginList() {
        QueryAllPluginListImpl.getInstance().getAppPluginList(
                ShareDataUtil.getUserName(requireContext()),
                AppUtil.getVersionCode(requireContext()),
                new QueryAllPluginListImpl.Callback() {
                    @Override
                    public void onFailure(ErrorBean e) {
                        showMsg(e.message);
                    }

                    @Override
                    public void onResponse(List<PluginBean> plugins) {
                        ArrayList<PluginBeanWrapper> pluginWrappers = new ArrayList<>();
                        for (int i = 0; i < plugins.size() && i < 11; ++i) {
                            pluginWrappers.add(new PluginBeanWrapper(plugins.get(i)));
                        }
                        pluginWrappers.add(new PluginBeanWrapper(null));
                        pluginViewAdapter.setData(pluginWrappers);
                    }
                });
    }

    // 获取banner列表
    private void getBannerList() {
        QueryAdvertisementListImpl.getInstance().getMainAdvList(new QueryAdvertisementListImpl.Callback() {
            @Override
            public void onResponse(List<AdvBean> advList) {
                resetAdvBanner(advList);
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }
        });
    }

    // 获取知识与方案数据
    private void getKnowledgeAndPlanList() {
        binding.refreshIcon.setVisibility(View.VISIBLE);
        binding.refreshTxt.setVisibility(View.VISIBLE);
        binding.refreshBtn.setBackgroundResource(R.color.transparent);

        binding.infoTitle.setText(getString(R.string.k_p));
        binding.infoTitle.setBackgroundResource(R.color.transparent);

        ArrayList<InformationBean> infoList = new ArrayList<>();
        for (int i = 0; i < 5; ++i) {
            infoList.add(new InformationBean());
        }
        informationAdapter.setInfos(infoList);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_layout:
                Fragment newFragment = new SearchFragment();
                newFragment.setSharedElementEnterTransition(
                        TransitionInflater.from(getContext()).inflateTransition(android.R.transition.move));
                ((BaseActivity) requireActivity()).pushShareEle(newFragment,
                        binding.searchIcon, binding.searchLayout);
                break;
            case R.id.upcoming_btn:
                // 点击了右上角的代办消息按钮
                // TODO 有个检查质量工单插件版本的逻辑 需要写
                push(new TodoListFragment());
                break;
        }
    }

    /**
     * 插件事件监听
     */
    private PluginView.PluginActionListener pluginActionListener = new PluginView.PluginActionListener() {
        @Override
        public void onNeedInstall(PluginBeanWrapper wrapper) {
            // 未安装插件 点击事件
            GCPluginManager.downloadPlugin(wrapper);
        }

        @Override
        public void onNeedUpdate(PluginBeanWrapper wrapper) {
            // 弹出是否升级的弹出框
            ConfirmCancelDialog dialog = new ConfirmCancelDialog();
            dialog.setConfirmText("升级")
                    .setBackground(R.drawable.bg_dialog_license)
                    .setCancelText("暂不升级")
                    .setContentText("有新版本可升级")
                    .setConfirmCancelCallback(new ConfirmCancelDialog.ConfirmCancelCallback() {
                        @Override
                        public void onConfirm() {
                            // 升级 下载插件
                            GCPluginManager.downloadPlugin(wrapper);
                        }

                        @Override
                        public void onCancel() {
                            GCPluginManager.openPlugin(getContext(), wrapper);
                        }
                    }).show(getChildFragmentManager());
        }

        @Override
        public void onDownloadSuccess(PluginBeanWrapper wrapper) {
            // 下载插件成功的事件
            if (null != wrapper && null != wrapper.pluginBean) {
                showMsg(wrapper.pluginBean.showName + " 插件下载成功");
            }
        }

        @Override
        public void onDownloadFailed(PluginBeanWrapper wrapper) {
            // 下载插件失败的事件
            if (null != wrapper && null != wrapper.pluginBean) {
                showMsg(wrapper.pluginBean.showName + " 插件下载失败");
            }
        }

        @Override
        public void onInstallCompleted(PluginBeanWrapper wrapper) {
            // 安装插件成功的事件
            if (null != wrapper && null != wrapper.pluginBean) {
                showMsg(wrapper.pluginBean.showName + " 插件安装成功");
            }
        }

        @Override
        public void onInstallFailed(PluginBeanWrapper wrapper) {
            // 安装插件失败的事件
            if (null != wrapper && null != wrapper.pluginBean) {
                showMsg(wrapper.pluginBean.showName + " 插件安装失败");
            }
        }

        @Override
        public void onOpenPlugin(PluginBeanWrapper wrapper) {
            // 打开插件事件
            if (null != wrapper && null != wrapper.pluginBean) {
                GCPluginManager.openPlugin(getContext(), wrapper.pluginBean.packageName,
                        wrapper.pluginBean.startActivity);
            }
        }

        @Override
        public void onMorePlugin() {
            // 点击了 更多应用
            push(new PluginManageFragment());
        }
    };

    private void getLocation() {
        String locationProvider;
        locationManager = (LocationManager) requireActivity().getSystemService(Context.LOCATION_SERVICE);
        List<String> providers = locationManager.getProviders(true);
        if (providers.contains(LocationManager.GPS_PROVIDER)) {
            locationProvider = LocationManager.GPS_PROVIDER;
        } else if (providers.contains(LocationManager.NETWORK_PROVIDER)) {
            locationProvider = LocationManager.NETWORK_PROVIDER;
        } else {
            GCLogger.error(Module.GENEX_CLOUD, "没有任何 LocationProvider");
            return;
        }
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.requestLocationUpdates(locationProvider, 3000, 100, locationListener);
    }
}
