package com.huawei.genexcloud.plugin;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.bean.PluginBean;
import com.huawei.genexcloud.bean.PluginBeanWrapper;
import com.huawei.genexcloud.database.LocalPluginData;
import com.huawei.genexcloud.database.LocalPluginDataDao;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.download.DownloadManager;
import com.qihoo360.replugin.RePlugin;
import com.qihoo360.replugin.model.PluginInfo;

import java.io.File;
import java.util.List;

public class GCPluginManager {

    /**
     * 安装插件apk
     * @param pluginPath 插件路径
     * @return
     */
    public static PluginInfo installPlugin(String pluginPath) {
        if (TextUtils.isEmpty(pluginPath)) {
            return null;
        }
        File pluginFile = new File(pluginPath);
        if (!pluginFile.exists() || !pluginFile.isFile()) {
            return null;
        }
        return installPlugin(pluginFile);
    }
    /**
     * 安装插件apk
     * @param file 插件文件
     * @return
     */
    public static PluginInfo installPlugin(File file) {
        if (null == file || !file.exists()) {
            return null;
        }
        return RePlugin.install(file.getAbsolutePath());
    }

    /**
     * 安装从服务器下载的插件，需要插件下载的位置，以及服务器插件信息用于存放数据库
     * 注： 服务器上的versionCode与插件apk文件内的versionCode可能不同
     * @param wrapper
     * @return
     */
    public static PluginInfo installPlugin(PluginBeanWrapper wrapper) {
        if (null == wrapper || null == wrapper.getDownloadEntry() || null == wrapper.pluginBean) {
            return null;
        }
        String filePath = wrapper.getDownloadEntry().getPath();
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        PluginInfo pluginInfo = RePlugin.install(filePath);
        if (null != pluginInfo) {
            // 安装成功 将信息插入数据库
            PluginBean pluginBean = wrapper.pluginBean;
            LocalPluginData lpd = LocalPluginData.parsePluginData(pluginBean);
            LocalPluginDataDao.getInstance(BaseApplication.getAppContext()).insertLocalPluginData(lpd);
        }
        return pluginInfo;
    }

    public static boolean isPluginInstalled(String packageName) {
        return RePlugin.isPluginInstalled(packageName);
    }

    /**
     * 耗时方法 应在子线程调用
     * @param pluginInfo
     * @return
     */
    public static boolean preparePlugin(PluginInfo pluginInfo) {
        return RePlugin.preload(pluginInfo);
    }

    /**
     * 打开一个插件
     * @param context 上下文
     * @param packageName 插件的包名
     * @param className 插件的启动activity名
     * @return
     */
    public static boolean openPlugin(Context context, String packageName, String className) {
        boolean pkgInstalled = isPluginInstalled(packageName);
        if (pkgInstalled) {
            if (!TextUtils.isEmpty(className)) {

                Intent in = new Intent();
                in.setComponent(RePlugin.createComponentName(packageName, className));
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                RePlugin.startActivity(context, in);
                return true;
            }
        }
        return false;
    }

    public static boolean openPlugin(Context context, PluginBeanWrapper wrapper) {
        if (null == wrapper || null == wrapper.pluginBean) {
            return false;
        }
        return openPlugin(context, wrapper.pluginBean.packageName, wrapper.pluginBean.startActivity);
    }

    /**
     * 查看已安装插件列表
     * @return
     */
    public static List<PluginInfo> getInstalledPlugin() {
        return RePlugin.getPluginInfoList();
    }


    public static DownloadEntry downloadPlugin(PluginBeanWrapper pluginBeanWrapper) {
        if (null == pluginBeanWrapper) {
            return null;
        }
        DownloadEntry entry = pluginBeanWrapper.getDownloadEntry();
        DownloadManager.getInstance().download(entry);
        return entry;
    }

    /**
     * 查看插件是否需要升级
     * @param pluginBean
     * @return
     */
    public static boolean needUpdate(PluginBean pluginBean) {
        if (null == pluginBean) {
            return false;
        }
        int serverVer = pluginBean.versionCode;
        LocalPluginData localPlugin = LocalPluginDataDao.getInstance(BaseApplication.getAppContext()).getLocalPluginByPackageName(pluginBean.packageName);
        if (null == localPlugin) {
            return true;
        } else {
            int localVer = localPlugin.versionCode;
            if (localVer < serverVer) {
                return true;
            }
        }
        return false;
    }
}
