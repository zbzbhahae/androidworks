package com.huawei.genexcloud.dialog;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import com.huawei.genexcloud.base.BaseDialog;
import com.huawei.genexcloud.databinding.DialogConfirmCancelBinding;
import com.huawei.genexcloud.util.AppUtil;

/**
 * 最基础的确定取消弹出框
 */
public class ConfirmCancelDialog extends BaseDialog implements View.OnClickListener {

    private final String tag = getClass().getSimpleName();

    private DialogConfirmCancelBinding binding;
    private ConfirmCancelCallback listener;

    private int backgroundRes;
    private String contentString, confirmString, cancelString;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogConfirmCancelBinding.inflate(getLayoutInflater(), container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.confirmBtn.setOnClickListener(this);
        binding.cancelBtn.setOnClickListener(this);

        if (0 != backgroundRes) {
            binding.layout.setBackgroundResource(backgroundRes);
        }
        if (!TextUtils.isEmpty(contentString)) {
            binding.content.setText(contentString);
        }
        if (!TextUtils.isEmpty(confirmString)) {
            binding.confirmBtn.setText(confirmString);
        }
        if (!TextUtils.isEmpty(cancelString)) {
            binding.cancelBtn.setText(cancelString);
        }

    }

    /**
     * 设置弹出框背景图片 资源类型
     * @param res
     * @return
     */
    public ConfirmCancelDialog setBackground(int res) {
        backgroundRes = res;
        if (null != binding) {
            binding.layout.setBackgroundResource(res);
        }
        return this;
    }

    /**
     * 设置确认按钮文字
     * @param text
     * @return
     */
    public ConfirmCancelDialog setConfirmText(String text) {
        confirmString = text;
        if (null != binding) {
            binding.confirmBtn.setText(text);
        }
        return this;
    }

    /**
     * 设置取消按钮显示文字
     * @param text
     * @return
     */
    public ConfirmCancelDialog setCancelText(String text) {
        cancelString = text;
        if (null != binding) {
            binding.cancelBtn.setText(text);
        }
        return this;
    }

    /**
     * 设置显示内容
     * @param text
     * @return
     */
    public ConfirmCancelDialog setContentText(String text) {
        contentString = text;
        if (null != binding) {
            binding.content.setText(text);
        }
        return this;
    }

    @Override
    public void onClick(View view) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (view == binding.confirmBtn) {
            if (null != listener) {
                listener.onConfirm();
                dismiss();
            }
        } else if (view == binding.cancelBtn) {
            if (null != listener) {
                listener.onCancel();
                dismiss();
            }
        }
    }

    /**
     * 设置点击监听
     * @param callback
     */
    public ConfirmCancelDialog setConfirmCancelCallback(ConfirmCancelCallback callback) {
        this.listener = callback;
        return this;
    }

    public void show(FragmentManager fragmentManager) {
        show(fragmentManager, tag);
    }

    /**
     * 确定取消点击事件
     */
    public interface ConfirmCancelCallback {
        void onConfirm();
        void onCancel();
    }
}
