package com.huawei.genexcloud.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.apply.CustomProgressBar;
import com.huawei.genexcloud.base.BaseApplication;
import com.huawei.genexcloud.bean.PluginBean;
import com.huawei.genexcloud.bean.PluginBeanWrapper;
import com.huawei.genexcloud.database.LocalPluginData;
import com.huawei.genexcloud.database.LocalPluginDataDao;
import com.huawei.genexcloud.databinding.ItemPluginBinding;
import com.huawei.genexcloud.http.download.DownloadEntry;
import com.huawei.genexcloud.http.download.DownloadManager;
import com.huawei.genexcloud.http.download.DownloadState;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.plugin.GCPluginManager;
import com.huawei.genexcloud.util.AppUtil;
import com.huawei.genexcloud.widget.PluginIconView;
import com.huawei.genexcloud.widget.PluginView;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.qihoo360.replugin.model.PluginInfo;

import java.util.ArrayList;
import java.util.List;

public class MainPluginViewAdapter extends RecyclerView.Adapter<MainPluginViewAdapter.PluginViewHolder> {

    private final List<PluginBeanWrapper> pluginList = new ArrayList<>();

    private PluginView.PluginActionListener pluginActionListener;

    public void setPluginActionListener(PluginView.PluginActionListener pluginActionListener) {
        this.pluginActionListener = pluginActionListener;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PluginViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PluginViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_plugin, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PluginViewHolder holder, int position) {
        final PluginBeanWrapper data = pluginList.get(position);
        if (data == null) {
        } else {
            holder.binding.pluginView.setPluginBean(data);
            holder.binding.pluginView.setPluginActionListener(pluginActionListener);


        }
    }


    @Override
    public int getItemCount() {
        return pluginList.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<PluginBeanWrapper> list) {
        if (list != null) {
            pluginList.clear();
            pluginList.addAll(list);
            notifyDataSetChanged();
        }
    }

    static public class PluginViewHolder extends RecyclerView.ViewHolder {

        private final ItemPluginBinding binding;

        public PluginViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemPluginBinding.bind(itemView);
        }
    }
}
