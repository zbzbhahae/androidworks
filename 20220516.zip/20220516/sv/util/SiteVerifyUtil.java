package com.huawei.genexcloud.survey.util;

import com.huawei.genexcloud.framework.bean.CellInfo;
import com.huawei.genexcloud.framework.bean.SiteInfo;
import com.huawei.genexcloud.framework.bean.SiteParam;

import java.util.List;

/**
 * 对站点 小区进行参数验证，查看是否符合规则
 */
public class SiteVerifyUtil {

    public static final String OK = "OK";

    private static final String NOOK_ANTENNAS_NUMBER = "天线数量错误，天线数量应使用[1,2,4,8,16,32,64]中的一个！";

    /**
     * 验证小区参数
     * @param cells 小区信息
     * @return
     */
    public static String verifyUpdateCellParams(List<CellInfo> cells) {
        if (null == cells || cells.isEmpty()) {
            return OK;
        }
        for (CellInfo cell : cells) {
            int RANumber = cell.getNumber_of_Reception_Antennas();
            int TANumber = cell.getNumber_of_Transmission_Antennas();
            if (!checkAntennasNumber(RANumber) || !checkAntennasNumber(TANumber)) {
                return NOOK_ANTENNAS_NUMBER;
            }
        }
        return OK;
    }

    public static String verifySurveyCellParams(List<SiteParam> sites) {

        return OK;
    }


    /**
     * 检查天线数量
     * @param number
     * @return
     */
    private static boolean checkAntennasNumber(int number) {
        if (number != 1 && number != 2 && number != 4 && number != 8 && number != 16 && number != 32 && number != 64) {
            return false;
        }
        return true;
    }
}
