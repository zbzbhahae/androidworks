package com.huawei.genexcloud.survey.activity;

import androidx.core.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.huawei.genexcloud.framework.base.BaseActivity;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.base.IBaseResultLinstener;
import com.huawei.genexcloud.framework.bean.CellInfo;
import com.huawei.genexcloud.framework.bean.SiteParam;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.CreateSiteTemplateUtil;
import com.huawei.genexcloud.framework.http.DeleteSiteTemplateUtil;
import com.huawei.genexcloud.framework.http.QuerySiteTemplateListUtil;
import com.huawei.genexcloud.framework.http.UpdateSiteTemplateUtil;
import com.huawei.genexcloud.framework.util.BasePopupWindow;
import com.huawei.genexcloud.framework.util.PopupwindowUtils;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.adapter.CellExpListAdapter;
import com.huawei.genexcloud.survey.http.QuerySiteTemplateImpl;
import com.huawei.genexcloud.survey.http.UpdateSiteTemplateImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;
import com.huawei.genexcloud.survey.interfaces.OnClickCrossLine;
import com.huawei.genexcloud.survey.views.MyEditText;
import com.huawei.genexcloud.survey.views.SuperExpandableListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Request;

/**
 * 站点模板
 */
public class SeleteSiteTemplateActivity extends BaseActivity implements View.OnClickListener, OnClickCrossLine {

    List<CellInfo> cellInfos = new ArrayList<>();
    private SuperExpandableListView communityListView;
    private CellExpListAdapter adapter;
    private View bgPop;

    private Button btnSave;

    private ImageView btnAdd;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_selete_site_template;
    }

    @Override
    protected void initView() {
        findViewById(R.id.back).setOnClickListener(this);
        communityListView = (SuperExpandableListView) findViewById(R.id.cell_list);
        communityListView.setGroupIndicator(null);

        bgPop = findViewById(R.id.bg_pop);

        btnSave = (Button) findViewById(R.id.btn_complete);
        btnSave.setOnClickListener(this);

        btnAdd = (ImageView) findViewById(R.id.add_cell);
        btnAdd.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        adapter = new CellExpListAdapter(this);
        adapter.setOnClickCressLineListener(this);
        communityListView.setAdapter(adapter);
        querySiteTemplate(false);

    }

    /**
     * 查询站点模板
     */
    private void querySiteTemplate(final boolean isFinish) {
        String account = SharedPreferencesUtil.getInstance(this).readStringValue(Constants.LOGIN_USER_KEY, "");
        QuerySiteTemplateImpl.getInstance().getSiteTemplate(account, new QuerySiteTemplateImpl.SiteTemplateCallback() {
            @Override
            public void onBefore(Request request) {
                createLoadingDialog(SeleteSiteTemplateActivity.this,
                        SeleteSiteTemplateActivity.this, "更新模板信息...", false);
            }
            @Override
            public void onAfter() {
                closeLoadDialog();
            }
            @Override
            public void onFailure(ErrorBean e) {
                if (isFinish) {
                    finish();
                } else {
                    adapter.setList(null);
                    showToast(e.message);
                }
            }
            @Override
            public void onResponse(List<CellInfo> response) {
                closeLoadDialog();
                if (isFinish) {
                    finish();
                } else {
                    cellInfos = response;
                    adapter.setList(cellInfos);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                finish();
                break;
            case R.id.btn_complete:
                save();
                break;
            case R.id.add_cell:
                addCell();
                break;
            default:
                break;
        }
    }

    @Override
    public void crossLine(int position) {

    }

    @Override
    public void takePhotoClick(int position) {

    }

    @Override
    public void reNameClick(final int position) {
        setDarkBackgroundForTimeSelect(true, bgPop);
        PopupwindowUtils.showReNameCell(this, new PopupwindowUtils.PopDismissAndItemClickCallBack() {
            @Override
            public void ToDismiss() {
                setDarkBackgroundForTimeSelect(false, bgPop);
            }

            @Override
            public void OnClick(MyEditText editText) {
                String cellName = editText.getText().toString();
                if (TextUtils.isEmpty(editText.getText().toString())) {
                    showToast("修改小区名不能为空");
                    return;
                }

                if (cellInfos != null && cellInfos.size() > 0) {
                    for (int i = 0; i < cellInfos.size(); i++) {
                        if (cellInfos.get(i).getCellName().equals(cellName)) {
                            showToast("小区名重复，请重新编辑");
                            return;
                        }
                    }
                }

                SiteParam siteParam = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                        .queryByCellName(Constants.PROJECT_ID, groupId, cellName);
                if (siteParam != null) {
                    showToast("同一任务下小区名称不能相同，请重新编辑");
                    return;
                }

                cellInfos.get(position).setCellName(editText.getText().toString());
                adapter.setList(cellInfos);
                BasePopupWindow.dismiss();
            }
        });
    }

    @Override
    public void deleteClick(final int position) {
        PopupwindowUtils.showIsDelete(this, bgPop, 5, new PopupwindowUtils.PopDismissCallBack() {
            @Override
            public void ToDismiss() {

            }

            @Override
            public void onSure() {
                deleteCellReq(cellInfos.get(position));
            }
        });
    }

    @Override
    public void isActivie(int position, boolean isCheck) {
    }

    @Override
    public void onShowAntennaList() {
    }

    @Override
    public void setActive(boolean isActive) {
    }

    @Override
    public void showMore(boolean isChecked, CheckBox ivMore, LinearLayout isShow) {
    }

    /**
     * 选择窗口设置暗黑效果
     */
    private void setDarkBackgroundForTimeSelect(boolean isDark, View tvBg) {
        if (isDark) {
            tvBg.setBackgroundColor(ContextCompat.getColor(this, R.color.transparent_black_50));
            tvBg.setVisibility(View.VISIBLE);
        } else {
            tvBg.setBackgroundColor(ContextCompat.getColor(this, R.color.transparent_black));
            tvBg.setVisibility(View.GONE);
        }
    }

    /**
     * 保存模板
     */
    private void save() {
        UpdateSiteTemplateImpl.getInstance().updateSiteTemplate(cellInfos, new UpdateSiteTemplateImpl.UpdateTemplateCallback() {
            @Override
            public void onBefore(Request request) {
                createLoadingDialog(SeleteSiteTemplateActivity.this, SeleteSiteTemplateActivity.this, "保存模板信息中...", false);
            }
            @Override
            public void onAfter() {
                closeLoadDialog();
            }
            @Override
            public void onFailure(ErrorBean e) {
                showToast(e.message);
            }
            @Override
            public void onResponse(Boolean response) {
                if (response) {
                    // 保存成功 更新站点模板
                    querySiteTemplate(true);
                } else {
                    // 保存失败
                    showToast("保存失败，请重试！");
                }
            }
        });
    }

    /**
     * 添加小区
     */
    private void addCell() {
        setDarkBackgroundForTimeSelect(true, bgPop);
        PopupwindowUtils.showAddCell(this, new PopupwindowUtils.PopDismissAndItemClickCallBack() {
            @Override
            public void ToDismiss() {
                setDarkBackgroundForTimeSelect(false, bgPop);
            }

            @Override
            public void OnClick(MyEditText editText) {
                String cellName = editText.getText().toString();
                if (TextUtils.isEmpty(editText.getText().toString())) {
                    showToast("修改小区名不能为空");
                    return;
                }

                if (cellInfos != null && cellInfos.size() > 0) {
                    for (int i = 0; i < cellInfos.size(); i++) {
                        if (cellInfos.get(i).getCellName().equals(cellName)) {
                            showToast("小区名重复，请重新编辑");
                            return;
                        }
                    }
                }

                addCellReq(cellName);
                BasePopupWindow.dismiss();
            }
        });
    }

    /**
     * 添加小区网络请求
     */
    private void addCellReq(String name) {
        createLoadingDialog(this, this, "", false);

        CellInfo cellInfo = new CellInfo();

        cellInfo.setTemplateid(cellInfos.get(0).getTemplateid());
        cellInfo.setCellName(name);

        if (cellInfos != null && cellInfos.size() > 0) {
            Collections.sort(cellInfos, new CompareData());
            cellInfo.setCellId((Long.parseLong(cellInfos.get(0).getCellId()) + 1) + "");
        } else {
            cellInfo.setCellId("1");
        }

        cellInfo.setAzimuth(0);
        cellInfo.setMechanical_Downtilt(0);
        cellInfo.setDigital_Azimuth(0);
        cellInfo.setDigital_Downtilt(6);
        cellInfo.setHeight(30);

        cellInfo.setAntenna("AAU5613/AAU5614(3UK) 3.5G_RAN2.0 64T_16H4V 3.5G S0_H105V6");
        cellInfo.setNumber_of_Reception_Antennas(64);
        cellInfo.setNumber_of_Transmission_Antennas(64);
        cellInfo.setRS_Power(17.856861);
        cellInfo.setFrequency_Band("N78");
        cellInfo.setMain_Calculation_Radius(800);
        cellInfo.setMain_Propagation_Model("Rayce HW Default");

        CreateSiteTemplateUtil.getInstance().asyncExecute(cellInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
                showToast("添加失败，请重试！");
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                querySiteTemplate(false);
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
                querySiteTemplate(false);
            }
        });
    }

    /**
     * 添加小区网络请求
     */
    private void deleteCellReq(CellInfo cellInfo) {
        createLoadingDialog(this, this, "", false);
        DeleteSiteTemplateUtil.getInstance().asyncExecute(cellInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
                showToast("删除失败，请重试！");
            }

            @Override
            public void onSuccess(Object obj) {
                closeLoadDialog();
                querySiteTemplate(false);
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
                querySiteTemplate(false);
            }
        });

    }

    class CompareData implements Comparator<CellInfo> {
        @Override
        public int compare(CellInfo r1, CellInfo r2) {
            long data1 = Long.parseLong(r1.getCellId());
            long data2 = Long.parseLong(r2.getCellId());
            if (data1 > data2) {
                return -1;
            } else if (data1 < data2) {
                return 1;
            }
            return 0;
        }
    }
}
