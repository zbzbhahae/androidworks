package com.huawei.genexcloud.survey.http.util;



import com.huawei.genexcloud.survey.BuildConfig;

import java.util.Map;

public abstract class JavaHttpUtil extends GCHttpUtil {

    private static String url;

    static {
        if (BuildConfig.DEBUG) {
            url = BuildConfig.GC_HOST + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile_kance";
        } else {
            url = BuildConfig.GC_HOST + "/mobileinfomgmtapps/wcfMapAction?endPoint=mobile_kance";
        }
    }

    /**
     * 发送post请求
     * @param body 访问参数的集合
     * @param callBack 结果回调
     */
    public void post(final Map<String, Object> body, final GCCallback callBack) {
        post(null, url, getHeaders(), buildBodyParams(getMessageName(), body), callBack);
    }

    /**
     * 发送单一post请求，只会同时存在一个相同tag的请求
     * @param tag post请求的标识
     * @param body 访问参数的集合
     * @param callBack 结果回调
     */
    public void postSingle(Object tag, final Map<String, Object> body, final GCCallback callBack) {
        if (null != tag) {
            OkHttpManager.cancel(tag);
        }
        post(tag, url, getHeaders(), buildBodyParams(getMessageName(), body), callBack);
    }

    /**
     * 获取messageName
     * @return
     */
    protected abstract String getMessageName();
}
