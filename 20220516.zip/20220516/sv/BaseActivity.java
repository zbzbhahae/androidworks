package com.huawei.genexcloud.framework.base;

import com.huawei.genexcloud.framework.bean.SiteInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.log.Module;
import com.huawei.genexcloud.framework.util.ActivityTackUtil;
import com.huawei.genexcloud.framework.util.CrashHandlerUtil;
import com.huawei.genexcloud.framework.util.FileUtil;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.framework.util.StringUtil;
import com.huawei.genexcloud.framework.util.SystemUIUtil;
import com.huawei.genexcloud.survey.R;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by yWX419033 on 2018/4/28.
 */

public abstract class BaseActivity extends FragmentActivity {
    protected Dialog loadingDialog = null;
    protected static String groupId;
    protected static String groupName;
    protected SiteInfo siteInfo;
    protected boolean isFullScreen = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GCLogger.error("view", "启动activity  -》" + this.getClass().getSimpleName());
        if (isFullScreen) {
            SystemUIUtil.fullScreenNotStatuBar(this);
        }
        setContentView(getLayoutId());
        this.initView();
        this.initData();
        ActivityTackUtil.getInstance().addActivity(this);
//        CrashHandlerUtil.getInstance().init(getApplicationContext());

        initStaticData();
    }

    protected abstract void initView();

    protected abstract void initData();

    protected abstract int getLayoutId();

    @Override
    protected void onStart() {
        super.onStart();
    }

    //查找布局的底层
    protected ViewGroup getRootView(Activity context) {
        return (ViewGroup) context.findViewById(android.R.id.content);
    }

    /**
     * 显示弹出提示
     *
     * @param resId 提示内容资源
     */
    protected void showToast(int resId) {
        Toast toast = Toast.makeText(this, getString(resId), Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * 显示弹出提示
     *
     * @param res 提示内容资源
     */
    protected void showToast(String res) {
        if (TextUtils.isEmpty(res)) {
            return;
        }
        Toast toast = Toast.makeText(this, res, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * 显示弹出提示
     *
     * @param res 提示内容资源
     */
    protected void showToast(String res, int place) {
        Toast toast = Toast.makeText(this, res, Toast.LENGTH_SHORT);
        toast.setGravity(place, 0, 0);
        toast.show();
    }

    /**
     * 等待框<此处需要修改 by wwx405921>
     *
     * @param activity
     * @param context
     * @param isCancel
     * @return
     */
    public Dialog createLoadingDialog(Activity activity, Context context, String msg, boolean isCancel) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.dialog_loading, null);// 得到加载view
        RelativeLayout layout = (RelativeLayout) v.findViewById(R.id.dialog_layout);// 加载布局
        // xml中的ImageView
        Animation anim = AnimationUtils.loadAnimation(context, R.anim.loading);
        ImageView imageView = (ImageView) v.findViewById(R.id.login_progressbar);
        imageView.startAnimation(anim);
        TextView textView = (TextView) v.findViewById(R.id.login_title);

        if (loadingDialog == null) {
            loadingDialog = new Dialog(context, R.style.loding_dialog);// 创建自定义样式dialog
        }

        // dialog透明
        WindowManager.LayoutParams lp = loadingDialog.getWindow().getAttributes();
        lp.alpha = 0.8f;
        loadingDialog.getWindow().setAttributes(lp);

        loadingDialog.setCancelable(true);// 不可以用“返回键”取消

        loadingDialog.setContentView(layout);// 设置布局
        textView.setText(msg);
        loadingDialog.setOwnerActivity(activity);
        if (!activity.isFinishing()) {
            loadingDialog.show();
        }
        return loadingDialog;
    }

    /**
     * 关闭等待框
     */
    public void closeLoadDialog() {
        if (loadingDialog != null && loadingDialog.isShowing()) {
            Activity activity = loadingDialog.getOwnerActivity();
            if (null != activity && !activity.isFinishing()) {
                try {
                    loadingDialog.dismiss();
                } catch (Exception e) {
                    GCLogger.error(Module.INDOOR, "dismiss Exception:" + e.toString());
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityTackUtil.getInstance().popActivity(this);
    }

    /**
     * 请求权限弹窗
     */
    public void requestDynamicPermissions(Activity a, int permissionCode, String... permissionNames) {
        ActivityCompat.requestPermissions(a, permissionNames, permissionCode);
    }

    /**
     * 检查动态权限
     *
     * @param permissionNames 权限名
     * @return 是否拥有权限
     */
    protected boolean checkDynamicPermissions(Activity a, int permissionCode, String... permissionNames) {

        // 因版本适配问题，暂时不做
        boolean isPermited;
        if (Build.VERSION.SDK_INT >= 23) {
            // 在版本上检查每项权限
            boolean success = true;
            for (String permissionName : permissionNames) {
                success = checkPermission(a, permissionName);
                if (!success) {
                    break;
                }
            }
            if (!success) {
                // 被拒绝,重新请求
                ActivityCompat.requestPermissions(a, permissionNames, permissionCode);
                isPermited = false;
            } else {
                // 被允许
                isPermited = true;
            }
        } else {
            // 低版本默认允许
            isPermited = true;
        }
        return isPermited;
    }

    /**
     * 检查权限是否被允许<回调codes>
     */
    protected boolean checkPermissionResultCodes(int... resultCodes) {

        boolean isAccessed = true;
        for (int code : resultCodes) {
            if (PackageManager.PERMISSION_DENIED == code) {
                isAccessed = false;
                break;
            }
        }

        return isAccessed;
    }

    /**
     * 检查权限<不同方法>
     */
    private boolean checkPermission(Activity a, String permissionName) {
        int state = ContextCompat.checkSelfPermission(a, permissionName);
        return state == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * 当焦点停留在view上时，隐藏输入法栏
     *
     * @param view view
     */
    protected void hideInputWindow(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        if (null != imm && null != view) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 初始化静态值
     */
    protected void initStaticData() {
        Constants.PROJECT_ID = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue("projectId", "24d8c783-1d80-420c-9207-37042b54a552");
        groupId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).readStringValue(Constants.GROUP_ID, "");
        groupName = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).readStringValue(Constants.GROUP_NAME, "");
    }

    /**
     * 保存静态值
     *
     * @param key
     * @param value
     */
    protected void saveStaticData(String key, String value) {
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).saveStringValue(key, value);
    }

    /**
     * 保存静态值
     *
     * @param key
     * @param value
     */
    protected void saveStaticData(String key, int value) {
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).saveIntValue(key, value);
    }

    /**
     * 清空静态值
     */
    protected void cleanStaticData() {
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).deleteValue("taskId");
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).deleteValue("taskName");

        groupId = "";
        groupName = "";
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).deleteValue(Constants.GROUP_ID);
        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext()).deleteValue(Constants.GROUP_NAME);
    }

    /**
     * 显示普通的提示框
     *
     * @param content
     * @param resId
     */
    public void showCommonPop(String content, int resId) {
        final View contextView = LayoutInflater.from(this).inflate(R.layout.item_common_pop_layout, null);

        TextView title = (TextView) contextView.findViewById(R.id.tv_tip);
        if (!StringUtil.isEmpty(content)) {
            title.setText(content);
        }

        ImageView ivTip = (ImageView) contextView.findViewById(R.id.iv_tip);
        if (resId != -1) {
            ivTip.setBackgroundResource(resId);
        }
        Button button = (Button) contextView.findViewById(R.id.btn_sure);
        final PopupWindow popupWindow = new PopupWindow(contextView, android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.FILL_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setAnimationStyle(R.style.main_menu_animstyle);
        popupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });
        popupWindow.showAtLocation(contextView, Gravity.CENTER, 0, 0);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
    }
}
