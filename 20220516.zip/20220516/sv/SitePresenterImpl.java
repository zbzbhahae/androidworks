package com.huawei.genexcloud.survey.presenter.impl;

import android.content.Intent;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.base.IBaseResultLinstener;
import com.huawei.genexcloud.framework.bean.AntennaBean;
import com.huawei.genexcloud.framework.bean.CellInfoBean;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.bean.EmulationStation;
import com.huawei.genexcloud.framework.bean.SimulationReqInfo;
import com.huawei.genexcloud.framework.bean.SiteInfo;
import com.huawei.genexcloud.framework.bean.SiteParam;
import com.huawei.genexcloud.framework.bean.WorkerParameter;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.QuerySubTaskListUtil;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.util.Formatter;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.http.QueryEmulationTaskListImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by lWX348305 on 2019/5/7. 站点信息处理
 */
public class SitePresenterImpl {

    /**
     * SiteParam列表转换为SiteInfo列表
     * 将同站点工参合并成单个站点信息
     *
     * @return
     */
    public List<SiteInfo> transformSiteInfos(String projectId, String groupId, List<SiteParam> beans) {
        Map<String, SiteInfo> siteMaps = new HashMap<String, SiteInfo>();
        List<SiteInfo> infos = new ArrayList<SiteInfo>();
        SiteInfo info;
        if (null != beans) {
            for (int i = 0; i < beans.size(); i++) {
                SiteParam bean = beans.get(i);
                if (null != bean) {
                    if (siteMaps.containsKey(bean.getSiteId() + "_" + bean.getSiteLat() + "_" + bean.getSiteLng())) {
                        siteMaps.get(bean.getSiteId() + "_" + bean.getSiteLat() + "_" + bean.getSiteLng()).getBeans()
                                .add(bean);
                    } else {
                        info = new SiteInfo();
                        info.setNodebId(bean.getSiteId());
                        info.setSiteName(bean.getSiteName());
                        info.setIndoorId(bean.getIndoorId());
                        info.setLat(Double.parseDouble(bean.getSiteLat()));
                        info.setLng(Double.parseDouble(bean.getSiteLng()));
                        info.setBeans(new ArrayList<SiteParam>());
                        info.getBeans().add(bean);

                        ArrayList<SiteParam> params = DBManager.getInstance(BaseApplication.getAppContext())
                                .getSimulationParamDB().queryAllBySiteId(projectId, groupId, bean.getSiteId() + "");
                        if (params == null || params.size() == 0) {
                            info.setIsSurvey(0);
                        } else {
                            info.setIsSurvey(1);
                        }
                        siteMaps.put(bean.getSiteId() + "_" + bean.getSiteLat() + "_" + bean.getSiteLng(), info);
                    }
                }
            }
        }

        Iterator<Map.Entry<String, SiteInfo>> it = siteMaps.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, SiteInfo> entry = it.next();
            if (entry.getKey() != null) {
                SiteInfo values = entry.getValue();
                infos.add(values);
            }
        }
        return infos;
    }

    /**
     * 合并已勘测的工参
     *
     * @param beans
     */
    public Map<Integer, SiteParam> mergeIsSurvrySiteParam(List<SiteParam> beans) {
        Map<Integer, SiteParam> maps = new HashMap<Integer, SiteParam>();
        if (null != beans) {
            for (int i = 0; i < beans.size(); i++) {
                SiteParam bean = beans.get(i);

                if (!maps.containsKey(bean.getSiteId())) {
                    maps.put(bean.getSiteId(), bean);
                }
            }
        }
        return maps;
    }

    /**
     * 获取最新站点id
     *
     * @return
     */
    public int getNewSiteId(String projectId, String groupId) {
        long startT = System.currentTimeMillis();
        int maxSiteId = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                .queryBiggestSiteId(projectId, groupId);

        int siteId;
        if (maxSiteId <= 0) {
            siteId = 0;
        } else {
            siteId = maxSiteId + 1;
        }

        return siteId;
    }

    /**
     * 获取最新小区id
     *
     * @return
     */
    public long getNewCellId(String projectId, String groupId, String siteId) {
        ArrayList<SiteParam> params = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                .queryAllBySiteId(projectId, groupId, siteId);
        long cellId;
        if (params != null && params.size() > 0) {
            cellId = params.get(params.size() - 1).getCellId();
        } else {
            cellId = 0;
        }
        return cellId + 1;
    }

    /**
     * @param siteInfo
     * @return
     */
    public void updateStieInfo(String projectId, String groupId, SiteInfo siteInfo) {

        //更新站点信息
        SiteParam siteParam = new SiteParam();
        siteParam.setProjectId(projectId);
        siteParam.setGroupId(groupId);
        siteParam.setSiteId(siteInfo.getNodebId());
        siteParam.setSiteName(siteInfo.getSiteName());
        siteParam.setSiteLat(siteInfo.getLat() + "");
        siteParam.setSiteLng(siteInfo.getLng() + "");
        siteParam.setHeight(siteInfo.getHeight() + "");
        siteParam.setAntennaLat(siteInfo.getLat() + "");
        siteParam.setAntennaLng(siteInfo.getLng() + "");

        DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().updateSiteInfo(siteParam);

        //查询该站点的所有小区
        List<SiteParam> oldParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB()
                .queryBySiteId(projectId, groupId, siteInfo.getNodebId() + "");
        //更新小区信息
        List<SiteParam> params = siteInfo.getBeans();

        //没有原始工参，说明小区都是新增
        if (oldParams == null || oldParams.size() == 0) {
            if (params != null && params.size() > 0) {
                for (int i = 0; i < params.size(); i++) {
                    SiteParam param = params.get(i);
                    param.setProjectId(projectId);
                    param.setGroupId(groupId);
                    param.setCellStatus("ADD");
                    DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().insertOrUpdate(param);
                }
            }
        } else {
            //原始的小于当前的，说明有新增;删除需要单独处理
            //            if (oldParams.size() < params.size()) {
            if (params != null && params.size() > 0) {
                for (int i = 0; i < params.size(); i++) {
                    SiteParam param = params.get(i);
                    param.setProjectId(projectId);
                    param.setGroupId(groupId);
                    /**
                     * 查询原始工参库
                     */
                    SiteParam oldParam = DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB()
                            .queryById(param.getProjectId(), param.getGroupId(), param.getSiteId() + "",
                                    param.getCellId() + "");

                    //不存在，说明新增；
                    if (oldParam == null) {
                        param.setCellStatus("ADD");
                    } else {
                        if (oldParam.toString().equals(param.toString())) {
                            param.setCellStatus("ORIGINAL");
                        } else {
                            param.setCellStatus("UPDATE");
                        }
                    }
                    DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().insertOrUpdate(param);
                }
            }
        }

        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                SiteParam param = params.get(i);
                param.setProjectId(projectId);
                param.setGroupId(groupId);

                /**
                 * 查询原始工参库，不存在，说明新增；
                 */
                SiteParam param1 = DBManager.getInstance(BaseApplication.getAppContext()).getSiteParamDB().queryById(
                        param.getProjectId(), param.getGroupId(), param.getSiteId() + "", param.getCellId() + "");

                DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().insertOrUpdate(param);
            }
        }

        Intent intent = new Intent(Constants.UPDATE_SITE);
        intent.setPackage(Constants.PACKAGE_NAME);
        BaseApplication.getAppContext().sendBroadcast(intent, Constants.PERMISSION_BROADCAST);
    }

    /**
     * 新建站点
     *
     * @return
     */
    public void newSiteParam(String projectId, String groupID, SiteInfo siteInfo) {
        List<SiteParam> beans = siteInfo.getBeans();

        for (int i = 0; i < beans.size(); i++) {
            SiteParam bean = beans.get(i);
            GCLogger.a(bean.getIndoorId());
            SiteParam info = new SiteParam();
            //默认值站点信息
            info.setProjectId(projectId);
            info.setGroupId(groupID);
            info.setSiteName(siteInfo.getSiteName());
            info.setSiteLng(siteInfo.getLng() + "");
            info.setSiteLat(siteInfo.getLat() + "");
            info.setAntennaLng(siteInfo.getLng() + "");
            info.setAntennaLat(siteInfo.getLat() + "");
            info.setHeight(siteInfo.getHeight() + "");
            info.setSiteId(getNewSiteId(projectId, groupID));

            //默认值小区信息
            info.setAzimuth(bean.getAzimuth());
            info.setMechanicalDowntilt(bean.getMechanicalDowntilt());
            info.setCellName(bean.getCellName());
            info.setCellId(bean.getCellId());

            info.setAntenna(bean.getAntenna());
            info.setNumberTransmissionAntennas(bean.getNumberTransmissionAntennas());
            info.setNumberReceptionAntennas(bean.getNumberReceptionAntennas());
            info.setRSPower(bean.getRSPower());
            info.setFrequencyBand(bean.getFrequencyBand());
            info.setMainCalculationRadius(bean.getMainCalculationRadius());
            info.setDigitalDowntilt(bean.getDigitalDowntilt());
            info.setDigitalAzimuth(bean.getDigitalAzimuth());
            info.setCellStatus("ADD");

            //默认值
            info.setMainPropagationModel("Rayce HW Default");
            info.setSiteEquipment("Default Site Equipment");
//            info.setDlEarfcn("63000");
            info.setDlEarfcn("513000");
            info.setRRUName("");
            info.setTotalLossDL("0");
            info.setTotalLossUL("0");
            info.setInputTotalLoss(true);
            info.setActive(true);
            info.setActualLoadUL("0.75");
            info.setPDSCHActualLoadDL("0.75");
            info.setNeighbourPDSCHLoad("0.75");
            info.setIoTUL("12");
            info.setPDSCHToRS("0");
            info.setCSIToRS("0");
            info.setSSIToRS("0");
//            info.setFrameConfiguration("19A 4D1U");
            info.setFrameConfiguration("8_2_DDDDDDDSUU");
            info.setPCI("0");
            info.setUlEarfcn("");
            info.setFramepParameter("Sub6G-TDD-NR");
            info.setDCSwitch(false);
            info.setIndoorId(siteInfo.getIndoorId());

            //新增工参
            info.setDlBandwidth("20");
            info.setBEAMSCENARIO("DEFAULT");
            info.setUlBandwidth("20");
            info.setCASwitchDL("Off");
            info.setCASwitchUL("Off");
            info.setDSSSwitch("FALSE");
            info.setDSSShareRatio("1");
            info.setULCompSwitch("FALSE");
            info.setInterSiteCA("FALSE");
            DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB().insertOrUpdate(info);
        }

        GCLogger.a("新建站点");
        Intent intent = new Intent(Constants.ADD_SITE);
        intent.setPackage(Constants.PACKAGE_NAME);
        BaseApplication.getAppContext().sendBroadcast(intent, Constants.PERMISSION_BROADCAST);
    }

    /**
     * 获取新小区
     *
     * @param groupId
     * @param siteInfo
     * @param cellName
     */
    public SiteParam getCellParam(String projectId, String groupId, SiteInfo siteInfo, String cellName) {
        SiteParam info = new SiteParam();
        //默认值站点信息
        info.setProjectId(projectId);
        info.setGroupId(groupId);
        info.setSiteName(siteInfo.getSiteName());
        info.setSiteLng(siteInfo.getLng() + "");
        info.setSiteLat(siteInfo.getLat() + "");
        info.setAntennaLng(siteInfo.getLng() + "");
        info.setAntennaLat(siteInfo.getLat() + "");
        info.setHeight(siteInfo.getHeight() + "");
        info.setSiteId(getNewSiteId(projectId, groupId));

        //默认值小区信息
        info.setAzimuth("0");
        info.setMechanicalDowntilt("0");
        info.setCellName(cellName);
        info.setCellId(getNewCellId(projectId, groupId, siteInfo.getNodebId() + ""));

        try {
            // TODO 默认值天线信息   应该从天线列表中获取
            AntennaBean defaultAntennaBean = DBManager.getInstance(BaseApplication.getAppContext()).getAntennaDB()
                    .queryOneMimoAntenna(projectId, "mimo", "modelAntennas");
            if (null != defaultAntennaBean && !TextUtils.isEmpty(defaultAntennaBean.AntennaName)) {
                info.setAntenna(defaultAntennaBean.AntennaName);
            } else {
                info.setAntenna("AAU5241_2.6G_Wide_S0_T-10And10_A0");
            }
        } catch (Exception e) {
            info.setAntenna("AAU5241_2.6G_Wide_S0_T-10And10_A0");
        }

        info.setNumberTransmissionAntennas("64");
        info.setNumberReceptionAntennas("64");
        info.setRSPower(countRSPower(Integer.parseInt("200"), "AAU5613"));
        info.setFrequencyBand("N78");
        info.setMainCalculationRadius("800");

        //默认值
        info.setMainPropagationModel("Rayce HW Default");
        info.setSiteEquipment("Default Site Equipment");
//        info.setDlEarfcn("63000");
        info.setDlEarfcn("513000");
        info.setRRUName("");
        info.setTotalLossDL("0");
        info.setTotalLossUL("0");
        info.setInputTotalLoss(true);
        info.setActive(true);
        info.setActualLoadUL("0.75");
        info.setPDSCHActualLoadDL("0.75");
        info.setNeighbourPDSCHLoad("0.75");
        info.setIoTUL("12");
        info.setPDSCHToRS("0");
        info.setCSIToRS("0");
        info.setSSIToRS("0");
//        info.setFrameConfiguration("19A 4D1U");
        info.setFrameConfiguration("8_2_DDDDDDDSUU");
        info.setPCI("0");
        info.setUlEarfcn("");
        info.setFramepParameter("Sub6G-TDD-NR");
        info.setDCSwitch(false);
        info.setDigitalDowntilt("6");
        info.setDigitalAzimuth("0");
        info.setCellStatus("ADD");

        //新增工参
        info.setDlBandwidth("20");
        info.setBEAMSCENARIO("DEFAULT");
        info.setUlBandwidth("20");
        info.setCASwitchDL("Off");
        info.setCASwitchUL("Off");
        info.setDSSSwitch("FALSE");
        info.setDSSShareRatio("1");
        info.setULCompSwitch("FALSE");
        info.setInterSiteCA("FALSE");
        info.setIndoorId(siteInfo.getIndoorId());

        return info;
    }

    /**
     * 获取新小区
     *
     * @param groupId
     * @param siteInfo
     * @param bean
     */
    public SiteParam getCellParam(String projectId, String groupId, SiteInfo siteInfo, CellInfoBean bean) {
        SiteParam info = new SiteParam();
        //默认值站点信息
        info.setProjectId(projectId);
        info.setGroupId(groupId);
        info.setSiteName(siteInfo.getSiteName());
        info.setSiteLng(siteInfo.getLng() + "");
        info.setSiteLat(siteInfo.getLat() + "");
        info.setAntennaLng(siteInfo.getLng() + "");
        info.setAntennaLat(siteInfo.getLat() + "");
        info.setSiteId(siteInfo.getNodebId());

        //默认值小区信息
        info.setCellId(Integer.parseInt(bean.getCellId()));
        info.setCellName(bean.getCellName());
        info.setActive(bean.isActive());
        info.setAzimuth("0");
        info.setMechanicalDowntilt(bean.getDowntilt());

        info.setHeight(bean.getAntennaHeight() + "");
        info.setDigitalDowntilt(bean.getDigitalDowntilt());
        info.setDigitalAzimuth(bean.getDigitalAzimuth());

        info.setAntenna(bean.getAntenna());
        info.setNumberTransmissionAntennas(bean.getNumberAntennaStations());
        info.setNumberReceptionAntennas(bean.getNumberReceiveStations());
        info.setRSPower(bean.getReferenceSignalPower());
        info.setFrequencyBand(bean.getFrequencyRange());
        info.setMainCalculationRadius(bean.getCalculationRadiuModel());
        info.setMainPropagationModel(bean.getPropagationModel());

        //默认值
        info.setSiteEquipment("Default Site Equipment");
        info.setDlEarfcn("513000");
        info.setRRUName("");
        info.setTotalLossDL("0");
        info.setTotalLossUL("0");
        info.setInputTotalLoss(true);
        info.setActualLoadUL("0.75");
        info.setPDSCHActualLoadDL("0.75");
        info.setNeighbourPDSCHLoad("0.75");
        info.setIoTUL("12");
        info.setPDSCHToRS("0");
        info.setCSIToRS("0");
        info.setSSIToRS("0");
//        info.setFrameConfiguration("19A 4D1U");
        info.setFrameConfiguration("8_2_DDDDDDDSUU");
        info.setPCI("0");
        info.setUlEarfcn("");
        info.setFramepParameter("Sub6G-TDD-NR");
        info.setDCSwitch(false);
        info.setCellStatus("ADD");

        //新增工参
        info.setDlBandwidth("20");
        info.setBEAMSCENARIO("DEFAULT");
        info.setUlBandwidth("20");
        info.setCASwitchDL("Off");
        info.setCASwitchUL("Off");
        info.setDSSSwitch("FALSE");
        info.setDSSShareRatio("1");
        info.setULCompSwitch("FALSE");
        info.setInterSiteCA("FALSE");

        info.setIndoorId(siteInfo.getIndoorId());
        return info;
    }

    /**
     * 获取要展示的工参：
     *
     * @param surveyParams 已勘测
     * @param serParams    服务器所有工参
     * @return
     */
    public List<SiteParam> getShowParams(String projectId, String groupId, List<SiteParam> surveyParams,
                                         List<SiteParam> serParams) {
        List<SiteParam> params = new ArrayList<>();
        //已勘测为空，返回服务器全部工参
        if (surveyParams == null || surveyParams.size() == 0) {
            return serParams;
        }
        Map<String, SiteParam> map = new HashMap<>();

        //GC服务器的
        if (null != serParams && !serParams.isEmpty()) {
            for (int i = 0; i < serParams.size(); i++) {
                map.put(serParams.get(i).getSiteId() + "_" + serParams.get(i).getCellId(), serParams.get(i));
            }
        }

        //已勘测的
        if (null != surveyParams && !surveyParams.isEmpty()) {
            for (int i = 0; i < surveyParams.size(); i++) {
                map.put(surveyParams.get(i).getSiteId() + "_" + surveyParams.get(i).getCellId(), surveyParams.get(i));
            }
        }

        // TODO 删除下面逻辑，新建站点并不在GC平台保存，而是存在勘测后台，不能过滤平台不存在的点
//        if (null != surveyParams && !surveyParams.isEmpty()) {
//            for (int i = 0; i < surveyParams.size(); i++) {
//                if (map.containsKey(surveyParams.get(i).getSiteId() + "_" + surveyParams.get(i).getCellId())) {
//                    map.put(surveyParams.get(i).getSiteId() + "_" + surveyParams.get(i).getCellId(), surveyParams.get(i));
//                }
//            }
//        }

        //本地存储的
        List<SiteParam> locParams = DBManager.getInstance(BaseApplication.getAppContext()).getSiteLocParamDB()
                .queryAllByTaskId(projectId, groupId);

        // TODO 是否需要本地数据库内容 20220505 注释代码删除

        Iterator<Map.Entry<String, SiteParam>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, SiteParam> entry = it.next();
            params.add(entry.getValue());
        }
        return params;
    }

    /**
     * 查询仿真任务列表数量
     */
    public void querySimulationList(final String projectId, final String groupId, final TextView tvTaskCount) {
        QueryEmulationTaskListImpl.getInstance().getEmulationTask(projectId, groupId, new QueryEmulationTaskListImpl.EmulationTaskCallback() {
            @Override
            protected String getProjectId() { return projectId; }
            @Override
            protected String getGroupId() { return groupId; }
            @Override
            public void onFailure(ErrorBean e) { tvTaskCount.setVisibility(View.GONE); }
            @Override
            public void onResponse(List<EmulationEntrance> response) {
                if (response != null && response.size() > 0) {
                    tvTaskCount.setVisibility(View.VISIBLE);
                    tvTaskCount.setText(response.size() + "");
                } else {
                    tvTaskCount.setVisibility(View.GONE);
                }
            }
        });
    }

    /**
     * 计算实际参考信号功率
     *
     * @param power
     * @param AntennaName
     * @return
     */
    public String countRSPower(double power, String AntennaName) {
        double newPower = 0;
        if ("AAU5270E".equals(AntennaName)) {
            newPower = 10 * Math.log10(power * 1000) - 10 * Math.log10(162 * 12);
        } else {
            newPower = 10 * Math.log10(power * 1000) - 10 * Math.log10(273 * 12);
        }

        Log.e("SimulationListActivity", "AntennaName = " + AntennaName + ";newPower=" + newPower);
        return String.valueOf(Formatter.formatDouble6Point(newPower));
    }

    public List<CellInfoBean> transformWorkerToCell(String taskId, List<EmulationStation> emulationStations) {
        List<CellInfoBean> cellInfoBeanList = new ArrayList<>();
        return cellInfoBeanList;
    }

    /**
     * 工参转换
     *
     * @return
     */
    public List<WorkerParameter> transformWorkerParameter(String operatorId, String province, String city,
                                                          String district, List<SiteParam> beans) {
        List<WorkerParameter> parameters = new ArrayList<>();
        for (int i = 0; i < beans.size(); i++) {
            WorkerParameter workPrames = new WorkerParameter();
            SiteParam siteParam = beans.get(i);

            workPrames.setDowntilt(siteParam.getMechanicalDowntilt());
            workPrames.setAzimuth(siteParam.getAzimuth());
            workPrames.setElectricDownTil(siteParam.getDigitalDowntilt());
            workPrames.setAntennaName(siteParam.getAntenna());
            workPrames.setAntennaType(siteParam.getAntenna());
            workPrames.setHeight(siteParam.getHeight());

            workPrames.setSiteName(siteParam.getSiteName());
            workPrames.setCellName(siteParam.getCellName());
            workPrames.setSiteLat(siteParam.getSiteLat());
            workPrames.setSiteLng(siteParam.getSiteLng());

            workPrames.setProvince(province);
            workPrames.setCity(city);
            workPrames.setDistrict(district);
            workPrames.setNetOperator(operatorId);

            workPrames.setEnterTime("");
            workPrames.setAntennaManufacturer("");
            workPrames.setAntennaStatus("");
            workPrames.setNetWorkType("5G");
            workPrames.setCountry("中国");

            parameters.add(workPrames);
        }

        return parameters;
    }
}
