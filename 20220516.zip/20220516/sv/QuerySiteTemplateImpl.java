package com.huawei.genexcloud.survey.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.bean.CellInfo;
import com.huawei.genexcloud.framework.bean.SiteInfo;
import com.huawei.genexcloud.framework.bean.SiteTemplate;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.survey.http.util.GCCallback;
import com.huawei.genexcloud.survey.http.util.JavaHttpUtil;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 查询站点的模板参数
 */
public class QuerySiteTemplateImpl extends JavaHttpUtil {

    private static QuerySiteTemplateImpl instance;

    public static QuerySiteTemplateImpl getInstance() {
        if (null == instance) {
            synchronized (QuerySiteTemplateImpl.class) {
                if (null == instance) {
                    instance = new QuerySiteTemplateImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "QueryStationTemplateInfo";
    }

    public void getSiteTemplate(String account, SiteTemplateCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("Account", account);
        post(body, callback);
    }

    public static abstract class SiteTemplateCallback extends GCCallback<List<CellInfo>> {
        @Override
        public List<CellInfo> parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            String dataString = jsonObject.optString("JsonData");
            if (TextUtils.isEmpty(dataString)) {
                return null;
            }
            List<SiteTemplate> list = new ArrayList<>();
            Gson gson = new Gson();
            JsonArray arry = new JsonParser().parse(dataString).getAsJsonArray();
            for (JsonElement jsonElement : arry) {
                list.add(gson.fromJson(jsonElement, SiteTemplate.class));
            }
            return getCells(list);
        }
    }

    /**
     * 处理成功请求
     *
     * @param infos
     */
    private static List<CellInfo> getCells(List<SiteTemplate> infos) {
        List<CellInfo> cellInfos = new ArrayList<>();
        if (infos != null && infos.size() > 0) {
            SiteTemplate template = infos.get(0);
            cellInfos = template.getStationList();
            if (cellInfos != null && cellInfos.size() > 0) {
                for (CellInfo info : cellInfos) {
                    info.setTemplateid(template.getTemplateId());
                }
            }
        }

        //更新任务列表
        if (cellInfos != null) {
            DBManager.getInstance(BaseApplication.getAppContext()).getCellTemplateDB().deleteAll();
            DBManager.getInstance(BaseApplication.getAppContext()).getCellTemplateDB().insert(cellInfos);
        }

        return cellInfos;
    }


}
