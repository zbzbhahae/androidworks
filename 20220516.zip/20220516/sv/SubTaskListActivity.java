package com.huawei.genexcloud.survey.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;

import com.huawei.genexcloud.framework.base.BaseActivity;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.base.IBaseResultLinstener;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.bean.SimulationReqInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.QuerySubTaskListUtil;
import com.huawei.genexcloud.framework.http.UpdateEmulationUtil;
import com.huawei.genexcloud.framework.service.TaskService;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.PopupwindowUtils;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.adapter.SubTaskAdapter;
import com.huawei.genexcloud.survey.http.QueryEmulationTaskListImpl;
import com.huawei.genexcloud.survey.http.util.ErrorBean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import okhttp3.Request;

/**
 * 仿真任务列表（子任务列表）
 */
public class SubTaskListActivity extends BaseActivity
        implements View.OnClickListener, SubTaskAdapter.OnLookOperaterLister {

    private SubTaskAdapter subTaskAdapter;
    private Spinner spinnerState;
    private EditText etSearch;
    private List<EmulationEntrance> emulationEntranceList;
    private List<EmulationEntrance> filteredData;

    private String selectStatus = "";

    private ReceiveBroadCast mBroadcastReceiver;

//    private final String PROJECT_ID = "c7940870-c1c8-4294-b426-a7eec8e8af3a";
//    private final String GROUP_ID = "6220";
//    private final String TASK_ID = "20220304091060032829";

    @Override
    protected void initView() {
        ListView listView = (ListView) findViewById(R.id.subtask_list);
        findViewById(R.id.back).setOnClickListener(this);
        subTaskAdapter = new SubTaskAdapter(this);
        subTaskAdapter.setOnLookOperaterLister(this);
        listView.setAdapter(subTaskAdapter);
        spinnerState = (Spinner) findViewById(R.id.sumilation_state_spinner);
        spinnerState.setAdapter(getAdapter(R.array.sumilation_state));
        etSearch = (EditText) findViewById(R.id.et_search);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                int position = spinnerState.getSelectedItemPosition();
                switch (position) {
                    case 0:
                        selectStatus = "";
                        break;
                    case 1:
                        selectStatus = "未完成";
                        break;
                    case 2:
                        selectStatus = "已完成";
                        break;
                }
                filteredData = filterTaskData(emulationEntranceList);
                subTaskAdapter.setList(filteredData);
                subTaskAdapter.notifyDataSetChanged();
            }
        });

        spinnerState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        selectStatus = "";
                        break;
                    case 1:
                        selectStatus = "未完成";
                        break;
                    case 2:
                        selectStatus = "已完成";
                        break;
                }
                filteredData = filterTaskData(emulationEntranceList);
                subTaskAdapter.setList(filteredData);
                subTaskAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            }
        });
    }

    @Override
    protected void initData() {
        if (!AppUtil.isServiceRunning(this, "com.huawei.genexcloud.framework.service.TaskService")) {
            Intent service = new Intent(this, TaskService.class);
            startService(service);
        }
        mBroadcastReceiver = new ReceiveBroadCast();
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction(Constants.STATUS_CHANGE);
        myIntentFilter.addAction(Constants.DOWNLOAD_STATUS_CHANGE);
        // 注册广播
        registerReceiver(mBroadcastReceiver, myIntentFilter, Constants.PERMISSION_BROADCAST, null);

        queryTaskList(true);
    }

    public ArrayAdapter getAdapter(int arrayID) {
        ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource(this, arrayID, R.layout.spinner_sumilation_selete);
        arrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        return arrayAdapter;
    }

    /**
     * 查询仿真任务列表
     */
    private void queryTaskList(boolean isShowLoading) {
        String projectId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.PROJECTID, "");
        String groupId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.GROUP_ID, "");
        QueryEmulationTaskListImpl.getInstance().getEmulationTask(projectId, groupId, new QueryEmulationTaskListImpl.EmulationTaskCallback() {
            @Override
            protected String getProjectId() { return projectId; }
            @Override
            protected String getGroupId() { return groupId; }
            @Override
            public void onBefore(Request request) {
                if (isShowLoading) {
                    createLoadingDialog(SubTaskListActivity.this, SubTaskListActivity.this, "更新任务列表信息", false);
                }
            }
            @Override
            public void onAfter() { closeLoadDialog(); }
            @Override
            public void onFailure(ErrorBean e) { showToast(e.message); }
            @Override
            public void onResponse(List<EmulationEntrance> response) {
                emulationEntranceList = response;
                if (emulationEntranceList == null) {
                    emulationEntranceList = new ArrayList<>();
                }
                if (emulationEntranceList.size() == 0) {
                    showToast("暂无数据");
                }
                // 根据查询条件进行过滤
                filteredData = filterTaskData(emulationEntranceList);
                subTaskAdapter.setList(filteredData);
                subTaskAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_sub_task_list;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                this.finish();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        queryTaskList(false);
    }

    /**
     * 点击查勘报告
     *
     * @param emulationEntrance
     */
    @Override
    public void onLookOperaer(EmulationEntrance emulationEntrance) {
        Intent intent = new Intent(this, LoadWebActivity.class);
        intent.putExtra("projectId", emulationEntrance.getProjectId());
        intent.putExtra("groupId", emulationEntrance.getGroupId());
        intent.putExtra("taskId", emulationEntrance.getTaskId());
        startActivityForResult(intent, 0);
    }

    @Override
    public void onDeleteOperaer(EmulationEntrance emulationEntrance) {
        final SimulationReqInfo simulationReqInfo = new SimulationReqInfo();
        simulationReqInfo.setProjectId(emulationEntrance.getProjectId());
        simulationReqInfo.setGroupid(emulationEntrance.getGroupId());
        simulationReqInfo.setGroupName(emulationEntrance.getGroupName());
        simulationReqInfo.setTaskId(emulationEntrance.getTaskId());
        simulationReqInfo.setTaskName(emulationEntrance.getTaskName());
        simulationReqInfo.setResultImg("");
        simulationReqInfo.setFinish(false);
        simulationReqInfo.setStatus(-1);

        PopupwindowUtils.showIsDelete(this, etSearch, 4, new PopupwindowUtils.PopDismissCallBack() {
            @Override
            public void ToDismiss() {
            }

            @Override
            public void onSure() {
                delete(simulationReqInfo, true);
            }
        });
    }

    /**
     * 进入仿真结果页面
     *
     * @param info
     */
    private void enterSimulationResult(EmulationEntrance info) {
        Intent intent = new Intent(this, SimulationResultActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("EmulationEntrance", info);
        intent.putExtras(bundle);
        startActivityForResult(intent, 0);
    }

    /**
     * 删除任务
     */
    private void delete(final SimulationReqInfo simulationReqInfo, boolean isShowLoading) {
        if (isShowLoading) {
            createLoadingDialog(this, this, "", false);
        }
        UpdateEmulationUtil.getInstance().asyncExecute(simulationReqInfo, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
                closeLoadDialog();
                showToast("删除失败");
            }

            @Override
            public void onSuccess(Object obj) {
                //                showToast("删除成功");
                queryTaskList(false);
                Intent intent = new Intent(Constants.CANCEL_SIMULATION);
                intent.setPackage(Constants.PACKAGE_NAME);
                sendBroadcast(intent, Constants.PERMISSION_BROADCAST);
            }

            @Override
            public void onEmpty() {
                closeLoadDialog();
            }
        });
    }

    /**
     * 查询数据库数据，展示
     */
    public void queryDBdata() {
        String projectId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue("projectId", "");
        String groupId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.GROUP_ID, "");
//        String projectId = PROJECT_ID;
//        String groupId = GROUP_ID;

        emulationEntranceList = DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB()
                .queryAllByTaskId(projectId, groupId);

        if (emulationEntranceList == null) {
            emulationEntranceList = new ArrayList<>();
        }

        // 根据查询条件进行过滤
        filteredData = filterTaskData(emulationEntranceList);


        subTaskAdapter.setList(filteredData);
        subTaskAdapter.notifyDataSetChanged();
    }

    /**
     * 根据选择结果进行过滤
     * @param unfilteredData 未过滤前数据
     */
    private List<EmulationEntrance> filterTaskData(List<EmulationEntrance> unfilteredData) {
        if (null == unfilteredData || 0 == unfilteredData.size()) {
            return null;
        }
        List<EmulationEntrance> filteredData = new ArrayList<>();
        filteredData.addAll(unfilteredData);
        // 先根据状态过滤
        if ("已完成".equals(selectStatus)) {
            Iterator<EmulationEntrance> iterator = filteredData.iterator();
            while (iterator.hasNext()) {
                EmulationEntrance item = iterator.next();
                if (!item.isFinish) {
                    iterator.remove();
                }
            }
        } else if ("未完成".equals(selectStatus)) {
            Iterator<EmulationEntrance> iterator = filteredData.iterator();
            while (iterator.hasNext()) {
                EmulationEntrance item = iterator.next();
                if (item.isFinish) {
                    iterator.remove();
                }
            }
        }
        // 过滤掉状态后 再根据搜索内容进行过滤
        String searchContent = etSearch.getText().toString();
        if (TextUtils.isEmpty(searchContent)) {
            return filteredData;
        }
        String[] inputs = searchContent.split(" ");
        for (String input : inputs) {
            if (!TextUtils.isEmpty(input)) {
                Iterator<EmulationEntrance> iterator = filteredData.iterator();
                while (iterator.hasNext()) {
                    EmulationEntrance item = iterator.next();
                    // 任务名称和创建账户都不存在搜索字段 则过滤该数据
                    if ( (TextUtils.isEmpty(item.getTaskName()) || !item.getTaskName().contains(input))
                            && (TextUtils.isEmpty(item.getAccount()) || !item.getAccount().contains(input)) ) {
                        iterator.remove();
                    }
                }
            }
        }
        return filteredData;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mBroadcastReceiver != null) {
            unregisterReceiver(mBroadcastReceiver);
            mBroadcastReceiver = null;
        }
    }

    /**
     * 接收状态改变广播
     *
     * @author lWX348305
     */
    class ReceiveBroadCast extends BroadcastReceiver {
        /**
         * {@inheritDoc}
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Constants.STATUS_CHANGE.equals(action)) {
                //状态更新后，只查询本地数据更新本地数据状态
                queryDBdata();
            } else if (Constants.DOWNLOAD_STATUS_CHANGE.equals(action)) {
                subTaskAdapter.notifyDataSetChanged();
            }
        }
    }
}
