package com.huawei.genexcloud.survey.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.framework.bean.CellInfo;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.log.Module;
import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 更新站点模板信息
 */
public class UpdateSiteTemplateImpl extends CSharpHttpUtil {

    private static UpdateSiteTemplateImpl instance;

    public static UpdateSiteTemplateImpl getInstance() {
        if (null == instance) {
            synchronized (UpdateSiteTemplateImpl.class) {
                if (null == instance) {
                    instance = new UpdateSiteTemplateImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "UpdateStationTmplateInfo";
    }

    public void updateSiteTemplate(List<CellInfo> cellInfos, UpdateTemplateCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("StationList", getCellParameters(cellInfos));
        postSingle(instance, body, callback);
    }

    public static abstract class UpdateTemplateCallback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            if ("Success".equals(jsonObject.optString("Message")) && 220 == jsonObject.optInt("StatusCode")) {
                return true;
            }
            return false;
        }
    }

    private static JSONArray getCellParameters(List<CellInfo> cellInfos) {
        if (null == cellInfos || cellInfos.isEmpty()) {
            return null;
        }
        JSONArray array = new JSONArray();
        for (int i = 0; i < cellInfos.size(); i++) {
            CellInfo param = cellInfos.get(i);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("Templateid", param.getTemplateid());
                jsonObject.put("CellName", param.getCellName());
                jsonObject.put("CellId", param.getCellId());

                jsonObject.put("Azimuth", param.getAzimuth());
                jsonObject.put("Mechanical_Downtilt", param.getMechanical_Downtilt());
                jsonObject.put("Height", param.getHeight());
                jsonObject.put("Digital_Downtilt", param.getDigital_Downtilt());
                jsonObject.put("Digital_Azimuth", param.getDigital_Azimuth());
                jsonObject.put("Antenna", param.getAntenna());
                jsonObject.put("Main_Propagation_Model", param.getMain_Propagation_Model());
                jsonObject.put("Frequency_Band", param.getFrequency_Band());
                jsonObject.put("RS_Power", param.getRS_Power());
                jsonObject.put("Number_of_Transmission_Antennas", param.getNumber_of_Transmission_Antennas());
                jsonObject.put("Number_of_Reception_Antennas", param.getNumber_of_Reception_Antennas());
                jsonObject.put("Main_Calculation_Radius", param.getMain_Calculation_Radius());
                array.put(jsonObject);
            } catch (JSONException e) {
                GCLogger.error("error", "更新站点模板 构建参数失败");
            }
        }

        return array;
    }
}
