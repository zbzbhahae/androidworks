package com.huawei.genexcloud.survey.activity;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.baidu.mapapi.map.MapView;
import com.huawei.genexcloud.framework.base.BaseActivity;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.base.IBaseResultLinstener;
import com.huawei.genexcloud.framework.bean.TaskInfo;
import com.huawei.genexcloud.framework.bean.VersionInfo;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.http.QueryVersionUtil;
import com.huawei.genexcloud.framework.service.TaskService;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.CrashHandlerUtil;
import com.huawei.genexcloud.framework.util.DensityUtil;
import com.huawei.genexcloud.framework.util.FileUtil;
import com.huawei.genexcloud.framework.util.GCEnvironmentInfo;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.fragment.BaseFragment;
import com.huawei.genexcloud.survey.fragment.FragmentFactory;
import com.huawei.genexcloud.survey.fragment.MainTabFragment;
import com.huawei.genexcloud.survey.fragment.UpdateDialogFragment;

import java.util.ArrayList;

/**
 * 勘测首页
 */
public class HomeActivity extends BaseActivity {

    private final String TAG = "HomeActivity";
    private FragmentManager fragmentManager = null;
    private BaseFragment currFragment;
    private PopupWindow popupWindow;

    private final Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            closeLoadDialog();
            switch (msg.what) {
                case Constants.QUERY_ANTENNA_FAILED:
                    break;
                case Constants.QUERY_ANTENNA_SUCCESS:
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseApplication.setMapCustomFile(BaseApplication.getAppContext(), BaseApplication.PATH);
    }

    @Override
    protected void initView() {
        intiUI();
    }

    private void intiUI() {
        fragmentManager = getSupportFragmentManager();
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.rg_tab);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                FragmentTransaction transaction = fragmentManager.beginTransaction();
                // 先移除
                if (currFragment != null) {
                    transaction.hide(currFragment);
                }

                currFragment = (BaseFragment) fragmentManager.findFragmentByTag(checkedId + "");

                if (currFragment == null) {
                    // 添加
                    currFragment = FragmentFactory.getMainByIndex(checkedId);
                    transaction.add(R.id.content, currFragment, checkedId + "");
                } else {
                    transaction.show(currFragment);
                }
                currFragment.onShow();
                transaction.commitAllowingStateLoss();
                fragmentManager.executePendingTransactions();
                setViewCheck(checkedId);
            }
        });

        ((RadioButton) radioGroup.getChildAt(0)).setChecked(true);
    }

    // 设置底部点击后的图标
    private void setViewCheck(int id) {
        MainTabFragment mainTabFragment;
        switch (id) {
            case R.id.home:
                ((RadioButton) findViewById(R.id.home)).setChecked(true);

                setDrawable(((RadioButton) findViewById(R.id.home)), R.drawable.icon_survey_main_down);
                setDrawable(((RadioButton) findViewById(R.id.cankao)), R.drawable.icon_cankao_gray);
                setDrawable(((RadioButton) findViewById(R.id.my)), R.drawable.icon_my_gray);
                break;
            case R.id.cankao:
                ((RadioButton) findViewById(R.id.cankao)).setChecked(true);
                setDrawable(((RadioButton) findViewById(R.id.home)), R.drawable.icon_survey_main_gray);
                setDrawable(((RadioButton) findViewById(R.id.cankao)), R.drawable.icon_cankao_down);
                setDrawable(((RadioButton) findViewById(R.id.my)), R.drawable.icon_my_gray);

                mainTabFragment = (MainTabFragment) fragmentManager.findFragmentByTag(R.id.home + "");
                if (mainTabFragment != null) {
                    mainTabFragment.onHide();
                }
                break;
            case R.id.my:
                ((RadioButton) findViewById(R.id.my)).setChecked(true);
                setDrawable(((RadioButton) findViewById(R.id.home)), R.drawable.icon_survey_main_gray);
                setDrawable(((RadioButton) findViewById(R.id.cankao)), R.drawable.icon_cankao_gray);
                setDrawable(((RadioButton) findViewById(R.id.my)), R.drawable.icon_my_down);

                mainTabFragment = (MainTabFragment) fragmentManager.findFragmentByTag(R.id.home + "");
                if (mainTabFragment != null) {
                    mainTabFragment.onHide();
                }
                break;
            default:
                break;
        }
    }

    private void setDrawable(RadioButton radioButton, int resId) {
        Drawable drawable_news = getResources().getDrawable(resId);
        drawable_news.setBounds(0, 0, DensityUtil.dip2px(this, 20), DensityUtil.dip2px(this, 20));
        radioButton.setCompoundDrawables(null, drawable_news, null, null);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // 防止Activity被回收，获取getActivity空指针；或者注释掉super.onSaveInstanceState(outState);
        if (outState != null) {
            String FRAGMENTS_TAG = "android:support:fragments";
            // remove掉保存的Fragment
            outState.remove(FRAGMENTS_TAG);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(new Intent(this, TaskService.class));
    }

    @Override
    protected void initData() {
        // 初始化存储路径变量
        GCEnvironmentInfo.initializeFirst(getApplicationContext());
        // 创建模板文件夹
        FileUtil.createDirector(GCEnvironmentInfo.getProductFileDirectory() + Constants.DIR_TEMPLATE);
//        CrashHandlerUtil.getInstance().init(getApplicationContext());
        // 检查更新
        checkVersion(true);
    }

    /**
     * 查询版本
     */
    public void checkVersion(final boolean auto) {
        QueryVersionUtil.getInstance().asyncExecute(null, new IBaseResultLinstener() {
            @Override
            public void onFail(int resultCode, String resultError) {
            }

            @Override
            public void onSuccess(Object obj) {
                if (!isFinishing()) {
                    VersionInfo info = (VersionInfo) obj;
                    if (info != null) {
                        SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                                .saveStringValue(Constants.SER_VERSION, info.getVersionName());
                        int level = info.getVersionLevel();// 获取到升级等级
                        if (AppUtil.checkVersionCode(getApplicationContext(), info.getVersionName())) {// 比较当前版本号与平台的
                            if (auto) {
                                if (level == 1 || level == 2) {
                                    new UpdateDialogFragment().setLevel(level, info.getDescribe(), info.getAppPath())
                                            .show(getSupportFragmentManager(), "update_apk_fragment");
                                }
                            } else {
                                new UpdateDialogFragment().setLevel(level, info.getDescribe(), info.getAppPath())
                                        .show(getSupportFragmentManager(), "update_apk_fragment");
                            }

                        }
                    }
                }
            }

            @Override
            public void onEmpty() {
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                exit();
                return true;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_home;
    }

    private void exit() {
        ArrayList<TaskInfo> infoList = DBManager.getInstance(BaseApplication.getAppContext()).getTempTaskInfoDB()
                .queryAll();

        if (infoList != null && infoList.size() > 0) {
            // 退出的确认框 “有任务正在创建”
            confirmExit();
        } else {
//            finish();
//            MapView.setMapCustomEnable(false);
            onBackPressed();
        }
    }

    private void confirmExit() {
        View view = LayoutInflater.from(this).inflate(R.layout.item_pop_exit, null);

        popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAtLocation(findViewById(R.id.content), Gravity.CENTER, 0, 0);
        view.findViewById(R.id.tv_bg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });

        view.findViewById(R.id.btn_pop_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        view.findViewById(R.id.btn_pop_sure).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                finish();
                MapView.setMapCustomEnable(false);
            }
        });
    }

    private long lastBackPressTime = 0;
    @Override
    public void onBackPressed() {
        long duration = System.currentTimeMillis() - lastBackPressTime;
        if (duration > 2000) {
            lastBackPressTime = System.currentTimeMillis();
            showToast("再按一次返回键退出");
            return;
        }
        this.moveTaskToBack(true);
    }
}
