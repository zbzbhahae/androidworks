package com.huawei.genexcloud.survey.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.bean.EmulationEntrance;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.db.DBManager;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.log.Module;
import com.huawei.genexcloud.survey.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.survey.http.util.GCCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 查询仿真任务列表
 */
public class QueryEmulationTaskListImpl extends CSharpHttpUtil {

    private static QueryEmulationTaskListImpl instance;

    public static QueryEmulationTaskListImpl getInstance() {
        if (null == instance) {
            synchronized (QueryEmulationTaskListImpl.class) {
                if (null == instance) {
                    instance = new QueryEmulationTaskListImpl();
                }
            }
        }
        return instance;
    }
    @Override
    protected String getMessageName() {
        return "QueryEmulationListGroup";
    }

    /**
     * 获取仿真任务列表
     * @param projectId 项目id
     * @param groupId 分组id
     * @param callback 回调
     */
    public void getEmulationTask(String projectId, String groupId, EmulationTaskCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("ProjectId", projectId);
        body.put("GroupId", groupId);
        postSingle(this, body, callback);
    }

    public static abstract class EmulationTaskCallback extends GCCallback<List<EmulationEntrance>> {
        protected abstract String getProjectId();
        protected abstract String getGroupId();
        @Override
        public List<EmulationEntrance> parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            String data = jsonObject.optString("JsonData");
            if (NULL_VALUE.equalsIgnoreCase(data) || TextUtils.isEmpty(data)) {
                // 返回无数据 删除数据库相关内容
                DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB()
                        .deleteByTask(getProjectId(), getGroupId());
                return null;
            } else {
                List<EmulationEntrance> emulationEntrances = new ArrayList<>();
                JSONArray array = new JSONArray(data);

                if (array != null && array.length() > 0) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        Gson gson = new Gson();
                        EmulationEntrance emulationEntrance = gson.fromJson(object.toString(), EmulationEntrance.class);
                        emulationEntrances.add(emulationEntrance);
                    }
                }

                //更新仿真任务表
                if (emulationEntrances != null) {
                    DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB()
                            .deleteByTask(getProjectId(),getGroupId());
                    DBManager.getInstance(BaseApplication.getAppContext()).getSimulationTaskDB().insert(emulationEntrances);
                }
                return emulationEntrances;
            }
        }
    }

}
