package com.huawei.genexcloud.permission.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


import com.huawei.genexcloud.permission.bean.UserDataPermissionBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PermissionViewModel extends ViewModel {

    private MutableLiveData<List<UserDataPermissionBean>> userPermissionLiveData;

    // 数据权限 角色id与角色描述的关系
    private Map<Integer, String> roleReference;
    // 数据权限 业务id与业务描述的关系
    private Map<Integer, String> modelReference;


    public PermissionViewModel() {
        List<UserDataPermissionBean> permissionList = new ArrayList<>();
        userPermissionLiveData = new MutableLiveData<>(permissionList);
    }

    public List<UserDataPermissionBean> getUserPermissions() {
        return userPermissionLiveData.getValue();
    }

    public MutableLiveData<List<UserDataPermissionBean>> getPermissionLiveData() {
        return userPermissionLiveData;
    }

    public void setUserPermissionNoNotify(List<UserDataPermissionBean> data) {
        List<UserDataPermissionBean> userList = userPermissionLiveData.getValue();
        if (null != data) {
            if (data != userList) {
                userList.clear();
                userList.addAll(data);
            }
        } else {
            userList.clear();
        }
    }

    public void setUserPermissionsNotify(List<UserDataPermissionBean> data) {
        List<UserDataPermissionBean> userList = userPermissionLiveData.getValue();
        if (null != data) {
            if (data != userList) {
                userList.clear();
                userList.addAll(data);
            }
        } else {
            userList.clear();
        }
        userPermissionLiveData.setValue(userList);
    }

    /**
     * 增加内容
     * @param needAddList
     */
    public void addUserPermissionNotify(List<UserDataPermissionBean> needAddList) {
        if (null != needAddList && !needAddList.isEmpty()) {
            userPermissionLiveData.getValue().addAll(needAddList);
        }
        userPermissionLiveData.setValue(userPermissionLiveData.getValue());
    }

    public void clear() {
        // 清除存储的数据
        List<UserDataPermissionBean> userList = userPermissionLiveData.getValue();
        userList.clear();
        userPermissionLiveData.setValue(userList);
    }

    public void setRoleReference(Map<Integer, String> reference) {
        if (null != reference && !reference.isEmpty()) {
            roleReference = reference;
        }
    }
    public void setModelReference(Map<Integer, String> reference) {
        if (null != reference && !reference.isEmpty()) {
            modelReference = reference;
        }
    }



}
