package com.huawei.genexcloud.permission.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.permission.bean.UserDataPermissionBean;

import java.util.List;

/**
 * 给用户授权数据权限时，显示已选择的数据权限列表的adapter
 */
public class GrantPermissionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_NORMAL = 1;
    private final int VIEW_TYPE_FOOTER = 2;

    private List<UserDataPermissionBean> data;

    private OnItemFooterClickListener listener;

    public void setOnItemFooterClickListener(OnItemFooterClickListener listener) {
        this.listener = listener;
    }

    public void setData(List<UserDataPermissionBean> data) {
        this.data = null;
        notifyDataSetChanged();
        this.data = data;
        if (null != data) {
            notifyItemMoved(0, data.size());
        }
    }

    public List<UserDataPermissionBean> getData() {
        return data;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (VIEW_TYPE_NORMAL == viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grant_permission, parent, false));
        } else if (VIEW_TYPE_FOOTER == viewType) {
            return new Footer(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grant_permission, parent, false));
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof VH) {
            UserDataPermissionBean bean = data.get(position);
            VH h = (VH) holder;
            h.permissionLimit.setText(String.format("%s/%s/%s/%s/%s", bean.getProvince(), bean.getCity(), bean.getOperatorName(), bean.getBusinessName(), bean.getRoleName()));
            h.permissionLimit.setTextColor(0xFF1C1C1C);
            h.handleButton.setImageResource(R.drawable.icon_minus_gray);
            h.handleButton.setOnClickListener(v->{
                if (null != listener) {
                    listener.onDeleteButtonClicked(h.getLayoutPosition());
                }
            });
        } else if (holder instanceof Footer) {
            Footer h = (Footer) holder;
            h.permissionLimit.setText("请选择");
            h.permissionLimit.setTextColor(0xFFC1C1C1);
            h.handleButton.setImageResource(R.drawable.icon_add_blue);
            h.handleButton.setOnClickListener(v->{
                if (null != listener) {
                    listener.onFooterClicked();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        // 包含footer
        return null == data ? 1 : data.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (null == data || position == data.size()) {
            return VIEW_TYPE_FOOTER;
        }
        return VIEW_TYPE_NORMAL;
    }

    class VH extends RecyclerView.ViewHolder {

        private TextView permissionLimit;
        private ImageView handleButton;

        public VH(@NonNull View itemView) {
            super(itemView);
            permissionLimit = itemView.findViewById(R.id.grant_permission_limit);
            handleButton = itemView.findViewById(R.id.grant_handle_button);
        }
    }

    class Footer extends RecyclerView.ViewHolder {

        private TextView permissionLimit;
        private ImageView handleButton;

        public Footer(@NonNull View itemView) {
            super(itemView);
            permissionLimit = itemView.findViewById(R.id.grant_permission_limit);
            handleButton = itemView.findViewById(R.id.grant_handle_button);
        }
    }

    public interface OnItemFooterClickListener {
        void onItemClicked(int position);

        void onFooterClicked();

        void onDeleteButtonClicked(int position);
    }

}
