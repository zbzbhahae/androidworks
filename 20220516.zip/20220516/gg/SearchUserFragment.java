package com.huawei.genexcloud.permission.frags;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.BaseFragment;
import com.huawei.genexcloud.databinding.FragSearchUserBinding;
import com.huawei.genexcloud.dialog.ConfirmCancelDialog;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.permission.adapter.PermissionListAdapter;
import com.huawei.genexcloud.permission.bean.ApplyDetailBean;
import com.huawei.genexcloud.permission.bean.UserDataPermissionBean;
import com.huawei.genexcloud.permission.dialog.RejectConfirmDialog;
import com.huawei.genexcloud.permission.http.AddDataPermissionImpl;
import com.huawei.genexcloud.permission.http.AddGCPermissionImpl;
import com.huawei.genexcloud.permission.http.DeleteDataPermissionImpl;
import com.huawei.genexcloud.permission.http.HandlerUserPermissionImpl;
import com.huawei.genexcloud.permission.http.QueryDataPermissionImpl;
import com.huawei.genexcloud.permission.http.QueryRoleBusinessInfoImpl;
import com.huawei.genexcloud.permission.viewmodel.PermissionViewModel;
import com.huawei.genexcloud.permission.widget.EmptyDividerItemDecoration;
import com.huawei.genexcloud.util.AppUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import okhttp3.Request;

public class SearchUserFragment extends BaseFragment implements View.OnClickListener {

    // 是搜索状态或者是给特定申请人员添加权限
    public static final int MODE_SEARCH = 1, MODE_STABLE = 2;
    private int mMode = MODE_SEARCH;
    // 申请人的详细申请信息
    private ApplyDetailBean applyDetailBean;

    private FragSearchUserBinding binding;
    private PermissionListAdapter adapter;
    private List<UserDataPermissionBean> userPermissionData;

    private PermissionViewModel viewModel;

    // 搜索权限成功的账号 用于添加时判断添加的账号是否是当前搜索的账号
    private String accountSearched;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyDetailBean = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragSearchUserBinding.inflate(inflater, container, false);
        Bundle args = getArguments();
        mMode = MODE_SEARCH;
        if (null != args) {
            applyDetailBean = args.getParcelable("data");
            if (null != applyDetailBean) {
                mMode = MODE_STABLE;
            }
        }
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        applyDetailBean = null;
        viewModel.setUserPermissionNoNotify(null);
    }

    public void initView() {
        binding.resetButton.setOnClickListener(this);
        binding.confirmButton.setOnClickListener(this);

        binding.searchUserPermissionList.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new PermissionListAdapter();
        binding.searchUserPermissionList.setAdapter(adapter);
        binding.searchUserPermissionList.addItemDecoration(new EmptyDividerItemDecoration(getContext(), EmptyDividerItemDecoration.VERTICAL));
    }

    public void initData() {
        // 查询角色id 和业务id对应关系 如果未能拿到具体信息 则使用固定值
        QueryRoleBusinessInfoImpl.getInstance().getRoleBusinessMap();
        if (mMode == MODE_STABLE) {
            // 查找对象
            // 输入框可编辑
            binding.searchInput.setEnabled(false);
            binding.searchInput.setFocusable(false);
            binding.searchInput.setFocusableInTouchMode(false);
            binding.searchInput.setText(applyDetailBean.account);
            binding.applyReasonLayout.setVisibility(View.VISIBLE);
            binding.applyReason.setText(applyDetailBean.reason);
            binding.resetButton.setText("拒绝");
        } else if (mMode == MODE_SEARCH) {
            // 给指定对象添加权限
            binding.searchInput.setEnabled(true);
            binding.searchInput.setFocusable(true);
            binding.searchInput.setFocusableInTouchMode(true);
            binding.searchInput.requestFocus();
            binding.applyReasonLayout.setVisibility(View.GONE);
            binding.resetButton.setText("重置");
        }

        viewModel = new ViewModelProvider(getActivity()).get(PermissionViewModel.class);
        userPermissionData = new ArrayList<>();
        adapter.setData(userPermissionData);

        viewModel.getPermissionLiveData().observe(getViewLifecycleOwner(), userDataPermissionBeans -> {
            userPermissionData.clear();
            userPermissionData.addAll(userDataPermissionBeans);
            adapter.setData(userPermissionData);
        });


        binding.searchInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || (null != event && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    // 点击了键盘的搜索
                    requestUserPermission();
                    return true;
                }
                return false;
            }
        });

        binding.backBtn.setOnClickListener(this);
        binding.resetButton.setOnClickListener(this);
        binding.confirmButton.setOnClickListener(this);

        adapter.setOnItemFooterClickListener(new PermissionListAdapter.OnItemFooterClickListener() {
            @Override
            public void onItemClicked(int position) { }
            @Override
            public void onFooterClicked() {
                // 点击了添加按钮
                if (mMode == MODE_STABLE) {
                    // 权限申请模式
                    if (null != applyDetailBean && !TextUtils.isEmpty(applyDetailBean.account)) {
                        goChoosePermission(applyDetailBean.account);
                    }
                } else if (mMode == MODE_SEARCH) {
                    String accountInput = binding.searchInput.getText().toString().trim();
                    if (TextUtils.isEmpty(accountInput) || !accountInput.equals(accountSearched)) {
                        // 账号权限未搜索过权限或者显示的权限不是当前账号
                        showMsg("请先搜索账号获取权限信息!");
                        return;
                    } else {
                        goChoosePermission(accountInput);
                    }
                }
            }
            @Override
            public void onDeleteButtonClicked(int position) {
                // 点击了删除按钮
                GCLogger.error("frag", "删除了-》" + position);

                List<UserDataPermissionBean> data = adapter.getData();
                if (null == data || data.isEmpty() || position < 0 || position >= data.size()) {
                    return;
                }
                UserDataPermissionBean bean = data.get(position);
                if (null != bean && bean.getId() > 0 && bean.getFrom() == UserDataPermissionBean.ONLINE) {
                    // 来自服务器的权限信息 删除需要操作确认
                    showDeleteDialog(position, data);
                } else {
                    // 手动添加的权限，删除无需用户确认
                    userPermissionData.remove(position);
                    adapter.notifyItemRemoved(position);
                }

            }
        });
    }

    /**
     * 去手动添加账号权限
     * @param account 需要手动添加数据权限的账号
     */
    private void goChoosePermission(String account) {
        GrantPermissionFragment grantPermissionFragment = new GrantPermissionFragment();
        Bundle bundle = new Bundle();
        bundle.putString("account", account);
        grantPermissionFragment.setArguments(bundle);
        push(grantPermissionFragment);
    }

    /**
     * 点击某条权限的删除按钮
     * @param position
     * @param data
     */
    private void showDeleteDialog(int position, List<UserDataPermissionBean> data) {
        UserDataPermissionBean bean = data.get(position);
        // 是查询出的用户权限信息 弹出删除确认框
        ConfirmCancelDialog dialog = new ConfirmCancelDialog()
                .setBackground(R.drawable.bg_dialog_license)
                .setCancelText("取消")
                .setConfirmText("删除")
                .setContentText("您确认要删除当前用户的该条权限吗？")
                .setConfirmCancelCallback(new ConfirmCancelDialog.ConfirmCancelCallback() {
                    @Override
                    public void onConfirm() {
                        // 确认删除 去访问网络
                        goDeleteDataPermission(position, data, bean);
                    }
                    @Override
                    public void onCancel() {
                        // 取消删除
                    }
                });
        dialog.show(getChildFragmentManager());
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.resetButton) {
            if (mMode == MODE_STABLE) {
                // 拒绝用户申请
                RejectConfirmDialog rejectConfirmDialog = new RejectConfirmDialog();
                rejectConfirmDialog.setListener(new RejectConfirmDialog.OnButtonClickListener() {
                    @Override
                    public void onCancel() {
                        // 取消 无操作
                    }

                    @Override
                    public void onConfirm(String rejectReason) {
                        // 拒绝申请
                        rejectUser(applyDetailBean, rejectReason);
                    }
                });
                rejectConfirmDialog.show(getChildFragmentManager(), "rejectConfirmDialog");
            } else {
                resetStatus();
            }
        } else if (v == binding.confirmButton) {
            // 同意用户申请
            String accountInput = binding.searchInput.getText().toString().trim();
            if (mMode == MODE_STABLE) {
                if (null != applyDetailBean) {
                    if (!TextUtils.isEmpty(applyDetailBean.account)) {
                        addGCPermission(applyDetailBean.account);
                    } else {
                        showMsg("权限账号与申请账号不符!");
                    }
                }
            } else if (mMode == MODE_SEARCH) {
                if (TextUtils.isEmpty(accountInput)) {
                    showMsg("请先输入需要添加权限的账号!");
                    return;
                } else if (!accountSearched.equals(accountInput)) {
                    // 即将添加权限的账号和获得权限的账号不同
                    showMsg("请先搜索该账号权限!");
                    return;
                }

                addGCPermission(accountInput);
            }
            // 收集当前添加的数据权限

            // 先添加用户的GC进入权限
            grantUser(applyDetailBean);
            // 再添加数据权限

        } else if (v == binding.backBtn) {
            backPressed();
        }
    }

    /**
     * 访问网络删除权限
     * @param position
     * @param data
     * @param bean
     */
    private void goDeleteDataPermission(int position, List<UserDataPermissionBean> data, UserDataPermissionBean bean) {
        DeleteDataPermissionImpl.getInstance().deleteDataPermission(bean.getId(), new DeleteDataPermissionImpl.DeleteDataPermissionCallback() {
            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }
            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }
            @Override
            public void onResponse(Boolean response) {
                if (response) {
                    // 删除成功
                    data.remove(bean);
                    adapter.notifyItemRemoved(position);
                } else {
                    showMsg("删除权限失败！");
                }
            }
        });
    }

    /**
     * 给用户添加GC进入权限
     */
    private void addGCPermission(String account) {
        AddGCPermissionImpl.getInstance().addTargetUserPermission(account, new AddGCPermissionImpl.GCAddPermissionCallback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }
            @Override
            public void onFailure(ErrorBean e) {
                dismissLoadingDialog();
                showMsg(e.message);
            }
            @Override
            public void onResponse(Integer response) {
                if (response == AddGCPermissionImpl.SUCCESS) {
                    // 添加GC进入权限成功 去添加数据权限
                    addDataPermission(account);
                } else if (response == AddGCPermissionImpl.NOT_ADMIN) {
                    dismissLoadingDialog();
                    showMsg("只有管理员能够添加权限!");
                } else {
                    dismissLoadingDialog();
                    showMsg("添加权限失败!");
                }
            }
        });
    }

    /**
     * 添加数据权限
     * @param account 对方的账号，如果是搜索结果，则是搜索输入的账号 ， 如果是权限申请进入，则是权限申请人账号
     */
    private void addDataPermission(String account) {
        List<UserDataPermissionBean> permissionList = viewModel.getUserPermissions();
        if (null == permissionList || permissionList.isEmpty()) {
            dismissLoadingDialog();
            showMsg("添加成功!");
            return;
        }
        // 防止对原数据进行改动，新建一个list将内容放进去
        List<UserDataPermissionBean> copyList = new ArrayList<>();
        copyList.addAll(permissionList);
        // 过滤来自查询的网络权限结果
        Iterator<UserDataPermissionBean> iterator = copyList.listIterator();
        while (iterator.hasNext()) {
            UserDataPermissionBean bean = iterator.next();
            if (UserDataPermissionBean.ONLINE == bean.getFrom() || !account.equals(bean.getAccount())) {
                // 账号不一致或者不是新增权限 则过滤掉
                iterator.remove();
            }
        }
        // 判断过滤后的新增权限
        if (copyList.isEmpty()) {
            dismissLoadingDialog();
            showMsg("添加成功!");
            return;
        }
        // 添加数据权限
        AddDataPermissionImpl.getInstance().addDataPermission(copyList, new AddDataPermissionImpl.AddDataPermissionCallback() {
            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }
            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onResponse(Boolean response) {
                if (response) {
                    showMsg("添加成功!");
                    backPressed();
                } else {
                    showMsg("添加失败!");
                }
            }
        });

    }

    /**
     * 重置搜索状态
     */
    private void resetStatus() {
        accountSearched = null;
        viewModel.clear();
        binding.searchInput.setText("");
    }

    /**
     * 拉取账号权限信息
     */
    private void requestUserPermission() {
        final String targetAccount = binding.searchInput.getText().toString().trim();
        if (TextUtils.isEmpty(targetAccount)) {
            showMsg("搜索内容不能为空~");
            return;
        }

        QueryDataPermissionImpl.getInstance().getUserDataPermission(targetAccount, new QueryDataPermissionImpl.DataPermissionCallback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onResponse(List<UserDataPermissionBean> response) {
                if (null == response || response.isEmpty()) {
                    showMsg("无该用户或者用户无数据权限");
                }
                // 给当前搜索的账号赋值
                accountSearched = targetAccount;
                viewModel.setUserPermissionsNotify(response);
            }
        });
    }

    /**
     * 拒绝用户申请的权限
     * @param user
     * @param rejectReason
     */
    public void rejectUser(ApplyDetailBean user, String rejectReason) {
        if (null == user) {
            return;
        }
        HandlerUserPermissionImpl.getInstance().rejectUser(user.applyId, rejectReason, new HandlerUserPermissionImpl.BooleanCallback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onResponse(Boolean response) {
                if (response) {
                    showMsg("操作成功");
                    // 拒绝后直接退出
                    backPressed();
                } else {
                    showMsg("操作失败");
                }
            }
        });
    }

    /**
     * 通过用户申请
     * @param user
     */
    public void grantUser(ApplyDetailBean user) {
        if (null == user) {
            return;
        }
        HandlerUserPermissionImpl.getInstance().grantUser(user.applyId, new HandlerUserPermissionImpl.BooleanCallback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onResponse(Boolean response) {
                if (response) {
                    // 添加权限成功 去添加数据权限
                } else {
                    showMsg("操作失败");
                }
            }
        });
    }


}
