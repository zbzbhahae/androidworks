package com.huawei.genexcloud.permission.bean;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * 用户数据权限bean
 * 一个bean代表一条权限
 */
public class UserDataPermissionBean {

    // 权限的来历 网上获取 手动添加(还未上传)
    public static final int ONLINE = 1, ADDING = 2;

    // 权限所在省份信息
    private String province;
    // 权限市信息
    private String city;
    // 对应的运营商代号
    private String operatorCode;
    // 运营商显示的中文名 只能get
    private String operatorName = "无";
    // 对应的插件信息 即businessCode对应的businessName
    private String businessName;
    // 对应的业务code
    private int businessCode = -1;
    // 权限角色id
    private int roleId;
    // 权限角色名称
    private String roleName;
    // 权限对应的账号
    private String account;
    // 如果是存在的权限 保留id
    private int id;
    // 权限的来历 从网络获取或者本地手动添加
    private int from;

    public int getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(int businessCode) {
        this.businessCode = businessCode;
        // 查询用户权限数据返回值中只有业务id没有业务名称
       businessName = RoleAndBusiness.getInstance().getBusinessReferenceMap().get(businessCode);
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getBusinessName() {
        return businessName;
    }


    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProvince() {
        if ("ALL".equals(province)) {
            return "全部";
        }
        return province;
    }

    public void setProvince(String province) {
        if ("全部".equals(province)) {
            this.province = "ALL";
        } else {
            this.province = province;
        }
    }

    public String getCity() {
        if ("ALL".equals(city)) {
            return "全部";
        }
        return city;
    }

    public void setCity(String city) {
        if ("全部".equals(city)) {
            this.city = "ALL";
        } else {
            this.city = city;
        }
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
        this.operatorName = getOperatorNameByCode(operatorCode);
    }

    public String getOperatorName() {
        return operatorName;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * 根据运营商的英文代号获取中文名称
     * @param operatorCode
     * @return
     */
    public static String getOperatorNameByCode(String operatorCode) {
        if (TextUtils.isEmpty(operatorCode)) {
            return "";
        }
        if ("CMCC".equals(operatorCode) || "CMTC".equals(operatorCode) || "移动".equals(operatorCode)) {
            return "移动";
        } else if ("CUCC".equals(operatorCode) || "CUTC".equals(operatorCode) || "联通".equals(operatorCode)) {
            return "联通";
        } else if ("CTCC".equals(operatorCode) || "CNTC".equals(operatorCode) || "电信".equals(operatorCode)) {
            return "电信";
        } else if ("ALL".equals(operatorCode)) {
            return "全部";
        } else {
            return "未知";
        }
    }

    /**
     * 根据运营商代号获取运营商中文名
     * @param operatorCode 运营商代号
     * @return
     */
    public static String getOperatorCodeByName(String operatorCode) {
        if (TextUtils.isEmpty(operatorCode)) {
            return "";
        }
        switch (operatorCode) {
            case "移动":
                return "CMCC";
            case "联通":
                return "CUTC";
            case "电信":
                return "CNTC";
            default:
                return "";
        }
    }

}

