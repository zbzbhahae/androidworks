package com.huawei.genexcloud.permission.http;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.http.util.GCCallback;
import com.huawei.genexcloud.http.util.JavaHttpUtil;
import com.huawei.genexcloud.permission.bean.RoleAndBusiness;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 查询权限数据库中 业务id  业务名称 角色id  角色名称的对应关系
 * {"data":{"roleAccess":[{"code":0,"rolename":"管理员"},{"code":1,"rolename":"一线接口人"},{"code":2,"rolename":"总体组接口人"},{"code":3,"rolename":"地区部接口人"},{"code":8,"rolename":"代表处其他人员"},{"code":9,"rolename":"总体组及以上部门其他人员"},{"code":10,"rolename":"测试权限"},{"code":10,"rolename":"测试权限"},{"code":7,"rolename":"代表处业务相关人员"},{"code":6,"rolename":"录入人"}],"businessType":[{"code":0,"name":"不区分"},{"code":1,"name":"精品网风险预警"},{"code":2,"name":"MCE经营预测"},{"code":3,"name":"月报"},{"code":15,"name":"性能事件"},{"code":999,"name":"测试"},{"code":4,"name":"网络质量"},{"code":5,"name":"网络规建"},{"code":6,"name":"网络维护"},{"code":11,"name":"作业工单数字化"},{"code":20,"name":"5G看板"},{"code":21,"name":"网络竟对"}]},"status":"success"}
 */
public class QueryRoleBusinessInfoImpl extends JavaHttpUtil {

    private static QueryRoleBusinessInfoImpl insteance;

    public static QueryRoleBusinessInfoImpl getInstance() {
        if (null == insteance) {
            synchronized (QueryRoleBusinessInfoImpl.class) {
                if (null == insteance) {
                    insteance = new QueryRoleBusinessInfoImpl();
                }
            }
        }
        return insteance;
    }

    @Override
    protected String getMessageName() {
        return "getUserAndBusType";
    }

    /**
     * 获取权限数据库 角色 - id   业务 - id 的对应关系
     */
    public void getRoleBusinessMap() {
        postSingle(insteance, null, new RoleBusinessCallback());
    }

    public static class RoleBusinessCallback extends GCCallback<RoleAndBusiness> {
        @Override
        public RoleAndBusiness parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            JSONObject dataObject = jsonObject.optJSONObject("data");
            JSONArray roleArray = dataObject.optJSONArray("roleAccess");
            JSONArray businessArray = dataObject.optJSONArray("businessType");
            if (null != roleArray && roleArray.length() > 0) {
                TreeMap<Integer, String> roleMap = new TreeMap<>();
                for (int i=0; i<roleArray.length(); i++) {
                    JSONObject roleJson = roleArray.optJSONObject(i);
                    if (null != roleJson) {
                        int roleId = roleJson.optInt("code");
                        String roleName = roleJson.optString("rolename");
                        if (roleId >= 0 && !TextUtils.isEmpty(roleName)) {
                            roleMap.put(roleId, roleName);
                        }
                    }
                }
                RoleAndBusiness.getInstance().setRoleReferenceMap(roleMap);
            }

            if (null != businessArray && businessArray.length() > 0) {
                TreeMap<Integer, String> businessMap = new TreeMap<>();
                for (int i=0; i<businessArray.length(); i++) {
                    JSONObject businessJson = businessArray.optJSONObject(i);
                    if (null != businessJson) {
                        int businessId = businessJson.optInt("code");
                        String businessName = businessJson.optString("name");
                        if (businessId >= 0 && !TextUtils.isEmpty(businessName)) {
                            businessMap.put(businessId, businessName);
                        }
                    }
                }
                RoleAndBusiness.getInstance().setBusinessReferenceMap(businessMap);
            }
            return RoleAndBusiness.getInstance();
        }

        @Override
        public void onFailure(ErrorBean e) {
        }

        @Override
        public void onResponse(RoleAndBusiness response) {
        }
    }

}
