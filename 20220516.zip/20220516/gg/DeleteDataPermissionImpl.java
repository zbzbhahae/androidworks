package com.huawei.genexcloud.permission.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.http.util.GCCallback;
import com.huawei.genexcloud.http.util.JavaHttpUtil;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * 删除用户的一条数据权限
 */
public class DeleteDataPermissionImpl extends JavaHttpUtil {

    private static DeleteDataPermissionImpl insteance;

    public static DeleteDataPermissionImpl getInstance() {
        if (null == insteance) {
            synchronized (DeleteDataPermissionImpl.class) {
                if (null == insteance) {
                    insteance = new DeleteDataPermissionImpl();
                }
            }
        }
        return insteance;
    }
    @Override
    protected String getMessageName() {
        return "deletePermission";
    }

    /**
     * 根据用户的权限id去删除用户的一条数据权限
     * @param id 该条数据权限的id
     * @param callback
     */
    public void deleteDataPermission(int id, DeleteDataPermissionCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("id", id);
        post(body, callback);
    }

    public static abstract class DeleteDataPermissionCallback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            if ("success".equalsIgnoreCase(jsonObject.optString("code"))) {
                return true;
            }
            return false;
        }
    }
}
