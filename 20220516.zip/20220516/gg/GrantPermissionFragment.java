package com.huawei.genexcloud.permission.frags;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.huawei.genexcloud.R;
import com.huawei.genexcloud.base.BaseFragment;
import com.huawei.genexcloud.databinding.FragGrantPermissionBinding;
import com.huawei.genexcloud.dialog.ConfirmCancelDialog;
import com.huawei.genexcloud.http.util.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.permission.adapter.GrantPermissionAdapter;
import com.huawei.genexcloud.permission.bean.RoleAndBusiness;
import com.huawei.genexcloud.permission.bean.UserDataPermissionBean;
import com.huawei.genexcloud.permission.dialog.ProvinceCityDialog;
import com.huawei.genexcloud.permission.dialog.SpinnerPopWindow;
import com.huawei.genexcloud.permission.http.DeleteDataPermissionImpl;
import com.huawei.genexcloud.permission.viewmodel.PermissionViewModel;
import com.huawei.genexcloud.permission.widget.EmptyDividerItemDecoration;
import com.huawei.genexcloud.util.AppUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Request;

/**
 * 给用户添加数据权限 选择具体权限的界面
 */
public class GrantPermissionFragment extends BaseFragment implements View.OnClickListener {

    private FragGrantPermissionBinding binding;

    private GrantPermissionAdapter adapter;

    private List<UserDataPermissionBean> grantData;

    private ProvinceCityDialog permissionDialog;

    // 模块信息
    private List<String> modelNameList;
    // 当前选择的模块名称
    private String selectedModelName = "不区分";
    // 模块选择弹出框
    private SpinnerPopWindow modelPopWindow;
    // 权限角色信息
    private List<String> roleNameList;
    // 角色选择弹出框
    private SpinnerPopWindow rolePopWindow;
    // 当前选择的角色
    private String seletedRoleName = "管理员";

    // 当前添加权限的账号
    private String account;

    // 用于和搜索界面fragment同步数据的viewmodel
    private PermissionViewModel viewModel;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragGrantPermissionBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    public void initView() {
        adapter = new GrantPermissionAdapter();
        adapter.setData(grantData);
        binding.grantPermissionList.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.grantPermissionList.setAdapter(adapter);
        binding.grantPermissionList.addItemDecoration(new EmptyDividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));

        binding.modelLayout.setOnClickListener(this);
        binding.modelText.setText(selectedModelName);
        binding.roleLayout.setOnClickListener(this);
        binding.roleText.setText(seletedRoleName);
        binding.backBtn.setOnClickListener(this);
        binding.grantPermissionConfirm.setOnClickListener(this);
    }

    public void initData() {
        if (null != getArguments()) {
            account = getArguments().getString("account");
            if (TextUtils.isEmpty(account)) {
                GCLogger.error("error", "手动添加数据权限缺失账号信息!");
                binding.getRoot().post(this::onBackPressed);
            }
        } else {
            GCLogger.error("error", "手动添加数据权限缺失账号信息!");
            binding.getRoot().post(this::onBackPressed);
        }
        viewModel = new ViewModelProvider(getActivity()).get(PermissionViewModel.class);

        modelNameList = RoleAndBusiness.getInstance().getBusinessNameList();
        selectedModelName = modelNameList.get(0);
        roleNameList = RoleAndBusiness.getInstance().getRoleNameList();
        seletedRoleName = roleNameList.get(0);


        grantData = new ArrayList<>();
        adapter.setData(grantData);

        adapter.setOnItemFooterClickListener(new GrantPermissionAdapter.OnItemFooterClickListener() {
            @Override
            public void onItemClicked(int position) {
            }
            @Override
            public void onFooterClicked() {
                addNewPermissionItem();
            }

            @Override
            public void onDeleteButtonClicked(int position) {
                List<UserDataPermissionBean> data = adapter.getData();
                data.remove(position);
                adapter.notifyItemRemoved(position);

            }
        });
        // 监听返回键事件, 触发后 取消正在显示的popupwindow
        requireActivity().getOnBackPressedDispatcher().addCallback(backPressedCallback);
    }

    private final OnBackPressedCallback backPressedCallback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            onBackPressed();
        }
    };

    /**
     * 添加一条权限信息
     */
    private void addNewPermissionItem() {
        if (null == permissionDialog) {
            permissionDialog = new ProvinceCityDialog();
            permissionDialog.setDialogListener(new ProvinceCityDialog.OnPermissionDialogListener() {
                @Override
                public void onConfirm(String province, String city, String operator) {
                    int businessTypeId = RoleAndBusiness.getInstance().getBusinessIdByBusinessName(binding.modelText.getText().toString());
                    String businessName = binding.modelText.getText().toString();
                    int roleId = RoleAndBusiness.getInstance().getRoleIdByRoleName(binding.roleText.getText().toString());
                    String roleName = binding.roleText.getText().toString();

                    if (-1 == businessTypeId || TextUtils.isEmpty(businessName)) {
                        showMsg("无效的应用信息");
                        return;
                    } else if (-1 == roleId || TextUtils.isEmpty(roleName)) {
                        showMsg("无效的角色信息");
                        return;
                    }

                    UserDataPermissionBean ub = new UserDataPermissionBean();
                    ub.setBusinessCode(businessTypeId);
                    ub.setProvince(province);
                    ub.setCity(city);
                    ub.setRoleId(roleId);
                    ub.setRoleName(roleName);
                    ub.setOperatorName(operator);
                    ub.setOperatorCode(UserDataPermissionBean.getOperatorCodeByName(operator));
                    ub.setFrom(UserDataPermissionBean.ADDING);
                    ub.setAccount(account);
                    grantData.add(ub);
                    adapter.notifyItemInserted(grantData.size() - 1);
                }

                @Override
                public void onCancel() {
                }
            });
        }
        if (!permissionDialog.isVisible()) {
            permissionDialog.show(getChildFragmentManager(), "tag");
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.backBtn) {
            backPressed();
        } else if (v == binding.modelLayout) {
            // 点击选择权限模块
            if (null == modelPopWindow) {
                modelPopWindow = new SpinnerPopWindow(getContext());
                modelPopWindow.setOnMenuItemSelectedListener(menuContent -> {
                    selectedModelName = menuContent;
                    binding.modelText.setText(menuContent);
                });
            }
            modelPopWindow.setOptions(modelNameList);
            modelPopWindow.setSelectedOption(selectedModelName);
            modelPopWindow.showAsDropDown(binding.modelText);
        } else if (v == binding.roleLayout) {
            // 点击了权限角色选择
            if (null == rolePopWindow) {
                rolePopWindow = new SpinnerPopWindow(getContext());
                rolePopWindow.setOnMenuItemSelectedListener(menuContent -> {
                    seletedRoleName = menuContent;
                    binding.roleText.setText(menuContent);
                });
            }
            rolePopWindow.setOptions(roleNameList);
            rolePopWindow.setSelectedOption(seletedRoleName);
            rolePopWindow.showAsDropDown(binding.roleLayout);
        } else if (v == binding.backBtn) {
            onBackPressed();
        } else if (v == binding.grantPermissionConfirm) {
            // 将手动添加的权限同步到搜索页面
            List<UserDataPermissionBean> data = viewModel.getUserPermissions();
            if (null == data || data.isEmpty()) {
                viewModel.setUserPermissionsNotify(grantData);
            } else {
                viewModel.addUserPermissionNotify(grantData);
            }
            onBackPressed();
        }
    }

    public void onBackPressed() {
        if (null != modelPopWindow && modelPopWindow.isShowing()) {
            modelPopWindow.dismiss();
            return;
        } else if (null != rolePopWindow && rolePopWindow.isShowing()) {
            rolePopWindow.dismiss();;
            return;
        }
        backPressedCallback.setEnabled(false);
        backPressed();
    }
}
