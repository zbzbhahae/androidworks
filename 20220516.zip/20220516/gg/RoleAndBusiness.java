package com.huawei.genexcloud.permission.bean;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 权限数据库中 业务id  业务名称 角色id  角色名称的数据bean
 */
public class RoleAndBusiness {
    // 角色对应关系
    private Map<Integer, String> roleReferenceMap;
    // 业务对应关系
    private Map<Integer, String> businessReferenceMap;

    private volatile static RoleAndBusiness instance;

    public static RoleAndBusiness getInstance() {
        if (null == instance) {
            synchronized (RoleAndBusiness.class) {
                if (null == instance) {
                    instance = new RoleAndBusiness();
                }
            }
        }
        return instance;
    }

    private RoleAndBusiness() {
        roleReferenceMap = new HashMap<>();
        roleReferenceMap.put(0, "全部");
        roleReferenceMap.put(1, "精品网风险预警");
        roleReferenceMap.put(2, "MCE经营预测");
        roleReferenceMap.put(3, "月报");
        roleReferenceMap.put(4, "网络质量");
        roleReferenceMap.put(5, "规划建设");
        roleReferenceMap.put(6, "网络维护");
        roleReferenceMap.put(11, "作业工单数字化");
        roleReferenceMap.put(15, "性能事件");
        roleReferenceMap.put(20, "5G看板");
        roleReferenceMap.put(21, "网络竞对");

        businessReferenceMap = new HashMap<>();
        businessReferenceMap.put(0, "不区分");
        businessReferenceMap.put(1, "精品网风险预警");
        businessReferenceMap.put(2, "MCE经营预测");
        businessReferenceMap.put(3, "月报");
        businessReferenceMap.put(4, "网络质量");
        businessReferenceMap.put(5, "网络规建");
        businessReferenceMap.put(6, "网络维护");
        businessReferenceMap.put(11, "作业工单数字化");
        businessReferenceMap.put(15, "性能事件");
        businessReferenceMap.put(20, "5G看板");
        businessReferenceMap.put(21, "网络竟对");
        businessReferenceMap.put(999, "测试");
    }

    public Map<Integer, String> getRoleReferenceMap() {
        return roleReferenceMap;
    }

    public void setRoleReferenceMap(Map<Integer, String> roleReferenceMap) {
        if (null == roleReferenceMap || roleReferenceMap.isEmpty()) {
            return;
        }
        this.roleReferenceMap = roleReferenceMap;
    }

    public Map<Integer, String> getBusinessReferenceMap() {
        return businessReferenceMap;
    }

    public void setBusinessReferenceMap(Map<Integer, String> businessReferenceMap) {
        if (null == businessReferenceMap || businessReferenceMap.isEmpty()) {
            return;
        }
        this.businessReferenceMap = businessReferenceMap;
    }

    /**
     * 获取所有角色的列表
     * @return
     */
    public List<String> getRoleNameList() {
        if (null == roleReferenceMap || roleReferenceMap.isEmpty()) {
            return null;
        }
        List<String> roleNameList = new ArrayList<>();
        for (Map.Entry<Integer, String> entry : roleReferenceMap.entrySet()) {
            String roleName = entry.getValue();
            if (!TextUtils.isEmpty(roleName)) {
                roleNameList.add(roleName);
            }
        }
        return roleNameList;
    }

    /**
     * 获取业务的名称列表
     * @return
     */
    public List<String> getBusinessNameList() {
        if (null == businessReferenceMap || businessReferenceMap.isEmpty()) {
            return null;
        }
        List<String> businessNameList = new ArrayList<>();
        for (Map.Entry<Integer, String> entry : businessReferenceMap.entrySet()) {
            String businessName = entry.getValue();
            if (!TextUtils.isEmpty(businessName)) {
                businessNameList.add(businessName);
            }
        }
        return businessNameList;
    }

    /**
     * 根据角色名称查询角色id
     * @param roleName 角色名称
     * @return 角色名称对应的角色id，如果没有 返回-1
     */
    public int getRoleIdByRoleName(String roleName) {
        if (TextUtils.isEmpty(roleName) || null == roleReferenceMap) {
            return -1;
        }
        for (Map.Entry<Integer, String> entry : roleReferenceMap.entrySet()) {
            String roleNameInMap = entry.getValue();
            if (roleName.equals(roleNameInMap)) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * 通过业务名称查询业务id
     * @param businessName 业务名称
     * @return 业务名称对应的业务id，如果没有 返回-1
     */
    public int getBusinessIdByBusinessName(String businessName) {
        if (TextUtils.isEmpty(businessName) || null == businessReferenceMap) {
            return -1;
        }
        for (Map.Entry<Integer, String> entry : businessReferenceMap.entrySet()) {
            String businessNameInMap = entry.getValue();
            if (businessName.equals(businessNameInMap)) {
                return entry.getKey();
            }
        }
        return -1;
    }

}
