package com.huawei.genexcloud.permission.http;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.http.util.GCCallback;
import com.huawei.genexcloud.http.util.JavaHttpUtil;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.permission.bean.UserDataPermissionBean;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 批量给用户添加数据权限
 */
public class AddDataPermissionImpl extends JavaHttpUtil {

    private static AddDataPermissionImpl insteance;

    public static AddDataPermissionImpl getInstance() {
        if (null == insteance) {
            synchronized (AddDataPermissionImpl.class) {
                if (null == insteance) {
                    insteance = new AddDataPermissionImpl();
                }
            }
        }
        return insteance;
    }

    @Override
    protected String getMessageName() {
        return "insertPermission";
    }
//    [{"employeecode":"zwx1094027","province":"陕西","city":"西安市","operator":"CNTC","businesstypecode":4,"roleid":0,"roledescription":"管理员"}]
//    [{"employeecode":"zwx1094027","province":"陕西","city":"西安","operator":"CNTC","businesstypecode":5,"roleid":0,"roledescription":"管理员"}]
    public void addDataPermission(List<UserDataPermissionBean> dataPermissionList, AddDataPermissionCallback callback) {
        Map<String, Object> body = new HashMap<>();
        try {
            JSONArray array = new JSONArray();
            for (UserDataPermissionBean item : dataPermissionList) {
                JSONObject object = new JSONObject();
                object.put("employeecode", item.getAccount());
                object.put("province", item.getProvince());
                object.put("city", item.getCity());
                object.put("operator", item.getOperatorCode());
                object.put("businesstypecode", item.getBusinessCode());
                object.put("roleid", item.getRoleId());
                object.put("roledescription", item.getRoleName());
                array.put(object);
            }
            body.put("message", URLEncoder.encode(array.toString(), StandardCharsets.UTF_8.name()));
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        postSingle(insteance, body, callback);
    }

    @Override
    protected Map<String, String> buildBodyParams(String messageName, Map<String, Object> body) {
        Map<String, String> params = new HashMap<>();
        params.put("messageName", messageName);
        params.put("message", body.get("message").toString());
        return super.buildBodyParams(messageName, body);
    }

    public static abstract class AddDataPermissionCallback extends GCCallback<Boolean> {
        @Override
        public Boolean parseNetworkResponse(@NonNull String response) throws Exception {
            JSONObject jsonObject = new JSONObject(response);
            if ("success".equalsIgnoreCase(jsonObject.optString("code"))) {
                return true;
            }
            return false;
        }
    }
}
