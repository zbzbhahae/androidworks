package com.huawei.genexcloud.scene.widget.popupwindow;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.huawei.genexcloud.scene.R;


public class PopWindowAdapter extends BaseAdapter {
    private String[] items;
    private Context mContext;
    private LayoutInflater mInflater;
    private ViewHolder holder;
    private int index = -1;

    public PopWindowAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
    }

    public void setItems(String[] items) {
        this.items = items;
    }

    @Override
    public int getCount() {
        return null == items ? 0 : items.length;
    }

    @Override
    public Object getItem(int position) {
        return items[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_operation_list_popwndow, null);
            // 初始化holder对象
            initHolder(holder, convertView);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        setData(position, convertView);

        return convertView;
    }

    private void initHolder(ViewHolder holder, View convertView) {
        holder.tvItem = (TextView) convertView.findViewById(R.id.tv_pop_list_item);
        convertView.setTag(holder);
    }

    private void setData(final int position, View convertView) {
        ViewHolder holder = (ViewHolder) convertView.getTag();
        if (items != null && items.length > 0) {
            holder.tvItem.setText(items[position]);
        }
        if (index == position) {
            holder.tvItem.setTextColor(ContextCompat.getColor(mContext, R.color.bg_btn_experience_site_next_end_blue));
        } else {
            holder.tvItem.setTextColor(ContextCompat.getColor(mContext, R.color.text_333));
        }

    }

    public void setIndex(int position) {
        this.index = position;
    }

    public class ViewHolder {
        TextView tvItem;
    }
}
