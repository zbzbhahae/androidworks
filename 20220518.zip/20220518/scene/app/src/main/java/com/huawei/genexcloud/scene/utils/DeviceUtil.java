package com.huawei.genexcloud.scene.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import java.util.Locale;

/**
 * 设备信息获取工具类
 */
public class DeviceUtil {

    /**
     * 获取手机信息管理对象
     */
    public static TelephonyManager getTelephonyManager(Context context) {
        return (TelephonyManager) context
                .getApplicationContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
    }

    /**
     * 获取连接管理类
     *
     * @param context
     * @return
     */
    public static ConnectivityManager getConnectivityManager(Context context) {
        return (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    /**
     * 获取手机机型型号 如 HMA-AL00
     */
    public static String getDeviceModel() {
        try {
            return Build.MODEL;
        } catch (Exception e) {
            Log.e("error", e.toString());
            return "";
        }
    }

    /**
     * 获取手机系统版本
     *
     * @return
     */
    public static String getSystemVersion() {
        return Build.VERSION.RELEASE;
    }

    /**
     * 获取手机系统语言
     *
     * @return
     */
    public static String getSystemLanguage() {
        return Locale.getDefault().getLanguage();
    }

    /**
     * 获取工业设备名
     *
     * @return
     */
    public static String getSystemDeviceName() {
        return Build.DEVICE;
    }

    /**
     * 获取手机厂商名
     *
     * @return
     */
    public static String getDeviceManufacturer() {
        return Build.MANUFACTURER;
    }

    /**
     * 获取手机主板名
     *
     * @return
     */
    public static String getDeviceBoard() {
        return Build.BOARD;
    }

    /**
     * 获取手机品牌
     *
     * @return
     */
    public static String getBrand() {
        return Build.BRAND;
    }


    /**
     * 获取设备id 可能相同
     * ANDROID_ID 是设备首次启动时由系统随机生成的一串64位的十六进制数字。
     */
    public static String getAndroidId(Context context) {
        String androidId = "";
        try {
            androidId = Settings.System.getString(
                    context.getApplicationContext().getContentResolver(),
                    Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        if (null == androidId) {
            androidId = "";
        }
        return androidId;
    }

    /**
     * 是否安装有sim卡
     *
     * @param context
     * @return
     */
    private static boolean hasSimCard(Context context) {
        String operator = getTelephonyManager(context).getSimOperator();
        if (TextUtils.isEmpty(operator)) {
            return false;
        }
        return true;
    }

    /**
     * 获取手机运营商
     *
     * @param context
     * @return
     */
    public static String getSimOperator(Context context) {
        int operatorType = -1;
        if (!hasSimCard(context)) {
            return "无运营商";
        }
        TelephonyManager tm = getTelephonyManager(context);
        String operator = tm.getNetworkOperator();
        if ("46001".equals(operator) || "46006".equals(operator) || "46009".equals(operator)) {
            return "中国联通";
        } else if ("46000".equals(operator) || "46002".equals(operator) || "46004".equals(operator) || "46007".equals(operator)) {
            return "中国移动";
        } else if ("46003".equals(operator) || "46005".equals(operator) || "46011".equals(operator)) {
            return "中国电信";
        } else if ("46020".equals(operator)) {
            return "中国铁通";
        } else {
            return "未知运营商";
        }
    }

    /**
     * 得到当前的手机网络类型
     *
     * @param context
     * @return
     */
    public static String getCurrentNetType(Context context) {
        String type = "";
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            type = "null";
        } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {
            type = "wifi";
        } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int subType = info.getSubtype();
            if (subType == TelephonyManager.NETWORK_TYPE_CDMA || subType == TelephonyManager.NETWORK_TYPE_GPRS
                    || subType == TelephonyManager.NETWORK_TYPE_EDGE) {
                type = "2g";
            } else if (subType == TelephonyManager.NETWORK_TYPE_UMTS || subType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || subType == TelephonyManager.NETWORK_TYPE_EVDO_A || subType == TelephonyManager.NETWORK_TYPE_EVDO_0
                    || subType == TelephonyManager.NETWORK_TYPE_EVDO_B) {
                type = "3g";
            } else if (subType == TelephonyManager.NETWORK_TYPE_LTE) {
                // LTE是3g到4g的过渡，是3.9G的全球标准
                type = "4g";
            } else if (subType == 20) {
                // 对应的20 只有依赖为android 10.0才有此属性
                type = "5G";
            } else {
                type = "other";
            }
        }
        return type;
    }
}
