package com.huawei.genexcloud.scene.http.util;

import android.content.Context;
import android.text.TextUtils;

import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.logger.GCLogger;
import com.huawei.genexcloud.scene.provider.IPCUtils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;


public class HeaderInterceptor implements Interceptor {
    Context context;

    public HeaderInterceptor(Context context) {
        this.context = context;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        try {
            Request.Builder builder = chain.request().newBuilder();
            String session = IPCUtils.getDataToDB(context, Constants.SESSION_ID);
            String token = IPCUtils.getDataToDB(context, Constants.CSFToken);
            if (!TextUtils.isEmpty(session) && !TextUtils.isEmpty(token)) {
                builder.addHeader("Cookie", session);
                builder.addHeader("X-CSRF-TOKEN", token);
            }
            return chain.proceed(builder.build());
        } catch (Exception e) {
            GCLogger.error("error", "Header添加 异常:" + e.toString());
        }
        return chain.proceed(chain.request());
    }
}
