package com.huawei.genexcloud.scene.http;


import com.huawei.genexcloud.scene.http.callback.SceneCallback;
import com.huawei.genexcloud.scene.http.util.JavaHttpUtil;
import com.huawei.genexcloud.scene.utils.OperatorUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * 查询4G指标详情，包含场景数据
 */
public class QuerySceneImpl extends JavaHttpUtil {

    private String mType = TYPE_4G;
    public static final String TYPE_4G = "4G", TYPE_5G = "5G";

    private static QuerySceneImpl instance;
    public static QuerySceneImpl getInstance() {
        if (null == instance) {
            synchronized (QuerySceneImpl.class) {
                if (null == instance) {
                    instance = new QuerySceneImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        if (TYPE_5G.equals(mType)) {
            return "/network/query5GQuota";
        } else {
            return "/network/query4GQuota";
        }
    }

    public void getSceneData(String province, String city, String operator, String sceneName, String type, SceneCallback callback) {
        mType = type;
        String operatorName = OperatorUtil.getOperatorENName(operator);
        Map<String, Object> body = new HashMap<>();
        body.put("province", province);
        body.put("city", city);
        body.put("operator", operatorName);
        body.put("scenario", sceneName);
        postSingle(this, body, callback);

    }


}
