package com.huawei.genexcloud.scene.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by zWX1094027 on 2021/10/22.
 * <p>
 * 水印view 替代字体文件
 */

public class WatermarkView extends View {


    private final float mTextSize = sp2px(17);

    private final float mTextStrokeSize = dp2px(1);

    private final float textSpacing = dp2px(2); // 两行文字间的距离

    private final int mTextColor = 0x33999999;

    private int width, height;
    private float mTextHeight;

    private Paint mPaint;

    private String account = "无账号信息";
    private final String message = "敏感信息严禁向客户展示";
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private final String dateString = sdf.format(new Date());

    public WatermarkView(Context context) {
        this(context, null);
    }

    public WatermarkView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public WatermarkView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private int dp2px(int dp) {
        int px = (int) (getContext().getResources().getDisplayMetrics().density * dp + .5);
        return px;
    }

    private float sp2px(int sp) {
        float px = getContext().getResources().getDisplayMetrics().scaledDensity * sp;
        return px;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            width = getMeasuredWidth();
            height = getMeasuredHeight();
        }
    }

    private void init(Context context) {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setTextSize(mTextSize);
        mPaint.setColor(mTextColor);
        mPaint.setFakeBoldText(true);
        mPaint.setStyle(Paint.Style.FILL);
        try {
            Typeface typeface = Typeface.createFromAsset(getContext().getAssets(), "romate.ttf");
            mPaint.setTypeface(typeface);
        } catch (Exception e) {
            Log.e("error", e.toString());
        }

        Paint.FontMetricsInt fmi = mPaint.getFontMetricsInt();
        mTextHeight = fmi.bottom - fmi.top;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //获取左上角一块矩形区域 用来显示账号和日期
        float accountW = mPaint.measureText(account);
        float dateStringW = mPaint.measureText(dateString);
        float messageW = mPaint.measureText(message);
        Paint.FontMetricsInt fmi = mPaint.getFontMetricsInt();
        float baseLine = (fmi.descent - fmi.ascent) * 0.5f - fmi.descent;

        float rectW = Math.max(accountW, dateStringW);
        float rectH = 2 * mTextHeight + textSpacing;
        float rectL = dp2px(15);
        float rectT = dp2px(125);
        float rotationX = rectL + rectW * 0.5f;
        float rotationY = rectT + rectH * 0.5f;

        canvas.save();

        canvas.rotate(-45, rotationX, rotationY);
        canvas.drawText(account, (rectW - accountW) * 0.5f + rectL, rectT + 0.5f * mTextHeight + baseLine, mPaint);
        canvas.drawText(dateString, (rectW - dateStringW) * 0.5f + rectL, rectT + textSpacing + 1.5f * mTextHeight + baseLine, mPaint);

        canvas.restore();
        canvas.save();
        canvas.rotate(-45, width * 0.5f, height * 0.5f);
        canvas.drawText(message, (width - messageW) * 0.5f, height * 0.5f, mPaint);
        canvas.restore();


        canvas.save();
        rectT = height - dp2px(55) - rectH;
        rectL = width - dp2px(15) - rectW;
        rotationX = rectL + rectW * 0.5f;
        rotationY = rectT + rectH * 0.5f;

        canvas.rotate(-45, rotationX, rotationY);
        canvas.drawText(account, (rectW - accountW) * 0.5f + rectL, rectT + 0.5f * mTextHeight + baseLine, mPaint);
        canvas.drawText(dateString, (rectW - dateStringW) * 0.5f + rectL, rectT + textSpacing + 1.5f * mTextHeight + baseLine, mPaint);

        canvas.restore();
    }

    /**
     * 设置账号信息
     *
     * @param account
     */
    public void setAccount(String account) {
        if (!TextUtils.isEmpty(account)) {
            this.account = account;
            invalidate();
        }
    }
}
