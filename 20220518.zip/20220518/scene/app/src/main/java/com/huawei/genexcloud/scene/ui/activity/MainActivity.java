package com.huawei.genexcloud.scene.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.ui.fragment.NationSceneFragment;
import com.huawei.genexcloud.scene.ui.fragment.SelectCityFragment;
import com.huawei.genexcloud.scene.utils.AppUtil;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {
        container = find(R.id.container);
        switchTo(new NationSceneFragment());

    }

    @Override
    protected int getFragmentContainerId() {
        return R.id.container;
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
    }
}
