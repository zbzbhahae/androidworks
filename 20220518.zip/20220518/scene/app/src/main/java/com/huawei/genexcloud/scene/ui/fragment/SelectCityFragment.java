package com.huawei.genexcloud.scene.ui.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.bean.ProvinceCityBean;
import com.huawei.genexcloud.scene.http.QueryProvinceCityImpl;
import com.huawei.genexcloud.scene.http.util.ErrorBean;
import com.huawei.genexcloud.scene.ui.adapter.GridProvinceAdapter;
import com.huawei.genexcloud.scene.utils.AppUtil;
import com.huawei.genexcloud.scene.viewmodel.StatusViewModel;
import com.huawei.genexcloud.scene.widget.DividerItemDecorationVertical;
import com.huawei.genexcloud.scene.widget.EmptyItemDecorationVertical;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;

/**
 * 选择城市页面
 */
public class SelectCityFragment extends BaseFragment implements GridProvinceAdapter.OnItemClickListener, View.OnClickListener {

    private TextView resetBtn, confirmBtn, provinceTxt, cityTxt;
    private RecyclerView list;
    private ImageView backBtn;
    private RelativeLayout noDataLayout, provinceLayout, cityLayout;

    // 省份城市数据
    private List<ProvinceCityBean> provinceCityList;
    private GridProvinceAdapter adapter;

    private String selectProvince, selectCity;

    private StatusViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_selecte_city, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        resetBtn = find(R.id.reset_button);
        confirmBtn = find(R.id.confirm_button);
        provinceTxt = find(R.id.select_province_text);
        cityTxt = find(R.id.select_city_text);
        provinceLayout = find(R.id.select_province_layout);
        cityLayout = find(R.id.select_city_layout);

        noDataLayout = find(R.id.no_data_layout);

        backBtn = find(R.id.select_back_btn);
        list = find(R.id.province_list);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),
                4, LinearLayoutManager.VERTICAL, false);
        list.setLayoutManager(gridLayoutManager);
        adapter = new GridProvinceAdapter();
        list.setAdapter(adapter);
        adapter.setOnItemClickListener(this);
        list.addItemDecoration(new EmptyItemDecorationVertical(getContext(), 10));

        provinceLayout.setOnClickListener(this);
        cityLayout.setOnClickListener(this);
        resetBtn.setOnClickListener(this);
        confirmBtn.setOnClickListener(this);
    }
    private void initData() {
        viewModel = new ViewModelProvider(getActivity(),
                new ViewModelProvider.NewInstanceFactory()).get(StatusViewModel.class);

        if (null == viewModel.getProvinceCityList() || viewModel.getProvinceCityList().isEmpty()) {
            getProvinceCityData();
        } else {
            provinceCityList = viewModel.getProvinceCityList();
        }
        selectProvince = viewModel.getProvince();
        selectCity = viewModel.getCity();
        setData(selectProvince, selectCity, provinceCityList);
    }

    private void showNoData() {
        noDataLayout.setVisibility(View.VISIBLE);
        provinceLayout.setVisibility(View.GONE);
        cityLayout.setVisibility(View.GONE);
    }

    private void setData(String selectProvince, String selectCity, List<ProvinceCityBean> provinceCityList) {
        if (null == provinceCityList || provinceCityList.isEmpty()) {
            showNoData();
            return;
        } else {
            noDataLayout.setVisibility(View.GONE);
        }
        if (TextUtils.isEmpty(selectProvince)) {
            // 没有选择省份 也就是没有选择城市
            List<String> provinceList = new ArrayList<>();
            for (ProvinceCityBean item : provinceCityList) {
                if (!TextUtils.isEmpty(item.getProvince())) {
                    provinceList.add(item.getProvince());
                }
            }
            adapter.setData(provinceList);
            adapter.setSelectedContent(null);
            provinceLayout.setVisibility(View.GONE);
            cityLayout.setVisibility(View.GONE);
        } else if (TextUtils.isEmpty(selectCity)) {
            // 选择了省份没选择城市
            if ("全国".equals(selectProvince)) {
                // 全国比较特殊 还是显示省份选择内容
                provinceLayout.setVisibility(View.VISIBLE);
                cityLayout.setVisibility(View.GONE);
                provinceTxt.setText(selectProvince);

                List<String> provinceList = new ArrayList<>();
                for (ProvinceCityBean item : provinceCityList) {
                    if (!TextUtils.isEmpty(item.getProvince())) {
                        provinceList.add(item.getProvince());
                    }
                }
                adapter.setData(provinceList);
                adapter.setSelectedContent("全国");
            } else {
                provinceLayout.setVisibility(View.VISIBLE);
                cityLayout.setVisibility(View.GONE);
                provinceTxt.setText(selectProvince);
                // 找到该省份下的城市内容 显示在list上
                for (ProvinceCityBean item : provinceCityList) {
                    if (selectProvince.equals(item.getProvince())) {
                        adapter.setData(item.getCityList());
                        adapter.setSelectedContent(null);
                        break;
                    }
                }
            }
        } else {
            // 选择了省份也选择了地市
            provinceLayout.setVisibility(View.VISIBLE);
            cityLayout.setVisibility(View.VISIBLE);
            provinceTxt.setText(selectProvince);
            cityTxt.setText(selectCity);
            // 找到该省份下的城市内容 显示在list上
            for (ProvinceCityBean item : provinceCityList) {
                if (selectProvince.equals(item.getProvince())) {
                    adapter.setData(item.getCityList());
                    adapter.setSelectedContent(selectCity);
                    break;
                }
            }
        }
    }

    private void getProvinceCityData() {
        QueryProvinceCityImpl.getInstance().getProvinceCityInfo(new QueryProvinceCityImpl.ProvinceCityCallback() {
            @Override
            public void onBefore(Request request) { showLoadingDialog(); }
            @Override
            public void onAfter() { dismissLoadingDialog(); }
            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
                showNoData();
            }
            @Override
            public void onResponse(List<ProvinceCityBean> response) {
                if (null == response || response.isEmpty()) {
                    showNoData();
                } else {
                    provinceCityList = response;
                    setData(selectProvince, selectCity, response);
                }
            }
        });
    }

    /**
     * 点击选择省份城市的数据列表
     * @param content
     */
    @Override
    public void onClick(String content) {
        if (TextUtils.isEmpty(content)) {
            return;
        }
        if (TextUtils.isEmpty(selectProvince)) {
            // 当前没有选择省份 点击了省份列表
            selectProvince = content;
            provinceTxt.setText(selectProvince);
            provinceLayout.setVisibility(View.VISIBLE);
            setData(selectProvince, selectCity, provinceCityList);
        } else if ("全国".equals(selectProvince)) {
            // 选中全国比较特殊
            // 查看是否还是选择的全国
            if ("全国".equals(content)) {
                return;
            } else {
                // 选择了其他的省份
                selectProvince = content;
                selectCity = null;
                adapter.setSelectedContent(null);
                setData(selectProvince, selectCity, provinceCityList);
            }
        } else {
            // 已经选择过了省份 现在选择了城市
            selectCity = content;
            cityTxt.setText(content);
            cityLayout.setVisibility(View.VISIBLE);
            adapter.setSelectedContent(content);
        }
    }

    /**
     * 点击事件
     * @param v
     */
    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.select_back_btn:
                backPressed();
                break;
            case R.id.select_province_layout: // 点击了选择的省份
                selectProvince = null;
                selectCity = null;
                setData(selectProvince, selectCity, provinceCityList);
                break;
            case R.id.select_city_layout:
                selectCity = null;
                setData(selectProvince, selectCity, provinceCityList);
                break;
            case R.id.reset_button:
                selectProvince = null;
                selectCity = null;
                setData(selectProvince, selectCity, provinceCityList);
                break;
            case R.id.confirm_button:
                if (TextUtils.isEmpty(selectProvince) || (!"全国".equals(selectProvince) && TextUtils.isEmpty(selectCity))) {
                    showMsg("请选择地市");
                    return;
                }
                if ("全国".equals(selectProvince)) {
                    selectCity = "全国";
                }
                viewModel.setProvinceAndCity(selectProvince, selectCity);
                backPressed();
                break;
        }
    }
}
