package com.huawei.genexcloud.scene.bean;

public class UserPermission {
    private int Id;
    private String EmployeeCode;
    private String Province;
    private String City;
    private String Operator;
    /**
     * 1:精品网风险预警（网络画像） 2:MCE经营预测 3:月报 4：网络质量（网络洞察） 5：网络规建 6：网络维护 7：网络经营（业务洞察） 8：精品网运营 9：网络档案 15：性能升级
     */
    private int BusinessTypeCode;
    private int SubBusinessType;
    private int RoleId;
    private String RoleDescription;
    private int NewRecordMark;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getEmployeeCode() {
        return EmployeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        EmployeeCode = employeeCode;
    }

    public String getProvince() {
        return Province;
    }

    public void setProvince(String province) {
        Province = province;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getOperator() {
        return Operator;
    }

    public void setOperator(String operator) {
        Operator = operator;
    }

    public int getBusinessTypeCode() {
        return BusinessTypeCode;
    }

    public void setBusinessTypeCode(int businessTypeCode) {
        BusinessTypeCode = businessTypeCode;
    }

    public int getSubBusinessType() {
        return SubBusinessType;
    }

    public void setSubBusinessType(int subBusinessType) {
        SubBusinessType = subBusinessType;
    }

    public int getRoleId() {
        return RoleId;
    }

    public void setRoleId(int roleId) {
        RoleId = roleId;
    }

    public String getRoleDescription() {
        return RoleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        RoleDescription = roleDescription;
    }

    public int getNewRecordMark() {
        return NewRecordMark;
    }

    public void setNewRecordMark(int newRecordMark) {
        NewRecordMark = newRecordMark;
    }

    @Override
    public String toString() {
        return "User{" + "Id=" + Id + ", EmployeeCode='" + EmployeeCode + '\'' + ", Province='" + Province + '\''
                + ", City='" + City + '\'' + ", Operator='" + Operator + '\'' + ", BusinessTypeCode=" + BusinessTypeCode
                + ", SubBusinessType=" + SubBusinessType + ", RoleId=" + RoleId + ", RoleDescription='" + RoleDescription
                + '\'' + ", NewRecordMark=" + NewRecordMark + '}';
    }
}
