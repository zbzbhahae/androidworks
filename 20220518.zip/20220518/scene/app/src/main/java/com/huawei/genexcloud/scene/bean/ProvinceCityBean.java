package com.huawei.genexcloud.scene.bean;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取省份名称 和  省份下的城市列表
 */
public class ProvinceCityBean {
    private String province;
    private List<String> cityList = new ArrayList<>();

    private ProvinceCityBean() {
    }

    public ProvinceCityBean(String province, String city) {
        this.province = province;
        cityList.add(city);
    }

    public ProvinceCityBean(String province, List<String> cityList) {
        this.province = province;
        this.cityList = cityList;
    }

    public void addCity(String city) {
        if (!TextUtils.isEmpty(city) && !cityList.contains(city)) {
            cityList.add(city);
        }
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public List<String> getCityList() {
        return cityList;
    }

    public void setCityList(List<String> cityList) {
        this.cityList = cityList;
    }
}
