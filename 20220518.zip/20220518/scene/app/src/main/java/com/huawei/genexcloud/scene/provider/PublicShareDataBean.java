package com.huawei.genexcloud.scene.provider;

/**
 * Created by lWX419034 on 2017/5/25.
 */

public class PublicShareDataBean {

    public String key;

    //值
    public String name;

    @Override
    public String toString() {
        return "PublicShareDataBean{" + "key='" + key + '\'' + ", name='" + name + '\'' + '}';
    }

    public String getKey() {

        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name == null ? "" : name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
