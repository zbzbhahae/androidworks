package com.huawei.genexcloud.scene.http.util;

public class HttpErrorException extends Exception {
    private ErrorBean errorBean;
    public HttpErrorException(ErrorBean bean) {
        this.errorBean = bean;
    }
    public ErrorBean getErrorBean() {
        return errorBean;
    }
}