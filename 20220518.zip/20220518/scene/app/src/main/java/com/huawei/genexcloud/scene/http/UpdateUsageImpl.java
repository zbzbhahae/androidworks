package com.huawei.genexcloud.scene.http;

import android.content.Context;

import com.huawei.genexcloud.scene.bean.AppUseInfo;
import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.callback.EmptyCallback;
import com.huawei.genexcloud.scene.http.util.AES256;
import com.huawei.genexcloud.scene.http.util.CSharpHttpUtil;
import com.huawei.genexcloud.scene.logger.GCLogger;
import com.huawei.genexcloud.scene.utils.SharedPreferencesUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdateUsageImpl extends CSharpHttpUtil {

    private static UpdateUsageImpl instance;
    public static UpdateUsageImpl getInstance() {
        if (null == instance) {
            synchronized (UpdateUsageImpl.class) {
                if (null == instance) {
                    instance = new UpdateUsageImpl();
                }
            }
        }
        return instance;
    }

    @Override
    protected String getMessageName() {
        return "CountAppUseInfo";
    }

    public void postUserUsage(Context context, AppUseInfo info) {
        if (null == info) {
            return;
        }
        Map<String, Object> body = new HashMap<>();
        JSONObject jsonObject = new JSONObject();
        String paramsJson = "";
        try {
            jsonObject.put("PageId", info.getPageId());
            jsonObject.put("EventId", info.getEventId());
            jsonObject.put("Account", info.getAccount());
            jsonObject.put("Parameter", info.getParameter());
            jsonObject.put("NetOperator", info.getNetOper());
            jsonObject.put("Longitude", info.getLongitude());
            jsonObject.put("Latitude", info.getLatitude());
            jsonObject.put("AppVersion", info.getAppVer());
            jsonObject.put("SystemVersion", info.getSystemVersion());
            jsonObject.put("Model", info.getModel());
            jsonObject.put("Imei", info.getImei());
            String cityParamName = SharedPreferencesUtil.getInstance(context).readStringValue(Constants.CURRENT_CITY, "西安市");
            body.put("City", cityParamName);
            paramsJson = AES256.getInstance_256().encryptStr(AES256.RANDYV, jsonObject.toString());
        } catch (JSONException e) {
            GCLogger.error("error", e.toString());
        }
        body.put("message", paramsJson);
        post(body, new EmptyCallback());
    }

    @Override
    protected Map<String, String> buildBodyParams(String messageName, Map<String, Object> body) {
        Map<String, String> params = new HashMap<>();
        params.put("messageName", getMessageName());
        if (null != body && null != body.get("message")) {
            params.put("message", body.get("message").toString());
        }
        return params;
    }
}
