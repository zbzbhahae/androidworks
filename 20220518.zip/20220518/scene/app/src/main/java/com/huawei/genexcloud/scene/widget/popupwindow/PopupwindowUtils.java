package com.huawei.genexcloud.scene.widget.popupwindow;


import static android.R.attr.type;
import static com.huawei.genexcloud.scene.widget.popupwindow.BasePopupWindow.popupWindow;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;


import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.utils.AppUtil;
import com.huawei.genexcloud.scene.utils.DensityUtil;

import java.util.List;

/**
 * Created by tWX430835 on 2017/8/2.
 */

public class PopupwindowUtils {

    /**
     * @param context                        DOU时间选择的popupwindow
     * @param parent
     * @param times
     * @param selTimeIndex
     * @param popDismissAndItemClickCallBack
     */
    public static void showNetOperMenuPop(final Context context, View parent, List<String> times, int selTimeIndex,
                                          int type, final PopDismissAndItemClickCallBack popDismissAndItemClickCallBack) {
        View view = LayoutInflater.from(context).inflate(R.layout.carrier_sel_layfor, null);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BasePopupWindow.dismiss();
            }
        });

        ListView listView = (ListView) view.findViewById(R.id.listView);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(40, 0, 0, 0);
        listView.setLayoutParams(params);
        TimeAdapter timeadapter = new TimeAdapter(context, type);
        timeadapter.setTimes(times);
        timeadapter.setSelIndex(selTimeIndex);
        listView.setAdapter(timeadapter);
        int totalHeight = 0;
        int count = timeadapter.getCount();
        if (count <= 8) {
            for (int i = 0; i < count; i++) {
                View listItem = timeadapter.getView(i, null, listView);
                listItem.measure(0, 0);
                totalHeight += listItem.getMeasuredHeight();
            }
        } else {
            View listItem = timeadapter.getView(0, null, listView);
            listItem.measure(0, 0);
            totalHeight = listItem.getMeasuredHeight() * 8;
        }

        totalHeight = totalHeight + DensityUtil.dp2px(context, 10);
        int width = AppUtil.getScreenWidth(context) / 3;
        popupWindow = new PopupWindow(view, width, totalHeight);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());

        if (type == 0) {
            popupWindow.showAsDropDown(parent, -dp2px(context, 15), 0);
        } else {
            popupWindow.showAsDropDown(parent, -width, 0);
        }

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                popDismissAndItemClickCallBack.ToDismiss();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                popDismissAndItemClickCallBack.OnItemClick(position);
                BasePopupWindow.dismiss();
            }
        });

    }

    /**
     * 指标选择
     *
     * @param context
     * @param parent
     * @param times
     * @param selTimeIndex
     * @param popDismissAndItemClickCallBack
     */
    public static void showQuotaPop(final Context context, View parent, List<String> times, int selTimeIndex,
                                    final PopDismissAndItemClickCallBack popDismissAndItemClickCallBack) {
        View view = LayoutInflater.from(context).inflate(R.layout.carrier_sel_layfor, null);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BasePopupWindow.dismiss();
            }
        });

        ListView listView = (ListView) view.findViewById(R.id.listView);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(40, 0, 0, 0);
        listView.setLayoutParams(params);
        TimeAdapter timeadapter = new TimeAdapter(context, type);
        timeadapter.setTimes(times);
        timeadapter.setSelIndex(selTimeIndex);
        listView.setAdapter(timeadapter);
        int totalHeight = 0;
        int count = timeadapter.getCount();
        if (count <= 8) {
            for (int i = 0; i < count; i++) {
                View listItem = timeadapter.getView(i, null, listView);
                listItem.measure(0, 0);
                totalHeight += listItem.getMeasuredHeight();
            }
        } else {
            View listItem = timeadapter.getView(0, null, listView);
            listItem.measure(0, 0);
            totalHeight = listItem.getMeasuredHeight() * 8;
        }

        totalHeight = totalHeight + DensityUtil.dp2px(context, 10);
        int width = AppUtil.getScreenWidth(context) * 3 / 5;
        popupWindow = new PopupWindow(view, width, totalHeight);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());

        popupWindow.showAsDropDown(parent, -width, 0);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                popDismissAndItemClickCallBack.ToDismiss();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                popDismissAndItemClickCallBack.OnItemClick(position);
                BasePopupWindow.dismiss();
            }
        });

    }

    /**
     * @param context                        DOU时间选择的popupwindow
     * @param parent
     * @param times
     * @param selTimeIndex
     * @param popDismissAndItemClickCallBack
     */
    public static void showTimeMenuPop(final Context context, View parent, List<String> times, int selTimeIndex,
                                       final PopDismissAndItemClickCallBack popDismissAndItemClickCallBack) {
        View view = LayoutInflater.from(context).inflate(R.layout.carrier_sel_layfor, null);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BasePopupWindow.dismiss();
            }
        });

        ListView listView = (ListView) view.findViewById(R.id.listView);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(20, 0, 20, 0);
        listView.setLayoutParams(params);
        TimeAdapter timeadapter = new TimeAdapter(context, type);
        timeadapter.setTimes(times);
        timeadapter.setSelIndex(selTimeIndex);
        listView.setAdapter(timeadapter);
        int totalHeight = 0;
        int count = timeadapter.getCount();
        int itemHeight = 0;
        for (int i = 0; i < count; i++) {
            View listItem = timeadapter.getView(i, null, listView);
            listItem.measure(0, 0);
            itemHeight = listItem.getMeasuredHeight();
            totalHeight += listItem.getMeasuredHeight();
        }
        if (count > 8) {
            totalHeight = itemHeight * 8 + DensityUtil.dp2px(context, 10);
        } else {
            totalHeight = totalHeight + DensityUtil.dp2px(context, 10);
        }
        int width = AppUtil.getScreenWidth(context) / 2;
        popupWindow = new PopupWindow(view, width, totalHeight);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.showAsDropDown(parent, 0, 0);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                popDismissAndItemClickCallBack.ToDismiss();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                popDismissAndItemClickCallBack.OnItemClick(position);
                BasePopupWindow.dismiss();
            }
        });

    }

    private static int dp2px(Context context, int dp) {
        return (int) (dp * (context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public interface PopDismissAndItemClickCallBack {

        void ToDismiss();

        void OnItemClick(int position);
    }
}
