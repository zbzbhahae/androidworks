package com.huawei.genexcloud.scene.ui.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;
import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.bean.LocOptBean;
import com.huawei.genexcloud.scene.bean.ResultBean;
import com.huawei.genexcloud.scene.bean.SceneIndicatorBean;
import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.QuerySceneImpl;
import com.huawei.genexcloud.scene.http.callback.SceneCallback;
import com.huawei.genexcloud.scene.http.util.ErrorBean;
import com.huawei.genexcloud.scene.logger.GCLogger;
import com.huawei.genexcloud.scene.ui.adapter.GridScenesAdapter;
import com.huawei.genexcloud.scene.utils.DensityUtil;
import com.huawei.genexcloud.scene.utils.PopupWindowUtils;
import com.huawei.genexcloud.scene.viewmodel.StatusBean;
import com.huawei.genexcloud.scene.viewmodel.StatusViewModel;
import com.huawei.genexcloud.scene.widget.GridDividerItemDecoration;
import com.huawei.genexcloud.scene.widget.HorizontalRoundListBar;
import com.huawei.genexcloud.scene.widget.popupwindow.PopupwindowUtils;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;

public class NationSceneFragment extends BaseFragment implements View.OnClickListener, SwipeRefreshLayout.OnRefreshListener {

    // 刷新外壳
    private SwipeRefreshLayout refreshLayout;
    //场景更新时间
    private TextView updateTimeTxt;
    //选择场景的点击外框
    private ViewGroup scenesChooseLayout;
    //选择场景的文字显示
    private TextView scenesChooseTxt;
    //全国场景下的描述信息
    private TextView scenesDescTxt;
    //全国指标的点击选择边框
    private ViewGroup indicatorLayout;
    //全国指标的选择显示
    private TextView indicatorTxt;
    //全国图表的标题
    private ViewGroup chartTitleLayout;
    //全国图表的提示文字
    private TextView top5Txt, bottom5Txt;
    //全国指标的图表
    private HorizontalRoundListBar chartView;
    //展开全部的layout
    private ViewGroup expandLayout;
    //展开全部的箭头显示
    private ImageView expandArrow;
    //显示展开全部或者只看前5
    private TextView expandTxt;
    //场景中没有数据时的提示
    private TextView noSceneDataTxt;

    /*************标题部分***********/
    private RelativeLayout provinceLayout, operatorLayout;
    private TextView provinceTxt, operatorTxt;
    private TabLayout tabLayout;
    private TabLayout.Tab lteTab, nrTab;
    /*****市级场景部分************/

    //市级场景内容
    private RecyclerView gridView;
    private GridScenesAdapter adapter;


    //数据部分
    private String mNetType = Constants.TYPE_4G;
    private ResultBean mDataBean;
    private int mLocationdType = 0;
    private String mOperator = "CMCC";

    //全国场景下选择显示的指标index
    // 4G下 0:VoLTE上行丢包率 1:VoLTE下行丢包率 2:4G下行平均速率
    // 5G下 0:SA接入长功率 1:SA掉线率  2:5G下行平均速率
    private int selectedIndicatorIndex = 0;
    //当前场景的名称
    private int mCurrentSceneNameIndex = 0;
    //当前场景的内容
    private String mCurrentSceneName = "";

    private StatusViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_nation_scene, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        updateTimeTxt = find(R.id.scenes_update_time);
        scenesChooseLayout = find(R.id.scenes_choose_layout);
        scenesChooseTxt = find(R.id.scenes_choose_text);
        scenesDescTxt = find(R.id.scenes_desc_text);
        indicatorLayout = find(R.id.scenes_indicator_layout);
        indicatorTxt = find(R.id.scenes_indicator_text);
        chartView = find(R.id.scenes_indicator_charts);
        chartTitleLayout = find(R.id.scenes_chart_title_layout);
        top5Txt = find(R.id.scenes_controller_top5_text);
        bottom5Txt = find(R.id.scenes_controller_bottom5_text);
        expandLayout = find(R.id.scenes_expand_layout);
        expandTxt = find(R.id.scenes_expand_text);
        expandArrow = find(R.id.scenes_expand_image);
        noSceneDataTxt = find(R.id.scenes_no_scene_data);
        refreshLayout = find(R.id.refresh_layout);
        provinceLayout = find(R.id.province_layout);
        operatorLayout = find(R.id.operator_layout);
        provinceTxt = find(R.id.province_text);
        operatorTxt = find(R.id.operator_text);

        tabLayout = find(R.id.tab_layout);
        lteTab = tabLayout.newTab();
        lteTab.setText("4G场景");
        nrTab = tabLayout.newTab();
        nrTab.setText("5G场景");

        tabLayout.addTab(lteTab);
        tabLayout.addTab(nrTab);
        tabLayout.selectTab(lteTab, true);




        //设置recyclerview的滑动行为,分割线等
        gridView = find(R.id.scenes_grid);
        gridView.setHasFixedSize(true);
        gridView.setNestedScrollingEnabled(false);
        gridView.addItemDecoration(new GridDividerItemDecoration(DensityUtil.dp2px(getContext(), 1)));
        gridView.setLayoutManager(
                new GridLayoutManager(getContext(), 4,
                        RecyclerView.VERTICAL, false));
        adapter = new GridScenesAdapter();
        gridView.setAdapter(adapter);

        refreshLayout.setOnRefreshListener(this);
    }
    private void initData() {
        viewModel = new ViewModelProvider(getActivity(),
                new ViewModelProvider.NewInstanceFactory()).get(StatusViewModel.class);
        viewModel.getUserStatusViewModel().observe(getViewLifecycleOwner(), new Observer<StatusBean>() {
            @Override
            public void onChanged(StatusBean statusBean) {
                // 状态信息改变了
                String city = viewModel.getCity();
                String operator = viewModel.getOperator();
                provinceTxt.setText(city);
                operatorTxt.setText(operator);
                onRefresh();
            }
        });
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                onRefresh();
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
        scenesChooseLayout.setOnClickListener(this);
        indicatorLayout.setOnClickListener(this);
        chartView.setOnClickListener(this);
        expandLayout.setOnClickListener(this);
        provinceLayout.setOnClickListener(this);
        operatorLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.scenes_choose_layout://点击了场景分析右侧的选择场景 暂时只有医院,什么都不做
                goChooseSceneType();
                break;
            case R.id.scenes_indicator_layout://点击了全国场景下选择指标的布局
                goChooseIndicator();
                break;
            case R.id.scenes_indicator_charts://点击了图表
                break;
            case R.id.scenes_expand_layout://点击了图表下的展开全部
                collapseOrExpandChart();
                break;
            case R.id.province_layout:
                push(new SelectCityFragment());
                break;
            case R.id.operator_layout:
                goSelectOperator();
                break;
        }
    }

    /**
     * 点击了选择场景下拉按钮
     */
    private void goChooseSceneType() {
        if(null == mDataBean || null == mDataBean.getScenesTypeNames()
                || mDataBean.getScenesTypeNames().size() <= 1) {
            showMsg("无可选场景");
            return;
        }
        final List<String> scenesTypeNames = mDataBean.getScenesTypeNames();
        PopupWindowUtils.createListPopWindow(getContext(), scenesTypeNames,
                mCurrentSceneNameIndex, scenesChooseTxt, new PopupWindowUtils.OnListItemSelected() {
                    @Override
                    public void onDismiss() {
                    }

                    @Override
                    public void onSelected(String content, int position) {
                        mCurrentSceneNameIndex = position;
                        mCurrentSceneName = scenesTypeNames.get(mCurrentSceneNameIndex);
                        scenesChooseTxt.setText(mCurrentSceneName);
                        onRefresh();
                    }
                });
    }

    /**
     * 获得当前所选场景的名称
     * @return
     */
    public String getCurrentSceneType() {
        if(null != mDataBean && null != mDataBean.getScenesTypeNames()
                && !TextUtils.isEmpty(mCurrentSceneName)) {
            if(mCurrentSceneNameIndex >=0 &&
                    mCurrentSceneNameIndex < mDataBean.getScenesTypeNames().size()
                    && mCurrentSceneName.equals(mDataBean.getScenesTypeNames().get(mCurrentSceneNameIndex))) {
                // 有选择场景信息并且和数据中的信息符合
                return mCurrentSceneName;
            }
        }
        return "";
    }

    /**
     * 在更换了省市或者运营商的时候, 应当重设场景选择
     * @return
     */
    public void resetCurrentSceneType() {
        mCurrentSceneName = "";
        mCurrentSceneNameIndex = 0;
    }


    /**
     * 选择显示的场景指标
     * 只有全国下才有
     */
    private void goChooseIndicator() {
        if(null == mDataBean || null == mDataBean.getScenesIndicatorNames()
                || 0 == mDataBean.getScenesIndicatorNames().size()) {
            return;
        }
        PopupWindowUtils.createListPopWindow(getContext(), mDataBean.getScenesIndicatorNames(),
                selectedIndicatorIndex, indicatorTxt, new PopupWindowUtils.OnListItemSelected() {
                    @Override
                    public void onDismiss() {
                    }

                    @Override
                    public void onSelected(String content, int position) {
                        selectedIndicatorIndex = position;
                        setChartData(mDataBean, mNetType, selectedIndicatorIndex);
                        setExpandChart(false);
                    }
                });
    }

    /**
     * 展开或收起图表
     */
    private void collapseOrExpandChart() {
        if(chartView.getShowAll()) {
            //展开状态 需要收缩
            chartView.setShowAll(false);
            expandArrow.setImageResource(R.drawable.icon_arrow_down);
            expandTxt.setText("展开全部");
        } else {
            chartView.setShowAll(true);
            expandArrow.setImageResource(R.drawable.icon_arrow_up);
            expandTxt.setText("只看前5");
        }
    }

    /**
     * 展开或收起图表
     */
    private void setExpandChart(boolean isExpand) {
        if(!isExpand) {
            //展开状态 需要收缩
            chartView.setShowAll(false);
            expandArrow.setImageResource(R.drawable.icon_arrow_down);
            expandTxt.setText("展开全部");
        } else {
            chartView.setShowAll(true);
            expandArrow.setImageResource(R.drawable.icon_arrow_up);
            expandTxt.setText("只看前5");
        }
    }

    /**
     * 选择右上角的运营商
     */
    private void goSelectOperator() {
        showPopUpWindow(operatorLayout);
    }

    /**
     * 展示运营商选择的popwindow
     *
     * @param parent
     */
    private void showPopUpWindow(View parent) {
        //创建并显示选择运营商的popupwindow
        final List<String> operatorList = new ArrayList<>();
        operatorList.add("移动");
        operatorList.add("联通");
        operatorList.add("电信");

        // 获取当前选择的运营商位置
        String currentOperator = viewModel.getOperator();
        int selectedIndex = operatorList.indexOf(currentOperator);
        if(selectedIndex < 0 || selectedIndex > 2) {
            selectedIndex = 0;
        }
        PopupwindowUtils.showNetOperMenuPop(getContext(), parent, operatorList, selectedIndex, 0,
                new PopupwindowUtils.PopDismissAndItemClickCallBack() {
                    @Override
                    public void ToDismiss() {

                    }

                    @Override
                    public void OnItemClick(int position) {
                        //如果选择的是之前已经选中的运营商,则不用保存新数据
                        if (operatorList.get(position).equals(viewModel.getOperator())) {
                            return;
                        }
                        viewModel.setOperator(operatorList.get(position));
                        //统计用户的点击
//                        countUseInfo("B-46-01", "click", "operator=" + viewModel.getOperator());
                        //根据用户选择的运营商，以及当前的区域进行判断，对相关layout设置新选择运营商数据，让它们自己去处理

                    }
                });
    }

    /**
     * 初始化view状态,如展开状态什么的
     */
    public void initViewState() {
        setExpandChart(false);
        scenesDescTxt.setVisibility(View.GONE);
        scenesChooseLayout.setVisibility(View.GONE);
        updateTimeTxt.setVisibility(View.GONE);
        gridView.setVisibility(View.GONE);
        chartView.setVisibility(View.GONE);
        chartTitleLayout.setVisibility(View.GONE);
        expandLayout.setVisibility(View.GONE);
    }


    /**
     * 没有获取到相关数据
     */
    public void setNoData(String message) {
        // 在描述信息的位置显示无数据
        scenesDescTxt.setVisibility(View.VISIBLE);
        if(TextUtils.isEmpty(message)) {
            scenesDescTxt.setText("没有相关数据");
        } else {
            scenesDescTxt.setText(message);
        }

        scenesChooseLayout.setVisibility(View.GONE);
        updateTimeTxt.setVisibility(View.GONE);
        gridView.setVisibility(View.GONE);
        chartView.setVisibility(View.GONE);
        chartTitleLayout.setVisibility(View.GONE);
        expandLayout.setVisibility(View.GONE);
    }





    /**
     * 给view绑定数据 需要选择的区域类型信息 网络类型
     * @param locationType 地市还是全国的flag
     * @param dataBean     数据内容
     * @param netType      网络类型 4g 5g
     */
    public void setData(ResultBean dataBean, int locationType, String netType) {
        mDataBean = dataBean;
        mLocationdType = locationType;
        mNetType = netType;

        // 不应该设置场景当前选择，因为这个方法会由重新拉取新场景的数据调用 要保持当前场景数据，
        // 当前场景重设由拉取数据前调用这个类的controller来重置
        // 问题：切换运营商时，上个场景类型在这个运营商中不存在
        selectedIndicatorIndex = 0;

        showOrHideViewByType(mLocationdType);
        initViewState();

        // 如果有场景数据 则显示场景选择 否则隐藏
        if(null != mDataBean && null != mDataBean.getScenesTypeNames()
                && mDataBean.getScenesTypeNames().size() > 0) {
            scenesChooseLayout.setVisibility(View.VISIBLE);
        } else {
            scenesChooseLayout.setVisibility(View.GONE);
        }

        if(mLocationdType == LocOptBean.LOC_TYPE_CITY) {
            setGridData(mDataBean, mNetType);
        } else {
            setChartData(mDataBean, mNetType, selectedIndicatorIndex);
        }

        //设置场景选择的名称
        setScenesTypeData(dataBean);
        // 设置场景的描述信息
        setScenesDesc(dataBean);
        //设置更新时间
        setUpdateText(dataBean);
    }

    /**
     * 设置全国界面下的描述信息
     * @param data
     */
    public void setScenesDesc(ResultBean data) {
        if(mLocationdType == LocOptBean.LOC_TYPE_CITY) { //城市界面下不显示场景描述信息
            scenesDescTxt.setVisibility(View.GONE);
            return;
        }
        scenesDescTxt.setVisibility(View.VISIBLE);
        if(null != data && !TextUtils.isEmpty(data.getScenesDesc())) {
            scenesDescTxt.setText(data.getScenesDesc());
        } else {
            scenesDescTxt.setVisibility(View.GONE);
        }
    }

    /**
     * 如果图表数据过长，点击返回键应该能收缩
     * @return
     */
    public boolean onBackPressed() {
        if(mLocationdType != LocOptBean.LOC_TYPE_CITY) {
            if(chartView.canCollapse()) {
                chartView.setShowAll(false);
                expandArrow.setImageResource(R.drawable.icon_arrow_down);
                expandTxt.setText("展开全部");
                return true;
            }
        }
        return false;
    }

    /**
     * 设置数据更新时间文字内容
     * @param data
     */
    private void setUpdateText(ResultBean data) {
        updateTimeTxt.setText("");
        if(null != data && null != data.getBatchList() && 0 < data.getBatchList().size()) {
            String updateTime = data.getBatchList().get(data.getBatchList().size() - 1);
            if(!TextUtils.isEmpty(updateTime)) {
                updateTimeTxt.setText("数据更新至:" + updateTime);
            }
        }
    }

    /**
     * 设置场景信息
     * @param data
     */
    private void setScenesTypeData(ResultBean data) {
        //设置场景内容等信息
        if(null != data && null != data.getScenesTypeNames()
                && 0 != data.getScenesTypeNames().size()) {
            // 通过拿到的场景数据来判断当前是哪个场景
            List<String> scenesTypeNames = data.getScenesTypeNames();
            if(null != data.getScenesData() && data.getScenesData().size() > 0
                    && null != data.getScenesData().get(0)
                    && !TextUtils.isEmpty(data.getScenesData().get(0).getScenesType())) {
                String scenesTypeFromBean = data.getScenesData().get(0).getScenesType();
                for(int i=0; i<scenesTypeNames.size(); i++) {
                    String scenesTypeName = scenesTypeNames.get(i);
                    if(null != scenesTypeName && scenesTypeName.equals(scenesTypeFromBean)) {
                        mCurrentSceneNameIndex = i;
                    }
                }
            }

            if(mCurrentSceneNameIndex < scenesTypeNames.size() && mCurrentSceneNameIndex >= 0) {
                scenesChooseTxt.setText(scenesTypeNames.get(mCurrentSceneNameIndex));
                mCurrentSceneName = scenesTypeNames.get(mCurrentSceneNameIndex);
            } else {
                scenesChooseTxt.setText("");
                mCurrentSceneName = "";
            }
        } else {
            scenesChooseTxt.setText("");
            mCurrentSceneName = "";
        }

    }


    /**
     * 根据所选的指标,4g 5g类型 来设置相应的图表数据
     * @param resultBean
     * @param netType
     * @param selectedIndicatorIndex
     */
    private void setChartData(ResultBean resultBean, String netType, int selectedIndicatorIndex) {
        // 如果该场景分类下没有场景数据，则隐藏
        if(null == resultBean || null == resultBean.getScenesData() || resultBean.getScenesData().size() == 0) {
            chartView.setVisibility(View.GONE);
            chartTitleLayout.setVisibility(View.GONE);
            expandLayout.setVisibility(View.GONE);
            noSceneDataTxt.setVisibility(View.VISIBLE);
            chartView.setData(null, null);
            return;
        } else {
            chartView.setVisibility(View.VISIBLE);
            chartTitleLayout.setVisibility(View.VISIBLE);
            expandLayout.setVisibility(View.VISIBLE);
            noSceneDataTxt.setVisibility(View.GONE);
        }

        List<ResultBean.ScenesBean> scenesDataList = null;
        scenesDataList = resultBean.getScenesData();
        // 获取当前选中的指标名称
        String selectedIndicatorName = "";
        //设置显示指标的文字
        if(null != resultBean.getScenesIndicatorNames() && resultBean.getScenesIndicatorNames().size() > 0) {
            List<String> names = resultBean.getScenesIndicatorNames();
            indicatorTxt.setText(names.get(selectedIndicatorIndex));
            selectedIndicatorName = names.get(selectedIndicatorIndex);
        }

        List<String> names = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        boolean isPercentageValue = false;
        // 是否负向指标 只用于展示颜色，不在影响显示顺序
        boolean isPositiveValue = false;
        for(ResultBean.ScenesBean sb : scenesDataList) {
            try {
                double value = 0;

                for (SceneIndicatorBean item : sb.getIndicators()) {
                    if (selectedIndicatorName.equals(item.cnName)) {
                        value = item.value;
                        isPositiveValue = item.isPositive;
                        isPercentageValue = "%".equals(item.unit);
                        break;
                    }
                }
                values.add(value);
                names.add(sb.getScenesLocaleName());

            } catch (Exception e) {
                GCLogger.error("http", "ScenesController parse number error : ");
            }
        }
        chartView.setData(names, values, isPercentageValue,!isPositiveValue);
    }

    /**
     * 根据网络类型, 选中的指标来设置数据
     * gridView中包含标题数据
     * @param resultBean
     * @param netType
     */
    private void setGridData(ResultBean resultBean,
                             String netType) {
        if(null == resultBean) {
            adapter.setData(null, netType);
        } else {
            if (null != resultBean.getScenesData() && 0 != resultBean.getScenesData().size()) {
                // 获取场景的指标数量
                int colCount = resultBean.getScenesData().get(0).getIndicatorRelations().size();
                colCount++; // 指标数量加上指标标题
                gridView.setLayoutManager(new GridLayoutManager(getContext(), colCount));
            }
            adapter.setData(resultBean.getScenesData(), netType);
        }

        // 如果该场景分类下没有场景数据，则隐藏
        if(null == resultBean || null == resultBean.getScenesData() || resultBean.getScenesData().size() == 0) {
            noSceneDataTxt.setVisibility(View.VISIBLE);
            gridView.setVisibility(View.GONE);
            return;
        } else {
            gridView.setVisibility(View.VISIBLE);
            noSceneDataTxt.setVisibility(View.GONE);
        }
    }

    /**
     * 根据传入的位置类型(全国或城市),判断显示的界面类型
     * @param locationType
     */
    private void showOrHideViewByType(int locationType) {
        scenesChooseLayout.setVisibility(View.VISIBLE);
        updateTimeTxt.setVisibility(View.VISIBLE);
        if(LocOptBean.LOC_TYPE_CITY == (locationType)) {
            //需要隐藏的
            gridView.setVisibility(View.VISIBLE);
            scenesDescTxt.setVisibility(View.VISIBLE);
            //需要显示的
            chartView.setVisibility(View.GONE);
            scenesDescTxt.setVisibility(View.GONE);
            chartTitleLayout.setVisibility(View.GONE);
            expandLayout.setVisibility(View.GONE);
        } else {
            //需要隐藏的
            gridView.setVisibility(View.GONE);
            scenesDescTxt.setVisibility(View.GONE);
            //需要显示的
            chartView.setVisibility(View.VISIBLE);
            scenesDescTxt.setVisibility(View.VISIBLE);
            chartTitleLayout.setVisibility(View.VISIBLE);
            expandLayout.setVisibility(View.VISIBLE);


        }
    }

    @Override
    public void onRefresh() {
        String province = viewModel.getProvince();
        String city = viewModel.getCity();
        String operator = viewModel.getOperator();
        String type;
        if (lteTab.isSelected()) {
            // 查询4G数据
            type = QuerySceneImpl.TYPE_4G;
        } else {
            // 查询5G数据
            type = QuerySceneImpl.TYPE_5G;
        }
        QuerySceneImpl.getInstance().getSceneData(province, city, operator, mCurrentSceneName, type, new SceneCallback() {
            @Override
            public void onFailure(ErrorBean e) {
                showMsg(e.message);
            }

            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                refreshLayout.setRefreshing(false);
                dismissLoadingDialog();
            }

            @Override
            public void onResponse(ResultBean response) {
                if ("全国".equals(province) || "全国".equals(city)) {
                    setData(response, LocOptBean.LOC_TYPE_NATION, "");
                } else {
                    setData(response, LocOptBean.LOC_TYPE_CITY, "");
                }

            }
        });
    }
}
