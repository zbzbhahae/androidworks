package com.huawei.genexcloud.scene.provider;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.huawei.genexcloud.scene.http.util.CommonProvider;
import com.huawei.genexcloud.scene.logger.GCLogger;

/**
 * Created by tWX430835 on 2017/6/8.
 */

public class CommonProviderUtils {
    private final static String TAG = "CommonProviderUtils";

    //通过key值进行查询,通过bean.get()方法就可以获取对应的值
    public static PublicShareDataBean queryByKey(Context context, String key) {

        Cursor c = null;
        PublicShareDataBean shareDataBean = new PublicShareDataBean();
        try {
            c = context.getContentResolver().query(CommonProvider.GenexCloudColumns.CONTENT_URI, null,
                    CommonProvider.GenexCloudColumns.KEY + "=?", new String[]{key}, null);
            if (c != null && c.moveToFirst()) {
                shareDataBean.key = c.getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.KEY));
                shareDataBean.name = c.getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.NAME));
            }
        } catch (Exception e) {
            GCLogger.error("error", "[" + TAG + "]" + "queryByKey e=" + e.toString());
        } finally {
            if (c != null) {
                c.close();
            }
        }
        GCLogger.info("error", "[" + TAG + "]" + "shareDataBean=" + shareDataBean.toString());
        return shareDataBean;
    }

    /**
     * 通过插件包名获取相关URL
     *
     * @param context
     * @param packageName
     * @return
     */

    //通过包名获取url
    public static PlugApkInfomationBean queryUrlByPackageName(Context context, String packageName) {
        Cursor c = null;
        PlugApkInfomationBean plugApkInfomationBean = new PlugApkInfomationBean();
        try {

            c = context.getContentResolver().query(CommonProvider.GenexCloudColumns.PLUG_APK_CONTENT_URI, null,
                    CommonProvider.GenexCloudColumns.PLUG_APK_PACKAGENAME + "=?", new String[]{packageName}, null);

            if (c != null && c.moveToFirst()) {

                plugApkInfomationBean.ModelName = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_MODEL_NAME));
                plugApkInfomationBean.DomainUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOMAIN_URL));
                plugApkInfomationBean.JavaUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_JAVA_URL));
                plugApkInfomationBean.DotNetUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOT_NET_URL));
                plugApkInfomationBean.DownLoadUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOWNLOAD_URL));
                plugApkInfomationBean.VersionName = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_VERSIONNAME));
                plugApkInfomationBean.ClassName = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_CLASSNAME));

            }
        } catch (Exception e) {
            GCLogger.error("error", "[" + TAG + "]" + "queryUrlByPackageName e=" + e.toString());
        } finally {
            if (c != null) {
                c.close();
            }
        }
        GCLogger.info("error", "[" + TAG + "]" + "plugApkInfomationBean=" + plugApkInfomationBean.toString());
        return plugApkInfomationBean;
    }

    /**
     * 通过modealName获取url
     *
     * @param context
     * @param modelName
     * @return
     */
    public static PlugApkInfomationBean queryUrlByModelName(Context context, String modelName) {
        Cursor c = null;
        PlugApkInfomationBean plugApkInfomationBean = new PlugApkInfomationBean();
        try {

            c = context.getContentResolver().query(CommonProvider.GenexCloudColumns.PLUG_APK_CONTENT_URI, null,
                    CommonProvider.GenexCloudColumns.PLUG_APK_MODEL_NAME + "=?", new String[]{modelName}, null);

            if (c != null && c.moveToFirst()) {

                plugApkInfomationBean.PackageName = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_PACKAGENAME));
                plugApkInfomationBean.ClassName = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_CLASSNAME));
                plugApkInfomationBean.DomainUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOMAIN_URL));
                plugApkInfomationBean.JavaUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_JAVA_URL));
                plugApkInfomationBean.DotNetUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOT_NET_URL));
                plugApkInfomationBean.DownLoadUrl = c
                        .getString(c.getColumnIndexOrThrow(CommonProvider.GenexCloudColumns.PLUG_APK_DOWNLOAD_URL));

            }
        } catch (Exception e) {
            GCLogger.error("error", "[" + TAG + "]" + "queryUrlByModelName e=" + e.toString());
        } finally {
            if (c != null) {
                c.close();
            }
        }
        GCLogger.info("error", "[" + TAG + "]" + "plugApkInfomationBean=" + plugApkInfomationBean.toString());
        return plugApkInfomationBean;
    }

    /**
     * 给公共的键值对数据库添加数据
     *
     * @return
     */
    public static int insertData(Context context, PublicShareDataBean bean) {
        ContentValues values = new ContentValues();
        values.put(CommonProvider.GenexCloudColumns.KEY, bean.key);
        values.put(CommonProvider.GenexCloudColumns.NAME, bean.name);
        Uri uri = null;
        int result = -1;
        try {
            uri = context.getContentResolver().insert(CommonProvider.GenexCloudColumns.CONTENT_URI, values);
        } catch (Exception e) {
            GCLogger.error("error", "[" + TAG + "]" + " insertData e=" + e.toString());
        }

        if (uri != null) {
            Log.i("", "insert uri=" + uri);
            String lastPath = uri.getLastPathSegment();
            if (TextUtils.isEmpty(lastPath)) {
                Log.i("", "insert failure!");
            } else {
                Log.i("", "insert success! the id is " + lastPath);
            }

            result = Integer.parseInt(lastPath);
        }

        return result;
    }

    /**
     * 根据键进行删除值
     *
     * @param context
     * @param key
     * @return
     */
    public static int deletDataByKey(Context context, String key) {
        int result = -1;

        try {
            result = context.getContentResolver().delete(CommonProvider.GenexCloudColumns.CONTENT_URI,
                    CommonProvider.GenexCloudColumns.KEY + "=?", new String[]{key});
        } catch (Exception e) {
            GCLogger.error("error", "[" + TAG + "]" + " deletDataByKey e=" + e.toString());
        }

        return result;
    }
}
