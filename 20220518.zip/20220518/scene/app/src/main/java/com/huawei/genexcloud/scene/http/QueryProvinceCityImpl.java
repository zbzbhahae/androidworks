package com.huawei.genexcloud.scene.http;

import android.text.TextUtils;
import android.util.ArrayMap;

import com.huawei.genexcloud.scene.bean.ProvinceCityBean;
import com.huawei.genexcloud.scene.http.util.GCCallback;
import com.huawei.genexcloud.scene.http.util.JavaHttpUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 获取省份城市数据
 */
public class QueryProvinceCityImpl extends JavaHttpUtil {

    private static QueryProvinceCityImpl instance;

    public static QueryProvinceCityImpl getInstance() {
        if (null == instance) {
            synchronized (QueryProvinceCityImpl.class) {
                if (null == instance) {
                    instance = new QueryProvinceCityImpl();
                }
            }
        }
        return instance;
    }
    @Override
    protected String getMessageName() {
        return "/network/getProvinceAndCity";
    }

    /**
     * 获取省份城市数据
     * @param callback
     */
    public void getProvinceCityInfo(ProvinceCityCallback callback) {
        postSingle(this, null, callback);
    }

    public static abstract class ProvinceCityCallback extends GCCallback<List<ProvinceCityBean>> {
        @Override
        public List<ProvinceCityBean> parseNetworkResponse(String responseStr) throws Exception {
            JSONObject jsonObject = new JSONObject(responseStr);
            List<ProvinceCityBean> data = new ArrayList<>();
            if (jsonObject.has("data")) {
                Map<String, List<String>> provinceCityMap = new ArrayMap<>();
                JSONArray dataArray = jsonObject.optJSONArray("data");
                if (null != dataArray && dataArray.length() > 0) {
                    for (int i=0; i<dataArray.length(); i++) {
                        JSONObject itemJson = dataArray.optJSONObject(i);
                        String province = itemJson.optString("province_name");
                        String city = itemJson.optString("city_name");
                        if (!TextUtils.isEmpty(province) && !TextUtils.isEmpty(city) && !"全国".equals(province) && !"全国".equals(city)) {
                            if (provinceCityMap.containsKey(province)) {
                                List<String> cityList = provinceCityMap.get(province);
                                if (null != cityList) {
                                    cityList.add(city);
                                }
                            } else {
                                List<String> cityList = new ArrayList<>();
                                cityList.add(city);
                                provinceCityMap.put(province, cityList);
                            }
                        }
                    }
                    for (Map.Entry<String, List<String>> entry : provinceCityMap.entrySet()) {
                        String province = entry.getKey();
                        List<String> cityList = entry.getValue();
                        if (!TextUtils.isEmpty(province) && null != cityList && cityList.size() > 0) {
                            data.add(new ProvinceCityBean(province, cityList));
                        }
                    }
                }
            }
            if (data.size() > 0) {
                data.add(0, new ProvinceCityBean("全国", "全国"));
            }
            return data;
        }
    }
}
