package com.huawei.genexcloud.scene.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.logger.GCLogger;
import com.huawei.genexcloud.scene.widget.DividerItemDecorationVertical;

import java.util.List;

/**
 * Created by zWX1094027 on 2021/9/11.
 * 创建下拉选择的popupwindow
 */

public class PopupWindowUtils {


    private static PopupWindow listPopWindow;
    private static PopupWindow hListPopWindow;
    private static ListPopAdapter adapter;

    /**
     * 显示一个下拉列表的菜单, 菜单内容只有TextView,并将菜单显示再achorView下方
     *
     * @param context
     * @param selections       提供选择的内容数据
     * @param selectedPosition 之前的选择位置
     * @param anchorView       显示在该View下方
     * @param listener         选择回调
     */
    public static void createListPopWindow(final Context context, List<String> selections,
                                           int selectedPosition, View anchorView, final OnListItemSelected listener) {

        if (null == context || null == selections || selections.size() == 0
                || null == anchorView || (null != listPopWindow && listPopWindow.isShowing())) {
            return;
        }
        if (null == listPopWindow) {
            RecyclerView listRV = null;

            View root = LayoutInflater.from(context).inflate(R.layout.pop_list_select, null, false);
            // 设置宽高参数，防止部分手机看不到view

            listRV = (RecyclerView) root.findViewById(R.id.pop_recycler_view);
            if (null == adapter) {
                adapter = new ListPopAdapter();
            }
            listRV.setLayoutManager(new LinearLayoutManager(context));
            listRV.setAdapter(adapter);
            listRV.addItemDecoration(new DividerItemDecorationVertical(context, LinearLayout.VERTICAL));

            //计算window大小
            listPopWindow = new PopupWindow(context);
            listPopWindow.setContentView(root);
            listPopWindow.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
            listPopWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            listPopWindow.setBackgroundDrawable(new ColorDrawable(0xFFFFFFF));
            listPopWindow.setOutsideTouchable(true);
            listPopWindow.setFocusable(true);
        }
        adapter.setData(selections, selectedPosition);

        adapter.setOnItemClickedListener(new ListPopAdapter.OnItemClicked() {
            @Override
            public void onClick(String selection, int position) {
                if (null != listener) {
                    listener.onSelected(selection, position);
                }
                listPopWindow.dismiss();
            }
        });

        listPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                if (null != listener) {
                    listener.onDismiss();
                }
                setWindowAlpah(context, 1.0f);
            }
        });
        GCLogger.error("zb", "isShowing:" + listPopWindow.isShowing());


        int position[] = new int[2];
        anchorView.getLocationOnScreen(position);
        int viewY = position[1];
        int screenHeight = AppUtil.getScreenHeight(context);
        int itemCount = adapter.getItemCount();
        int popHeight = itemCount * DensityUtil.dp2px(context, 33) + DensityUtil.dp2px(context, 20);
        if (screenHeight - popHeight - viewY < 0) {
            listPopWindow.showAsDropDown(anchorView, 0, (screenHeight - popHeight - viewY));
        } else {
            listPopWindow.showAsDropDown(anchorView);
        }

        setWindowAlpah(context, 0.5f);
    }

    public static void createHListPopWindow(final Context context, List<String> selections,
                                            int selectedPosition, View anchorView,
                                            final OnListItemSelected listener) {
        if (null == context || null == selections || selections.size() == 0
                || null == anchorView || (null != hListPopWindow && hListPopWindow.isShowing())) {
            return;
        }
        if (null == hListPopWindow) {
            RecyclerView listRV = null;
            hListPopWindow = new PopupWindow(context);
            View root = LayoutInflater.from(context).inflate(R.layout.pop_list_select, null, false);
            listRV = (RecyclerView) root.findViewById(R.id.pop_recycler_view);
            if (null == adapter) {
                adapter = new ListPopAdapter();
            }
            listRV.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
            listRV.setAdapter(adapter);
            listRV.addItemDecoration(new DividerItemDecorationVertical(context, LinearLayout.VERTICAL));
            hListPopWindow.setContentView(root);
            hListPopWindow.setBackgroundDrawable(new ColorDrawable(0xFFFFFFF));
            hListPopWindow.setOutsideTouchable(true);
            hListPopWindow.setFocusable(true);
        }
        adapter.setData(selections, selectedPosition);

        adapter.setOnItemClickedListener(new ListPopAdapter.OnItemClicked() {
            @Override
            public void onClick(String selection, int position) {
                if (null != listener) {
                    listener.onSelected(selection, position);
                }
                listPopWindow.dismiss();
            }
        });

        hListPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                if (null != listener) {
                    listener.onDismiss();
                }
                setWindowAlpah(context, 1.0f);
            }
        });
        hListPopWindow.showAsDropDown(anchorView);
        setWindowAlpah(context, 0.5f);
    }

    /**
     * 设置window的背景色
     *
     * @param context
     * @param alpha
     */
    public static void setWindowAlpah(Context context, float alpha) {
        if (context instanceof Activity) {
            Window window = ((Activity) context).getWindow();
            WindowManager.LayoutParams windowParams = window.getAttributes();
            windowParams.alpha = alpha;
            window.setAttributes(windowParams);
        }
    }

    /**
     * Popwindow对外接口
     */
    public interface OnListItemSelected {
        void onDismiss();

        void onSelected(String content, int position);
    }


    /**
     * 列表选择适配器 内容只有一个TextView
     */
    static class ListPopAdapter extends RecyclerView.Adapter<ListPopAdapter.ListPopViewHolder> {

        private List<String> selections;
        private OnItemClicked listener;
        private int selectedPosition = -1;

        public void setOnItemClickedListener(OnItemClicked listener) {
            this.listener = listener;
        }

        public void setData(List<String> selections) {
            this.selections = selections;
            notifyDataSetChanged();
        }

        public void setData(List<String> selections, int selectedPosition) {
            this.selections = selections;
            this.selectedPosition = selectedPosition;
            notifyDataSetChanged();
        }

        @Override
        public ListPopViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_text, parent, false);
            return new ListPopViewHolder(root);
        }

        @Override
        public void onBindViewHolder(ListPopViewHolder holder, int position) {
            final int finalPosition = position;
            holder.contentTxt.setText(selections.get(position));
            if (selectedPosition == position) {
                holder.contentTxt.setTextColor(0xFF33AAFF);
            } else {
                holder.contentTxt.setTextColor(0xFF333333);
            }
            holder.contentTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != listener) {
                        listener.onClick(selections.get(finalPosition), finalPosition);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return null == selections ? 0 : selections.size();
        }

        interface OnItemClicked {
            void onClick(String selection, int position);
        }

        class ListPopViewHolder extends RecyclerView.ViewHolder {
            private TextView contentTxt;

            public ListPopViewHolder(View itemView) {
                super(itemView);
                contentTxt = (TextView) itemView.findViewById(R.id.item_content_text);
            }
        }
    }
}
