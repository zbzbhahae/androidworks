package com.huawei.genexcloud.scene.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import androidx.core.content.FileProvider;

import com.huawei.genexcloud.scene.logger.GCLogger;

import java.io.File;
import java.util.List;

/**
 * 与App有关的工具类
 */
public class AppUtil {
    private AppUtil() {
    }

    /**=====================================屏幕相关==============================**/

    /**
     * 获得屏幕实例
     *
     * @param context 上下文
     * @return 屏幕实例
     */
    public static Display getDisplay(Context context) {
        return ((WindowManager) context.getApplicationContext()
                .getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay();
    }

    /**
     * 获取屏幕宽高 与display的getwidth等结果一致 不包含虚拟键与状态栏的宽高
     *
     * @param context 上下文
     * @return 宽高组成的point对象
     */
    public static Point getScreenSize(Context context) {
        Display display = getDisplay(context);
        Point point = new Point();
        display.getSize(point);
        return point;
    }

    /**
     * 获取屏幕宽度
     *
     * @param context 上下文
     * @return 屏幕宽度
     */
    public static int getScreenWidth(Context context) {
        Point point = getScreenSize(context);
        return point.x;
    }

    /**
     * 获取屏幕高度
     *
     * @param context 上下文
     * @return 屏幕高度
     */
    public static int getScreenHeight(Context context) {
        Point point = getScreenSize(context);
        return point.y;
    }

    /**
     * 获取屏幕真实宽高  包含虚拟键和导航栏
     *
     * @param context 上下文
     * @return 宽高组成的point对象
     */
    public static Point getRealScreenSize(Context context) {
        Display display = getDisplay(context);
        Point point = new Point();
        display.getRealSize(point);
        return point;
    }

    /**
     * 获取屏幕宽度
     *
     * @param context 上下文
     * @return 屏幕宽度
     */
    public static int getRealScreenWidth(Context context) {
        Point point = getRealScreenSize(context);
        return point.x;
    }

    /**
     * 获取屏幕高度
     *
     * @param context 上下文
     * @return 屏幕高度
     */
    public static int getRealScreenHeight(Context context) {
        Point point = getRealScreenSize(context);
        return point.y;
    }

    /**
     * 获取手机状态栏高度
     */
    public static int getStatusBarHeight(Context context) {
        Resources resources = context.getApplicationContext().getResources();

        int resourceId = resources.getIdentifier("status_bar_height",
                "dimen", "android");
        int height = resources.getDimensionPixelSize(resourceId);
        return height;
    }

    /**
     * 获取手机导航栏高度
     */
    public static int getNavigationBarHeight(Context context) {
        Resources resources = context.getApplicationContext().getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height",
                "dimen", "android");
        if (resourceId > 0) {
            return resources.getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    /**
     * 是否显示导航栏
     */
    public static boolean isNavigationBarShow(Context context) {
        // 获取内容屏幕高度
        int screenHeight = getScreenHeight(context);
        // 获取屏幕真正高度
        int realScreenHeight = getRealScreenHeight(context);
        // 获取状态栏定义高度
        int statusBarHeight = getStatusBarHeight(context);
        // 判断 状态栏 + 内容高度是否小于等于真正高度
        return realScreenHeight > (statusBarHeight + screenHeight);
    }

    /**=====================================APP信息相关==============================**/
    /**
     * 获取包管理器
     *
     * @param context 上下文
     * @return 包管理器
     */
    public static PackageManager getPackageManager(Context context) {
        return context.getApplicationContext().getPackageManager();
    }

    /**
     * 获取应用包名
     *
     * @param context 上下文
     * @return 应用的包名
     */
    public static String getPackageName(Context context) {
        return context.getApplicationContext().getPackageName();
    }

    /**
     * 获取应用版本名字符串
     *
     * @param context 上下文
     * @return 应用版本字符串
     */
    public static String getVersionName(Context context) {
        PackageManager packageManager = getPackageManager(context);
        try {
            // 设置Flag可以过滤Package信息，防止一次拿取全部信息导致Binder通信内容过大而失败
            PackageInfo packageInfo = packageManager
                    .getPackageInfo(getPackageName(context), PackageManager.GET_CONFIGURATIONS);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("error", e.toString());
        }
        return "";
    }

    /**
     * 获取应用版本号 数字
     *
     * @param context 上下文
     * @return 版本号
     */
    public static int getVersionCode(Context context) {
        PackageManager packageManager = getPackageManager(context);
        try {
            // 设置Flag可以过滤Package信息，防止一次拿取全部信息导致Binder通信内容过大而失败
            PackageInfo packageInfo = packageManager
                    .getPackageInfo(getPackageName(context), PackageManager.GET_CONFIGURATIONS);
            return packageInfo.versionCode;
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return 0;
    }

    /**
     * 获取App图标
     *
     * @param context 上下文
     * @return 图标
     */
    public static Bitmap getAppIcon(Context context) {
        PackageManager packageManager = getPackageManager(context);
        try {
            Drawable drawable = packageManager.getApplicationIcon(getPackageName(context));
            return ((BitmapDrawable) drawable).getBitmap();
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return null;
    }

    private static long lastClickTime = 0;

    /**
     * 检查是否是快速的两次单击
     */
    public static boolean isFastDoubleClick() {
        long time = System.currentTimeMillis();
        long duration = time - lastClickTime;
        if (duration > 0 && duration < 100) {
            return true;
        }
        lastClickTime = time;
        return false;
    }

    /**
     * 手机是否root
     *
     * @return
     */
    public static boolean isRoot() {
        boolean root = false;
        try {
            if ((!new File("/system/bin/su").exists())
                    && (!new File("/system/xbin/su").exists())) {
                root = false;
            } else {
                root = true;
            }
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return root;
    }

    /**
     * 关闭键盘
     *
     * @param activity Activity
     */
    public static void hideSoftInput(Activity activity) {
        if (activity.getCurrentFocus() != null)
            ((InputMethodManager) activity
                    .getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(activity.getCurrentFocus()
                            .getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    /**
     * 安装apk
     *
     * @param context 上下文
     * @param path    文件路劲
     */
    public static void installAPK(Context context, String path) {
        try {
            Intent intent = new Intent();
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setAction(Intent.ACTION_VIEW);

            if (Build.VERSION.SDK_INT >= 24) {
                //添加这一句表示对目标应用临时授权该Uri所代表的文件
                intent.addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                intent.setDataAndType(FileProvider.getUriForFile(context,
                        "com.huawei.genexcloud.fileprovider", new File(path)),
                        "application/vnd.android.package-archive");
            } else {
                intent.setDataAndType(Uri.parse("file://" + path),
                        "application/vnd.android.package-archive");
            }
            context.startActivity(intent);
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
    }

    /**
     * 直接拨号，需要增加CALL_PHONE权限
     *
     * @param context 上下文
     * @param phone   手机号码
     */
    public static void callPhone(Context context, String phone) {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
        intent.setAction(Intent.ACTION_CALL);// 直接拨号
        context.startActivity(intent);
    }

    /**
     * 跳到拨号盘-拨打电话
     *
     * @param context 上下文
     * @param phone   手机号码
     */
    public static void dialPhone(Context context, String phone) {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
        intent.setAction(Intent.ACTION_DIAL);// 拨号盘
        context.startActivity(intent);
    }

    /**
     * 检查版本是否需要升级
     *
     * @param currVer 本地安装版本
     * @param ver 数据库版本
     */
    public static boolean checkVersionCode(String currVer, String ver) {

        // 当前版本
        String[] currVers = currVer.split("\\.");
        int currStart = 0;
        int currMiddle = 0;
        int currEnd = 0;
        for (int i = 0; i < currVers.length; i++) {
            switch (i) {
                case 0:
                    currStart = Integer.parseInt(currVers[0]);
                    break;
                case 1:
                    currMiddle = Integer.parseInt(currVers[1]);
                    break;
                case 2:
                    currEnd = Integer.parseInt(currVers[2]);
                    break;
                default:
                    break;
            }
        }
        // 服务器版本
        String[] serVer = ver.split("\\.");
        int serStart = 0;
        int serMiddle = 0;
        int serEnd = 0;
        for (int i = 0; i < serVer.length; i++) {
            switch (i) {
                case 0:
                    if (!TextUtils.isEmpty(serVer[0])) {
                        serStart = Integer.parseInt(serVer[0]);
                    }
                    break;
                case 1:
                    if (!TextUtils.isEmpty(serVer[1])) {
                        serMiddle = Integer.parseInt(serVer[1]);
                    }
                    break;
                case 2:
                    if (!TextUtils.isEmpty(serVer[2])) {
                        serEnd = Integer.parseInt(serVer[2]);
                    }
                    break;
                default:
                    break;
            }
        }

        if (serStart > currStart) {
            return true;
        } else if (serStart == currStart) {
            if (serMiddle > currMiddle) {
                return true;
            } else if (serMiddle == currMiddle) {
                return serEnd > currEnd;
            }
        }
        return false;
    }

    /**
     *
     *检查指定应用是否安装
     */
    public static PackageInfo checkAppInstalled(Context context, String pkgName) {

        PackageInfo packageInfo = null;
        if (pkgName == null || pkgName.isEmpty()) {
            return null;
        }
        final PackageManager packageManager = context.getPackageManager();
        // 获取所有已安装程序的包信息
        List<PackageInfo> info = packageManager.getInstalledPackages(0);
        if (info == null || info.isEmpty()) {
            return null;
        }

        for (int i = 0; i < info.size(); i++) {
            if (pkgName.equals(info.get(i).packageName)) {
                packageInfo = info.get(i);
                return packageInfo;
            }
        }
        return null;
    }

    /**
     * 判断是否安装了某应用
     * @param context  上下文
     * @param packageName  该应用的主包名
     * @return 是否安装了该应用
     */
    public static boolean isInstalledApp(Context context, String packageName) {
        if(TextUtils.isEmpty(packageName) || null == context) {
            return false;
        }
        try {
            PackageManager pm = context.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            if(null != ai) {
                return true;
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
        return false;
    }


    /**
     * 打开安装的Apk
     * @param context 上下文
     * @param packageName 包名
     */
    public static void openInstalledApk(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        if (null != intent) {
            context.startActivity(intent);
        }
    }

    /**
     * 替换特殊字符
     *  发送反馈信息时会使用到 @link{com.huawei.genexcloud.http.util.FeedbackImpl}
     * @param result
     * @return
     */
    public static String replaceAll(String result) {
        result = result.replace("%", "%25");
        result = result.replace("+", "%2B");
        result = result.replace(" ", "&nbsp;");
        result = result.replace("/", "%2F");
        result = result.replace("?", "%3F");
        result = result.replace("#", "%23");
        result = result.replace("&", "%26");
        result = result.replace("=", "%3D");
        result = result.replace("\n", "<br/>");
        result = result.replace("'", "%26%2339%3b");
        return result;
    }
}
