package com.huawei.genexcloud.scene;

import android.app.Application;
import android.content.Context;

import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.util.OkHttpManager;
import com.huawei.genexcloud.scene.utils.PathUtil;

public class App extends Application {
    public static final String TAG = "SceneApplication";
    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        Constants.initUrl();
        OkHttpManager.initClient(this);
        PathUtil.init(this);
    }

    public static Context getAppContext() {
        return context;
    }
}
