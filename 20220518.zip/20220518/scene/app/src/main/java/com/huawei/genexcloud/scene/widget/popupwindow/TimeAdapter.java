package com.huawei.genexcloud.scene.widget.popupwindow;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;


import com.huawei.genexcloud.scene.R;

import java.util.ArrayList;
import java.util.List;

public class TimeAdapter extends BaseAdapter {

    private final Context mContext;
    private final LayoutInflater mInflater;
    private List<String> times = new ArrayList<>();
    private ViewHolder holder;
    private int type;
    private int selIndex;

    private String mTag = "";

    public TimeAdapter(Context context, int type) {
        this.type = type;
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
    }

    public void setTimes(List<String> times) {
        this.times = times;
    }

    public void setSelIndex(int selIndex) {
        this.selIndex = selIndex;
    }

    @Override
    public int getCount() {
        return times.size();
    }

    @Override
    public Object getItem(int position) {
        return times.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();

            convertView = mInflater.inflate(R.layout.carrier_sel_item, null);
            // 初始化holder对象
            initHolder(holder, convertView);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        setData(position, convertView);

        return convertView;
    }

    private void initHolder(ViewHolder holder, View convertView) {
        holder.nameView = (TextView) convertView.findViewById(R.id.text1);
        convertView.setTag(holder);
    }

    private void setData(final int position, View convertView) {
        ViewHolder holder = (ViewHolder) convertView.getTag();
        if (times != null && times.size() > 0) {
            String info = times.get(position);
            convertView.setBackgroundResource(R.drawable.sel_list_bg_color_checked);
            if (position == selIndex) {
                holder.nameView.setTextColor(ContextCompat.getColor(mContext, R.color.text_atu_lay_blue));
            } else {
                holder.nameView.setTextColor(ContextCompat.getColor(mContext, R.color.text_333));
            }

            holder.nameView.setText(info);

        }
    }

    private String formatRightNormalText(String str, String unit) {

        return "<body>" + "<font size=\"4\" color=\"#333333\"><normal>" + str + "</normal></font>"
                + "<font color=\"#666666\"><small>" + unit + "</small></font>" + "</body>";
    }

    private String formatRightSelectedText(String str, String unit) {

        return "<body>" + "<font size=\"4\" color=\"#33aaff\"><normal>" + str + "</normal></font>"
                + "<font color=\"#33aaff\"><small>" + unit + "</small></font>" + "</body>";
    }

    public void setTag(String tag) {
        this.mTag = tag;
    }

    public class ViewHolder {
        TextView nameView;
    }
}
