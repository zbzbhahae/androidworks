package com.huawei.genexcloud.scene.utils;

import android.text.TextUtils;

import java.util.Locale;

/**
 * 运营商名称 工具类
 */
public class OperatorUtil {

    public static String getOperatorCNName(String operatorName) {
        if (TextUtils.isEmpty(operatorName)) {
            return "";
        }
        switch (operatorName.toUpperCase(Locale.ROOT)) {
            case "CMCC":
            case "移动":
                return "移动";
            case "CUCC":
            case "CUTC":
            case "联通":
                return "联通";
            case "CNTC":
            case "CNCC":
            case "CTCC":
            case "电信":
                return "电信";
            default:
                return "";
        }
    }

    public static String getOperatorENName(String operatorName) {
        if (TextUtils.isEmpty(operatorName)) {
            return "";
        }
        switch (operatorName.toUpperCase(Locale.ROOT)) {
            case "CMCC":
            case "移动":
                return "CMCC";
            case "CUCC":
            case "CUTC":
            case "联通":
                return "CUCC";
            case "CNTC":
            case "CNCC":
            case "CTCC":
            case "电信":
                return "CTCC";
            default:
                return "";
        }
    }
}
