package com.huawei.genexcloud.scene.ui.activity;

import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;

import com.huawei.genexcloud.scene.bean.AppUseInfo;
import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.UpdateUsageImpl;
import com.huawei.genexcloud.scene.provider.CommonProviderUtils;
import com.huawei.genexcloud.scene.utils.AppUtil;
import com.huawei.genexcloud.scene.utils.DeviceUtil;

public class BaseActivity extends BaseFragmentActivity {
    // 用于存储创建同进程内共享的viewmodel使用
    private ViewModelStoreOwner sharedViewModelStoreOwner;
    private static ViewModelStore sharedViewModelStore;

    /**
     * 获取共享的ViewModel的存储Owner
     */
    public ViewModelStoreOwner getSharedViewModelStoreOwner() {
        if (this.getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        } else {
            if (sharedViewModelStore == null) {
                sharedViewModelStore = new ViewModelStore();
            }
            if (sharedViewModelStoreOwner == null) {
                sharedViewModelStoreOwner = new ViewModelStoreOwner() {
                    @NonNull
                    @Override
                    public ViewModelStore getViewModelStore() {
                        return sharedViewModelStore;
                    }
                };
            }
        }
        return sharedViewModelStoreOwner;
    }

    /**
     * 获取动向的ViewModel的存储对象
     */
    public ViewModelStore getSharedViewModelStore() {
        if (this.getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        } else {
            if (sharedViewModelStore == null) {
                sharedViewModelStore = new ViewModelStore();
            }
            if (sharedViewModelStoreOwner == null) {
                sharedViewModelStoreOwner = new ViewModelStoreOwner() {
                    @NonNull
                    @Override
                    public ViewModelStore getViewModelStore() {
                        return sharedViewModelStore;
                    }
                };
            }
        }
        return sharedViewModelStore;
    }

    /**
     * 统计用户信息
     *
     * @param pageId  定义好的页面信息
     * @param eventId 定义好的事件信息
     * @param param   事件参数
     */
    public void countUseInfo(final String pageId, final String eventId, final String param) {
        // 没有账号信息不统计
        if (TextUtils.isEmpty(account)) {
            return;
        }
        AppUseInfo appUseInfo = new AppUseInfo();
        appUseInfo.setPageId(pageId);
        appUseInfo.setEventId(eventId);
        appUseInfo.setAccount(account);
        appUseInfo.setParameter(param);
        // 获取运营商信息
        appUseInfo.setNetOper(DeviceUtil.getSimOperator(this));

        String latString = CommonProviderUtils.queryByKey(getApplicationContext(), Constants.CURRENT_LAT).getName();
        String lngString = CommonProviderUtils.queryByKey(getApplicationContext(), Constants.CURRENT_LNG).getName();
        double lat = (TextUtils.isEmpty(latString) ? 34.277798 : Double.parseDouble(latString));
        double lng = (TextUtils.isEmpty(lngString) ? 108.953095 : Double.parseDouble(lngString));
        appUseInfo.setLatitude(lat);
        appUseInfo.setLongitude(lng);

        appUseInfo.setAppVer(AppUtil.getVersionName(getApplicationContext())); // app版本
        appUseInfo.setSystemVersion(android.os.Build.VERSION.RELEASE); // 系统版本
        appUseInfo.setModel(android.os.Build.MODEL); // 手机型号
        appUseInfo.setImei(DeviceUtil.getAndroidId(this)); // 手机IMEI

        UpdateUsageImpl.getInstance().postUserUsage(this, appUseInfo);
    }

    public void showMsg(String message) {
        if (!TextUtils.isEmpty(message)) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

}
