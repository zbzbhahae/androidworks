package com.huawei.genexcloud.scene.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.huawei.genexcloud.scene.bean.ProvinceCityBean;
import com.huawei.genexcloud.scene.bean.UserPermission;

import java.util.List;

/**
 * 保存插件运行时的用户参数信息
 */
public class StatusViewModel extends ViewModel {

    private MutableLiveData<StatusBean> userStatus;
    // 用户的数据权限方面 在MainActivity中只提供是否显示无数据权限界面 具体数据权限在fragment中判断
    private List<UserPermission> userPermissions;
    // 存储省份城市列表信息
    private List<ProvinceCityBean> provinceCityList;

    public List<UserPermission> getUserPermissions() {
        return userPermissions;
    }

    public void setUserPermissions(List<UserPermission> userPermissions) {
        this.userPermissions = userPermissions;
    }

    public List<ProvinceCityBean> getProvinceCityList() {
        return provinceCityList;
    }

    public void setProvinceCityList(List<ProvinceCityBean> provinceCityList) {
        this.provinceCityList = provinceCityList;
    }

    public StatusViewModel() {
        userStatus = new MutableLiveData<>();
        userStatus.setValue(new StatusBean());
    }

    public MutableLiveData<StatusBean> getUserStatusViewModel() {
        return userStatus;
    }

    public void setProvince(String province) {
        StatusBean status = userStatus.getValue();
        status.setProvince(province);
        userStatus.setValue(status);
    }
    public void setCity(String city)  {
        StatusBean status = userStatus.getValue();
        status.setCity(city);
        userStatus.setValue(status);
    }
    public void setOperator(String operator) {
        StatusBean status = userStatus.getValue();
        status.setOperator(operator);
        userStatus.setValue(status);
    }
    public void setProvinceAndCity(String province, String city) {
        StatusBean statusBean = userStatus.getValue();
        statusBean.setProvince(province);
        statusBean.setCity(city);
        userStatus.setValue(statusBean);
    }
    public void setStatus(String province, String city, String operator) {
        StatusBean statusBean = userStatus.getValue();
        statusBean.setProvince(province);
        statusBean.setCity(city);
        statusBean.setOperator(operator);
        userStatus.setValue(statusBean);
    }
    public String getProvince() {
        return userStatus.getValue().getProvince();
    }
    public String getCity() {
        return userStatus.getValue().getCity();
    }
    public String getOperator() {
        return userStatus.getValue().getOperator();
    }
    public boolean isNationStatus() {
        return userStatus.getValue().isNationStatus();
    }

}
