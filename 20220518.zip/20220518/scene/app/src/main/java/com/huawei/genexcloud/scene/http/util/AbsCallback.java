package com.huawei.genexcloud.scene.http.util;


import androidx.annotation.NonNull;

import okhttp3.Request;
import okhttp3.Response;

public abstract class AbsCallback<T> {

    /**
     * UI Thread
     */
    public void onBefore(Request request) {}

    /**
     * UI Thread
     */
    public void onAfter() {}
    /**
     * 用于返回字符串内容的解析 一般用这个
     * 子线程
     * @param response 返回对象
     * @return 解析出的对应bean
     * @throws Exception
     */
    public abstract T parseNetworkResponse(@NonNull Response response) throws Exception;

    public abstract void onFailure(ErrorBean e);

    public abstract void onResponse(T response);
}