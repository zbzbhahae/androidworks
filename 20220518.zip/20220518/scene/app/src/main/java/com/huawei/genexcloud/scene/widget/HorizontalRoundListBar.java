package com.huawei.genexcloud.scene.widget;

/**
 * Created by zWX1094027 on 2021/9/26.
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 横向的文字 bar 数值 图表
 * 有显示最高5条和最低5条功能
 * DataSet为图表所接收的数据，或者文字list + double值 list
 * setData后会进行数值校验，排序。现只支持大于等于0的数值
 * 最高5条 最低5条的bar颜色需要自己设置 所有文字颜色 大小需要在类中硬编码
 * 暂未实现 自定义属性
 * 已知问题：value为0时，bar的左起始位置会向左移动
 * 实现高度自计算，宽度由view来控制
 * bar的宽度由最大数值 和 MAX_VALUE_LENGTH_PERCENTAGE控制，后者表示最大数值站可用bar宽度空间的百分比
 * 流程  设置数值-》requestLayout计算控件高度-》onDraw之前计算文字，bar的宽度-》onDraw
 */
public class HorizontalRoundListBar extends View {
    private final int COLOR_TEXT = 0xFF666666;
    private final int COLOR_VALUE = 0xFF999999;
    private final int COLOR_CHART_LARGE = 0xFF6FBAFF;//最大5条的图表默认颜色
    private final int COLOR_CHART_SMALL = 0xFFFF8672;//最小5条的图表默认颜色
    private final String MAX_LEFT_TEXT = "一二三四五六";  //用于计算左侧文字宽度的占位文字
    private final String MAX_RIGHT_VALUE_TEXT = "99.99%"; //用于计算右侧数值文字宽度的占位文字
    private Paint mValuePaint, mChartPaint;//数值画笔与图表画笔
    private TextPaint mTextPaint; // 文字画笔
    private List<DataSet> data; //图表支持的数据
    private final float mTextSize = sp2px(7);  //文字大小
    private final float mValueSize = sp2px(8);  //数值文字大小
    private final int mTextColor = COLOR_TEXT; //文字颜色
    private final int mValueColor = COLOR_VALUE; //数值文字颜色
    private final int mChartLargeColor = COLOR_CHART_LARGE;
    private final int mChartSmallColor = COLOR_CHART_SMALL;
    //bar的粗细
    private final float mChartSize = dp2px(8);
    //左侧文字的最大宽度
    private float mTextMaxWidth;
    //右侧数值文字的最大宽度
    private float mValueTextWidth;
    //图表最大宽度
    private float mMaxChartWidth;
    //图表和文字间的间距
    private final float spacing = dp2px(5);
    //每条数据之间的间距
    private final float dataSapcing = dp2px(4);

    private float width, height;

    private double mMaxValue = 0.00000001d;
    //最大值数据的图表占图表最大宽度的90%
    private final double MAX_VALUE_LENGTH_PERCENTAGE = 0.9d;

    //绘制最高，最低5条
    private boolean isDrawAll = false;

    // 图表顺序反向
    private boolean reverse = false;
    // 是否是百分比显示的数值
    private boolean isPercentageValue = false;

    private final DecimalFormat valueFormater = new DecimalFormat("#.##");
    private final DecimalFormat tinyValueFormater = new DecimalFormat("#.###");

    public HorizontalRoundListBar(Context context) {
        this(context, null);
    }

    public HorizontalRoundListBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HorizontalRoundListBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    /**
     * 内部调用，用于是否展示全部
     * 不改变数值类型和排序类型
     * @param data
     */
    private void setData(List<DataSet> data) {
        this.data = data;
        checkData(data);
        initValueLayout();
        requestLayout();
        invalidate();
    }

    public void setData(List<String> names, List<Double> values) {
        setData(names, values, false, false);
    }

    public void setData(List<String> names, List<Double> values, boolean reverse) {
        setData(names, values, false, reverse);
    }

    /**
     * 绑定数据
     * @param names 数据坐标list
     * @param values 数值list
     * @param isPercentageValue 是否显示%  0.1 = 10%
     * @param reverse 是否倒序展示
     */
    public void setData(List<String> names, List<Double> values, boolean isPercentageValue, boolean reverse) {
        this.reverse = reverse;
        this.isPercentageValue = isPercentageValue;
        this.data = wrappedToDataSet(names, values);
        checkData(data);
        initValueLayout();
        requestLayout();
        invalidate();
    }

    private List<DataSet> wrappedToDataSet(List<String> names, List<Double> values) {
        if (null == names || null == values || 0 == names.size() || 0 == values.size()
                || names.size() != values.size()) {
            return null;
        }
        List<DataSet> dataSets = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            DataSet d = new DataSet(names.get(i), values.get(i));
            dataSets.add(d);
        }

        return dataSets;
    }

    /**
     * 是否可以收起， 可见状态
     *
     * @return
     */
    public boolean canCollapse() {
        return getVisibility() == VISIBLE && null != data && isDrawAll && data.size() > 10;
    }

    /**
     * 设置数据  按数值大小从高到低排序
     *
     * @param data
     */
    private void checkData(List<DataSet> data) {
        if (null == data || data.size() == 0)
            return;
        Collections.sort(data); // 关于reverse 改动，负向指标只更改颜色相反，不用更改展示顺序
    }

    /**
     * 通过数值大小来获得数值文字
     *
     * @param value
     * @return 根据isPercentageValue返回数值文字
     */
    private String getValueText(double value) {
        if (isPercentageValue) {
            double percentageValue = value * 100;
            if (percentageValue < 0.01 && percentageValue >= 0.001) {
                return tinyValueFormater.format(percentageValue) + "%";
            } else if (percentageValue < 0.001 && 0 != percentageValue) {
                return "<0.001%";
            } else {
                return valueFormater.format(percentageValue) + "%";
            }
        } else {
            return valueFormater.format(value);
        }
    }

    public boolean getShowAll() {
        return isDrawAll;
    }

    /**
     * 是否展示所有数据
     *
     * @param showAll
     */
    public void setShowAll(boolean showAll) {
        isDrawAll = showAll;
        setData(data);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (null == data || data.size() == 0)
            return;
//        //初始化文字，图表
        initValueLayout();
        canvas.save();

        if (isDrawAll || data.size() < 10) { //如果需要画全部数据或者数据条目小于10条
            for (DataSet element : data) {
                drawSingleElement(element, canvas, true);
            }
        } else {//只画最高 最低5条
            for (int i = 0; i < 5; i++) {  // 关于reverse 改动，负向指标只更改颜色相反，不用更改展示顺序
                drawSingleElement(data.get(i), canvas, !reverse);
            }
            for (int i = data.size() - 5; i < data.size(); i++) {
                drawSingleElement(data.get(i), canvas, reverse);
            }
        }

        canvas.restore();
    }

    /**
     * 画单条数据
     *
     * @param data
     * @param canvas
     * @param isTop  是前5还是后5
     */
    private void drawSingleElement(DataSet data, Canvas canvas, boolean isTop) {
        if (isTop) {
            mChartPaint.setColor(COLOR_CHART_LARGE);
        } else {
            mChartPaint.setColor(COLOR_CHART_SMALL);
        }
        StaticLayout textLayout = new StaticLayout(data.name, mTextPaint, (int) (mTextMaxWidth + 0.5f),
                Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.0F, true);
        float leftTextHeight = textLayout.getHeight();
        float mBarWidth = 0;
        if (data.value < 0) {
            mBarWidth = 0;
        } else {
            mBarWidth = (float) (mMaxChartWidth * MAX_VALUE_LENGTH_PERCENTAGE * (data.value / mMaxValue + 0.01));
        }
        float mLineHeight = getLineHeight(data);
        float centerY = 0.5f * mLineHeight;
        Paint.FontMetricsInt valueFMI = mValuePaint.getFontMetricsInt();
        float valueBaseLine = (valueFMI.descent - valueFMI.ascent) * .5f - valueFMI.descent;
        // 将文字画在中间
        canvas.save();
        canvas.translate(0, (mLineHeight - leftTextHeight) * 0.5f);
        textLayout.draw(canvas);
        canvas.restore();

        if (-255 == data.value) {
            // 无效数据
            // 将行高设置为了3行高度 固定每个柱子的高度
            canvas.drawLine(mTextMaxWidth + spacing, centerY, mTextMaxWidth + mBarWidth + spacing, centerY, mChartPaint);
            canvas.drawText("无数据", mTextMaxWidth + mBarWidth + spacing * 2, centerY + valueBaseLine, mValuePaint);
        } else {
            // 将行高设置为了3行高度 固定每个柱子的高度
            canvas.drawLine(mTextMaxWidth + spacing, centerY, mTextMaxWidth + mBarWidth + spacing, centerY, mChartPaint);
            canvas.drawText(getValueText(data.value), mTextMaxWidth + mBarWidth + spacing * 2, centerY + valueBaseLine, mValuePaint);
        }
        canvas.translate(0, mLineHeight);
    }

    /**
     * 在画图前初始化文字，图表占位宽度 设置最大数据值
     */
    private void initValueLayout() {
        mTextMaxWidth = mTextPaint.measureText(MAX_LEFT_TEXT);
        mValueTextWidth = mValuePaint.measureText(MAX_RIGHT_VALUE_TEXT);
        mMaxChartWidth = width - 2f * spacing - mTextMaxWidth - mValueTextWidth;

        if (null == data || 0 == data.size())
            return;

        mMaxValue = 0.0000000001d;
        //获取图表数据最大值
        for (DataSet element : data) {
            mMaxValue = Math.max(mMaxValue, element.value);
        }
        if (0 == mMaxValue)
            mMaxValue = 0.01d;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 先调用super 以便在后续使用getMeasuredWidth时能获取值
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int barCount = null == data ? 0 : data.size();
        if ((heightMode == MeasureSpec.UNSPECIFIED || heightMode == MeasureSpec.AT_MOST) && barCount > 0) {

            //计算图表高度
            if (isDrawAll) {
                float heightSum = 0;
                if (barCount > 0) {
                    for (DataSet element : data) {
                        heightSum += getLineHeight(element);
                    }
                }
                setMeasuredDimension(getMeasuredWidth(), (int) heightSum);
            } else { //只画10个数据
                float heightSum = 0;
                if (barCount >= 10) {
                    for (int i = 0; i < 5; i++) {
                        heightSum += getLineHeight(data.get(i));

                    }
                    for (int i = data.size() - 1; i > data.size() - 6; i--) {
                        heightSum += getLineHeight(data.get(i));
                    }
                } else {
                    for (int i = 0; i < data.size(); i++) {
                        heightSum += getLineHeight(data.get(i));
                    }
                }
                setMeasuredDimension(getMeasuredWidth(), (int) heightSum);
            }
        } else {
            //什么都不做 让super处理
        }
    }

    /**
     * 获取数据对应的每条数据应占高度
     *
     * @param element
     * @return
     */
    private float getLineHeight(DataSet element) {
        // 为了使行高统一, 使用最长字符串3行来设置行高,避免行高不统一造成的图表密集程度不一的问题
        StaticLayout textLayout = new StaticLayout("一二三四五六七八九十十一十二", mTextPaint, (int) (mTextMaxWidth),
                Layout.Alignment.ALIGN_NORMAL, 1F, 0F, true);
        float leftTextHeight = textLayout.getHeight();
        float barHeight = mChartSize;
        float mLineHeight = Math.max(barHeight, leftTextHeight);
        return mLineHeight + dataSapcing;

    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            width = getWidth();
            height = getHeight();
        }
    }

    private void init() {
        mTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setTextSize(mTextSize);
        mTextPaint.setColor(mTextColor);

        mValuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mValuePaint.setTextSize(mValueSize);
        mValuePaint.setColor(mValueColor);

        mChartPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mChartPaint.setColor(mChartLargeColor);
        mChartPaint.setStrokeWidth(mChartSize);
    }

    private float dp2px(float dp) {
        return getResources().getDisplayMetrics().density * dp;
    }

    private float sp2px(float sp) {
        return getResources().getDisplayMetrics().scaledDensity * sp;
    }


    /**
     * 图表的数据bean
     */
    private class DataSet implements Comparable {
        public int id;
        public String name;
        public double value;

        public DataSet() {
        }

        public DataSet(int id, String name, double value) {
            this.id = id;
            this.name = name;
            this.value = value;
        }

        public DataSet(String name, double value) {
            this.name = name;
            this.value = value;
        }

        @Override
        public int compareTo(Object o) {
            DataSet target = (DataSet) o;
            int result = Double.compare(target.value, value);
            if (0 == result) {
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(target.name)) {
                    if (name.charAt(0) > target.name.charAt(0)) {
                        return -1;
                    } else if (name.charAt(0) == target.name.charAt(0)) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 0;
                }
            } else {
                return result;
            }
        }
    }


}