package com.huawei.genexcloud.scene.viewmodel;

import com.huawei.genexcloud.scene.utils.OperatorUtil;

/**
 * 保存用户选择的省份 城市 运营商等信息
 */
public class StatusBean {

    private String province;
    private String city;
    private String operator;

    public StatusBean() {
        province = "全国";
        city = "全国";
        operator = "移动";
    }

    /**
     * 用户参数是全国界面否
     * @return
     */
    public boolean isNationStatus() {
        if ("全国".equals(city) && "全国".equals(province)) {
            return true;
        }
        return false;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = OperatorUtil.getOperatorCNName(operator);
    }
}
