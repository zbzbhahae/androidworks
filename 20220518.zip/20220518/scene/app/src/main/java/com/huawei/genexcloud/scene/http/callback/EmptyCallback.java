package com.huawei.genexcloud.scene.http.callback;

import androidx.annotation.NonNull;

import com.huawei.genexcloud.scene.http.util.ErrorBean;
import com.huawei.genexcloud.scene.http.util.GCCallback;

public class EmptyCallback extends GCCallback {
    @Override
    public void onFailure(ErrorBean e) {

    }

    @Override
    public void onResponse(Object response) {

    }

    @Override
    public Object parseNetworkResponse(@NonNull String response) throws Exception {
        return null;
    }
}
