package com.huawei.genexcloud.scene.ui.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.huawei.genexcloud.scene.R;
import com.huawei.genexcloud.scene.common.Constants;
import com.huawei.genexcloud.scene.http.util.CommonProvider;
import com.huawei.genexcloud.scene.provider.IPCUtils;
import com.huawei.genexcloud.scene.provider.CommonProviderUtils;
import com.huawei.genexcloud.scene.widget.LoadingDialog;
import com.huawei.genexcloud.scene.widget.WatermarkView;

/**
 * Created by zWX1094027 on 2021/10/22.
 */

public class BaseFragmentActivity extends AppCompatActivity {


    protected String account;
    private boolean addedWatermark = false;
    private ClosingBroadCast mClosingBroadCast;

    private Fragment currentFragment;
    private int loadingDialogCounter;
    private LoadingDialog loadingDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme);

        initWindow();
        trackFragmentBackStack();

        // 从contentprovider中获取登录的账号信息
        account = CommonProviderUtils.queryByKey(this, CommonProvider.GenexCloudColumns.USERID).getName();
        if (TextUtils.isEmpty(account)) {//如果没有账号信息 则设置为默认值 genexCloud
            account = "genexCloud";
        }

        registerClosingReceiver();
    }

    private void initWindow() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            View view = getWindow().getDecorView();
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | view.getSystemUiVisibility());
        }
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

    }

    @Override
    protected void onStart() {
        super.onStart();
        addWaterMark(account); // 在设置过contentView之后调用添加水印的方法
    }

    @Override
    protected void onDestroy() {
        unregisterClosingReceiver();
        super.onDestroy();
    }

    /**
     * 给页面添加水印
     */
    private void addWaterMark(String account) {
        boolean isAddedWater = IPCUtils.getIsAddedWater(getApplicationContext());
        if (isAddedWater && !addedWatermark) {
            addedWatermark = true;
            ViewGroup rootView = findViewById(android.R.id.content);
            WatermarkView watermarkView = new WatermarkView(this);
            ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            watermarkView.setLayoutParams(params);
            watermarkView.setAccount(account);
            rootView.addView(watermarkView);
        }
    }


    /**
     * 注册登录过期结束自己的广播
     */
    private void registerClosingReceiver() {
        if (null == mClosingBroadCast) {
            mClosingBroadCast = new ClosingBroadCast();
        }
        registerReceiver(mClosingBroadCast, new IntentFilter(Constants.EXPIRE_COOKIE), Constants.PERMISSION_BROADCAST, null);
    }

    /**
     * 取消注册广播
     */
    private void unregisterClosingReceiver() {
        if (null != mClosingBroadCast) {
            unregisterReceiver(mClosingBroadCast);
            mClosingBroadCast = null;
        }
    }

    /**
     * 查找控件
     */
    protected <T extends View> T find(int resId) {
        return findViewById(resId);
    }

    /**
     * 接收Cookie过期广播，结束插件进程
     */
    class ClosingBroadCast extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Constants.EXPIRE_COOKIE.equals(action)) {
                finish(); // 收到登录过期的广播后,结束自己
            }
        }
    }

    protected int getFragmentContainerId() {
        throw new AndroidRuntimeException("Override this method, return fragment container layout resouce id please");
    }

    public String getCurrentFragmentTag() {
        if (currentFragment == null) {
            return "current fragment name (unknown)";
        }

        return currentFragment.getClass().getCanonicalName();
    }

    public void switchTo(Fragment target) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(getFragmentContainerId(), target, target.getClass().getCanonicalName());
        ft.setCustomAnimations(0, 0, 0, 0);
        ft.commitAllowingStateLoss();
        currentFragment = target;
    }

    public void push(Fragment next) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left,
                R.anim.slide_in_left, R.anim.slide_out_right);
        ft.add(getFragmentContainerId(), next, next.getClass().getCanonicalName())
                .hide(currentFragment)
                .addToBackStack(currentFragment.getClass().getCanonicalName());
        ft.commitAllowingStateLoss();
        currentFragment = next;
    }

    private void trackFragmentBackStack() {
        getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                FragmentManager fm = getSupportFragmentManager();
                Fragment fragment = fm.findFragmentById(getFragmentContainerId());
                if (fragment != null) {
                    currentFragment = fragment;
                }
            }
        });
    }

    public void pushShareEle(Fragment next, View... views) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        for (View view: views) {
            String transitionName = ViewCompat.getTransitionName(view);
            if (transitionName != null) {
                ft.addSharedElement(view, transitionName);
            }
        }
        ft.replace(getFragmentContainerId(), next)
                .addToBackStack(currentFragment.getClass().getCanonicalName());
        ft.commitAllowingStateLoss();
        currentFragment = next;
    }

    public void showLoadingDialog() {
        synchronized (BaseActivity.class) {
            ++loadingDialogCounter;
            if (loadingDialogCounter > 1) {
                return;
            }
        }

        if (loadingDialog == null) {
            loadingDialog = new LoadingDialog(this);
        }
        if (loadingDialog.isShowing()) {
            return;
        }
        loadingDialog.show();
    }

    public void dismissLoadingDialog() {
        synchronized (BaseActivity.class) {
            if (loadingDialogCounter > 0) {
                --loadingDialogCounter;
            }
            if (loadingDialogCounter == 0 && loadingDialog != null) {
                loadingDialog.dismiss();
            }
        }
    }
}
