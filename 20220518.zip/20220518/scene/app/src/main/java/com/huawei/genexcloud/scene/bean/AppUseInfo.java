package com.huawei.genexcloud.scene.bean;

import java.io.Serializable;

/**
 * 应用使用情况
 *
 * @author lWX348305
 */
public class AppUseInfo implements Serializable {

    private static final long serialVersionUID = 1425474982534762265L;
    private String pageId;

    private String eventId;

    private String account;

    private String parameter;

    private String netOper;

    private double longitude;

    private double latitude;

    private String appVer;

    private String systemVersion;

    private String model;

    private String imei;

    private String exceptionLog;

    private String exceptionTime;
    private String city;

    public String getCity() {
        return city == null ? "" : city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPageId() {
        return pageId == null ? "" : pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }

    public String getEventId() {
        return eventId == null ? "" : eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getAccount() {
        return account == null ? "" : account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getParameter() {
        return parameter == null ? "" : parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getNetOper() {
        return netOper == null ? "" : netOper;
    }

    public void setNetOper(String netOper) {
        this.netOper = netOper;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public String getAppVer() {
        return appVer == null ? "" : appVer;
    }

    public void setAppVer(String appVer) {
        this.appVer = appVer;
    }

    public String getSystemVersion() {
        return systemVersion == null ? "" : systemVersion;
    }

    public void setSystemVersion(String systemVersion) {
        this.systemVersion = systemVersion;
    }

    public String getModel() {
        return model == null ? "" : model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getImei() {
        return imei == null ? "" : imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getExceptionLog() {
        return exceptionLog == null ? "" : exceptionLog;
    }

    public void setExceptionLog(String exceptionLog) {
        this.exceptionLog = exceptionLog;
    }

    public String getExceptionTime() {
        return exceptionTime == null ? "" : exceptionTime;
    }

    public void setExceptionTime(String exceptionTime) {
        this.exceptionTime = exceptionTime;
    }

}
