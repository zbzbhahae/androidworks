package com.huawei.genexcloud.scene.http.callback;

import android.text.TextUtils;

import com.huawei.genexcloud.scene.bean.ResultBean;
import com.huawei.genexcloud.scene.bean.SceneIndicatorBean;
import com.huawei.genexcloud.scene.http.util.GCCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 解析场景数据内容
 * 有点长，大致流程： 1.解析场景中的指标关系，获取指标中文、英文名称和是否正向指标等
 * 2. 获取某一个场景具体json，然后使用该数据过滤 指标关系列表数据中多余的真值表信息
 * 3. 通过指标关系列表获取一个中文指标名称的list 用于用户切换指标
 * 4. 用过指标关系列表数据，将用户的场景数据一条一条解析出来
 */
public abstract class SceneCallback extends GCCallback<ResultBean> {

    @Override
    public ResultBean parseNetworkResponse(String responseStr) throws Exception {
        List<ResultBean> list = new ArrayList<>();
        JSONObject jsonAll = new JSONObject(responseStr);

        JSONArray jsonArray = jsonAll.optJSONArray("JsonData");
        ResultBean sceneData = new ResultBean();
        if (jsonArray.length() > 0) {

            // 场景分析中指标的名称与key对应关系
            List<SceneIndicatorBean> indicatorRelationList = null;
//            //场景指标的具体项名称,占单独一个数组,在遍历数组之前创建
            List<String> scenesIndicatorNames = new ArrayList<String>();

            boolean isIndicatorRelationSorted = false;
            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject jsonObject = jsonArray.optJSONObject(i);

                // 获取场景指标具体内容 指标的名称 单位 对应的英文字段等
                if (jsonObject.has("newCounterName")) {
                    // 解析指标名称数值关系内容 { "counterNameCN": "VoLTE上行丢包率","counterNameEN": "voLTEUpHighLoseRate","positive": 0,"unit": "%"}
                    indicatorRelationList = parseSceneIndicatorRelation(jsonObject.optJSONArray("newCounterName"));
                    continue;// 这个json数组元素只有单独的场景指标名称列表,不需要解析其他内容
                }

                // 获取场景分析的描述信息  只有全国状态下才有描述信息
                if (jsonObject.has("description")) {
                    sceneData.setScenesDesc(jsonObject.optString("description"));
                }

                //场景具体数据
                if (jsonObject.has("scenario")) {
                    //解析指标数据列表
                    JSONArray scenesDataArray = jsonObject.optJSONArray("scenario");
                    if (null != scenesDataArray && scenesDataArray.length() > 0) {
                        List<ResultBean.ScenesBean> scenesBeanList = new ArrayList<>();
                        for (int j = 0; j < scenesDataArray.length(); j++) {
                            // 对指标关系列表进行过滤，因为要拿关系列表去一条一条解析对应场景的数据，要将场景中不存在的指标从关系表中过滤除去
                            if (!isIndicatorRelationSorted) {
                                // 是否对指标关系进行过 过滤和排序，后面的场景bean需要根据指标关系来解析数据以及排列数据
                                JSONObject objectToSortIndicator = scenesDataArray.optJSONObject(0);
                                // 对指标关系进行排序
                                indicatorRelationList = indicatorRelationfilter(indicatorRelationList, objectToSortIndicator);

                                // 指标关系过滤排序后，需要解析指标列，以供用户切换指标时显示
                                if (null != indicatorRelationList && indicatorRelationList.size() > 0) {
                                    for (SceneIndicatorBean item : indicatorRelationList) {
                                        scenesIndicatorNames.add(item.cnName);
                                    }
                                }

                                isIndicatorRelationSorted = true;
                            }
                            // 通过指标关系列表数据，解析场景具体数据
                            ResultBean.ScenesBean scenesBean = parseIndicatorByRelation(scenesDataArray.optJSONObject(j), indicatorRelationList);
                            // 解析的内容 名称 场景名称和城市不能为空 否则为无效数据
                            if (null != scenesBean) {
                                scenesBeanList.add(scenesBean);
                            }

                            //读取指标批次信息
                            JSONArray batchArray = jsonObject.optJSONArray("batchList");//下标名称数组
                            if (null != batchArray && batchArray.length() > 0) {
                                List<String> batchList = new ArrayList<String>();
                                for (int k = 0; k < batchArray.length(); k++) {//解析下标文字列表
                                    String singleBatch = batchArray.optString(k);
                                    if (singleBatch.length() > 0) {//一个非空的batch
                                        batchList.add(singleBatch);
                                    }
                                }
                                sceneData.setBatchList(batchList);
                            }
                        }
                        sceneData.setScenesData(scenesBeanList);
                    }
                }

                // 场景分析部分
                if (jsonObject.has("scenario") && jsonObject.has("scenarioList")) {
                    JSONArray scenesTypeArray = jsonObject.optJSONArray("scenarioList");
                    if (null != scenesTypeArray && scenesTypeArray.length() > 0) {
                        List<String> scenesTypeNames = new ArrayList<String>();
                        for (int j = 0; j < scenesTypeArray.length(); j++) {
                            String scenesTypeName = scenesTypeArray.optString(j);
                            scenesTypeNames.add(scenesTypeName);
                        }
                        //设置场景可选择列表和场景具体指标名称  指标名称在整个json数组数据的第一条
                        //此时设置能够获取
                        sceneData.setScenesTypeNames(scenesTypeNames);
                        sceneData.setScenesIndicatorNames(scenesIndicatorNames);
                    }
                }

                //设置运营商姓名
                sceneData.setOperator(jsonObject.optString("operator"));
            }
        }
        return sceneData;
    }

    /**
     * 将指标关系列表 根据 具体每个场景的json数据排列
     *
     * @param indicatorRelations
     * @param objectForSort
     * @return
     */
    private List<SceneIndicatorBean> indicatorRelationfilter(List<SceneIndicatorBean> indicatorRelations, JSONObject objectForSort) {
        if (null == indicatorRelations || 0 == indicatorRelations.size() || null == objectForSort) {
            return null;
        }
        List<SceneIndicatorBean> sortedList = new ArrayList<>();
        Iterator<String> iterator = objectForSort.keys();
        while (iterator.hasNext()) {
            String key = iterator.next();
            for (SceneIndicatorBean item : indicatorRelations) {
                if (key.equals(item.enName)) {
                    sortedList.add(item);
                }
            }
        }

        return sortedList;
    }

    /**
     * 解析场景指标名称和指标在json中的对应英文名等关系
     *
     * @return
     */
    private List<SceneIndicatorBean> parseSceneIndicatorRelation(JSONArray array) {
        if (null == array || 0 == array.length()) {
            return null;
        }
        List<SceneIndicatorBean> indicatorBeans = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject itemJson = array.optJSONObject(i);
            SceneIndicatorBean indicator = new SceneIndicatorBean();
            indicator.cnName = itemJson.optString("counterNameCN");
            indicator.enName = itemJson.optString("counterNameEN");
            indicator.isPositive = "1".equals(itemJson.optString("positive"));
            indicator.unit = itemJson.optString("unit");
            if (!TextUtils.isEmpty(indicator.cnName) && !TextUtils.isEmpty(indicator.enName)) {
                indicatorBeans.add(indicator);
            }
        }
        return indicatorBeans;
    }

    /**
     * 根据 场景指标的关系内容，将场景解析城单个数据
     *
     * @param object
     * @param relations
     * @return
     */
    private ResultBean.ScenesBean parseIndicatorByRelation(JSONObject object, List<SceneIndicatorBean> relations) {
        if (null == relations || 0 == relations.size() || null == object) {
            return null;
        }
        ResultBean.ScenesBean bean = new ResultBean.ScenesBean();
        bean.setCity(object.optString("city"));
        bean.setScenesType(object.optString("scenario"));
        bean.setScenesLocaleName(object.optString("scenarioName"));
        bean.setIndicators(new ArrayList<>());
        for (SceneIndicatorBean indicator : relations) {
            if (object.has(indicator.enName)) {
                SceneIndicatorBean sib = new SceneIndicatorBean();
                sib.enName = indicator.enName;
                sib.cnName = indicator.cnName;
                sib.isPositive = indicator.isPositive;
                sib.unit = indicator.unit;
                sib.value = object.optDouble(indicator.enName, -255);
                if (Double.isNaN(sib.value) || Double.isInfinite(sib.value) || sib.value < 0) {
                    sib.value = -255;
                }
                bean.getIndicators().add(sib);
                bean.setIndicatorRelations(relations);
            }
        }
        if (!TextUtils.isEmpty(bean.getCity()) && !TextUtils.isEmpty(bean.getScenesType())
                && !TextUtils.isEmpty(bean.getScenesLocaleName()) && bean.getIndicators().size() > 0) {
            return bean;
        }
        return null;
    }
}
