package com.huawei.genexcloud.scene.bean;

/**
 * Created by zWX1094027 on 2021/9/8.
 * <p>
 * 用于保存主页选择的省份,城市和运营商信息
 */

public class LocOptBean {

    public static final String OPT_NAME_CMCC = "移动";
    public static final String OPT_NAME_CUTC = "联通";
    public static final String OPT_NAME_CNTC = "电信";


    //选择的位置信息类型 全国 省 市
    public static final int LOC_TYPE_NATION = 0;
    public static final int LOC_TYPE_PROVINCE = 1;
    public static final int LOC_TYPE_CITY = 2;
}
