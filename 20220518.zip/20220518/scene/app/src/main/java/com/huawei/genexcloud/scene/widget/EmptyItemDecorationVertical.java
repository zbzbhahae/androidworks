package com.huawei.genexcloud.scene.widget;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EmptyItemDecorationVertical extends RecyclerView.ItemDecoration {

    private int verticalSpace = 0;

    public EmptyItemDecorationVertical(Context context, int dp) {
        verticalSpace = (int) dp2px(context, dp);
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        outRect.set(0, 0, 0, verticalSpace);
    }

    private float dp2px(Context context, float dp) {
        return context.getResources().getDisplayMetrics().density * dp;
    }

}
