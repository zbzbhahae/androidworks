package com.huawei.genexcloud.scene.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.genexcloud.scene.R;

import java.util.List;

/**
 * 选择省份城市的adapter
 */
public class GridProvinceAdapter extends RecyclerView.Adapter<GridProvinceAdapter.ViewHolder> {

    // 选中和非选中的文字颜色
    private final int normalColor = 0xFF999999, selectColor = 0xFFFFFFFF;

    private List<String> data;
    private OnItemClickListener listener;
    private String selectedContent;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setSelectedContent(String content) {
        this.selectedContent = content;
        notifyDataSetChanged();
    }

    public void setData(List<String> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_province_city, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String content = data.get(position);
        holder.content.setText(content);
        if (null != selectedContent && selectedContent.equals(content)) {
            holder.content.setTextColor(selectColor);;
            holder.content.setSelected(true);
        } else {
            holder.content.setTextColor(normalColor);;
            holder.content.setSelected(false);
        }
        holder.itemView.setOnClickListener(v-> {
            if (null != listener) {
                listener.onClick(content);
            }
        });
    }

    @Override
    public int getItemCount() {
        return null == data? 0 : data.size();
    }

    protected class ViewHolder extends RecyclerView.ViewHolder {
        private TextView content;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            content = itemView.findViewById(R.id.item_province_city_content);
        }
    }

    public interface OnItemClickListener {
        void onClick(String content);
    }
}
