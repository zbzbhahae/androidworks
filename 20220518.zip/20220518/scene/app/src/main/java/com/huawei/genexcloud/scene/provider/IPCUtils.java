package com.huawei.genexcloud.scene.provider;

import android.content.ClipboardManager;
import android.content.Context;

/**
 * 进程间数据存储共享 Created by lWX348305 on 2017/4/24.
 */

public class IPCUtils {

    /**
     * 获取数据(适合一次性存储使用)
     *
     * @param context
     * @return
     */
    public static String getData(Context context) {
        ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboardManager != null && clipboardManager.getText() != null) {
            return clipboardManager.getText().toString();
        } else {
            return "";
        }
    }

    /**
     * 获取数据从共享数据库
     *
     * @param context
     * @return
     */
    public static String getDataToDB(Context context, String key) {
        return CommonProviderUtils.queryByKey(context, key).getName();
    }

    /**
     * 获取是否添加水印
     */
    public static boolean getIsAddedWater(Context context) {
        boolean isAddedWater = true;

        PublicShareDataBean shareDataBean = CommonProviderUtils.queryByKey(context, "isAddedWater");
        if (shareDataBean != null) {
            if ("true".equals(shareDataBean.getName())) {
                isAddedWater = true;
            } else {
                isAddedWater = false;
            }
        }
        return isAddedWater;
    }
}
