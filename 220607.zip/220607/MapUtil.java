package com.huawei.genexcloud.main.sencemap.util;


import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.huawei.BaseApplication;
import com.huawei.genexcloud.R;

public class MapUtil {


    /**
     * 初始化百度地图
     * @param mMapView 百度地图view
     * @param mapLoadedCallback 地图加载完毕回调
     * @param onMapStatusChangeListener 地图状态改变回调
     * @param onMapClickListener 地图点击回调
     * @param onMarkerClickListener 地图marker点击回调
     */
    public static void initBaiduMap(MapView mMapView, BaiduMap.OnMapLoadedCallback mapLoadedCallback,
                                    BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener,
                                    BaiduMap.OnMapClickListener onMapClickListener,
                                    BaiduMap.OnMarkerClickListener onMarkerClickListener) {
        BaiduMap mBaiduMap = mMapView.getMap();
        mMapView.removeViewAt(1);// 去掉百度logo
        mMapView.showZoomControls(false);// 去掉屏幕缩放比例尺控制器
        mMapView.showScaleControl(false);// 去掉比例尺
        mMapView.setMapCustomStylePath(BaseApplication.getCustomPtah());
        mMapView.setMapCustomStyleEnable(true);
        // 此处初始化地图
        mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
        mBaiduMap.setMaxAndMinZoomLevel(21.0f, 3.5f);
        mBaiduMap.setMyLocationEnabled(true);
        mBaiduMap.setMyLocationConfiguration(new MyLocationConfiguration(
                MyLocationConfiguration.LocationMode.FOLLOWING,
                true,
                BitmapDescriptorFactory.fromResource(R.drawable.mark_navi_locate)));
        // 设置是否显示室内图, 默认室内图不显示
        mBaiduMap.setIndoorEnable(false);
        // 设置建筑物模式开启
        mBaiduMap.setBuildingsEnabled(false);
        // 设置交通模式
        mBaiduMap.setTrafficEnabled(false);
        // 设置手势
        mBaiduMap.getUiSettings().setAllGesturesEnabled(true);
        // 设置是否允许指南针，默认允许。
        mBaiduMap.getUiSettings().setCompassEnabled(false);
        // 设置是否允许旋转手势，默认允许
        mBaiduMap.getUiSettings().setRotateGesturesEnabled(false);
        // 设置是否允许俯视手势，默认允许
        mBaiduMap.getUiSettings().setOverlookingGesturesEnabled(false);
        // 设置地图初始化完成回调
        mBaiduMap.setOnMapLoadedCallback(mapLoadedCallback);
        // 设置地图改变回调
        mBaiduMap.setOnMapStatusChangeListener(onMapStatusChangeListener);
        // 地图点击事件
        mBaiduMap.setOnMapClickListener(onMapClickListener);

        // 地图marker的点击事件
        mBaiduMap.setOnMarkerClickListener(onMarkerClickListener);
    }
}
