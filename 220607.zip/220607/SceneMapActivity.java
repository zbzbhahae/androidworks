package com.huawei.genexcloud.main.sencemap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.district.DistrictResult;
import com.baidu.mapapi.search.district.DistrictSearch;
import com.baidu.mapapi.search.district.DistrictSearchOption;
import com.baidu.mapapi.search.district.OnGetDistricSearchResultListener;
import com.huawei.framework.utils.AppUtil;
import com.huawei.framework.utils.SystemUIUtil;
import com.huawei.genexcloud.BaseActivity;
import com.huawei.genexcloud.R;
import com.huawei.genexcloud.databinding.ActivitySceneMapBinding;
import com.huawei.genexcloud.main.sencemap.util.MapUtil;

import java.util.List;

public class SceneMapActivity extends BaseActivity implements View.OnClickListener {

    private ActivitySceneMapBinding binding;
    // 是否有npo权限
    private boolean hasNopLimit = false;
    // 我也不知道是啥
    private boolean hasDiffLimit = false;
    // 也不知道是啥
    private int openTag = -1;

    // 运营商网络类型
    private final String TYPE_4G = "4G";
    private final String TYPE_5G = "5G";
    private String mNetType = TYPE_4G;

    private BaiduMap mBaiduMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initIntentTrance();
        // 设置窗口无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        SystemUIUtil.fullScreenNotStatuBar(this);

        binding = ActivitySceneMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initView();
    }

    /**
     * 处理传入的intent的数据
     */
    public void initIntentTrance() {
        Intent intent = getIntent();
        if (intent != null) {
            //跨进程传入的数据
            hasNopLimit = intent.getBooleanExtra("hasNpo", false);//通过6 控制  或npo
            hasDiffLimit = intent.getBooleanExtra("hasDiff", false);  //通过1 控制
            openTag = intent.getIntExtra("openTag", -1);
        }
    }

    @Override
    public void initView() {
        MapUtil.initBaiduMap(binding.baiduMap, onMapLoadedCallback,
                onMapStatusChangeListener, onMapClickListener, onMarkerClickListener);
        mBaiduMap = binding.baiduMap.getMap();
        binding.operatorTypeImage.setOnClickListener(this);
    }

    /**
     * 点击事件
     * @param v
     */
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.operatorTypeImage) {
            // 点击了4G 5G选项
            if (TYPE_4G.equals(mNetType)) {
                mNetType = TYPE_5G;
                binding.operatorTypeImage.setImageResource(R.drawable.icon_5g);
            } else {
                mNetType = TYPE_4G;
                binding.operatorTypeImage.setImageResource(R.drawable.icon_4g);
            }
            // 网络类型改变 去更新数据或界面
            onNetTypeChanged();
//        } else if (v == binding.indoorLayout) {

        }
    }
    /** 地图加载完毕事件 **/
    private BaiduMap.OnMapLoadedCallback onMapLoadedCallback = new BaiduMap.OnMapLoadedCallback() {
        @Override
        public void onMapLoaded() {

        }
    };
    /** 地图状态改变事件 **/
    private BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener = new BaiduMap.OnMapStatusChangeListener() {
        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus) {

        }

        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus, int i) {

        }

        @Override
        public void onMapStatusChange(MapStatus mapStatus) {

        }

        @Override
        public void onMapStatusChangeFinish(MapStatus mapStatus) {

        }
    };
    /** 地图点击事件 **/
    private BaiduMap.OnMapClickListener onMapClickListener = new BaiduMap.OnMapClickListener() {
        @Override
        public void onMapClick(LatLng latLng) {

        }

        @Override
        public void onMapPoiClick(MapPoi mapPoi) {

        }
    };
    /** 地图上marker点击事件 **/
    private BaiduMap.OnMarkerClickListener onMarkerClickListener = new BaiduMap.OnMarkerClickListener() {
        @Override
        public boolean onMarkerClick(Marker marker) {
            return false;
        }
    };

    /**
     * 网络类型改变 由4G->5G 或者 5G->4G 改变后会调用此方法
     */
    private void onNetTypeChanged() {
        DistrictSearch districtSearch = DistrictSearch.newInstance();
        DistrictSearchOption option = new DistrictSearchOption();
        option.mCityName = "北京市";
        option.mDistrictName = "海淀";
        districtSearch.setOnDistrictSearchListener(new OnGetDistricSearchResultListener() {
            @Override
            public void onGetDistrictResult(DistrictResult districtResult) {
                mBaiduMap.clear();
                if (districtResult == null) {
                    return;
                }
                if (districtResult.error == SearchResult.ERRORNO.NO_ERROR) {
                    List<List<LatLng>> polyLines = districtResult.getPolylines();
                    if (polyLines == null) {
                        return;
                    }
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    for (List<LatLng> polyline : polyLines) {
                        OverlayOptions ooPolyline = new PolylineOptions().width(10).points(polyline).dottedLine(true).color(0xAA00FF00);
                        mBaiduMap.addOverlay(ooPolyline);
                        OverlayOptions ooPolygon = new PolygonOptions().points(polyline).stroke(new Stroke(5, 0xAA00FF88))
                                .fillColor(0xAAFFFF00);
                        mBaiduMap.addOverlay(ooPolygon);
                        for (LatLng latLng : polyline) {
                            builder.include(latLng);
                        }
                    }
                    mBaiduMap.setMapStatus(MapStatusUpdateFactory.newLatLngBounds(builder.build()));
                }
            }
        });
        districtSearch.searchDistrict(option);
    }
}
