package com.huawei.down.logger;

public class Module {
    public final static String GENEX_CLOUD = "GENEX_CLOUD";
    public final static String CRASH_HANDLE = "CRASH_HANDLE";
}
