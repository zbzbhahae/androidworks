package com.huawei.down.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.down.R;
import com.huawei.down.bean.Plugin;
import com.huawei.down.download.DownloadEntry;
import com.huawei.down.download.DownloadManager;
import com.huawei.down.download.DownloadState;
import com.jeremyliao.liveeventbus.LiveEventBus;

import java.text.DecimalFormat;
import java.util.List;

public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {

    private List<Plugin> data;

    public void setData(List<Plugin> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_download, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Plugin p = data.get(position);
        DownloadEntry e = p.getDownloadEntry();
        LiveEventBus.get(DownloadEntry.class).observeForever(new Observer<DownloadEntry>() {
            @Override
            public void onChanged(DownloadEntry entry) {
                if (e.getUrl().equals(entry.getUrl())) {
                    setView(holder, entry);
                }
            }
        });
        setView(holder, e);

    }

    private void setView(ViewHolder holder, DownloadEntry e) {
        switch (e.getState()) {
            case DownloadState.STATE_WAIT:
                holder.button.setOnClickListener(null);
                holder.button.setText("连接中");
                holder.progressBar.setIndeterminate(true);
                holder.text.setText("连接中");
                break;
            case DownloadState.STATE_DOWNLOADING:
                holder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DownloadManager.getInstance().cancel(e.getUrl());
                    }
                });
                holder.button.setText("取消下载");
                holder.progressBar.setIndeterminate(false);
                holder.progressBar.setMax((int) e.getLength());
                holder.progressBar.setProgress((int) e.getCurrentLength());
                holder.text.setText("下载中 " + getProgressString(e));
                break;
            case DownloadState.STATE_FAILED:
                holder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DownloadManager.getInstance().download(e);
                    }
                });
                holder.button.setText("重新下载");
                holder.progressBar.setIndeterminate(false);
                holder.text.setText("下载失败");
                break;
            case DownloadState.STATE_IDLE:
                holder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DownloadManager.getInstance().download(e);
                    }
                });
                holder.button.setText("下载");
                holder.progressBar.setIndeterminate(false);
                holder.text.setText("等待下载");
                break;
            case DownloadState.STATE_SUCCESS:
                holder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });
                holder.button.setText("安装");
                holder.progressBar.setIndeterminate(true);
                holder.text.setText("下载完成");
                break;
        }
    }

    private DecimalFormat df = new DecimalFormat("#.##");
    private String getProgressString(DownloadEntry entry) {
        if (null == entry || entry.getLength() <= 0) {
            return "";
        }
        float progress = entry.getCurrentLength() * 1f / entry.getLength();
        return df.format(progress * 100) + "%";
    }

    @Override
    public int getItemCount() {
        return null == data ? 0 : data.size();
    }

    protected static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView text;
        private ProgressBar progressBar;
        private Button button;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.text);
            progressBar = itemView.findViewById(R.id.progressbar);
            button = itemView.findViewById(R.id.button);
        }
    }
}
