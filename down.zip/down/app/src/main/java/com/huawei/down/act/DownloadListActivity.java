package com.huawei.down.act;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.down.R;
import com.huawei.down.adapter.DownloadAdapter;
import com.huawei.down.bean.Plugin;

import java.util.ArrayList;
import java.util.List;

public class DownloadListActivity extends AppCompatActivity {

    private List<Plugin> data;
    private RecyclerView list;
    private DownloadAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_list);

        initView();
        initData();
    }

    private void initView() {
        list = findViewById(R.id.list);
        adapter = new DownloadAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
    }
    private void initData() {
        data = new ArrayList<>();
        data.add(new Plugin("https://d.douyuba.cn/wsd-pkg-div/2022/04/12/Douyu_7.2.6.110726101_market.apk", "110726101_market.apk"));
        data.add(new Plugin("https://mcloud-uat.huawei.com/mcloud/umag/fg/FreeProxyForDownLoad/speedtest_mag/file/downloadFile?path=/root/downloadApp/GenexCloudApp.apk", "GenexCloudApp.apk"));
        data.add(new Plugin("https://mcloud-uat.huawei.com/mcloud/umag/fg/FreeProxyForDownLoad/speedtest_mag/file/downloadFile?path=/root/downloadApp/Disturb.apk", "Disturb.apk"));
        data.add(new Plugin("https://mcloud-uat.huawei.com/mcloud/umag/fg/FreeProxyForDownLoad/speedtest_mag/file/downloadFile?path=/root/downloadApp/SurveyApp_Release.apk", "SurveyApp_Release.apk"));
        data.add(new Plugin("https://mcloud-uat.huawei.com/mcloud/umag/fg/FreeProxyForDownLoad/speedtest_mag/file/downloadFile?path=/root/downloadApp/phu_rf_survey.apk", "phu_rf_survey.apk"));
        data.add(new Plugin("https://serviceboxpub-drcn.dbankcdn.com/servicebox/6A4BC4DEA60439B53A9AEAF109DEEE59.apk", "6A4BC4DEA60439B53A9AEAF109DEEE59.apk"));
        adapter.setData(data);
    }
}
