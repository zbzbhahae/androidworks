package com.huawei.down.download;

import android.text.TextUtils;

import com.huawei.down.App;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.jeremyliao.liveeventbus.core.LiveEvent;

import java.io.File;

public class DownloadEntry implements LiveEvent {
    private long length;
    private String url;
    private String fileName;
    private String path;
    private long currentLength;
    private int mState = DownloadState.STATE_IDLE;

    public DownloadEntry(String url, String fileName, String path) {
        if (TextUtils.isEmpty(path)) {
            path = App.getContext().getExternalCacheDir().getAbsolutePath() + File.separator + fileName;
        }
        this.url = url;
        this.path = path;
        this.fileName = fileName;
    }

    public DownloadEntry(String url, String fileName) {
        this(url, fileName, null);
    }

    public DownloadEntry(String url) {
        this(url, MD5Util.getMD5(url), null);
    }

    public long getLength() {
        return length;
    }

    public void setLength(long length) {
        this.length = length;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public long getCurrentLength() {
        return currentLength;
    }

    public void setCurrentLength(long currentLength) {
        this.currentLength = currentLength;
    }

    public int getState() {
        return mState;
    }

    public void setState(int mState) {
        this.mState = mState;
    }


    @Override
    public String toString() {
        return "DownloadEntry{" +
                "length=" + length +
                ", url='" + url + '\'' +
                ", fileName='" + fileName + '\'' +
                ", path='" + path + '\'' +
                ", currentLength=" + currentLength +
                ", mState=" + mState +
                '}';
    }

    /**********************************发送通知事件***************************/
    public void onWait() {
        setState(DownloadState.STATE_WAIT);
        post();
    }
    public void onDownload(long contentLength, long currentLength) {
        if (!canPost()) {
            return;
        }
        setState(DownloadState.STATE_DOWNLOADING);
        setLength(contentLength);
        setCurrentLength(currentLength);
        post();
    }
    private long lastPostTime = 0;

    /**
     * 控制发送事件的间隔
     * @return
     */
    private boolean canPost() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastPostTime > 300) {
            lastPostTime = currentTime;
            return true;
        }
        return false;
    }

    public void onDownloadSuccess() {
        setState(DownloadState.STATE_SUCCESS);
        post();
    }

    public void onFailed() {
        setState(DownloadState.STATE_FAILED);
        post();
    }

    private void post() {
        LiveEventBus.get( DownloadEntry.class)
                .postOrderly(this);
    }

}
