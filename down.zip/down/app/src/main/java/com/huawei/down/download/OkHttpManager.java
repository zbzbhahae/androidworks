package com.huawei.down.download;

import android.content.Context;
import android.text.TextUtils;

import com.huawei.down.logger.GCLogger;
import com.huawei.down.logger.Module;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;


/**
 * Created by zWX1094027 on 2021/9/13.
 */

public class OkHttpManager {

    private static final int TIME_OUT_CONNECT = 30;
    private static final int TIME_OUT_READ = 30;
    private static final int TIME_OUT_WRITE = 30;


    private static volatile OkHttpClient client;
    private static volatile OkHttpClient imageClient;

    public static synchronized OkHttpClient initClient(Context context) {
        if (null == client) {
            synchronized (OkHttpManager.class) {
                if (null == client) {
                    String cacheDir = context.getCacheDir().getAbsolutePath();
                    String cachePath = cacheDir + "/okhttp/";
                    int maxCacheSize = 10 * 1024 * 1024; // 10M缓存大小
                    OkHttpClient.Builder builder = new OkHttpClient.Builder();
                    builder.connectTimeout(TIME_OUT_CONNECT, TimeUnit.SECONDS)
                            .readTimeout(TIME_OUT_READ, TimeUnit.SECONDS)
                            .writeTimeout(TIME_OUT_WRITE, TimeUnit.SECONDS)
                            .cache(new Cache(new File(cachePath), maxCacheSize));
                    client = builder.build();
                }
            }
        }
        return client;
    }

//    public static synchronized OkHttpClient getImageClient(Context context) {
//        if (null == imageClient) {
//            synchronized (OkHttpManager.class) {
//                if (null == imageClient) {
//                    String cacheDir = context.getCacheDir().getAbsolutePath();
//                    String cachePath = cacheDir + "/okhttp/";
//                    int maxCacheSize = 10 * 1024 * 1024; // 10M缓存大小
//                    OkHttpClient.Builder builder = new OkHttpClient.Builder();
//                    builder.connectTimeout(TIME_OUT_CONNECT, TimeUnit.SECONDS)
//                            .readTimeout(TIME_OUT_READ, TimeUnit.SECONDS)
//                            .writeTimeout(TIME_OUT_WRITE, TimeUnit.SECONDS)
//                            .addInterceptor(new HeaderInterceptor(context))
//                            .cache(new Cache(new File(cachePath), maxCacheSize));
//                    imageClient = builder.build();
//                }
//            }
//        }
//        return imageClient;
//    }


    public static void post(Request request, Callback callback) {
        if (client != null) {
            Call call = client.newCall(request);
            call.enqueue(callback);
        }
    }

    /**
     * 获得get请求的request
     *
     * @param params
     * @return
     */
    public static Request buildGetRequest(Object tag, String url, Map<String, String> params) {
        return new Request.Builder()
                .url(encodeParams(url, params))
                .get()
                .tag(tag)
                .build();
    }

    /**
     * 获取一个post请求
     */
    public static Request buildPostRequest(Object tag, String url, Map<String, String> headers, Map<String, String> params, Map<String, String> body) {
        Request.Builder build = new Request.Builder()
                .url(encodeParams(url, params))
                .cacheControl(new CacheControl.Builder()
                        .maxAge(5, TimeUnit.MINUTES)
                        .maxStale(5, TimeUnit.MINUTES).build())
                .post(getPostBody(body))
                .headers(Headers.of(headers));
        if (null != tag) {
            build.tag(tag);
        }
        return build.build();
    }

    /**
     * 组装post的表单数据
     */
    public static RequestBody getPostBody(Map<String, String> params) {
        FormBody.Builder builder = new FormBody.Builder();
        if (null != params && 0 != params.size()) {
            for (Map.Entry<String, String> e : params.entrySet()) {
                String key = e.getKey();
                String value = e.getValue();
                if (null != key && null != value && !TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    try {
                        builder.addEncoded(key.trim(), URLEncoder.encode(value.trim(), "utf-8"));
                    } catch (UnsupportedEncodingException exp) {
                        builder.addEncoded(key.trim(), value.trim());
                    }

                }

            }
        }
        return builder.build();
    }


    /**
     * 将get请求的参数进行网络编码组装
     *
     * @param url
     * @param params
     * @return
     */
    public static HttpUrl encodeParams(String url, Map<String, String> params) {
        HttpUrl httpUrl = HttpUrl.parse(url);
        assert httpUrl != null;
        HttpUrl.Builder httpUrlBuilder = httpUrl.newBuilder();

        if (null != params && 0 != params.size()) {
            for (Map.Entry<String, String> e : params.entrySet()) {
                String key = e.getKey();
                String value = e.getValue();
                if (null != key && null != value && !TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    try {
                        httpUrlBuilder.addEncodedQueryParameter(key, URLEncoder.encode(value.trim(), "utf-8"));
                    } catch (UnsupportedEncodingException exp) {
                        httpUrlBuilder.addEncodedQueryParameter(key.trim(), value.trim());
                    }
                }
            }
        }
        HttpUrl xxx =  httpUrlBuilder.build();
        GCLogger.error(Module.GENEX_CLOUD, xxx.toString());
        return xxx;
    }

    public static void cancel(Object tag) {
        if(null == client || null == tag) {
            return;
        }
        try {
            for (Call call : client.dispatcher().queuedCalls()) {
                if (tag.equals(call.request().tag())) {
                    call.cancel();
                }
            }
            for (Call call : client.dispatcher().runningCalls()) {
                if (tag.equals(call.request().tag())) {
                    call.cancel();
                }
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
    }
}
