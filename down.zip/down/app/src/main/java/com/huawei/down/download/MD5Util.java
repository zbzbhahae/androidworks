package com.huawei.down.download;

import android.text.TextUtils;
import android.util.Log;

import java.security.MessageDigest;
import java.util.Locale;

/**
 * MD5 工具类
 */
public class MD5Util {

    /**
     * 获取指定字符串的md5码
     * @param source 字符串
     * @param sixteenBit 16位md5还是32位md5
     * @param toLowerCase 是否转换为小写
     * @return
     */
    public static String getMD5(String source, boolean sixteenBit, boolean toLowerCase) {
        if (TextUtils.isEmpty(source)) {
            return null;
        }
        String result = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(source.getBytes());
            byte b[] = md.digest();

            int i;

            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString();// 32位的加密

            if (sixteenBit) {
                // 16位的加密
                result = result.substring(8, 24);
            }
            if (toLowerCase) {
                result = result.toLowerCase(Locale.ROOT);
            } else {
                result = result.toUpperCase(Locale.ROOT);
            }
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return result;
    }

    public static String getMD5(String source) {
        return getMD5(source, true, true);
    }
}
