package com.huawei.down.act;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.huawei.down.R;
import com.huawei.down.download.DownloadEntry;
import com.huawei.down.download.DownloadManager;
import com.huawei.down.download.DownloadState;
import com.huawei.down.logger.GCLogger;
import com.jeremyliao.liveeventbus.LiveEventBus;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button startBtn, cancelBtn;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init() {
        startBtn = findViewById(R.id.download_btn);
        cancelBtn = findViewById(R.id.cancel_btn);
        progressBar = findViewById(R.id.progress);

        startBtn.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);

        LiveEventBus.get(DownloadEntry.class)
                .observeForever(downloadEntry -> {
                    GCLogger.error("error", downloadEntry.toString());
                    switch (downloadEntry.getState()) {
                        case DownloadState.STATE_CONNECTING:
                        case DownloadState.STATE_WAIT:
                        case DownloadState.STATE_FAILED:
                        case DownloadState.STATE_SUCCESS:
                            progressBar.setIndeterminate(true);
                            break;
                        case DownloadState.STATE_DOWNLOADING:
                            progressBar.setIndeterminate(false);
                            progressBar.setMax((int) downloadEntry.getLength());
                            progressBar.setProgress((int) downloadEntry.getCurrentLength());
                            break;
                    }
                });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.download_btn:
                DownloadManager.getInstance().download("https://d.douyuba.cn/wsd-pkg-div/2022/04/12/Douyu_7.2.6.110726101_market.apk");
                break;
            case R.id.cancel_btn:
                startActivity(new Intent(this, DownloadListActivity.class));
                break;
        }
    }
}