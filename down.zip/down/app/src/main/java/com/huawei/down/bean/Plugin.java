package com.huawei.down.bean;

import com.huawei.down.download.DownloadEntry;

public class Plugin {
    private String url;
    private DownloadEntry downloadEntry;
    public Plugin(String url) {
        this.url = url;
        downloadEntry = new DownloadEntry(url);
    }

    public Plugin(String url, String fileName) {
        this.url = url;
        downloadEntry = new DownloadEntry(url, fileName);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public DownloadEntry getDownloadEntry() {
        return downloadEntry;
    }

    public void setDownloadEntry(DownloadEntry downloadEntry) {
        this.downloadEntry = downloadEntry;
    }
}
