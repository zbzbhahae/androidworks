package com.huawei.down.download;

import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class FileUtil {

    /**
     * 将内容保存到指定文件路径  数据量较小时使用
     * @param content 要保存的内容
     * @param path 保存的路径
     * @return
     */
    public static boolean writeStringToFile(String content, String path) {
        if (TextUtils.isEmpty(content) || TextUtils.isEmpty(path)) {
            return false;
        }

            File targetFile = new File(path);
        long fileSize = targetFile.length();
        try (FileOutputStream fos = new FileOutputStream(targetFile)){
            if (targetFile.exists()) {
                if (!targetFile.delete()) {
                    return false;
                }
            }
            if (null != targetFile.getParentFile() && (!targetFile.getParentFile().exists() || !targetFile.getParentFile().isDirectory())) {
                if (!targetFile.getParentFile().mkdirs()) {
                    return false;
                }
            }
            if (!targetFile.createNewFile()) {
                return false;
            }

            fos.write(content.getBytes(StandardCharsets.UTF_8));
            fos.flush();
            return true;
        } catch (IOException e) {
            Log.e("error", e.toString());
        }
        return false;
    }

    /**
     * 查看文件是否存在，如果不存在则创建该文件
     * @param path
     * @return
     */
    public static boolean checkExistNorCreate(String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }

        try {
            File targetFile = new File(path);
            if (targetFile.exists()) {
                return true;
            }
            if (null != targetFile.getParentFile() && (!targetFile.getParentFile().exists() || !targetFile.getParentFile().isDirectory())) {
                if (!targetFile.getParentFile().mkdirs()) {
                    return false;
                }
            }
            if (!targetFile.createNewFile()) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 从文件中读取字符串内容
     * @param path 文件路径
     * @return
     */
    public static String readStringFromFile(String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        File targetFile = new File(path);
        if (!targetFile.exists() || !targetFile.isFile()) {
            return null;
        }
        String result = null;
        try (FileInputStream fis = new FileInputStream(targetFile);
                ByteArrayOutputStream baos = new ByteArrayOutputStream()){
                byte[] buffer = new byte[1024];
                int length = 0;
                while ((length = fis.read(buffer)) != -1) {
                    baos.write(buffer, 0, length);
                }
                result = baos.toString("UTF-8");
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
        return result;
    }

    /**
     * 将文件拷贝到目标路径
     * @param sourcePath 原文件路径
     * @param targetPath 目标路径
     * @return
     */
    public static boolean copyFileTo(String sourcePath, String targetPath) {
        if (TextUtils.isEmpty(sourcePath) || TextUtils.isEmpty(targetPath)) {
            return false;
        }
        File source = new File(sourcePath);
        File target = new File(targetPath);

        if (!source.exists() || !source.isFile()) {
            return false;
        }
        if (target.exists() && target.isFile()) {
            if (!target.delete()) {
                return false;
            }
        }
        if (!target.getParentFile().exists() || !target.getParentFile().isDirectory()) {
            if (target.getParentFile().mkdirs()) {
                return false;
            }
        }
        try (FileInputStream fis = new FileInputStream(source);
                FileOutputStream fos = new FileOutputStream(target)) {
            if (!target.createNewFile()) {
                return false;
            }
            byte[] buff = new byte[1024];
            int length;
            while ( (length = fis.read(buff)) != -1) {
                fos.write(buff, 0, length);
            }
            fos.flush();
            return true;
        } catch (IOException e) {
            Log.e("error", e.toString());
        }
        return false;
    }

    /**
     * 获取指定文件夹内所有文件大小的和
     *
     * @param file file
     * @return size
     */
    public static long getFolderSize(File file) {
        long size = 0;
        File[] fileList = file.listFiles();
        for (File aFileList : fileList) {
            if (aFileList.isDirectory()) {
                size = size + getFolderSize(aFileList);
            } else {
                size = size + aFileList.length();
            }
        }
        return size;
    }

    /**
     * 删除指定目录下的文件，这里用于缓存的删除
     *
     * @param filePath       filePath
     * @param deleteThisPath deleteThisPath
     */
    public static void deleteFolderFile(String filePath, boolean deleteThisPath) {
        if (!TextUtils.isEmpty(filePath)) {
            try {
                File file = new File(filePath);
                if (file.isDirectory()) {
                    File files[] = file.listFiles();
                    for (File file1 : files) {
                        deleteFolderFile(file1.getCanonicalPath(), true);
                    }
                }
                if (deleteThisPath) {
                    if (!file.isDirectory()) {
                        file.delete();
                    } else {
                        if (file.listFiles().length == 0) {
                            file.delete();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("error", e.toString());
            }
        }
    }

    /**
     * 将图片bitmap写入到指定路径
     * @param bitmap 要写入文件的图片
     * @param filePath 写入的路径
     * @return
     */
    public static boolean writeBitmapToFile(Bitmap bitmap, String filePath) {
        if (null == bitmap || TextUtils.isEmpty(filePath)) {
            return false;
        }
        boolean found = checkExistNorCreate(filePath);
        if (!found) {
            return false;
        }
        File targetFile = new File(filePath);
        try ( FileOutputStream fos = new FileOutputStream(targetFile);
                BufferedOutputStream bos = new BufferedOutputStream(fos)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
            bos.flush();
            return true;
        } catch (Exception e) {
            Log.e("error", e.toString());
            return false;
        }
    }

    /**
     * 将字节数组写入文件
     * @param bytes 要写入的字节数组
     * @param targetPath 要写入的文件路径
     * @return
     */
    private static boolean writeBytesToFile(@NonNull byte[] bytes, @NonNull String targetPath) {
        File targetFile = new File(targetPath);
        if (!targetFile.exists() || !targetFile.isFile()) {
            return false;
        }
        String result = null;
        try (FileOutputStream fos = new FileOutputStream(targetFile)) {
            fos.write(bytes);
            fos.flush();
            return true;
        } catch (Exception e) {
            Log.e("error", e.toString());
            return false;
        }
    }
}
