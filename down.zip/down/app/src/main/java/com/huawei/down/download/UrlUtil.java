package com.huawei.down.download;

import android.text.TextUtils;

public class UrlUtil {

    /**
     * 通过url下载地址获取文件名称
     * @param url 下载地址
     * @return
     */
    public static String getFileNameFromUrl(String url) {
        if (TextUtils.isEmpty(url)) {
            return null;
        }
        int nameIndex = url.lastIndexOf('/');
        if (-1 == nameIndex || url.length() <= (nameIndex + 1)) {
            return MD5Util.getMD5(url);
        } else {
            return url.substring(nameIndex + 1);
        }
    }
}
