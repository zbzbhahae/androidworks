package com.huawei.genexcloud.sdk.http;

import android.content.Context;



import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */

public class ApiServices {

    //查询权限
    public static final String I_AUTH = "queryUserAuth";
    //用户app使用情况统计接口
    public static final String I_USER_USAGE = "CountAppUseInfo";
    // 发送反馈内容
    public static final String I_FEED_BACK = "InsertHelpInfo";
    // 网络结构数据
    public static final String I_NET_STRUCTURE = "getNetworkStructureData";
    // 口碑场景数据
    public static final String I_STAR_SCENE = "getScenarioData";
    // 高潜站和refarming数据
    public static final String I_HIGH = "getHighPotentialStation";
    // refarming数据
    public static final String I_REFARMING = "getNRRefarming";
    // 查询省级信息
    public static final String I_PROVINCE_DATA = "getProvinceAndCityData";
    // 查询移动主页数据
    public static final String I_CMCC_HOME_DATA = "getHomeData";


    private static final Object TAG_CMCC_HOME = new Object();
    private static final Object TAG_STRUCTURE = new Object();
    private static final Object TAG_SCENE = new Object();
    private static final Object TAG_PROVINCE = new Object();
    private static final Object TAG_HIGH = new Object();
    private static final Object TAG_REFARMING = new Object();



    /**
     * 根据需要的参数返回参数map
     *
     * @param messageName 接口名称
     * @param paramJson   参数拼接的json字符串
     * @return
     */
    public static Map<String, String> getParamsMap(String messageName, String paramJson) {
        Map<String, String> params = new HashMap<>();
        params.put("messageName", messageName);
        params.put("message", paramJson);
        return params;
    }
}
