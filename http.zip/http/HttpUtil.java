package com.huawei.genexcloud.sdk.http;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.huawei.genexcloud.sdk.http.callback.AbsCallback;
import com.huawei.genexcloud.sdk.http.header.IHeaderParams;
import com.huawei.genexcloud.sdk.logger.GCLogger;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by zWX1094027 on 2021/9/15.
 */

public class HttpUtil {

    private static final Handler handler = new Handler(Looper.getMainLooper());



    /**
     * 获取header参数
     */
    private static IHeaderParams headerParams = new IHeaderParams() {
        @Override
        public Map<String, String> getHeaders() {
            return null;
        }
    };

    public static void post(String url, final Map<String, String> params,
                            final AbsCallback callBack) {
        post(url, params, callBack);
    }

    public static void postSingle(Object tag, String url, final Map<String, String> params,
                                  final AbsCallback callBack) {
        if (null != tag) {
            OkHttpManager.cancel(tag);
        }
        post(tag, url, params, callBack);
    }



    /**
     * 发送post请求
     */
    public static void post(Object tag, String url,
                            final Map<String, String> params,
                            final AbsCallback callBack) {
        Request preparedRequest = OkHttpManager.getPostRequest(tag, url, params);
        if (null != callBack) {
            callBack.onBefore(preparedRequest);
        }
        OkHttpManager.post(headerParams, preparedRequest, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                String url = call.request().url().toString();
                ErrorBean errorBean;
                //如果访问的页面是登录页面,而访问失败
                if (url.contains("/genexcloud/portal/login.do")) {
                    sendBroadcast();

                    errorBean = new ErrorBean();

                    errorBean.errorCode = ErrorBean.ERROR_LOGIN;
                    errorBean.message = "登录过期";
                    sendFailure(callBack, handler, errorBean);
                    return;
                }

                if (null != e) { //可能是网络无链接 请求被cancel导致的socket关闭等
                    if (e instanceof UnknownHostException) { // 服务器地址问题或者无网络都会触发
                        errorBean = ErrorBean.make(ErrorBean.ERROR_NETWORK, e); //网络访问失败
                    } else if (e instanceof SocketTimeoutException) {
                        errorBean = ErrorBean.make(ErrorBean.ERROR_TIMEOUT, e); //连接超时
                    } else {
                        errorBean = ErrorBean.make(ErrorBean.ERROR_EXCEPTION, e);
                    }
                    sendFailure(callBack, handler, errorBean);
                }
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        GCLogger.error("http", "返回信息:[" + result + "]");

                        if (TextUtils.isEmpty(result)) { //访问无返回内容
                            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_EMPTY, null);
                            sendFailure(callBack, handler, errorBean);
                            return;
                        }

                        //如果返回的是一个html信息 (登录网址) 表示登录cookie token过期了 需要重新登录
                        if (result.contains("<!DOCTYPE HTML")) {
                            sendBroadcast();

                            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_LOGIN, null);
                            sendFailure(callBack, handler, errorBean);
                            return;
                        }
                        //返回值是json数据
                        if (isJsonData(result)) { // json数据或者json数组
                            try {
                                Object o = callBack.parseNetworkResponse(result);
                                sendSuccess(callBack, handler, o);
                            } catch (Exception e) {
                                //解析数据失败
                                ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_PARSE_EXCEPTION, e);
                                sendFailure(callBack, handler, errorBean);
                            }

                        } else {//不是json字符串或者json数组
                            ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_NOT_JSON, null);
                            sendFailure(callBack, handler, errorBean);
                        }
                    } else { // OKHttp判断的访问是否成功为false
                        ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_NETWORK_SERVER, null);
                        String result = response.body().string();
                        sendFailure(callBack, handler, errorBean);
                    }
                } catch (Exception e) {
                    ErrorBean errorBean = ErrorBean.make(ErrorBean.ERROR_EXCEPTION, e);
                    sendFailure(callBack, handler, errorBean);
                }
            }
        });
    }

    /**
     * 发送登录过期的广播
     * // TODO
     */
    private static void sendBroadcast() {

    }

    public static void get(final Context context, String url,
                           final Map<String, String> params,
                           final AbsCallback callBack, final int id, Object tag) {
        Request preparedRequest = OkHttpManager.getRequest(tag, url, params);
        if (null != callBack) {
            callBack.onBefore(preparedRequest);
        }
        OkHttpManager.get(headerParams, preparedRequest, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                GCLogger.error("http", "GET - url:" + call.request().url().toString() + " 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //TODO 未实现逻辑
                throw new IOException("未实现get逻辑 请查阅HttpUtil中get方法");
            }
        });
    }

    public static void get(final Context context, String url,
                           final Map<String, String> params,
                           final AbsCallback callBack) {
        get(context, url, params, callBack, 0, null);
    }

    /**
     * 判断一段字符串是否是json数据
     *
     * @param result
     * @return
     */
    private static boolean isJsonData(String result) {
        if (TextUtils.isEmpty(result)) {
            return false;
        }
        if ( (result.startsWith("{") && result.endsWith("}"))
                || (result.startsWith("[") && result.endsWith("]")) ) {
            return true;
        }
        return false;
    }


    /**
     * 将网络访问失败信息回调到主线程
     *
     * @param callBack
     * @param h
     * @param failure
     */
    private static void sendFailure(final AbsCallback callBack,
                                    Handler h, final ErrorBean failure) {
        if (null != callBack) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    callBack.onError(failure);
                    callBack.onAfter();
                }
            });
        }
    }


    private static void sendSuccess(final AbsCallback callBack
            , Handler h, final Object result) {
        if (null != callBack) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    callBack.onResponse(result);
                    callBack.onAfter();
                }
            });
        }
    }


}
