package com.huawei.genexcloud.sdk.http.header;

import java.util.Map;

/**
 * 获取header内容
 */
public interface IHeaderParams {
    Map<String, String> getHeaders();
}
