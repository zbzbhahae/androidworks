package com.huawei.genexcloud.sdk.http;

import android.os.Environment;
import android.text.TextUtils;

import com.huawei.genexcloud.sdk.http.header.IHeaderParams;
import com.huawei.genexcloud.sdk.http.interceptor.HeaderInterceptor;
import com.huawei.genexcloud.sdk.logger.GCLogger;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


/**
 * Created by zWX1094027 on 2021/9/13.
 */

public class OkHttpManager {

    private static final int TIME_OUT_CONNECT = 30;
    private static final int TIME_OUT_READ = 30;
    private static final int TIME_OUT_WRITE = 30;


    private static volatile OkHttpClient client;

    public static synchronized OkHttpClient getClient(IHeaderParams headerParams) {
        if (null == client) {
            synchronized (OkHttpManager.class) {
                if (null == client) {
                    String sdCard = Environment.getExternalStorageDirectory().getAbsolutePath();
                    String cachePath = sdCard + "/GenexCloud/Cache/okhttp/";
                    int maxCacheSize = 10 * 1024 * 1024; // 10M缓存大小
                    OkHttpClient.Builder builder = new OkHttpClient.Builder();
                    builder.connectTimeout(TIME_OUT_CONNECT, TimeUnit.SECONDS)
                            .readTimeout(TIME_OUT_READ, TimeUnit.SECONDS)
                            .writeTimeout(TIME_OUT_WRITE, TimeUnit.SECONDS)
                            .cache(new Cache(new File(cachePath), maxCacheSize))
                            .addInterceptor(new HeaderInterceptor(headerParams));
                    client = builder.build();
                }
            }
        }
        return client;
    }



    public static void get(IHeaderParams headerParams, Object tag, String url, Map<String, String> params, Map<String, String> headers) {

        Call call = getClient(headerParams).newCall(getRequest(tag, url, params));
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

            }
        });
    }

    public static void get(IHeaderParams headerParams, Object tag, String url, Map<String, String> params, Callback callback) {

        Call call = getClient(headerParams).newCall(getRequest(tag, url, params));
        call.enqueue(callback);
    }

    public static void post(IHeaderParams headerParams, Request request, Callback callback) {
        Call call = getClient(headerParams).newCall(request);
        call.enqueue(callback);
    }

    public static void get(IHeaderParams headerParams, Request request, Callback callback) {
        Call call = getClient(headerParams).newCall(request);
        call.enqueue(callback);
    }

    /**
     * 获得get请求的request
     *
     * @param params
     * @return
     */
    public static Request getRequest(Object tag, String url, Map<String, String> params) {
        Request request = new Request.Builder()
                .url(encodeGetParams(url, params))
                .get()
                .tag(tag)
                .build();
        return request;
    }

    /**
     * 获取一个post请求
     */
    public static Request getPostRequest(Object tag, String url, Map<String, String> params) {
        Request.Builder build = new Request.Builder()
                .url(url)
                .cacheControl(new CacheControl.Builder()
                        .maxAge(5, TimeUnit.MINUTES)
                        .maxStale(5, TimeUnit.MINUTES).build())
                .post(getPostBody(params));
        if (null != tag) {
            build.tag(tag);
        }
        return build.build();
    }

    /**
     * 组装post的表单数据
     */
    public static RequestBody getPostBody(Map<String, String> params) {
        FormBody.Builder builder = new FormBody.Builder();
        if (null != params && 0 != params.size()) {
            for (Map.Entry<String, String> e : params.entrySet()) {
                String key = e.getKey();
                String value = e.getValue();
                if (null != key && null != value && !TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    builder.addEncoded(key.trim(), value.trim());
                }

            }
        }
        return builder.build();
    }


    /**
     * 将get请求的参数进行网络编码组装
     *
     * @param url
     * @param params
     * @return
     */
    public static HttpUrl encodeGetParams(String url, Map<String, String> params) {
        HttpUrl httpUrl = HttpUrl.parse(url);
        HttpUrl.Builder httpUrlBuilder = httpUrl.newBuilder();

        if (null != params && 0 == params.size()) {
            for (Map.Entry<String, String> e : params.entrySet()) {
                String key = e.getKey();
                String value = e.getValue();
                if (null != key && null != value && !TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    httpUrlBuilder.addEncodedQueryParameter(key, value);
                }
            }
        }
        return httpUrlBuilder.build();
    }

    public static void cancel(Object tag) {
        if(null == client || null == tag) {
            return;
        }
        try {
            for (Call call : client.dispatcher().queuedCalls()) {
                if (tag.equals(call.request().tag())) {
                    call.cancel();
                }
            }
            for (Call call : client.dispatcher().runningCalls()) {
                if (tag.equals(call.request().tag())) {
                    call.cancel();
                }
            }
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
    }

}
