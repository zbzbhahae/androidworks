package com.huawei.genexcloud.sdk.http.callback;


import android.text.TextUtils;

import com.huawei.genexcloud.sdk.http.ErrorBean;
import com.huawei.genexcloud.sdk.http.HttpUtil;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import okhttp3.Request;

public abstract class AbsCallback<T> {


    private static final String URL_JAVA = "";
    private static final String URL_CSHARP = "";
    private static final String URL_ZZPT = "";

    /**
     * UI Thread
     */
    public void onBefore(Request request) {}

    /**
     * UI Thread
     */
    public void onAfter() {}


    /**
     * 用于返回字符串内容的解析 一般用这个
     * 子线程
     * @param responseStr 返回字符串
     * @return 解析出的对应bean
     * @throws Exception
     */
    public abstract T parseNetworkResponse(String responseStr) throws Exception;

    public abstract void onError(ErrorBean e);

    public abstract void onResponse(T response);

    public static String getMessageName() {
        return "";
    }

    public static void postJava(Map<String, String> params, AbsCallback callback) {
        HttpUtil.post(URL_JAVA, buildParams(params), callback);
    }
    public static void postJavaSingle(Object tag, Map<String, String> params, AbsCallback callback) {
        HttpUtil.postSingle(tag, URL_JAVA, buildParams(params), callback);
    }

    public static void postCSHARP(Map<String, String> params, AbsCallback callback) {
        HttpUtil.post(URL_CSHARP, buildParams(params), callback);
    }
    public static void postCSHARPSingle(Object tag, Map<String, String> params, AbsCallback callback) {
        HttpUtil.postSingle(tag, URL_CSHARP, buildParams(params), callback);
    }

    public static void postZZPT(Map<String, String> params, AbsCallback callback) {
        HttpUtil.post(URL_ZZPT, buildParams(params), callback);
    }
    public static void postZZPTSingle(Object tag, Map<String, String> params, AbsCallback callback) {
        HttpUtil.postSingle(tag, URL_ZZPT, buildParams(params), callback);
    }

    /**
     * 将 messageName 与 message信息打包
     * @param params
     * @return
     */
    private static Map<String, String> buildParams(Map<String, String> params) {
        String messageName = getMessageName();
        if (TextUtils.isEmpty(getMessageName())) {
            throw new IllegalArgumentException("请重写getMessageName方法");
        }
        Map<String, String> newParams = new HashMap<>();
        newParams.put("messageName", messageName);
        if (null == params || params.size() == 0) {
            newParams.put("message", "{}");
        } else {
            try {
                JSONObject jsonObject = new JSONObject();
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    jsonObject.put(entry.getKey(), entry.getValue());
                }
                newParams.put("message", jsonObject.toString());
            } catch (Exception e) {
                // TODO
            }
        }
        return newParams;
    }

}