package com.huawei.genexcloud.sdk.http;

/**
 * Created by zWX1094027 on 2021/9/14.
 */

public class ErrorBean {

    public static final int ERROR_LOGIN = 1;             //登录cookie过时
    public static final int ERROR_EXCEPTION = 2;     //发生异常
    public static final int ERROR_EMPTY = 3;         //访问成功但返回内容为空
    public static final int ERROR_CANCELED = 4;      //请求被取消
    public static final int ERROR_NETWORK = 5;       //网络错误
    public static final int ERROR_TIMEOUT = 6;       //请求超时
    public static final int ERROR_NOT_JSON = 7;      //返回数据不是json字符串或者其中没有message和statuscode
    public static final int ERROR_NOT_SUCCESS = 8;      //responsecode不是200
    public static final int ERROR_PARSE_EXCEPTION = 9;      //解析返回数据失败
    public static final int ERROR_NETWORK_SERVER = 10;   //请求能通，但是返回错误代码 如405 不是200


    public String message;
    public int errorCode;
    public Exception exception;

    public ErrorBean() {
    }

    public ErrorBean(String message, int errorCode, Exception exception) {
        this.message = message;
        this.errorCode = errorCode;
        this.exception = exception;
    }

    /**
     * 生成错误信息  方便统一管理
     *
     * @param errorCode
     * @return
     */
    public static ErrorBean make(int errorCode, Exception e) {
        switch (errorCode) {
            case ERROR_LOGIN:
                return new ErrorBean("登录过期", errorCode, e);
            case ERROR_EXCEPTION:
                return new ErrorBean("发生错误", errorCode, e);
            case ERROR_EMPTY:
                return new ErrorBean("无内容", errorCode, e);
            case ERROR_CANCELED:
                return new ErrorBean("请求取消", errorCode, e);
            case ERROR_NETWORK:
                return new ErrorBean("网络异常，请检查网络", errorCode, e);
            case ERROR_TIMEOUT:
                return new ErrorBean("请求超时", errorCode, e);
            case ERROR_NOT_JSON:
                return new ErrorBean("返回数据不标准", errorCode, e);
            case ERROR_NOT_SUCCESS:
                return new ErrorBean("访问失败", errorCode, e);
            case ERROR_PARSE_EXCEPTION:
                return new ErrorBean("解析数据失败", errorCode, e);
            case ERROR_NETWORK_SERVER:
                return new ErrorBean("访问服务器失败", errorCode, e);
        }
        return new ErrorBean("未知错误", errorCode, e);
    }

    @Override
    public String toString() {
        String result = "ErrorBean{" +
                "message='" + message + '\'' +
                ", errorCode=" + errorCode;
        if (null == exception) {
            result += "}";
        } else {
            result += exception.toString() + '}';
        }
        return result;
    }
}
