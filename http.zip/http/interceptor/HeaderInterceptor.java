package com.huawei.genexcloud.sdk.http.interceptor;

import android.text.TextUtils;

import com.huawei.genexcloud.sdk.http.header.IHeaderParams;
import com.huawei.genexcloud.sdk.logger.GCLogger;

import java.io.IOException;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 设置请求头
 */
public class HeaderInterceptor implements Interceptor {
    IHeaderParams headerParams;

    public HeaderInterceptor(IHeaderParams headerParams) {
        this.headerParams = headerParams;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        if (null == headerParams) {
            return chain.proceed(chain.request());
        } else {
            Map<String, String> headers = headerParams.getHeaders();
            if (null != headers && headers.size() > 0) {
                try {
                    Request.Builder builder = chain.request().newBuilder();
                    for (Map.Entry<String, String> entry : headers.entrySet()) {
                        String key = entry.getKey();
                        String value = entry.getValue();
                        if (!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                            builder.addHeader(key, value);
                        }
                    }
                    return chain.proceed(builder.build());
                } catch (Exception e) {
                    GCLogger.error("error", e.toString());
                }
            }
        }
        return chain.proceed(chain.request());
    }
}
