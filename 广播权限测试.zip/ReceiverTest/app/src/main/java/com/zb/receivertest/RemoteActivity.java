package com.zb.receivertest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class RemoteActivity extends AppCompatActivity implements View.OnClickListener {

    private Button localRemote;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote);

        localRemote = findViewById(R.id.local_remote);
        localRemote.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String message = "本地广播";
        Intent i = new Intent();
        i.putExtra("message", message);
        i.setAction("com.zb.receiver");
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this);
        localBroadcastManager.sendBroadcast(i);
//        sendBroadcast(i);
    }
}
