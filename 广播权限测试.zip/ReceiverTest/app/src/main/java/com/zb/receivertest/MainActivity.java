package com.zb.receivertest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.zb.receivertest.utils.L;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private MyReceiver local, normal, permission;
    private Button remote;
    private boolean isReged = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        remote = findViewById(R.id.remote);
        remote.setOnClickListener(this);

        if(!isReged) {
            regLocal();
            regNormal();
            regPermission();
        }
    }


    private void regNormal() {
        if(null == normal) {
            normal = new MyReceiver();
        }
        IntentFilter intentFilter = new IntentFilter("com.zb.receiver");
        registerReceiver(normal, intentFilter);
    }

    private void regLocal() {
        if(null == local) {
            local = new MyReceiver();
        }
        IntentFilter intentFilter = new IntentFilter("com.zb.receiver");
        LocalBroadcastManager.getInstance(this).registerReceiver(local, intentFilter);
    }

    private void regPermission() {
        if(null == local) {
            local = new MyReceiver();
        }
        IntentFilter intentFilter = new IntentFilter("com.zb.receiver");
        registerReceiver(local, intentFilter, "com.zb.permission.sendreceiver", null);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(this, RemoteActivity.class);
        startActivity(i);
    }


    private class MyReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(null != intent) {
                L.e("收到广播" + intent.getStringExtra("message"));
            }
        }
    }
}