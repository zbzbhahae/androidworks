package com.zb.receivertest.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.zb.receivertest.utils.L;

public class LocalReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        L.e("LocalReceiver收到广播" + intent.getStringExtra("message"));
    }
}
