package com.zb.broadcastsender.utils;

import android.util.Log;

public class L {
    private static final String tag = "ReceiverTest";
    public static void e(String message) {
        Log.e(tag, message);
    }
    public static void e(Object message) {
        if(null == message) {
            return;
        }
        Log.e(tag, message.toString());
    }
}
