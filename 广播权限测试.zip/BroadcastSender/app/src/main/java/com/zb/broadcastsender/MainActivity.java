package com.zb.broadcastsender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button normal, permission, local;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        normal = findViewById(R.id.normal);
        permission = findViewById(R.id.permission);
        local = findViewById(R.id.local);

        normal.setOnClickListener(this);
        permission.setOnClickListener(this);
        local.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.normal: // 普通广播
                sendNormal();
                break;
            case R.id.permission: // 带权限的广播
                sendPermission();
                break;
            case R.id.local: // 发送本地广播
                sendLocal();
                break;
        }
    }

    private void sendNormal() {
        String message = "普通广播";
        Intent i = new Intent();
        i.putExtra("message", message);
        i.setAction("com.zb.receiver");
        sendBroadcast(i);
    }

    private void sendPermission() {
        String message = "带权限的广播";
        Intent i = new Intent();
        i.putExtra("message", message);
        i.setAction("com.zb.receiver");
        sendBroadcast(i, "com.zb.permission.receive_broadcast");
    }

    private void sendLocal() {
        String message = "本地广播";
        Intent i = new Intent();
        i.putExtra("message", message);
        i.setAction("com.zb.receiver");
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this);
        localBroadcastManager.sendBroadcast(i);
    }

    private void sendPackage() {
        String message = "带权限的广播";
        Intent i = new Intent();
        i.putExtra("message", message);
        i.setAction("com.zb.receiver");
    }
}