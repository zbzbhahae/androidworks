package com.huawei.genexcloud.survey.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.huawei.genexcloud.survey.R;

public class SiteMapView extends View {

    private static Bitmap flagBitmap;
    private boolean isSurveyed = false;

    public SiteMapView(Context context) {
        super(context);
        init();
    }

    public SiteMapView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SiteMapView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private float dp2px(float dp) {
        return getResources().getDisplayMetrics().density * dp;
    }

    private float sp2px(float sp) {
        return getResources().getDisplayMetrics().scaledDensity * sp;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            width = getWidth();
            height = getHeight();
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 室外站 图片大小 25dp * 25dp  室内站 图片大小 20dp * 20dp
        setMeasuredDimension((int) dp2px(36), (int) dp2px(36));
    }

    private int width, height;

    // 小区方位角
    private Float[] angles = new Float[]{0f, 120f, 240f};
    // 方位角画笔
    private Paint anglePaint;
    // 图标画笔
    private Paint iconPaint;
    // 画小区扇形使用的rect
    private RectF rect = new RectF();
    // 小区方位角扇形角度大小
    private final float CELL_ANGLE = 60;
    // 画供应商图标所用的rect
    private RectF bitmapRect = new RectF();

    private int angleColor = Color.parseColor("#6ECEFE");

    private void init() {
        anglePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        anglePaint.setColor(angleColor);
        anglePaint.setStyle(Paint.Style.FILL);

        iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        flagBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_flag_finish);
    }

    public void setData(Float[] angles) {
        this.angles = angles;
        if (null != getParent()) {
            invalidate();
        }
    }

    public void setSurveyed(boolean isSurveyed) {
        this.isSurveyed = isSurveyed;
        if (null != getParent()) {
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawCellAngle(canvas);
        drawSiteIcon(canvas);
        drawSurveyFlag(canvas);
    }

    /**
     * 绘制小区方位角
     *
     * @param canvas
     */
    private void drawCellAngle(Canvas canvas) {
        if (null == angles || angles.length == 0) {
            return;
        }
        rect.left = 0;
        rect.top = 0;
        rect.right = width;
        rect.bottom = height;

        for (Float f : angles) {
            // -120 因为弧线起点为正右方向 扫过角度为正数时是逆时针绘制，-90使其回到正上方向，再-30使扇形区域中心对准正上
            canvas.drawArc(rect, f - 120f, CELL_ANGLE, true, anglePaint);
        }
    }

    private void drawSiteIcon(Canvas canvas) {
    }


    /**
     * 设置view大小
     * 注：百度从view中获取bitmap时，会使用measure方法 此方法无效
     *
     * @param widthDp
     * @param heightDp
     */
    public void setSize(int widthDp, int heightDp) {
        if (widthDp >= 0 && heightDp >= 0) {
            width = (int) dp2px(widthDp);
            height = (int) dp2px(heightDp);
            setMeasuredDimension(width, height);
            invalidate();
        }
    }


    private void drawSurveyFlag(Canvas canvas) {
        if (isSurveyed) {
            float bitmapWidth = flagBitmap.getWidth();
            float bitmapHeight = flagBitmap.getHeight();
            float targetBitmapWidth = getWidth() * 0.8f;
            float targetBitmapHeight = targetBitmapWidth / bitmapWidth * bitmapHeight;
            float left = getWidth() * 0.4f;
            float top = 0f;
            float right = left + targetBitmapWidth;
            float bottom = top + targetBitmapHeight;
            canvas.drawBitmap(flagBitmap, new Rect(0, 0, getRight(), getBottom()), new RectF(left, top, right, bottom), new Paint());
        }
    }
}
