package com.huawei.genexcloud.survey.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.util.DensityUtil;

/**
 * Created by wWX553206 on 2019/3/5.
 */

public class MyDownTiltView extends View {

    //X轴的原点坐标
    private int xOri;
    //Y轴的原点坐标
    private int yOri;
    //x轴颜色
    private int xyLineColor;
    private int lineBlue;
    private int lineRed;
    private int lineYellow;
    private int groundGreen;
    private float interval;
    private int bgColor;
    private Paint xyPaint;
    private Paint textPaint;
    private Paint linePaint;
    private float lineWidth;
    private int height;
    private int width;
    private float xyTextSize;
    private final float DOT_FIVE = 0.5f;
    private double towerHeight;
    private double lower3;
    private double mainBeam3;
    private double upper3;
    private int xyTextColor;
    private Path mPath;
    private int yLength;
    private Paint circlePaint;


    public MyDownTiltView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public MyDownTiltView(Context context) {
        super(context);
    }

    public MyDownTiltView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initAttrs(context, attrs);
        initPaint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawXY(canvas);
        drawXYText(canvas);
        drawBrokenLine(canvas);
    }

    private void drawBrokenLine(Canvas canvas) {


        //dip2px(11.5f)为0点，塔的中间
        float rate = (float) ((interval * 10) / upper3);

        circlePaint.setColor(Color.GREEN);
        circlePaint.setAlpha(10);
        mPath.reset();
        mPath.moveTo(xOri, yOri - yLength * 5);
        mPath.lineTo(interval * 10 + xOri, yOri);
        mPath.lineTo((float) (xOri + lower3 * rate), yOri);
        mPath.close();
        canvas.drawPath(mPath, circlePaint);

        linePaint.setColor(lineYellow);
        mPath.reset();
        mPath.moveTo(xOri, yOri - yLength * 5);
        mPath.lineTo((float) (xOri + lower3 * rate), yOri - dip2px(1));
        canvas.drawPath(mPath, linePaint);
        circlePaint.setColor(lineYellow);
        canvas.drawCircle((float) (xOri + lower3 * rate), yOri, dip2px(3), circlePaint);
        circlePaint.setColor(Color.WHITE);
        canvas.drawCircle((float) (xOri + lower3 * rate), yOri, dip2px(1.5f), circlePaint);

        linePaint.setColor(lineRed);
        mPath.reset();
        mPath.moveTo(xOri, yOri - yLength * 5);
        mPath.lineTo((float) (xOri + mainBeam3 * rate), yOri - dip2px(1));
        canvas.drawPath(mPath, linePaint);
        circlePaint.setColor(lineRed);
        canvas.drawCircle((float) (xOri + mainBeam3 * rate), yOri, dip2px(3), circlePaint);
        circlePaint.setColor(Color.WHITE);
        canvas.drawCircle((float) (xOri + mainBeam3 * rate), yOri, dip2px(1.5f), circlePaint);

        linePaint.setColor(lineBlue);
        mPath.reset();
        mPath.moveTo(xOri, yOri - yLength * 5);
        mPath.lineTo(interval * 10 + xOri, yOri - dip2px(1));
        canvas.drawPath(mPath, linePaint);
        circlePaint.setColor(lineBlue);
        canvas.drawCircle(interval * 10 + xOri, yOri, dip2px(3), circlePaint);
        circlePaint.setColor(Color.WHITE);
        canvas.drawCircle(interval * 10 + xOri, yOri, dip2px(1.5f), circlePaint);

        mPath.reset();
    }

    private void drawXYText(Canvas canvas) {
        int splitLines = 5;
        linePaint.setColor(xyLineColor);
        //y轴上面空出12%,计算出y轴刻度间距
        yLength = (int) (yOri * (1 - 0.1f) / splitLines);
        for (int i = 0; i < splitLines + 1; i++) {
            //绘制Y轴文本
            String text = String.valueOf((int) (Math.round(towerHeight / splitLines * i)));
            Rect rect = getTextBounds(text, textPaint);
            canvas.drawText(text, 0, text.length(), xOri - rect.width() + dip2px(11),
                    yOri - yLength * i + dip2px(2), textPaint);
            //绘制Y轴刻度
            if (i != 0) {
                mPath.moveTo(xOri + dip2px(12), yOri - yLength * i);
                mPath.lineTo(width - dip2px(10), yOri - yLength * i);
                canvas.drawPath(mPath, linePaint);
            }
        }
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_site_base);
        // 将画布坐标系移动到画布中央
        canvas.translate(xOri + dip2px(23), 0);
        // 指定图片绘制区域(左上角的四分之一)
        Rect src = new Rect(0, 0, bitmap.getWidth(), yOri);
        // 指定图片在屏幕上显示的区域
        Rect dst = new Rect(0, (int) (0.1f * yOri), dip2px(23), yOri);
        // 绘制图片
        canvas.drawBitmap(bitmap, src, dst, null);
        //绘制X轴文本
        for (int i = 0; i < 11; i++) {
            String textX = String.valueOf((int) Math.round(upper3 / 10 * i));
            Rect rect = getTextBounds(textX, textPaint);
            textPaint.setColor(xyTextColor);
            canvas.drawText(textX, 0, textX.length(), interval * i + dip2px(11.5f) - rect.width() / 2,
                    yOri + dip2px(15), textPaint);
            canvas.drawLine(interval * i + dip2px(11.5f), yOri, interval * i + xOri, yOri - dip2px(1.5f), textPaint);
        }

    }

    private void drawXY(Canvas canvas) {
        //绘制X轴
        canvas.drawLine(xOri + dip2px(11), yOri, width - dip2px(10), yOri, xyPaint);
    }

    /**
     * 根据Y值文本的宽度和X轴文本的高度，确定原点坐标
     */
    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        height = getHeight();
        width = getMeasuredWidth();
        //Y轴左边文本最大宽度
        xOri = dip2px(11.5f);
        //X轴文本最大高度
        float textXHeight = getTextBounds("000", textPaint).height();
        //确定坐标原点Y点
        yOri = (int) (height - textXHeight - dip2px(10));
        super.onLayout(changed, left, top, right, bottom);
    }

    public void setData(double towerHeight, double lower3, double mainBeam3, double upper3) {
        this.towerHeight = towerHeight;
        this.lower3 = lower3;
        this.mainBeam3 = mainBeam3;
        this.upper3 = upper3;
        invalidate();
    }

    private void initPaint() {
        //XY轴画笔
        xyPaint = new Paint();
        xyPaint.setAntiAlias(true);
        xyPaint.setColor(xyLineColor);
        xyPaint.setStrokeWidth(lineWidth);
        xyPaint.setStrokeCap(Paint.Cap.ROUND);
        //文字画笔
        textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(xyTextColor);
        textPaint.setTextSize(xyTextSize);
        textPaint.setStrokeCap(Paint.Cap.ROUND);
        textPaint.setStyle(Paint.Style.STROKE);
        //虚线画笔
        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setStrokeWidth(lineWidth);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setPathEffect(new DashPathEffect(new float[]{5, 5}, 0));
        //圆画笔
        circlePaint = new Paint();
        circlePaint.setAntiAlias(true);
        circlePaint.setStrokeCap(Paint.Cap.ROUND);
        circlePaint.setStyle(Paint.Style.FILL);

        mPath = new Path();
    }

    private void initAttrs(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.DownTitleView, 0, 0);
        xyLineColor = typedArray.getColor(R.styleable.DownTitleView_xylinecolor, 0xeeeeee);
        lineWidth = typedArray.getDimension(R.styleable.DownTitleView_linewidth, 2);
        lineBlue = typedArray.getColor(R.styleable.DownTitleView_lineBlue, 0x09d3c2);
        lineRed = typedArray.getColor(R.styleable.DownTitleView_lineRed, 0xf8413d);
        lineYellow = typedArray.getColor(R.styleable.DownTitleView_lineYellow, 0xff7a29);
        groundGreen = typedArray.getColor(R.styleable.DownTitleView_groundGreen, 0xff8f8f);
        interval = typedArray.getDimension(R.styleable.DownTitleView_interval, 75);
        bgColor = typedArray.getColor(R.styleable.DownTitleView_bgcolor, 0xffffff);
        xyTextSize = typedArray.getDimension(R.styleable.DownTitleView_textSize2, dip2px(10));
        xyTextColor = typedArray.getColor(R.styleable.DownTitleView_xytextcolor, 0x999999);

        interval = (float) (DensityUtil.getDeviceInfo(context)[0] * 0.9 / 11);
    }

    /**
     * 获取丈量文本的矩形
     */
    private Rect getTextBounds(String text, Paint paint) {
        Rect rect = new Rect();
        paint.getTextBounds(text, 0, text.length(), rect);
        return rect;
    }

    /**
     * dip to px 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    private int dip2px(float dip) {
        float density = getDensity(getContext());
        return (int) (dip * density + DOT_FIVE);
    }

    /**
     * get screen density
     */
    private float getDensity(Context context) {
        return context.getResources().getDisplayMetrics().density;
    }

}



