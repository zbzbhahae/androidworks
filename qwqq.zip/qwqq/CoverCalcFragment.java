package com.huawei.genexcloud.survey.fragment.survey.tool;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.huawei.genexcloud.survey.base.BasicFragment;
import com.huawei.genexcloud.survey.databinding.FragmentCoverCalcBinding;

import java.text.DecimalFormat;
import java.text.ParseException;

/**
 * 覆盖预算页面
 */
public class CoverCalcFragment extends BasicFragment {

    private FragmentCoverCalcBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentCoverCalcBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        binding.titleLayout.leftButton.setOnClickListener(v->{
            backPressed();
        });
        binding.titleLayout.rightButton.setVisibility(View.GONE);
        binding.titleLayout.title.setText("覆盖预算");

        binding.antennaHeight.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        binding.powerAngle.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        binding.tiltAngle.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);

        binding.calculate.setOnClickListener(v->{
            doCalc(true);
        });
    }

    private void initData() {
        binding.antennaHeight.setText("30");
        binding.powerAngle.setText("10");
        binding.tiltAngle.setText("6");
        setChartData();
    }

    private void setChartData() {
        doCalc(false);
    }

    /**
     * 获取输入的天线高度 默认30
     * @return
     */
    private double getAntennaHeight() {
        String heightContent = binding.antennaHeight.getText().toString().trim();
        if (TextUtils.isEmpty(heightContent)) {
            return 30;
        } else {
            try {
                return Double.parseDouble(heightContent);
            } catch (NumberFormatException e) {
                showMsg("请输入正确的天线高度数值");
                return 30;
            }
        }
    }

    /**
     * 获取输入的功率角 默认10
     * @return
     */
    private double getPowerAngle() {
        String powerAngle = binding.powerAngle.getText().toString().trim();
        if (TextUtils.isEmpty(powerAngle)) {
            return 10;
        } else {
            try {
                return Double.parseDouble(powerAngle);
            } catch (NumberFormatException e) {
                showMsg("请输入正确的功率角数值");
                return 10;
            }
        }
    }

    /**
     * 获取输入的下倾角 默认6
     * @return
     */
    private double getTiltAngle() {
        String tiltAngle = binding.tiltAngle.getText().toString().trim();
        if (TextUtils.isEmpty(tiltAngle)) {
            return 6;
        } else {
            try {
                return Double.parseDouble(tiltAngle);
            } catch (NumberFormatException e) {
                showMsg("请输入正确的下倾角数值");
                return 6;
            }
        }
    }


    /**
     * 计算数值
     */
    private void doCalc(boolean showOutputText) {
        if (TextUtils.isEmpty(binding.antennaHeight.getText().toString().trim())) {
            showMsg("请输入天线高度");
            return;
        }
        double antennaHeight = getAntennaHeight();
        if (antennaHeight <= 0) {
            showMsg("天线高度必须大于0");
            return;
        }
        if (TextUtils.isEmpty(binding.powerAngle.getText().toString().trim())) {
            showMsg("请输入垂半功率角");
            return;
        }
        double powerAngle = getPowerAngle();
        if (TextUtils.isEmpty(binding.tiltAngle.getText().toString().trim())) {
            showMsg("请输入天线下倾角");
            return;
        }
        double tiltAngle = getTiltAngle();
        if (tiltAngle < 0) {
            showMsg("天线下倾角必须大于0度");
            return;
        } else if (tiltAngle > 90) {
            showMsg("天线下倾角必须小于90度");
            return;
        }
        double farDistance = 0;
        double mainDistance = 0;
        double nearDistance = 0;
        if (tiltAngle == 0) {
            farDistance = 10E14;
            mainDistance = 10E14;
            nearDistance = antennaHeight / Math.tan(toRadius(powerAngle * 0.5f));
        } else {
            farDistance = formatDouble3Point(antennaHeight / (Math.tan(toRadius(tiltAngle) - toRadius(powerAngle) * 0.5)));
            mainDistance = formatDouble3Point(antennaHeight / (Math.tan(toRadius(tiltAngle))));
            nearDistance = formatDouble3Point(antennaHeight / (Math.tan(toRadius(tiltAngle) + toRadius(powerAngle) * 0.5)));
        }

        if (showOutputText) {
            binding.farDistance.setText("" + (farDistance > 10E10 ? "Over Horizon" : "" + farDistance));
            if (farDistance < 0) {
                binding.farDistance.setText("Over Horizon");
            }
            binding.mainDistance.setText("" + (mainDistance > 10E10 ? "Over Horizon" : "" + mainDistance));
            if (mainDistance < 0) {
                binding.mainDistance.setText("Over Horizon");
            }
            if (tiltAngle == 90) {
                binding.nearDistance.setText("" + (farDistance > 10E10 ? "Over Horizon" : "" + farDistance));
            } else {
                binding.nearDistance.setText(nearDistance < 0.0000001 ? "" + 0 : "" + nearDistance);
            }
        }

        binding.chart.setData(antennaHeight, nearDistance, mainDistance, farDistance);
    }

    /**
     * 角度转化为弧度
     *
     * @param angle
     * @return
     */
    private double toRadius(double angle) {
        return Math.toRadians(angle);
    }

    /**
     * 保留3位数
     * @param db
     * @return
     */
    public static double formatDouble3Point(double db) {
        DecimalFormat decimalFormat = new DecimalFormat("######0.000");
        String result = decimalFormat.format(db);
        double resultDouble = Double.parseDouble(result);
        return resultDouble;
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
