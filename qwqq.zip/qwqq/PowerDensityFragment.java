package com.huawei.genexcloud.survey.fragment.survey.tool;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.base.BasicFragment;
import com.huawei.genexcloud.survey.databinding.FragmentPowerDensityBinding;
import com.huawei.genexcloud.survey.fragment.guide.SurveyAbilityFragment;

import java.text.DecimalFormat;

/**
 * 功率密度计算
 */
public class PowerDensityFragment extends BasicFragment {

    private FragmentPowerDensityBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPowerDensityBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        binding.titleLayout.leftButton.setOnClickListener(v->{
            backPressed();
        });
        binding.titleLayout.rightButton.setImageResource(R.drawable.icon_explain);
        binding.titleLayout.rightButton.setImageTintList(null);
        binding.titleLayout.rightButton.setOnClickListener(v->{
            actPush(new SurveyAbilityFragment());
        });
        binding.titleLayout.title.setText("测算电磁辐射功率密度");

        binding.calculate.setOnClickListener(v-> {
            calculate();
        });

        binding.horizontalDistance.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        binding.verticalDistance.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        binding.avgPower.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        binding.antennaDb.setInputType(EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_FLAG_DECIMAL);
        addTextChangedListener(binding.horizontalDistance);
        addTextChangedListener(binding.verticalDistance);
        addTextChangedListener(binding.avgPower);
        addTextChangedListener(binding.antennaDb);
    }

    private void initData() {
    }

    private void addTextChangedListener(EditText et) {
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void afterTextChanged(Editable s) {
                judgeEditTextInput(s);
            }
        });
    }

    /**
     * 对EditText输入框进行判断,不能输入不正确的数字
     */
    private void judgeEditTextInput(Editable s) {
        if (s.toString().startsWith("0.")) {
            return;
        } else if (s.toString().startsWith(".")) {
            s.clear();
        }
        if (s.toString().length() >= 2 && s.toString().startsWith("0")) {
            s.clear();
        }
    }

    /**
     * 根据输入计算结果
     */
    private void calculate() {
        if (binding.horizontalDistance.getText().toString().isEmpty()) {
            showMsg("请输入水平距离");
            return;
        }
        if (binding.verticalDistance.getText().toString().isEmpty()) {
            showMsg("请输入垂直距离");
            return;
        }
        if (binding.avgPower.getText().toString().isEmpty()) {
            showMsg("请输入发射机平均功率");
            return;
        }
        if (binding.antennaDb.getText().toString().isEmpty()) {
            showMsg("请输入天线数字增益");
            return;
        }
        startCalculate();
    }
    /**
     * 计算功率密度 单位 w/m² 公式 ：p * G / ( 4 * π * R²)
     */
    private void startCalculate() {
        //计算R
        double distanceL = Double.parseDouble(binding.horizontalDistance.getText().toString());
        double distanceH = Double.parseDouble(binding.verticalDistance.getText().toString());
        double distance1 = Math.pow(distanceL, 2) + Math.pow(distanceH, 2);

        double power = Double.parseDouble(binding.avgPower.getText().toString());
        double gain = Double.parseDouble(binding.antennaDb.getText().toString());
        double powerDensity = power * gain / (4 * Math.PI * distance1);
        String result = formatDoubleReserveNumber(powerDensity, 10) + "W/m²";
        binding.result.setText(result);
    }

    /**
     * 浮点数转换
     * <p>
     * db输入的浮点数 number保留几位有效数字
     **/
    private static String formatDoubleReserveNumber(double db, int number) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < number; i++) {
            buffer.append("0");
        }
        DecimalFormat decimalFormat = new DecimalFormat("#####0." + buffer.toString());
        String result = decimalFormat.format(db);
        return Double.parseDouble(result) + "";
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
