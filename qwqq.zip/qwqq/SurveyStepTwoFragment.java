package com.huawei.genexcloud.survey.fragment.survey;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.huawei.genexcloud.httplib.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.activity.CameraActivity;
import com.huawei.genexcloud.survey.adapter.SitePhotoTypeListAdapter;
import com.huawei.genexcloud.survey.adapter.SurveyCellListAdapter;
import com.huawei.genexcloud.survey.base.BasicActivity;
import com.huawei.genexcloud.survey.base.BasicFragment;
import com.huawei.genexcloud.survey.bean.CellBean;
import com.huawei.genexcloud.survey.bean.SiteBean;
import com.huawei.genexcloud.survey.bean.SitePhotoBean;
import com.huawei.genexcloud.survey.bean.SitePhotoTypeBean;
import com.huawei.genexcloud.survey.data.StatusAndDataVM;
import com.huawei.genexcloud.survey.databinding.FragmentSurveyStepTwoBinding;
import com.huawei.genexcloud.survey.dialog.SVAlertDialog;
import com.huawei.genexcloud.survey.dialog.SurveyEffectPredictDialog;
import com.huawei.genexcloud.survey.fragment.EditCellFragment;
import com.huawei.genexcloud.survey.fragment.PhotoGridFragment;
import com.huawei.genexcloud.survey.fragment.survey.tool.CoverCalcFragment;
import com.huawei.genexcloud.survey.fragment.survey.tool.PowerDensityFragment;
import com.huawei.genexcloud.survey.http.kance.CreateOrUpdateSurveyImpl;
import com.huawei.genexcloud.survey.http.gcpt.DeleteCellImpl;
import com.huawei.genexcloud.survey.http.kance.UploadImageImpl;
import com.huawei.genexcloud.survey.util.map.SiteUtil;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import okhttp3.Request;

/**
 * 勘测第二步  站点照片 小区照片 工参修改
 */
public class SurveyStepTwoFragment extends BasicFragment {

    private FragmentSurveyStepTwoBinding binding;

    // 站点数据
    private SiteBean site;

    // 小区列表适配器
    private SurveyCellListAdapter cellAdapter;
    private StatusAndDataVM viewModel;

    private SitePhotoTypeListAdapter photoAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (null != bundle) {
            site = bundle.getParcelable("site");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSurveyStepTwoBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        binding.titleLayout.leftButton.setOnClickListener(v -> {
            backPressed();
        });
        binding.titleLayout.title.setText("站点勘测信息");
        binding.titleLayout.rightButton.setImageResource(R.drawable.icon_tool);
        binding.titleLayout.rightButton.setOnClickListener(v -> {
            // 显示效果预估 功率密度 覆盖预算选项弹窗
            SurveyEffectPredictDialog dialog = new SurveyEffectPredictDialog();
            dialog.setSurveyEffectSelectedListener(new SurveyEffectPredictDialog.SurveyEffectSelectedListener() {
                @Override
                public void onSelected(int type) {
                    if (type == SurveyEffectPredictDialog.TYPE_PREDICT) {
                        // 效果预估
                    } else if (type == SurveyEffectPredictDialog.TYPE_POWER_DENSITY) {
                        // 功率密度
                        actPush(new PowerDensityFragment());
                    } else if (type == SurveyEffectPredictDialog.TYPE_COVER_CALC) {
                        // 覆盖预算
                        actPush(new CoverCalcFragment());
                    }
                }
            });
            dialog.show(getChildFragmentManager(), "SurveyEffectPredictDialog");
        });

        binding.confirm.setOnClickListener(v -> {
            onConfirmClicked();
        });

        binding.cellList.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.cellList.setNestedScrollingEnabled(false);
        cellAdapter = new SurveyCellListAdapter();
        if (null != site) {
            cellAdapter.setData(site.cells);
        }
        cellAdapter.setSurveyCellListener(cellListener);
        binding.cellList.setAdapter(cellAdapter);

        binding.photoList.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.photoList.setNestedScrollingEnabled(false);
        photoAdapter = new SitePhotoTypeListAdapter();
        photoAdapter.setTypeListener(photoTypeListener);
        binding.photoList.setAdapter(photoAdapter);
    }

    private void initData() {
        if (null == site) {
            showMsg("无效的站点信息");
            return;
        }
        viewModel = new ViewModelProvider(getActivity()).get(StatusAndDataVM.class);
        if (null == viewModel.getStatusLiveData().getValue() || TextUtils.isEmpty(viewModel.getStatusLiveData().getValue().getProjectId())
                || TextUtils.isEmpty(viewModel.getStatusLiveData().getValue().getTaskId())) {
            showMsg("无效的项目信息");
            return;
        }
        binding.siteHeight.setText(String.valueOf(site.stationHeight));
        binding.buildingHeight.setText(String.valueOf(site.buildingHeight));
        binding.buildingDistance.setText(String.valueOf(site.buildingDistance));
        binding.buildingWidth.setText(String.valueOf(site.buildingWidth));
    }

    private SurveyCellListAdapter.SurveyCellListener cellListener = new SurveyCellListAdapter.SurveyCellListener() {
        @Override
        public void onCellEdit(CellBean cell) {
            EditCellFragment fragment = new EditCellFragment(site, cell);
            if (null != getActivity() && getActivity() instanceof BasicActivity) {
                ((BasicActivity) getActivity()).push(fragment);
            }
        }

        @Override
        public void onCellDelete(CellBean cell) {
            if (null == cell || TextUtils.isEmpty(cell.sectorEqmKey)) {
                showMsg("无效的小区信息");
                return;
            }
            new SVAlertDialog().content("是否删除该站点小区?")
                    .confirmContent("删除")
                    .cancelContent("取消")
                    .setConfirmListener(v -> {
                        DeleteCellImpl.getInstance().deleteCell(cell.taskId, cell, new DeleteCellImpl.Callback() {
                            @Override
                            public void onBefore(Request request) {
                                showLoadingDialog();
                            }

                            @Override
                            public void onAfter() {
                                dismissLoadingDialog();
                            }

                            @Override
                            public void onFailure(ErrorBean errorBean) {
                                showMsg("删除工参失败");
                            }

                            @Override
                            public void onResponse(Boolean aBoolean) {
                                if (null != aBoolean && aBoolean) {
                                    showMsg("删除工参成功");
                                    site.cells.remove(cell);
                                    cellAdapter.notifyDataSetChanged();
                                } else {
                                    showMsg("删除工参失败");
                                }
                            }
                        });

                    })
                    .show(getChildFragmentManager());
        }
    };

    /**
     * 点击拍照 和  点击进入照片列表的回调
     */
    private SitePhotoTypeListAdapter.PhotoTypeListener photoTypeListener = new SitePhotoTypeListAdapter.PhotoTypeListener() {
        @Override
        public void onCameraClicked(SitePhotoTypeBean bean) {
            if (!SiteUtil.checkPhotoDir(site) || null == bean || TextUtils.isEmpty(bean.typeFileDir)) {
                return;
            }
            Intent i = new Intent(getContext(), CameraActivity.class);
            i.putExtra("photoType", bean.typeFileDir);
            i.putExtra("photoDir", SiteUtil.getDirPathByImageType(site, bean.typeFileDir));
            startActivity(i);
        }

        @Override
        public void onPhotoGalleryClicked(SitePhotoTypeBean bean) {
            if (!SiteUtil.checkPhotoDir(site) || null == bean || TextUtils.isEmpty(bean.typeFileDir)) {
                return;
            }
            PhotoGridFragment fragment = new PhotoGridFragment();
            Bundle b = new Bundle();
            b.putParcelable("site", site);
            b.putString("photoType", bean.typeFileDir);
            fragment.setArguments(b);
            actPush(fragment);
        }
    };

    /**
     * 点击了确定 上传站点信息
     */
    private void onConfirmClicked() {
        if (null == site || !site.isAvailable()) {
            showMsg("无效的站点信息");
            return;
        }
        double siteHeight = 0;
        double buildingHeight = 0;
        double buildingDistance = 0;
        double buildingWidth = 0;

        try {
            if (TextUtils.isEmpty(binding.siteHeight.getText())) {
                siteHeight = 0;
            } else {
                siteHeight = Double.parseDouble(binding.siteHeight.getText().toString().trim());
            }
            if (TextUtils.isEmpty(binding.buildingHeight.getText())) {
                buildingHeight = 0;
            } else {
                buildingHeight = Double.parseDouble(binding.buildingHeight.getText().toString().trim());
            }
            if (TextUtils.isEmpty(binding.buildingDistance.getText())) {
                buildingDistance = 0;
            } else {
                buildingDistance = Double.parseDouble(binding.buildingDistance.getText().toString().trim());
            }
            if (TextUtils.isEmpty(binding.buildingWidth.getText())) {
                buildingWidth = 0;
            } else {
                buildingWidth = Double.parseDouble(binding.buildingWidth.getText().toString().trim());
            }
            if (siteHeight < 0 || buildingHeight < 0 || buildingDistance < 0 || buildingWidth < 0) {
                throw new NumberFormatException();
            }
            site.stationHeight = String.valueOf(siteHeight);
            site.buildingHeight = String.valueOf(buildingHeight);
            site.buildingDistance = String.valueOf(buildingDistance);
            site.buildingWidth = String.valueOf(buildingWidth);
        } catch (NumberFormatException e) {
            GCLogger.error("http", "站点勘测第二步 数值转换错误:" + e.getMessage());
            showMsg("站点周边勘测数值错误,请重新填写");
            return;
        }
        // 检查图片并上传图片
        // 检查未上传的所有图片
        List<SitePhotoBean> uploadPhoto = SiteUtil.getNeedUploadPhotos(site);
        if (null != uploadPhoto && !uploadPhoto.isEmpty()) {
            // 上传照片 一张一张上传
            // 记录进度
            netProgress = uploadPhoto.size();
            uploadImage(uploadPhoto, 0);
        } else {
            uploadSiteInfo();
        }
    }

    private void uploadImage(List<SitePhotoBean> photos, int index) {
        if (null == photos || photos.isEmpty() || index < 0) {
            return;
        }
        if (index >= photos.size()) {
            // 上传完毕了
            uploadSiteInfo();
            return;
        }
        SitePhotoBean item = photos.get(index);
        UploadImageImpl.getInstance().uploadImage(item.projectId, item.groupId, item.siteId,
                item.photoType, 0, Arrays.asList(item.localFilePath), new UploadImageImpl.Callback() {
                    @Override
                    public void onBefore(Request request) {
                        showLoadingDialog();
                    }

                    @Override
                    public void onAfter() {
                        dismissLoadingDialog();
                    }

                    @Override
                    public void onFailure(ErrorBean errorBean) {
                        // TODO 敏感信息
                        GCLogger.error("error", "上传失败 : " + item.localFilePath);
                        showMsg("照片上传失败");
                    }

                    @Override
                    public void onResponse(Boolean aBoolean) {
                        if (null != aBoolean && aBoolean) {
                            File f = new File(item.localFilePath);
                            boolean deleted = f.delete();
                            GCLogger.error("error", "文件:" + f.getPath() + " 是否删除?" + deleted);
                            uploadImage(photos, index + 1);
                        } else {
                            showMsg("照片上传失败");
                        }
                    }
                });
    }

    private void uploadSiteInfo() {
        CreateOrUpdateSurveyImpl.getInstance().createOrUpdate(site, new CreateOrUpdateSurveyImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean errorBean) {
                showMsg("站点信息更新失败");
                binding.confirm.setEnabled(true);
            }

            @Override
            public void onResponse(Boolean aBoolean) {
                if (null != aBoolean && aBoolean) {
                    showMsg("站点信息更新成功");
                    backPressed();
                } else {
                    showMsg("站点信息更新失败");
                }
                binding.confirm.setEnabled(true);
            }
        });
    }

    // 检查网络访问进度
    private int netProgress = 0;

    private boolean checkNetworkProgress() {
        netProgress--;
        if (netProgress <= 0) {
            netProgress = 0;
            return true;
        }
        return false;
    }


    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
