package com.zb.plugina.activity;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.zb.plugina.R;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tv = findViewById(R.id.text);
        tv.setText(new Date() + "");

        TestReceiver tr = new TestReceiver();
        registerReceiver(tr, new IntentFilter("onclick"));
    }

    public void onReceiverSend(View view) {

        sendBroadcast(new Intent("onclick"));
    }


    class TestReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Snackbar.make( MainActivity.this.findViewById(R.id.text), "aaa", Snackbar.LENGTH_SHORT).show();
            MainActivity.this.findViewById(R.id.text).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(MainActivity.this, FullscreenActivity.class);
                    MainActivity.this.startActivity(i);
                }
            }, 2000);
        }
    }
}
