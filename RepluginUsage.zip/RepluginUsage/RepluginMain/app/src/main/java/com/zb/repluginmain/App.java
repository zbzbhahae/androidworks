package com.zb.repluginmain;

import com.qihoo360.replugin.RePluginApplication;

/**
 * Created by Administrator on 2021/10/17.
 */

public class App extends RePluginApplication {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
