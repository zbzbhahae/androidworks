package com.huawei.genexcloud.survey;

import android.app.Application;
import android.content.Context;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.CoordType;
import com.baidu.mapapi.SDKInitializer;
import com.huawei.genexcloud.httplib.OkHttpManager;
import com.huawei.genexcloud.logger.GCLogger;
import com.tencent.mmkv.MMKV;

public class BaseApplication extends Application {

    private static Context context;

    public static Context getAppContext() {
        return context;
    }

    @Override
    public void onCreate() {
        context = this;
        super.onCreate();

        initBaiduMap();
        OkHttpManager.initClient(this);
        GCLogger.init(BuildConfig.DEBUG);
        MMKV.initialize(this);
    }

    private void initBaiduMap() {
        try {
            SDKInitializer.setAgreePrivacy(getAppContext(), true);
            LocationClient.setAgreePrivacy(true);
            SDKInitializer.initialize(this.getApplicationContext());
            SDKInitializer.setCoordType(CoordType.BD09LL);
        } catch (Exception e) {
            GCLogger.error("error", e.toString());
        }
    }
}
