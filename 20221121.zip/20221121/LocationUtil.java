package com.huawei.genexcloud.survey.util.map;

import android.content.Context;
import android.location.Geocoder;

import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.utils.CoordinateConverter;
import com.huawei.genexcloud.logger.GCLogger;

/**
 * 关于百度地图定位的工具类
 */
public class LocationUtil {

    private static LocationClient locationClient;

    /**
     * 获取定位客户端
     * @param context
     * @return
     */
    public static LocationClient getLocationClient(Context context) {
        if (null == context) {
            return null;
        }
        if (null == locationClient) {
            synchronized (LocationUtil.class) {
                if (null == locationClient) {
                    try {
                        locationClient = new LocationClient(context);
                    } catch (Exception e) {
                        GCLogger.error("error", "定位组件初始化失败");
                    }
                }
            }
        }
        return locationClient;
    }

    /**
     * 开启定位
     * @param myLocationListener
     */
    public static void startLocating(Context context, BDLocationListener myLocationListener) {
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true); // 打开gps
        option.setCoorType("bd09ll"); // 设置坐标类型
        option.setScanSpan(30_000); // 定位间隔

        locationClient = getLocationClient(context);
        if (null == locationClient) {
            return;
        }
        //设置locationClientOption
        locationClient.setLocOption(option);
        //注册LocationListener监听器
        locationClient.registerLocationListener(myLocationListener);
        //开启地图定位图层
        locationClient.start();
    }

    /**
     * 查询经纬度地理位置的文字地址
     * @param baiduLL 百度地图坐标
     * @param listener 回调
     */
    public static GeoCoder searchLocationAddress(LatLng baiduLL, GCReverseGeoCoderResultListener listener) {
        if (null == baiduLL || null == listener) {
            if (null != listener) {
                listener.onReverseGeoResult("");
            }
            return null;
        }
        // 逆地理查询
        GeoCoder mCoder = GeoCoder.newInstance();
        mCoder.setOnGetGeoCodeResultListener(listener);
        ReverseGeoCodeOption option = new ReverseGeoCodeOption();
        option.location(baiduLL).newVersion(1).radius(100);
        mCoder.reverseGeoCode(option);
        return mCoder;
    }

    /**
     * 查询经纬度地理位置的文字地址
     * @param gpsLL     gps地理位置
     * @param listener  回调
     * @return
     */
    public static GeoCoder searchGPSLocationAddress(LatLng gpsLL, GCReverseGeoCoderResultListener listener) {
        LatLng baiduLL = gpsToBaidu(gpsLL);
        return searchLocationAddress(baiduLL, listener);
    }

    /**
     * 将gps坐标转换成百度坐标
     * @param latLng
     * @return
     */
    public static LatLng gpsToBaidu(LatLng latLng) {
        if (null == latLng) {
            return null;
        }
        CoordinateConverter converter = new CoordinateConverter()
                .from(CoordinateConverter.CoordType.GPS)
                .coord(latLng);
        LatLng result = converter.convert();
        return result;
    }


    private static final double PI = 3.1415926535897932384626;
    private static final double A = 6378245.0;
    private static final double EE = 0.00669342162296594323;

//: Change BD-09 to Gcj-02

    public static LatLng baiduToGps(LatLng latLng) {
        return gcj02ToGps(baiduToGcj02(latLng));
    }

    public static LatLng baiduToGcj02(LatLng baiduLL) {
        double x = baiduLL.longitude - 0.0065;

        double y = baiduLL.latitude - 0.006;

        double z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * PI);

        double theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * PI);

        return new LatLng(z * Math.sin(theta), z * Math.cos(theta));

    }

//: Change Gcj-02 to WGS-84

    public static LatLng gcj02ToGps(LatLng gcjLL) {
        LatLng wgs84_pos = trans(new LatLng(gcjLL.latitude, gcjLL.longitude));

        double gcj02_lon = wgs84_pos.longitude * 2 - wgs84_pos.longitude;

        double gcj02_lat = wgs84_pos.latitude * 2 - wgs84_pos.latitude;

        return new LatLng(gcj02_lat, gcj02_lon);

    }

//: Private func

    private static LatLng trans(LatLng latLng) {
        double dLat = transformLat(latLng.longitude - 105.0, latLng.latitude- 35.0);

        double dLon = transformLon(latLng.longitude - 105.0, latLng.latitude - 35.0);

        double radLat = latLng.latitude / 180.0 * PI;

        double magic = Math.sin(radLat);

        magic = 1 - EE * magic * magic;

        double sqrtMagic = Math.sqrt(magic);

        dLat = (dLat * 180.0) / ((A * (1 - EE)) / (magic * sqrtMagic) * PI);

        dLon = (dLon * 180.0) / (A / sqrtMagic * Math.cos(radLat) * PI);

        double mgLat = latLng.latitude + dLat;

        double mgLon = latLng.latitude + dLon;

        return new LatLng(mgLat, mgLon);

    }

    private static double transformLat(double x, double y) {
        double ret = -100.0 + 2.0 * x + 3.0 * y;
        ret += 0.2 * y * y + 0.1 * x * y;
        ret += 0.2 * Math.sqrt(Math.abs(x));
        ret += (20.0 * Math.sin(6.0 * x * PI) + 20.0 * Math.sin(2.0 * x * PI)) * 2.0 / 3.0;
        ret += (20.0 * Math.sin(y * PI) + 40.0 * Math.sin(y / 3.0 * PI)) * 2.0 / 3.0;
        ret += (160.0 * Math.sin(y / 12.0 * PI) + 320 * Math.sin(y * PI / 30.0)) * 2.0 / 3.0;
        return ret;

    }

    private static double transformLon(double x, double y) {

        double ret = 300.0 + x + 2.0 * y;
        ret += 0.1 * x * x + 0.1 * x * y;
        ret += 0.1 * Math.sqrt(Math.abs(x));
        ret += (20.0 * Math.sin(6.0 * x * PI) + 20.0 * Math.sin(2.0 * x * PI)) * 2.0 / 3.0;
        ret += (20.0 * Math.sin(x * PI) + 40.0 * Math.sin(x / 3.0 * PI)) * 2.0 / 3.0;
        ret += (150.0 * Math.sin(x / 12.0 * PI) + 300.0 * Math.sin(x / 30.0 * PI)) * 2.0 / 3.0;
        return ret;

    }
}
