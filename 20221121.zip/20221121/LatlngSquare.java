package com.huawei.genexcloud.survey.util.map;

import com.baidu.mapapi.model.LatLng;

import java.util.HashMap;
import java.util.Map;

/**
 * 生成一个gps为坐标系的 地理正方形围栏
 */
public class LatlngSquare {
    public LatLng leftTopPoint;
    public LatLng leftBottomPoint;
    public LatLng rightTopPoint;
    public LatLng rightBottomPoint;
    public LatLng centerPoint;

    /**
     * 生成正方形围栏
     * @param centerPoint   注意：该类坐标系均为GPS坐标系，在百度地图上显示需要转换
     * @param distance      范围 米
     * @return
     */
    public static LatlngSquare createSquare(LatLng centerPoint, int distance) {
        if (null == centerPoint || distance <= 0) {
            return null;
        }
        LatlngSquare square = new LatlngSquare();
        square.centerPoint = centerPoint;
        Map<String, Double> pointArgs = getAround(centerPoint.latitude, centerPoint.longitude, distance);
        LatLng leftTopPoint = new LatLng(pointArgs.get("maxLat"), pointArgs.get("minLng"));
        LatLng leftBottomPoint = new LatLng(pointArgs.get("minLat"), pointArgs.get("minLng"));
        LatLng rightTopPoint = new LatLng(pointArgs.get("maxLat"), pointArgs.get("maxLng"));
        LatLng rightBottomPoint = new LatLng(pointArgs.get("minLat"), pointArgs.get("maxLng"));
        square.leftTopPoint = leftTopPoint;
        square.leftBottomPoint = leftBottomPoint;
        square.rightTopPoint = rightTopPoint;
        square.rightBottomPoint = rightBottomPoint;
        return square;
    }


    /**
     * 获取当前用户一定距离以内的经纬度值
     * <p>
     * 单位米 return minLat
     * <p>
     * 最小经度 minLng
     * <p>
     * 最小纬度 maxLat
     * <p>
     * 最大经度 maxLng
     * <p>
     * 最大纬度 minLat
     */

    public static Map getAround(double latitude, double longitude, double radius) {

        Map<String, Double> map = new HashMap();

        double degree = (24901 * 1609) / 360.0; // 获取每度


        Double mpdLng = Double.parseDouble((degree * Math.cos(latitude * (Math.PI / 180)) + "").replace("-", ""));

        Double dpmLng = 1 / mpdLng;

        Double radiusLng = dpmLng * radius;

        //获取最小经度

        Double minLng = longitude - radiusLng;

        // 获取最大经度

        Double maxLng = longitude + radiusLng;

        Double dpmLat = 1 / degree;

        Double radiusLat = dpmLat * radius;

        // 获取最小纬度

        Double minLat = latitude - radiusLat;

        // 获取最大纬度

        Double maxLat = latitude + radiusLat;

        map.put("minLat", minLat);

        map.put("maxLat", maxLat);

        map.put("minLng", minLng);

        map.put("maxLng", maxLng);

        return map;

    }

}
