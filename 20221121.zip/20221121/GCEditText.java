package com.huawei.genexcloud.survey.widget;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * 可以限制输入内容的EditText
 * 包含 整数输入 或者 小数输入 小数可以指定小数点后位数
 */
public class GCEditText extends androidx.appcompat.widget.AppCompatEditText {

    public static final int INPUT_NONE = 0; // 不做额外限制
    public static final int INPUT_NUMBER = 1; // 整型数字
    public static final int INPUT_FLOAT = 2; // 小数

    public static final int DEFAULT_INPUT_NUMBER = 0; // 小数默认数字

    private int floatDigits = -1; // 设置小数点后位数

    private int inputType = INPUT_NONE;

    public GCEditText(@NonNull Context context) {
        super(context);
        init();
    }

    public GCEditText(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GCEditText(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private final TextWatcher textWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String content = getInput(s);
            removeTextChangedListener(this);
            setText(content);
            addTextChangedListener(this);
            setSelection(getText().length());
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    private void init() {
        this.addTextChangedListener(textWatcher);
    }

    public void setInputMode(int mode) {
        inputType = mode;
        setText(getInput(getText()));
    }

    public void setFloatDigits(int floatDigits) {
        this.floatDigits = floatDigits;
        setText(getInput(getText()));
    }


    /**
     * 对内容进行过滤
     * @param s
     * @return
     */
    private String getInput(CharSequence s) {
        StringBuilder sb;
        switch (inputType) {
            case INPUT_NUMBER:
                if (null == s || s.length() == 0) {
                    return "";
                }
                sb = new StringBuilder();
                for (int i=0; i<s.length(); i++) {
                    char c = s.charAt(i);
                    if (sb.length() > 9) {
                        // 不能超过9位数
                        continue;
                    }
                    if (c == '-') {
                        if (i == 0) {
                            sb.append(c);
                        } else {
                            continue;
                        }
                    }
                    if (c == '0') {
                        if (i == 0 || (s.charAt(0) == '-' && (i == 1))
                                || (i == 2 && (s.charAt(0) == '-' && s.charAt(1) != '0')
                                    || (s.charAt(0) > '0' && s.charAt(0) <= '9')) || i > 2) {
                            // 第一位可以是0 或者第一位是负号 第二位可以是0 或者 第一位不是负号且不是0 或者第一位是负号第二位不是0，第三位可以是0
                            sb.append(c);
                        }
                    } else if (c >= '1' && c <= '9' && !(i == 2 && s.charAt(0) == '-' && s.charAt(1) == '0')
                                && !(i == 1 && s.charAt(0) == '0')) {
                        sb.append(c);
                    } else {
                        continue;
                    }
                }
                return sb.toString();
            case INPUT_FLOAT:
                // 可以填写小数
                if (null == s || s.length() == 0) {
                    return "";
                }
                int digits = 0;
                boolean hasDot = false;
                sb = new StringBuilder();
                for (int i=0; i<s.length(); i++) {
                    char c = s.charAt(i);
                    if (sb.length() > 12) {
                        // 限制12位
                        continue;
                    }
                    if (c == '-') {
                        if (i == 0) {
                            sb.append(c);
                        } else {
                            continue;
                        }
                    } else if (c == '.') {
                        // 不可以是 . 或者-. 或者多个.
                        if (i != 0 && s.charAt(i-1) != '-' && !hasDot) {
                            sb.append(c);
                            hasDot = true;
                        } else {
                            continue;
                        }
                    } else if (c == '0') {
                        // 第一位是0或者 -0 x0 x.0  不可以是00 -00
                        if ( (i == 1 && s.charAt(0) == '0') || (i == 2 && s.charAt(0) == '-' && s.charAt(1) == '0')) {
                            continue;
                        } else {
                            if (hasDot) {
                                digits++;
                            }
                            if (floatDigits != -1 && digits > floatDigits) {
                                // 超过小数点位数
                                return sb.toString();
                            } else {
                                sb.append(c);
                            }
                        }
                    } else if (c >= '1' && c <= '9') {
                        // 不可以是-0x 或者0x
                        if ( (i == 1 && s.charAt(0) == '0') || (i == 2 && s.charAt(0) == '-' && s.charAt(1) == '0') ) {
                            continue;
                        }
                        if (hasDot) {
                            digits++;
                        }
                        if (floatDigits != -1 && digits > floatDigits) {
                            // 超过小数点位数
                            return sb.toString();
                        } else {
                            sb.append(c);
                        }
                    } else {
                        continue;
                    }
                }
                return sb.toString();
            case INPUT_NONE:
            default:
                return s.toString();
        }
    }
}
