package com.huawei.genexcloud.survey.util.map;

import android.text.TextUtils;

import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;

/**
 * 通过经纬度查询具体地址的回调
 */
public abstract class GCReverseGeoCoderResultListener implements OnGetGeoCoderResultListener {
    @Override
    public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {

    }

    @Override
    public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {
        if (reverseGeoCodeResult == null || reverseGeoCodeResult.error != SearchResult.ERRORNO.NO_ERROR) {
            //没有找到检索结果
            return;
        } else {
            //详细地址
            String address = reverseGeoCodeResult.getAddressDetail().toString();
            ReverseGeoCodeResult.AddressComponent detail = reverseGeoCodeResult.getAddressDetail();
            StringBuilder sb = new StringBuilder();
            if (null != detail) {
                if (!TextUtils.isEmpty(detail.province)) {
                    sb.append(detail.province);
                }
                if (!TextUtils.isEmpty(detail.city)) {
                    sb.append(detail.city);
                }
                if (!TextUtils.isEmpty(detail.district)) {
                    sb.append(detail.district);
                }
                if (!TextUtils.isEmpty(detail.town)) {
                    sb.append(detail.town);
                }
                if (!TextUtils.isEmpty(detail.street)) {
                    sb.append(detail.street);
                    if (!TextUtils.isEmpty(detail.streetNumber)) {
                        sb.append(detail.streetNumber);
                    }
                }
            }
            onReverseGeoResult(sb.toString());
            //行政区号
            int adCode = reverseGeoCodeResult. getCityCode();
        }
    }

    public abstract void onReverseGeoResult(String address);
}
