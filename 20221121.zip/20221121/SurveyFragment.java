package com.huawei.genexcloud.survey.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolygonOptions;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.huawei.genexcloud.httplib.ErrorBean;
import com.huawei.genexcloud.logger.GCLogger;
import com.huawei.genexcloud.survey.R;
import com.huawei.genexcloud.survey.base.BasicFragment;
import com.huawei.genexcloud.survey.bean.SimulationTaskBean;
import com.huawei.genexcloud.survey.bean.SiteBean;
import com.huawei.genexcloud.survey.bean.UserStatusBean;
import com.huawei.genexcloud.survey.data.MainShareViewModel;
import com.huawei.genexcloud.survey.databinding.FragmentSurveyBinding;
import com.huawei.genexcloud.survey.dialog.OnDialogDismissListener;
import com.huawei.genexcloud.survey.dialog.StartSurveySiteDialog;
import com.huawei.genexcloud.survey.dialog.TaskSelectDialog;
import com.huawei.genexcloud.survey.http.gcpt.QueryTaskListImpl;
import com.huawei.genexcloud.survey.http.gcpt.QueryTaskParamsImpl;
import com.huawei.genexcloud.survey.util.AppUtil;
import com.huawei.genexcloud.survey.util.map.CoordinateTransformUtil;
import com.huawei.genexcloud.survey.util.map.GCReverseGeoCoderResultListener;
import com.huawei.genexcloud.survey.util.map.LatlngSquare;
import com.huawei.genexcloud.survey.util.map.LocationUtil;
import com.huawei.genexcloud.survey.util.map.MapUtil;
import com.huawei.genexcloud.survey.util.map.SiteUtil;
import com.huawei.genexcloud.survey.widget.GCEditText;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;

public class SurveyFragment extends BasicFragment implements View.OnClickListener {

    private FragmentSurveyBinding binding;
    // ViewModel共享数据
    private MainShareViewModel viewModel;

    private List<Overlay> siteOverlay;

    private BaiduMap map;
    // 地图中心点
    private LatLng mapCenter;
    // 用户定位位置
    private LatLng myLocation;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSurveyBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
        initData();
    }

    private void initView() {
        MapUtil.initBaiduMap(binding.map, onMapLoadedCallback, onMapStatusChangeListener, onMapClickListener, onMarkerClickListener);
        binding.titleLayout.setOnClickListener(this);
        binding.surveyTask.setOnClickListener(this);
        binding.myLocationButton.setOnClickListener(this);
        map = binding.map.getMap();

        double distance = DistanceUtil.getDistance(new LatLng(34, 108), new LatLng(35, 108));
        double distance2 = DistanceUtil.getDistance(new LatLng(34, 108), new LatLng(34, 109));
        double distance3 = DistanceUtil.getDistance(LocationUtil.gpsToBaidu(new LatLng(34, 108)), LocationUtil.gpsToBaidu(new LatLng(35, 108)));
        double distance4 = DistanceUtil.getDistance(LocationUtil.gpsToBaidu(new LatLng(34, 108)), LocationUtil.gpsToBaidu(new LatLng(34, 109)));

        GCLogger.error("view", "distance : " + distance);
        GCLogger.error("view", "distance : " + distance2);
        GCLogger.error("view", "distance : " + distance3);
        GCLogger.error("view", "distance : " + distance4);
    }

    private void initData() {
        viewModel = new ViewModelProvider(getActivity()).get(MainShareViewModel.class);
        viewModel.getStatusLiveData().observe(getViewLifecycleOwner(), new Observer<UserStatusBean>() {
            @Override
            public void onChanged(UserStatusBean userStatusBean) {
                GCLogger.error("view", "选中的项目信息 : " + userStatusBean.toString());
                onNewTaskSelected(userStatusBean);
            }
        });

        LocationUtil.startLocating(getContext(), new BDLocationListener() {
            @Override
            public void onReceiveLocation(BDLocation bdLocation) {
                //mapView 销毁后不在处理新接收的位置
                if (bdLocation == null || null == binding || binding.map == null){
                    return;
                }
                MyLocationData locData = new MyLocationData.Builder()
                        .accuracy(bdLocation.getRadius())
                        // 此处设置开发者获取到的方向信息，顺时针0-360
                        .latitude(bdLocation.getLatitude())
                        .longitude(bdLocation.getLongitude()).build();
                myLocation = new LatLng(bdLocation.getLatitude(), bdLocation.getLongitude());
                GCLogger.error("view", "定位位置：" + bdLocation.getLatitude() + "  " + bdLocation.getLongitude());
                LocationUtil.searchLocationAddress(new LatLng(32.207461322, 104.85769432), new GCReverseGeoCoderResultListener() {
                    @Override
                    public void onReverseGeoResult(String address) {
                        int a = 1;
                        int c = a++;
                        GCLogger.error("view", "获取地址:" + address);
                    }
                });
                map.setMyLocationData(locData);
            }
        });
    }

    /**
     * 选择了一个新的任务
     *
     * @param statusBean
     */
    private void onNewTaskSelected(UserStatusBean statusBean) {
        if (null != statusBean && null != statusBean.getProjectInfo() && null != statusBean.getTaskInfo()) {
            queryTaskData();
        } else {
            // 只选择了项目 还没选择任务
        }
    }

    /**
     * 选中一个任务后,去获取相关数据,包括工参信息
     */
    private void queryTaskData() {
        UserStatusBean status = viewModel.getStatusLiveData().getValue();
        if (null == status) {
            showMsg("请先选择一个任务");
            return;
        }
        String projectId = status.getProjectId();
        String taskId = status.getTaskId();
        String projectName = status.getProjectName();
        String groupName = status.getGroupName();
        String taskName = status.getTaskName();
        if (TextUtils.isEmpty(projectId) || TextUtils.isEmpty(taskId)) {
            showMsg("请先选择一个任务");
            return;
        }
        // 设置项目信息显示
        binding.projectText.setText("项目: " + projectName);
        binding.groupText.setText("分组: " + groupName);
        binding.taskText.setText("任务: " + taskName);

        getTaskSiteInfo(projectId, taskId);
        getSimulationInfo(projectId);
    }

    /**
     * 获取任务工参信息
     *
     * @param projectId
     * @param taskId
     */
    private void getTaskSiteInfo(String projectId, String taskId) {
        // 查询任务工参信息
        QueryTaskParamsImpl.getInstance().getTaskParams(projectId, taskId, new QueryTaskParamsImpl.Callback() {
            @Override
            public void onBefore(Request request) {
                showLoadingDialog();
            }

            @Override
            public void onAfter() {
                if (!isContextAvailable()) {
                    return;
                }
                dismissLoadingDialog();
            }

            @Override
            public void onFailure(ErrorBean errorBean) {
                showMsg("该任务未查询到工参信息");
            }

            @Override
            public void onResponse(List<SiteBean> siteBeans) {
                binding.map.getMap().clear();
                if (null == siteBeans || siteBeans.isEmpty()) {
                    // TODO
                    return;
                } else {
                    List<OverlayOptions> siteOptions = SiteUtil.getSiteDetailMarkerOptions(getContext(), siteBeans);
                    if (null != siteOverlay) {
                        siteOverlay.clear();
                        siteOverlay = null;
                    }
                    if (null != siteOptions && !siteOptions.isEmpty()) {
                        siteOverlay = binding.map.getMap().addOverlays(siteOptions);
                    }
                }
            }
        });
    }

    /**
     * 查询仿真任务信息
     */
    private void getSimulationInfo(String projectId) {
        // 查询仿真任务信息
        QueryTaskListImpl.getInstance().getTaskList(projectId, new QueryTaskListImpl.Callback() {
            @Override
            public void onFailure(ErrorBean errorBean) {
                // 错误处理
            }

            @Override
            public void onResponse(List<SimulationTaskBean> simulationTaskBeans) {
                viewModel.updateSimulationTaskList(simulationTaskBeans);
            }
        });
    }


    /**
     * 选择项目任务
     */
    private void showTaskSelectDialog() {
        TaskSelectDialog dialog = new TaskSelectDialog();
        dialog.show(getChildFragmentManager(), "taskSelect");
    }

    @Override
    public void onClick(View v) {
        if (AppUtil.isFastDoubleClick()) {
            return;
        }
        if (v == binding.titleLayout) {
            showTaskSelectDialog();
        } else if (v == binding.surveyTask) {
            // 进入仿真任务界面
//            actPush(new SimulationTaskListFragment());
            actPush(new SurveyStepOneFragment());
        } else if (v == binding.myLocationButton) {
            if (null != myLocation) {
                MapUtil.transToLocation(map, myLocation);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.map.onResume();
        // 如果选中了相关任务 去获取仿真任务列表信息
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.map.onPause();
    }

    @Override
    public void onDestroyView() {
        binding = null;
        map = null;
        super.onDestroyView();
    }

    /***************************** 地图回调信息 ****************/
    private BaiduMap.OnMapLoadedCallback onMapLoadedCallback = new BaiduMap.OnMapLoadedCallback() {
        @Override
        public void onMapLoaded() {
            GCLogger.error("map", "地图加载完毕");
        }
    };

    private BaiduMap.OnMapStatusChangeListener onMapStatusChangeListener = new BaiduMap.OnMapStatusChangeListener() {
        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus) {
            GCLogger.error("map", "OnMapStatusChangeListener::onMapStatusChangeStart");
        }

        @Override
        public void onMapStatusChangeStart(MapStatus mapStatus, int i) {
            GCLogger.error("map", "OnMapStatusChangeListener::onMapStatusChangeStart");
//            int REASON_GESTURE = 1;
//            int REASON_API_ANIMATION = 2;
//            int REASON_DEVELOPER_ANIMATION = 3;
        }

        @Override
        public void onMapStatusChange(MapStatus mapStatus) {
            GCLogger.error("map", "OnMapStatusChangeListener::onMapStatusChange");
        }

        @Override
        public void onMapStatusChangeFinish(MapStatus mapStatus) {
            mapCenter = mapStatus.target;
            map.clear();
            //定义Maker坐标点
            double[] centerPointArray = CoordinateTransformUtil.bd09towgs84(mapCenter.longitude, mapCenter.latitude);
            LatlngSquare square = LatlngSquare.createSquare(new LatLng(centerPointArray[1], centerPointArray[0]), 800);
            List<LatLng> points = new ArrayList<>();
            points.add(LocationUtil.gpsToBaidu(square.leftTopPoint));
            points.add(LocationUtil.gpsToBaidu(square.leftBottomPoint));
            points.add(LocationUtil.gpsToBaidu(square.rightBottomPoint));
            points.add(LocationUtil.gpsToBaidu(square.rightTopPoint));

            //构造PolygonOptions
            PolygonOptions mPolygonOptions = new PolygonOptions()
                    .points(points)
                    .fillColor(0xAAFFFF00) //填充颜色
                    .stroke(new Stroke(5, 0xAA00FF00)); //边框宽度和颜色

//在地图上显示多边形
            map.addOverlay(mPolygonOptions);
            GCLogger.error("map", "OnMapStatusChangeListener::onMapStatusChangeFinish");
        }
    };

    private BaiduMap.OnMapClickListener onMapClickListener = new BaiduMap.OnMapClickListener() {
        @Override
        public void onMapClick(LatLng latLng) {

            GCLogger.error("map", "OnMapClickListener::onMapClick");
        }

        @Override
        public void onMapPoiClick(MapPoi mapPoi) {
            GCLogger.error("map", "OnMapClickListener::onMapPoiClick");
        }
    };

    private InfoWindow clickMarkerIndicator;
    private BaiduMap.OnMarkerClickListener onMarkerClickListener = new BaiduMap.OnMarkerClickListener() {
        @Override
        public boolean onMarkerClick(Marker marker) {
            GCLogger.error("map", "OnMarkerClickListener::onMarkerClick");
            // 点击了marker
            clearMarkIndicator();
            if (null == marker.getExtraInfo() && null == marker.getExtraInfo().getParcelable("data")
                    || !(marker.getExtraInfo().get("data") instanceof SiteBean)) {
                return false;
            }
            BitmapDescriptor cacheDescriptor = BitmapDescriptorFactory.fromResource(R.drawable.icon_spin);
            clickMarkerIndicator = new InfoWindow(cacheDescriptor, marker.getPosition(), 0, null);
            map.showInfoWindow(clickMarkerIndicator);
            map.animateMapStatus(MapStatusUpdateFactory.newLatLng(marker.getPosition()));
            SiteBean siteBean = (SiteBean) marker.getExtraInfo().getParcelable("data");

            // 是否勘测过
            if (true) {
                StartSurveySiteDialog startSurveySiteDialog = new StartSurveySiteDialog();
                Bundle b = new Bundle();
                b.putParcelable("data", siteBean);
                startSurveySiteDialog.setArguments(b);
                startSurveySiteDialog.show(getChildFragmentManager(), "startSurveySite");
                startSurveySiteDialog.setOnDialogDismissListener(new OnDialogDismissListener() {
                    @Override
                    public void onDismiss() {
                        clearMarkIndicator();
                    }
                });
                return true;
            }
            return false;
        }
    };

    /**
     * 清除marker的点击大头针图标
     */
    private void clearMarkIndicator() {
        if (null != clickMarkerIndicator) {
            map.hideInfoWindow(clickMarkerIndicator);
        }
    }

    /******************************************************************************************/

}
