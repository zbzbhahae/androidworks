package com.huawei.genexcloud.ltequality.http;

import android.text.TextUtils;

import com.huawei.genexcloud.ltequality.activity.datastore.TestData;
import com.huawei.genexcloud.ltequality.base.BaseApplication;
import com.huawei.genexcloud.ltequality.base.Result;
import com.huawei.genexcloud.ltequality.bean.User;
import com.huawei.genexcloud.ltequality.common.Constants;
import com.huawei.genexcloud.ltequality.db.DBManager;
import com.huawei.genexcloud.ltequality.dongcha.bean.DimensionCityBean;
import com.huawei.genexcloud.ltequality.dongcha.bean.NationalDataBean;
import com.huawei.genexcloud.ltequality.dongcha.bean.ResultBean;
import com.huawei.genexcloud.ltequality.utils.ParseJsonUtils;
import com.huawei.genexcloud.ltequality.utils.log.GCLogger;
import com.huawei.genexcloud.ltequality.utils.log.Module;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by zWX1094027 on 2021/9/8.
 */

public class ApiService {

    public static final String TAG = "ApiService";

    public static final String HOST = Constants.HOST_ADDRESS_RNAC_INSIGHTASSESS;

    //洞察结论和红线城市 4G的
    public static final String I_RED_CITY_AND_MAP = "/ReadLineQuotaUnder/getData";
    //获取4g关键指标
    public static final String I_LTE_QUOTA = "/network/query4GQuota";
    //获取5g关键指标
    public static final String I_NR_QUOTA = "/network/query5GQuota";
    //查询用户权限
    public static final String I_USER_PERMISSION = "queryUserAuth";
    //查询城市网络性能得分的数据(网格图)
    public static final String I_CITY_SPIDER_INFO = "/phoneDimensionCore/getPhoneDimensionCoreByCityAndOperator";


    /**
     * 无数据
     */
    public final static String NULL_VALUE = "null value";

    //    protected ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
    /**
     * 网络异常
     */
    public final static String NETWORK_ERR = "network_err";


    /**
     * 认证权限信息
     * @param params
     * @param callback
     */
    public static void getAuthInfo(Map<String, Object> params,
                                   final IResultCallBackListener callback) {
        sendRequest(I_USER_PERMISSION, params, new OkHttpUtil.HttpCallback() {
            @Override
            public void onSuccess(String result, int code, String messageName) {
                callback.onSuccess(result);
            }

            @Override
            public void onStart(int code, String messageName) {
            }

            @Override
            public void onFailure(int code, String messageName, Result result) {
                handleFailuer(code, messageName, result, callback);
            }
        });
    }


    /**
     * 获得洞察结论和红线城市
     * @param params
     * @param callback
     */
    @Deprecated
    public static void getInsightAndRedCity(Map<String, Object> params,
                                            final IResultCallBackListener callback) {
        sendRequest(I_RED_CITY_AND_MAP, params, new OkHttpUtil.HttpCallback() {
            @Override
            public void onSuccess(String result, int code, String messageName) {
                if (code != OkHttpUtil.DEF_REQ_CODE) {
                    callback.onEmpty();
                }
                if (handlerException(result, callback)) {
                    return;
                }
                try {
                    NationalDataBean nationalDataBean = ParseJsonUtils.jsonToBean(result, NationalDataBean.class);
                    callback.onSuccess(nationalDataBean);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    GCLogger.error(Module.HTTP_UTIL, "[" + TAG + "]" + e.toString());
                    callback.onFail(e.toString());
                }
            }
            @Override
            public void onStart(int code, String messageName) {
            }
            @Override
            public void onFailure(int code, String messageName, Result result) {
                handleFailuer(code, messageName, result, callback);
            }
        });
    }

    public static final String TYPE_4G = "4G";
    public static final String TYPE_5G = "5G";
    /**
     * 获得洞察结论和红线城市
     * @param params
     * @param type  类型 分4G 5G
     * @param callback
     */
    public static void getInsightAndRedCityByType(Map<String, Object> params, final String type,
                                                  final IResultCallBackListener callback) {
        sendRequest(I_RED_CITY_AND_MAP, params, new OkHttpUtil.HttpCallback() {
            @Override
            public void onSuccess(String result, int code, String messageName) {
                if (code != OkHttpUtil.DEF_REQ_CODE) {
                    callback.onEmpty();
                }
                if (handlerException(result, callback)) {
                    return;
                }
                try {
                    JSONObject jo = new JSONObject(result);

                    NationalDataBean nationalDataBean = ParseJsonUtils.jsonToBean(
                            jo.optJSONObject(type).toString(), NationalDataBean.class);
                    callback.onSuccess(nationalDataBean);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    GCLogger.error(Module.HTTP_UTIL, "[" + TAG + "]" + e.toString());
                    callback.onFail(e.toString());
                }
            }
            @Override
            public void onStart(int code, String messageName) {
            }
            @Override
            public void onFailure(int code, String messageName, Result result) {
                handleFailuer(code, messageName, result, callback);
            }
        });
    }




    /**
     * 获取4G关键指标分类及相应指标内容
     * @param params
     * @param callback
     * @param type 类型 是4g还是5g
     */
    public static void getQuotaWithType(Map<String, Object> params, String type,
                                        final IResultCallBackListener callback) {
        String interfaceString;
        //默认4G
        if(TYPE_5G.equals(type)) {
            interfaceString = I_NR_QUOTA;
        } else {
            interfaceString = I_LTE_QUOTA;
        }
        sendRequest(interfaceString, params, new OkHttpUtil.HttpCallback() {

            @Override
            public void onSuccess(String result, int code, String messageName) {
                if (code != OkHttpUtil.DEF_REQ_CODE) {
                    callback.onEmpty();
                }
                if (handlerException(result, callback)) {
                    return;
                }
                List<ResultBean> list = new ArrayList<>();
                try {
                    JSONArray jsonArray = new JSONArray(result);
                    if (jsonArray.length() > 0) {
                        for(int i=0; i<jsonArray.length(); i++) {
                            ResultBean singleOperatorQuota = new ResultBean();
                            JSONObject jsonObject = jsonArray.optJSONObject(i);
                            //设置运营商姓名
                            singleOperatorQuota.setOperator(jsonObject.optString("operator"));
                            //读取场景分析描述信息 TODO
//                            singleOperatorQuota.setScenesAnalizeDesc(jsonObject.optString("description"));
//                            //读取场景分析数据列表
//                            JSONArray scenesArray = jsonObject.optJSONArray("scenario");
//                            if(null != scenesArray && scenesArray.length() > 0) {//有场景分析数据
//                                List<ResultBean.ScenesBean> scenesList = new ArrayList<ResultBean.ScenesBean>();
//                                for(int j=0; j<scenesArray.length(); j++) {
//                                    ResultBean.ScenesBean singleScenesBean = ParseJsonUtils.fromJson(scenesArray.optJSONObject(j).toString(), ResultBean.ScenesBean.class);
//                                    scenesList.add(singleScenesBean);
//                                }
//
////                                scenesList = ParseJsonUtils.getList(scenesArray.toString(), ResultBean.ScenesBean.class);
//                                singleOperatorQuota.setScenesBeanList(scenesList);
//                            }
                            //读取指标下表
                            JSONArray batchArray = jsonObject.optJSONArray("batchList");//下标名称数组
                            if(null != batchArray && batchArray.length() > 0) {
                                List<String> batchList = new ArrayList<String>();
                                for(int j=0; j<batchArray.length(); j++) {//解析下标文字列表
                                    String singleBatch = batchArray.optString(j);
                                    if(singleBatch.length() > 0) {//一个非空的batch
                                        batchList.add(singleBatch);
                                    }
                                }
                                singleOperatorQuota.setBatchList(batchList);
                            }
                            JSONArray typeArray = jsonObject.optJSONArray("data");
                            if(null != typeArray && typeArray.length() > 0) {
                                List<ResultBean.QuotaType> typeList = new ArrayList<ResultBean.QuotaType>();
                                for(int j=0; j<typeArray.length(); j++) { //解析指标分类,每个分类中有数个指标
                                    JSONObject typeObject = typeArray.optJSONObject(j);
                                    String typeName = typeObject.optString("typeName");
                                    ResultBean.QuotaType singleType = ParseJsonUtils.fromJson(
                                            typeArray.optJSONObject(j).toString(), ResultBean.QuotaType.class);
                                    if(null != singleType) {
                                        typeList.add(singleType);
                                    }
                                    singleType.setTypeName(typeName);
                                }

                                singleOperatorQuota.setQuotaTypes(typeList);
                            }
                            list.add(singleOperatorQuota);
                        }
                        callback.onSuccess(list);
                    } else {//指标数组数据无内容
                        callback.onFail("查询数据为空");
                        return;
                    }

                }
                catch (Exception e) {
                    e.printStackTrace();
                    GCLogger.error(Module.HTTP_UTIL, "[" + TAG + "]" + e.toString());
                    callback.onFail(e.toString());
                }
            }

            @Override
            public void onStart(int code, String messageName) {
            }

            @Override
            public void onFailure(int code, String messageName, Result result) {
                handleFailuer(code, messageName, result, callback);
            }
        });
    }



    /**
     * 获取具体城市的维度信息得分
     * 参数 城市名,userId,运营商英文名 CMCC  CUTC CNTC
     * @param params
     * @param callback
     * @param netType 4G还是5G
     */
    public static void getCitySpiderInfoByNetType(Map<String, Object> params, final String netType,
                                                  final IResultCallBackListener callback) {
        sendRequest(I_CITY_SPIDER_INFO, params, new OkHttpUtil.HttpCallback() {
            @Override
            public void onSuccess(String result, int code, String messageName) {
                /**
                 * 如果有异常直接返回
                 */
                if (handlerException(result, callback))
                {
                    return;
                }
                if (code != OkHttpUtil.DEF_REQ_CODE) {
                    callback.onEmpty();
                }

                DimensionCityBean dimensionCityBean = null;
                try
                {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("JsonData"))
                    {
                        jsonObject = jsonObject.getJSONObject("JsonData");
                    }
                    if (jsonObject.has("dimension"))
                    {
                        result = jsonObject.getString("dimension");
                    }
                    String conclusion = "";
                    if(TYPE_4G.equals(netType)) {
                        conclusion = jsonObject.optString("4Gconclusion");
                    } else if(TYPE_5G.equals(netType)) {
                        conclusion = jsonObject.optString("5Gconclusion");
                    } else {
                        conclusion = "";
                    }
//                    if (jsonObject.has("conclusion"))
//                    {
//                        conclusion = jsonObject.getString("conclusion");
//                    }
                    dimensionCityBean = ParseJsonUtils.jsonToBean(result, DimensionCityBean.class);
                    if (dimensionCityBean != null)
                    {
                        dimensionCityBean.conclusion = conclusion;
                        //解析维度得分
                        if(null != dimensionCityBean.cityDimensionScore) {
                            ResultBean.Quota dimensionQuota = new ResultBean.Quota();
                            dimensionQuota.setDimensionScore(true); // 表示这项指标是维度得分
                            List<String> labels = new ArrayList<String>();
                            List<Double> values = new ArrayList<Double>();
                            DimensionCityBean.Dimension dimension = dimensionCityBean.cityDimensionScore;
                            if(0 != dimension.fault_maintenance) {
                                labels.add("故障维护");
                                values.add(dimension.fault_maintenance);
                            }
                            if(0 != dimension.network_interference) {
                                labels.add("网络干扰");
                                values.add(dimension.network_interference);
                            }
                            if(0 != dimension.volte_services) {
                                labels.add("VoLTE业务");
                                values.add(dimension.volte_services);
                            }
                            if(0 != dimension.network_coverage) {
                                labels.add("网络覆盖");
                                values.add(dimension.network_coverage);
                            }
                            if(0 != dimension.network_capacity) {
                                labels.add("网络容量");
                                values.add(dimension.network_capacity);
                            }
                            if(0 != dimension.data_experience) {
                                labels.add("数据体验");
                                values.add(dimension.data_experience);
                            }
                            if(0 != dimension.voice) {
                                labels.add("语音");
                                values.add(dimension.voice);
                            }
                            if(0 != dimension.data) {
                                labels.add("数据");
                                values.add(dimension.data);
                            }
                            if(0 != dimension.jamming) {
                                labels.add("干扰");
                                values.add(dimension.jamming);
                            }
                            if(0 != dimension.overlays) {
                                labels.add("覆盖");
                                values.add(dimension.overlays);
                            }
                            if(0 != dimension.maintenance) {
                                labels.add("维护");
                                values.add(dimension.maintenance);
                            }
                            if(0 != dimension.voice_experience) {
                                labels.add("语音体验");
                                values.add(dimension.voice_experience);
                            }
                            if(0 != dimension.capacity) {
                                labels.add("容量");
                                values.add(dimension.capacity);
                            }
                            if(values.size() > 0) {
                                dimensionQuota.setDifBatchVaule(values);
                                dimensionQuota.setIndexLabels(labels);
                                dimensionCityBean.dimensionQuota = dimensionQuota;
                            }
                        }
                    }
                    callback.onSuccess(dimensionCityBean);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    GCLogger.error(Module.HTTP_UTIL, "[" + TAG + "]" + e.toString());
                    callback.onFail(e.toString());
                }
            }
            @Override
            public void onStart(int code, String messageName) {
            }
            @Override
            public void onFailure(int code, String messageName, Result result) {
                handleFailuer(code, messageName, result, callback);
            }
        });
    }














    /**
     * 处理失败
     * @param code
     * @param messageName
     * @param result
     * @param callback
     */
    private static void handleFailuer(int code, String messageName, Result result,
                                      IResultCallBackListener callback) {
        // 返回失败提示，由页面决定是否根据result错误码给出具体提示
        if (result.getDesc().contains("SocketTimeoutException"))
        {
            callback.onFail("请求超时");
        }
        else if (result.getDesc().contains("UnknownHostException"))
        {
            callback.onFail("网络异常，请检查网络");
        }
        else
        {
            if (result != null)
            {
                callback.onFail(result.getDesc());
            }
            else
            {
                callback.onFail("暂无数据");
            }
        }
    }


    /**
     * 网络访问
     * @param iString 接口名
     * @param params  参数集合
     * @param callback 回调
     */
    public static void sendRequest(String iString, Map<String, Object> params,
                                   OkHttpUtil.HttpCallback callback) {
        String url = HOST;
        Map<String, Object> data = builderParams(params, iString);
        if(null == data) {
            GCLogger.error("build http request params error!");
        }
        long reqTag = System.currentTimeMillis();
        OkHttpUtil.getInstance().asyncExecute(reqTag, url, OkHttpUtil.DEF_REQ_CODE, iString, data,
                callback);

    }

    /**
     * 解析数据
     *
     * @param result
     * @param code
     */
    private static void parseResults(String result, int code, IResultCallBackListener callBack)
    {
        if (code != OkHttpUtil.DEF_REQ_CODE)
        {
//            parseResult(result, code);
        }
        else
        {
            parseResult(result, callBack);
        }
    }

    public static void parseResult(String result, IResultCallBackListener callBack)
    {
        /**
         * 如果有异常直接返回
         */
        if (handlerException(result, callBack))
        {
            return;
        }

        List<User> list = new ArrayList<>();
        try
        {
            JSONObject jsonObject = new JSONObject(result);
            JSONArray jsonArray = jsonObject.getJSONArray("UserAccesses");

            if (jsonArray != null && jsonArray.length() > 0)
            {
                for (int i = 0; i < jsonArray.length(); i++)
                {
                    User user = ParseJsonUtils.fromJson(jsonArray.getString(i), User.class);
                    list.add(user);
                }

                if (list != null && list.size() > 0)
                {
                    DBManager.getInstance(BaseApplication.getAppContext()).getUserAuthorityDB().deleteAll();
                    DBManager.getInstance(BaseApplication.getAppContext()).getUserAuthorityDB().insert(list);
                }

                callBack.onSuccess(list);
            }
            else
            {
                callBack.onEmpty();
            }

        }
        catch (JSONException e)
        {
            callBack.onFail(e.toString());
            e.printStackTrace();
        }
    }



    /**
     * 处理异常返回
     *
     * @param resultStr
     * @return
     */
    protected static boolean handlerException(String resultStr, IResultCallBackListener baseResultLinstener)
    {
        if (TextUtils.isEmpty(resultStr))
        {
            baseResultLinstener.onFail("暂无数据");
            return true;
        }

        if (NETWORK_ERR.equalsIgnoreCase(resultStr))
        {
            baseResultLinstener.onFail("网络异常，请检查网络");
            return true;
        }

        if (NULL_VALUE.equalsIgnoreCase(resultStr))
        {
            baseResultLinstener.onEmpty();
            return true;
        }

        return false;
    }










    private static Map<String, Object> builderParams(Object object, String iString)
    {
        try
        {
            Map<String, Object> params = new HashMap<>();
            params.put("messageName", URLEncoder.encode(iString, "utf-8"));
            params.put("message", buildJsonParams("TAG_" + iString, object));
            return params;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static String buildJsonParams(String tag, Object object)
    {
        JSONObject jsonObject = new JSONObject();
        Set<Map.Entry<String, Object>> entrySet = ((Map<String, Object>) object).entrySet();
        for (Map.Entry<String, Object> entry : entrySet)
        {
            try
            {
                jsonObject.put(entry.getKey(), entry.getValue());
            }
            catch (JSONException e)
            {
                GCLogger.error(Module.HTTP_UTIL,
                        "[" + tag + "]" + "[HttpsRequest] getParams Exception " + e.toString());
            }
        }
        return jsonObject.toString();
    }

}
