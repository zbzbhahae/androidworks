package com.huawei.genexcloud.ltequality.dongcha.bean;

import java.io.Serializable;

/**
 * 城市维度得分
 */

public class DimensionCityBean implements Serializable {
    public String conclusion;
    public Dimension cityDimensionScore;
    public Dimension averageDimensionScore;
    public ResultBean.Quota dimensionQuota;

    @Override
    public String toString() {
        return "DimensionCityBean{" +
                "conclusion='" + conclusion + '\'' +
                ", cityDimensionScore=" + cityDimensionScore +
                ", averageDimensionScore=" + averageDimensionScore +
                '}';
    }

    public class Dimension {

        public double fault_maintenance; //故障维护
        public String phase; //期次
        public double basic_indicators; //基础指标
        public double network_interference; //网络干扰
        public double volte_services; //VoLTE业务
        public double network_coverage; //网络覆盖
        public double network_capacity; //网络容量
        public double network_scheduling; //网络调度
        public double data_services; //数据业务
        public double data_experience; //数据体验


        public double voice; //语音
        public double data; //数据
        public double jamming; //干扰
        public double overlays; //覆盖
        public double maintenance; //维护

        public double fast_network_speed; //网速快
        public double no_call_drop; //不掉话
        public double connected; //连的通
        public double listen_clear; //听的清
        public double full_coverage; //覆盖优
        public double hits_pass; //打得通
        public double no_lined_drop; //不掉线
        public double problem_cell; //问题小区
        public double out_of_service_rate; //退服率

        public double voice_experience; // 语音体验
//        private double data_experience; // 数据体验
//        private double overlays; // 覆盖
        public double capacity; // 容量
//        private double jamming; // 干扰
//        private double maintenance; // 维护


    }

}
