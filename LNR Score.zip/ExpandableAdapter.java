package com.huawei.genexcloud.ltequality.dongcha.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.huawei.genexcloud.ltequality.R;
import com.huawei.genexcloud.ltequality.dongcha.bean.ResultBean;
import com.huawei.genexcloud.ltequality.utils.Formatter;
import com.huawei.genexcloud.ltequality.view.OperLineView;

import java.util.ArrayList;
import java.util.List;

/**
 * 关键指标适配器
 */

public class ExpandableAdapter extends BaseExpandableListAdapter {

    private Context mContext;
    private List<ResultBean.Quota> quotaList;
    //    private ResultBean resultBean;
    private List<String> batchList;
    private String operatorName;
    private boolean shouldShowTB = true;//是否显示同比数据

    private ResultBean.Quota dimensionScoreQuota;
    private boolean showDimensionScore = false;

    public ExpandableAdapter(Context context) {
        this.mContext = context;
    }

    @Deprecated
    public void setData(ResultBean resultBean, boolean isShowTongBi) {
//        this.resultBean = resultBean;
        if (resultBean != null) {
            this.quotaList = resultBean.getQuotaList();
        } else {
            quotaList = null;
        }
        notifyDataSetChanged();
    }

    public boolean isDimensionScoreAvaliable() {
        return showDimensionScore && null != dimensionScoreQuota;
    }

    /**
     * 将维度得分接口获得的维度数据绑定给适配器，由showDimensionScore来决定是否显示
     * 耦合严重，接口不支持下难以改进
     * @param dimensionScoreQuota
     */
    public void setDimensionScoreQuota(ResultBean.Quota dimensionScoreQuota) {
        this.dimensionScoreQuota = dimensionScoreQuota;
        notifyDataSetChanged();
    }

    public void setIsShowDimensionScore(boolean showDimensionScore) {
        this.showDimensionScore = showDimensionScore;
        notifyDataSetChanged();
    }

    /**
     * 给指标list填充数据
     *
     * @param quotaList    指标列表
     * @param batchList    折线图的横坐标
     * @param operatorInEN 运营商英文简称
     * @param isShowTongBi 是否显示同比数据 电信不显示
     */
    public void setData(List<ResultBean.Quota> quotaList, List<String> batchList, String operatorInEN, boolean isShowTongBi) {
        shouldShowTB = isShowTongBi;
        if (null == quotaList || null == batchList) {
            this.quotaList = null;
            this.batchList = null;
        } else {
            this.quotaList = quotaList;
            this.batchList = batchList;
            operatorName = operatorInEN;
        }
        shouldShowTB = isShowTongBi;
        notifyDataSetChanged();
    }

    @Override
    public int getGroupCount() {
        if(showDimensionScore) {
            if (null != dimensionScoreQuota) {
                return null == quotaList ? 0 : quotaList.size() + 1;
            }
        }
        return null == quotaList ? 0 : quotaList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return quotaList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return 1;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder;
        if (convertView == null) {
            groupViewHolder = new ExpandableAdapter.GroupViewHolder();

            convertView = View.inflate(mContext, R.layout.item_expandable_group, null);
            // 初始化holder对象
            groupViewHolder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
            groupViewHolder.tvValue = (TextView) convertView.findViewById(R.id.tv_vlaue);
            groupViewHolder.tvTongbi = (TextView) convertView.findViewById(R.id.tv_tongbi);
            groupViewHolder.tvHuanbi = (TextView) convertView.findViewById(R.id.tv_huanbi);
            groupViewHolder.ivArrow = (ImageView) convertView.findViewById(R.id.iv_arrow);
            groupViewHolder.ivTongbi = (ImageView) convertView.findViewById(R.id.iv_tonbgbi);
            groupViewHolder.ivHuanbi = (ImageView) convertView.findViewById(R.id.iv_huanbi);
            groupViewHolder.llTongbi = (LinearLayout) convertView.findViewById(R.id.ll_tongbi_container);
            convertView.setTag(groupViewHolder);
        } else {
            groupViewHolder = (ExpandableAdapter.GroupViewHolder) convertView.getTag();
        }
        if (isExpanded) {
            groupViewHolder.ivArrow.setImageResource(R.drawable.ic_arrow_up);
        } else {
            groupViewHolder.ivArrow.setImageResource(R.drawable.ic_arrow_down);
        }
        setGroupData(groupPosition, groupViewHolder);
        return convertView;
    }

    private void setGroupData(int groupPosition, GroupViewHolder groupViewHolder) {
        if(isDimensionScoreAvaliable() && groupPosition == 0) {
            groupViewHolder.ivHuanbi.setVisibility(View.INVISIBLE);
            groupViewHolder.ivTongbi.setVisibility(View.INVISIBLE);
            groupViewHolder.tvName.setText("维度得分");
            groupViewHolder.tvValue.setText("");
            groupViewHolder.tvTongbi.setText("");
            groupViewHolder.tvHuanbi.setText("");
            groupViewHolder.llTongbi.setVisibility(View.GONE);
            return;
        }

        int newGroupPosition = groupPosition;
        if(isDimensionScoreAvaliable()) {
            newGroupPosition = groupPosition - 1;
        }
        String quotaName = quotaList.get(newGroupPosition).getQuotaName();
        String quotaUnit = quotaList.get(newGroupPosition).getQuotaUnit();
        //判断是否显示同比
        if (shouldShowTB) {
            groupViewHolder.llTongbi.setVisibility(View.VISIBLE);
        } else {
            groupViewHolder.llTongbi.setVisibility(View.GONE);
        }
        //如果指标名称自带单位 则要省略单位 考虑到括号的半角全角...
        if (!TextUtils.isEmpty(quotaName)) {
            quotaName = quotaName.trim().replace("（", "(").replace("）", ")");
            if (quotaName.endsWith(quotaUnit)) {
                //TODO 考虑是否从指标名称中删除数据单位 以保持单位显示样式一致
                quotaName = quotaName.replace(quotaUnit, "");
                groupViewHolder.tvName.setText(Html.fromHtml(
                        formatHtmlText(quotaName, quotaUnit)));
            } else {
                groupViewHolder.tvName.setText(Html.fromHtml(
                        formatHtmlText(quotaList.get(newGroupPosition).getQuotaName(), quotaList.get(newGroupPosition).getQuotaUnit())));
            }
        } else {
            groupViewHolder.tvName.setText("");
        }
        if (quotaList.get(newGroupPosition).getDifBatchVaule() != null
                && quotaList.get(newGroupPosition).getDifBatchVaule().size() > 0 && quotaList.get(newGroupPosition)
                .getDifBatchVaule().get(quotaList.get(newGroupPosition).getDifBatchVaule().size() - 1) == -255) {
            groupViewHolder.tvValue.setText("--");
        } else {
//            if (quotaList.get(newGroupPosition).getQuotaUnit().contains("%"))
            if (null != quotaList.get(newGroupPosition).getQuotaUnit() && quotaList.get(newGroupPosition).getQuotaUnit().contains("%")) {
                groupViewHolder.tvValue.setText(Formatter.formatDouble2Point(quotaList.get(newGroupPosition)
                        .getDifBatchVaule().get(quotaList.get(newGroupPosition).getDifBatchVaule().size() - 1) * 100) + "");
            } else {
                groupViewHolder.tvValue.setText(Formatter.formatDouble2Point(quotaList.get(newGroupPosition)
                        .getDifBatchVaule().get(quotaList.get(newGroupPosition).getDifBatchVaule().size() - 1)) + "");
            }

        }
        groupViewHolder.tvTongbi.setText(
                Math.abs(Formatter.formatDouble2Point(quotaList.get(newGroupPosition).getSameMonthRatio() * 100)) + "");

        String huanbiStr = Math.abs(Formatter.formatDouble2Point(quotaList.get(newGroupPosition).getRelativeRatio() * 100)) + "";
        groupViewHolder.tvHuanbi.setText(
                Math.abs(Formatter.formatDouble2Point(quotaList.get(newGroupPosition).getRelativeRatio() * 100)) + "");

        if (quotaList.get(newGroupPosition).getRelativeRatio() == -255) {
            groupViewHolder.ivHuanbi.setVisibility(View.INVISIBLE);
            groupViewHolder.tvHuanbi.setText("--");
        } else {
            showData(groupViewHolder.ivHuanbi, quotaList.get(newGroupPosition).getRelativeRatio(),
                    quotaList.get(newGroupPosition).isForward());
            groupViewHolder.ivHuanbi.setVisibility(View.VISIBLE);
        }
        if (quotaList.get(newGroupPosition).getSameMonthRatio() == -255) {
            groupViewHolder.ivTongbi.setVisibility(View.INVISIBLE);

            groupViewHolder.tvTongbi.setText("--");

        } else {
            showData(groupViewHolder.ivTongbi, quotaList.get(newGroupPosition).getSameMonthRatio(),
                    quotaList.get(newGroupPosition).isForward());
            groupViewHolder.ivTongbi.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView,
                             ViewGroup parent) {
        final ItemViewHolder itemViewHolder;
        if (convertView == null) {
            itemViewHolder = new ExpandableAdapter.ItemViewHolder();
            convertView = View.inflate(mContext, R.layout.item_expandable_child, null);
            itemViewHolder.operLineView = (OperLineView) convertView.findViewById(R.id.view_line);
            itemViewHolder.isShowValue = (CheckBox) convertView.findViewById(R.id.item_ishow_vlaue);
            itemViewHolder.tvOper = (TextView) convertView.findViewById(R.id.tv_child_oper);
            convertView.setTag(itemViewHolder);
        } else {
            itemViewHolder = (ExpandableAdapter.ItemViewHolder) convertView.getTag();
        }
        setChildData(groupPosition, itemViewHolder);
        return convertView;
    }

    private void setChildData(final int groupPosition, final ItemViewHolder itemViewHolder) {

        if ("CMCC".equals(operatorName)) {
            itemViewHolder.tvOper.setText("移动");
        } else if ("CUCC".equals(operatorName)) {
            itemViewHolder.tvOper.setText("联通");
        } else if ("CTCC".equals(operatorName)) {
            itemViewHolder.tvOper.setText("电信");
        }

        if(isDimensionScoreAvaliable() && groupPosition == 0) {
            if(dimensionScoreQuota.isOpen()) {
                itemViewHolder.isShowValue.setChecked(true);
            } else {
                itemViewHolder.isShowValue.setChecked(false);
            }
            itemViewHolder.operLineView.setIsDimensionScore(true);
            itemViewHolder.operLineView.setData(dimensionScoreQuota.getDifBatchVaule(),
                    dimensionScoreQuota.getIndexLabels(), dimensionScoreQuota.isOpen());
            itemViewHolder.isShowValue.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    dimensionScoreQuota.setOpen(isChecked);
                    itemViewHolder.operLineView.notifydChart(isChecked);
                }
            });
            return;
        }
        itemViewHolder.operLineView.setIsDimensionScore(false);

        ResultBean.Quota info;
        if(isDimensionScoreAvaliable()) {
            itemViewHolder.isShowValue.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    quotaList.get(groupPosition - 1).setOpen(isChecked);
                    itemViewHolder.operLineView.notifydChart(isChecked);
                }
            });
            info = quotaList.get(groupPosition - 1);
            if (quotaList.get(groupPosition - 1).isOpen()) {
                itemViewHolder.isShowValue.setChecked(true);
            } else {
                itemViewHolder.isShowValue.setChecked(false);
            }
        } else {
            itemViewHolder.isShowValue.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    quotaList.get(groupPosition).setOpen(isChecked);
                    itemViewHolder.operLineView.notifydChart(isChecked);
                }
            });
            info = quotaList.get(groupPosition);
            if (quotaList.get(groupPosition).isOpen()) {
                itemViewHolder.isShowValue.setChecked(true);
            } else {
                itemViewHolder.isShowValue.setChecked(false);
            }
        }


        if (info.getQuotaUnit().contains("%")) {
            List<Double> values = new ArrayList<>();
            for (int i = 0; i < info.getDifBatchVaule().size(); i++) {
                if (info.getDifBatchVaule().get(i) != -255) {
                    values.add(Formatter.formatDouble2Point(info.getDifBatchVaule().get(i) * 100));
                } else {
                    values.add(info.getDifBatchVaule().get(i));
                }
            }
            itemViewHolder.operLineView.setData(values, batchList, info.isOpen());
        } else {
            itemViewHolder.operLineView.setData(info.getDifBatchVaule(), batchList, info.isOpen());
        }

    }

    private String formatHtmlText(String str, String temp) {
        return "<body>" + "<font  color=\"#666666\">" + str + "</font>" + "<font  color=\"#989898\"><small>" + temp
                + "</small></font>" + "</body>";
    }

    private void showData(ImageView image, double vlaue, boolean isForward) {
        if (isForward) { //正向指标
            if (vlaue >= 0) {
                image.setImageResource(R.drawable.green_up);
            } else {
                image.setImageResource(R.drawable.red_down);
            }
        } else { //负向指标
            if (vlaue >= 0) {
                image.setImageResource(R.drawable.red_up);
            } else {
                image.setImageResource(R.drawable.green_down);
            }
        }

    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    class GroupViewHolder {
        ImageView ivTongbi, ivHuanbi, ivArrow;
        TextView tvName, tvValue, tvTongbi, tvHuanbi;
        LinearLayout llTongbi;
    }

    class ItemViewHolder {
        OperLineView operLineView;
        CheckBox isShowValue;
        TextView tvOper;
    }
}
