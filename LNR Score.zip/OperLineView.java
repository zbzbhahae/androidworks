package com.huawei.genexcloud.ltequality.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.huawei.genexcloud.ltequality.R;
import com.huawei.genexcloud.ltequality.utils.Formatter;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */

public class OperLineView extends View
{
    private static final float DOT_FIVE = 0.5f;
    //xy轴的颜色
    private int xyLineColor;
    //xy轴的字体颜色
    private int xyTextColor;
    //xy轴的字体大小
    private float xyTextSize;
    // x轴各个坐标点水平间距
    private float interval;
    //xy轴   刻度线画笔
    private Paint xyPaint;
    //文字画笔
    private Paint textPaint;
    //折线画笔
    private Paint linePaint;
    //轴数据源
    private List<String> chartLables = new ArrayList<>();
    private List<Double> valuesCmcc = new ArrayList<>();
    //X轴的原点坐标
    private int xOri;
    //Y轴的原点坐标
    private int yOri;
    //第一个点X的坐标
    private float xInit;
    //Y轴刻度线的颜色
    private int bgLineColor;
    //折线图控件的宽度
    private int width;
    //折线图控件的高度
    private int height;
    //第一个点对应的最大X坐标
    private float maxXInit;
    //第一个点对应的最小X坐标
    private float minXInit;
    //Y轴文本的最大值
    private double maxColumnHeight = 0;
    //Y轴文本的最大值
    private double minColumnHeight = 0;
    private int splitLines = 5;
    private float startX;
    private int cmccLineColor;
    //XY轴宽度
    private float xyLineWidth = 3;
    private boolean isOpen = true;
    private boolean isFirst;
    private boolean isMinNoZero = false;
    private boolean isMin99 = false;

    private boolean isDimensionScore = false;
    public void setIsDimensionScore(boolean isDimensionScore) {
        this.isDimensionScore = isDimensionScore;
        if(isDimensionScore) {
            interval = dip2px(68);
        } else {
            interval = dip2px(34);
        }
    }

    public OperLineView(Context context)
    {
        super(context);
    }

    public OperLineView(Context context, AttributeSet attrs)
    {
        super(context, attrs);

        initAttrs(context, attrs);
        initPaint();

    }

    public OperLineView(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context, attrs, defStyleAttr);
    }

    /**
     * 初始化折线图的属性
     */

    private void initAttrs(Context context, AttributeSet attrs)
    {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.HistogramChartView, 0, 0);
        xyLineColor = typedArray.getColor(R.styleable.HistogramChartView_xylinecolor, 0xb4cde6);
        xyTextColor = Color.parseColor("#989898");
        xyTextSize = dip2px(10);
        interval = dip2px(34);
        cmccLineColor = Color.parseColor("#6FBAFF");
        bgLineColor = Color.parseColor("#F5F5F5");
    }

    /**
     * 初始化画笔
     */
    private void initPaint()
    {
        xyPaint = new Paint();
        xyPaint.setAntiAlias(true);
        xyPaint.setColor(xyLineColor);
        xyPaint.setStrokeWidth(xyLineWidth);
        xyPaint.setStrokeCap(Paint.Cap.ROUND);

        textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(xyTextColor);
        textPaint.setTextSize(xyTextSize);
        textPaint.setStrokeCap(Paint.Cap.ROUND);
        textPaint.setStyle(Paint.Style.STROKE);

        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setColor(cmccLineColor);
        linePaint.setStrokeWidth(5);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStyle(Paint.Style.STROKE);

    }

    /**
     * 根据Y值文本的宽度和X轴文本的高度，确定原点坐标
     */
    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom)
    {
        if (changed)
        {
            width = getWidth();
            height = getHeight();
            initLayout();

        }
        super.onLayout(changed, left, top, right, bottom);

    }

    private void initLayout()
    {
        textPaint.setTextSize(dip2px(10));
        //Y轴左边文本最大宽度
        float textYWidthL = getTextBounds("0000", textPaint).width();
        textYWidthL = getTextBounds(Formatter.formatDouble2Point(maxColumnHeight) + "", textPaint).width() > textYWidthL
            ? getTextBounds(Formatter.formatDouble2Point(maxColumnHeight) + "", textPaint).width()
            : textYWidthL;

        //确定坐标原点X点（左边）
        xOri = (int) (textYWidthL + xyLineWidth);
        //X轴文本最大高度
        float textXHeight = getTextBounds("000", textPaint).height();
        for (int i = 0; i < chartLables.size(); i++)
        {
            textXHeight = getTextBounds(String.valueOf(chartLables.get(i)), textPaint).height() > textXHeight
                ? getTextBounds(String.valueOf(chartLables.get(i)), textPaint).height()
                : textXHeight;
        }
        //确定坐标原点Y点
        yOri = (int) (height - textXHeight - dip2px(6));

        //        if (chartLables.size() < 6) {
        //            xInit = (width - (chartLables.size() - 1) * interval) / 2;
        //        } else {
        //            xInit = xOri + interval / 2;
        //        }

        xInit = xOri + interval / 2;

        minXInit = width - (width - xOri) * 0.11f - interval * (chartLables.size() - 1);//减去0.1f是因为最后一个X周刻度距离右边的长度为X轴可见长度的10%

        maxXInit = xInit;

    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        drawXY(canvas);
        drawXYText(canvas);
        drawBrokenLineAndPoint(canvas);
    }

    /**
     * 绘制折线和折线交点处对应的点
     */
    private void drawBrokenLineAndPoint(Canvas canvas)
    {
        if (chartLables.size() < 0)
        {
            return;
        }
        //重新开一个图层
        int layerId = canvas.saveLayer(0, 0, width, height + dip2px(30), null, Canvas.ALL_SAVE_FLAG);

        drawPointLine(canvas, valuesCmcc, cmccLineColor);
        drawPoint(canvas, valuesCmcc, cmccLineColor);

        // 将折线超出x轴坐标的部分截取掉
        linePaint.setStyle(Paint.Style.FILL);
        linePaint.setColor(Color.WHITE);
        linePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        RectF rectF = new RectF(0, 0, xOri, height + dip2px(30));
        canvas.drawRect(rectF, linePaint);
        linePaint.setXfermode(null);
        //保存图层
        canvas.restoreToCount(layerId);
    }

    //绘制节点对应的原点
    private void drawPoint(Canvas canvas, List<Double> valuePoint, int lineColor)
    {
        float dp2 = dip2px(1f);
        float dp5 = dip2px(2.2f);
        for (int i = 0; i < chartLables.size(); i++)
        {
            if (valuePoint.get(i) == -255)
            {
                continue;
            }
            float x = interval * i + xInit;
            float y = 0;
            if (isMinNoZero || isMin99)
            {
                y = (float) (yOri
                    - yOri * (1 - 0.12f) * (valuePoint.get(i) - minColumnHeight) / (maxColumnHeight - minColumnHeight))
                    - xyLineWidth;

            }
            else
            {
                y = (float) (yOri - yOri * (1 - 0.12f) * (valuePoint.get(i)) / (maxColumnHeight)) - xyLineWidth;
            }
            linePaint.setStyle(Paint.Style.FILL);
            linePaint.setColor(lineColor);
            canvas.drawCircle(x, y, dp5, linePaint);
            linePaint.setStyle(Paint.Style.FILL);
            linePaint.setColor(Color.WHITE);
            canvas.drawCircle(x, y, dp2, linePaint);
            if (isOpen)
            {
                drawFloatTextBox(canvas, x, y, valuePoint.get(i));
            }
        }
    }

    /**
     * 制作折线图数值
     */
    private void drawFloatTextBox(Canvas canvas, float x, float y, Double integer)
    {
        Rect rect = getTextBounds(integer + "", textPaint);
        textPaint.setColor(Color.parseColor("#999999"));
        textPaint.setTextSize(dip2px(9));
        textPaint.setTextAlign(Paint.Align.CENTER);
        if (maxColumnHeight > 100)
        {
            canvas.drawText(Math.round(integer) + "", x, y - dip2px(1.5f) - rect.height() / 2, textPaint);
        }
        else
        {
            canvas.drawText(Formatter.formatDouble2Point(integer) + "", x, y - dip2px(1.5f) - rect.height() / 2,
                textPaint);
        }
    }

    private void drawPointLine(Canvas canvas, List<Double> valuePoint, int lineColor)
    {
        isFirst = true;
        linePaint.setColor(lineColor);
        linePaint.setStyle(Paint.Style.STROKE);
        Path path = new Path();
        Path shadowPath = new Path();
        float minY = 0;
        float lastX = 0;
        float x = 0;
        float y = 0;
        if (valuePoint != null && valuePoint.size() > 0)
        {
            for (int i = 0; i < valuePoint.size(); i++)
            {
                if (valuePoint.get(i) == -255)
                {
                    continue;
                }
                x = interval * i + xInit;
                if (isMin99 || isMinNoZero)
                {
                    y = (float) (yOri - yOri * (1 - 0.12f) * (valuePoint.get(i) - minColumnHeight)
                        / (maxColumnHeight - minColumnHeight)) - xyLineWidth;
                }
                else
                {
                    y = (float) (yOri - yOri * (1 - 0.12f) * (valuePoint.get(i)) / (maxColumnHeight)) - xyLineWidth;
                }
                if (isFirst)
                {
                    path.moveTo(x, y);
                    isFirst = false;
                    shadowPath.moveTo(x, yOri);
                    shadowPath.lineTo(x, y);
                }
                else
                {
                    path.lineTo(x, y);
                    shadowPath.lineTo(x, y);
                }
                minY = Math.min(minY, y);
                lastX = x;
            }
            shadowPath.lineTo(lastX, yOri);
            shadowPath.close();

            canvas.drawPath(path, linePaint);
            int[] colors = new int[]{linePaint.getColor(), linePaint.getColor() & 0x00FFFFFF};
            LinearGradient lg = new LinearGradient(xOri, minY, xOri, yOri, colors, null, Shader.TileMode.CLAMP);
            linePaint.setShader(lg);
            linePaint.setStyle(Paint.Style.FILL);
            canvas.drawPath(shadowPath, linePaint);
            linePaint.setShader(null);
            linePaint.setStyle(Paint.Style.STROKE);
        }

    }

    /**
     * 画XY坐标数值及刻度
     */

    private void drawXYText(Canvas canvas)
    {

        textPaint.setTextSize(xyTextSize);
        textPaint.setColor(Color.parseColor("#989898"));
        xyPaint.setColor(Color.parseColor("#F5F5F5"));
        xyPaint.setStrokeWidth(2);
        //y轴上面空出12%,计算出y轴刻度间距
        float yLength = yOri * (1 - 0.12f) / splitLines;
        for (int i = 0; i < splitLines + 1; i++)
        {
            //绘制Y轴刻度
            if (i != 0)
            {
                canvas.drawLine(xOri, yOri - yLength * i - xyLineWidth, width, yOri - yLength * i - xyLineWidth,
                    xyPaint);
                //绘制Y轴文本

                String text = "";
                if (2 >= maxColumnHeight)
                {
                    text = Formatter.formatDouble2Point(maxColumnHeight * 1f / splitLines * i) + "";
                }
                else
                {
                    if (isMinNoZero)
                    {
                        text = (int) Math.ceil(maxColumnHeight - (maxColumnHeight - minColumnHeight) / 5 * (5 - i))
                            + "";
                    }
                    else if (isMin99)
                    {
                        text = Formatter.formatDouble2Point(
                            maxColumnHeight - (maxColumnHeight - minColumnHeight) / 5 * (5 - i)) + "";
                    }
                    else
                    {
                        text = (int) Math.ceil(maxColumnHeight / splitLines * i) + "";
                    }

                }

                textPaint.setTextAlign(Paint.Align.RIGHT);
                Rect rect = getTextBounds(text, textPaint);
                canvas.drawText(text, 0, text.length(), xOri, yOri - yLength * i + rect.height() / 2, textPaint);

            }
        }
        //绘制X轴文本
        textPaint.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < chartLables.size(); i++)
        {
            String text;
            if(!isDimensionScore) {
                text = String.valueOf(chartLables.get(i).substring(2, 4) + "/" + chartLables.get(i).substring(4));
            } else {
                text = chartLables.get(i);
            }
            Rect rect = getTextBounds(text, textPaint);
            canvas.drawText(text, 0, text.length(), interval * i + xInit,
                yOri + rect.height() + xyLineWidth + dip2px(4), textPaint);
        }
    }

    /**
     * // * @param flag 标志 :0：右边坐标从0开始，1：代表右边坐标从数据最小值开始
     */
    public void setData(List<Double> valueA, List<String> chartLabels, boolean isOpen)
    {

        this.isOpen = isOpen;
        isMinNoZero = false;
        isMin99 = false;

        if (this.valuesCmcc != null)
        {
            this.valuesCmcc.clear();
            this.valuesCmcc.addAll(valueA);
        }

        if (this.chartLables != null)
        {
            this.chartLables.clear();
            this.chartLables.addAll(chartLabels);
        }

        maxColumnHeight = getMaxColumnHeight();

        initLayout();

        invalidate();

    }

    /**
     * 画XY坐标轴
     */
    private void drawXY(Canvas canvas)
    {
        //绘制X轴
        xyPaint.setColor(Color.parseColor("#D7D7D7"));
        xyPaint.setStrokeWidth(xyLineWidth);
        canvas.drawLine(xOri, yOri, width, yOri, xyPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        this.getParent().requestDisallowInterceptTouchEvent(true);//当该view获得点击事件，就请求父控件不拦截事件sd
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                break;
            case MotionEvent.ACTION_MOVE:
                if (interval * chartLables.size() > width - xOri)
                {//当期的宽度不足以呈现全部数据
                    float dis = event.getX() - startX;
                    startX = event.getX();
                    if (xInit + dis < minXInit)
                    {
                        xInit = minXInit;
                    }
                    else if (xInit + dis > maxXInit)
                    {
                        xInit = maxXInit;
                    }
                    else
                    {
                        xInit = xInit + dis;
                    }
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_UP:
                this.getParent().requestDisallowInterceptTouchEvent(false);
                break;
            case MotionEvent.ACTION_CANCEL:
                this.getParent().requestDisallowInterceptTouchEvent(false);
                break;
        }
        return true;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 获取丈量文本的矩形
     *
     * @param text 文本
     * @param paint 画笔
     */
    private Rect getTextBounds(String text, Paint paint)
    {
        Rect rect = new Rect();
        paint.getTextBounds(text, 0, text.length(), rect);
        return rect;
    }

    /**
     * dip to px 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    private int dip2px(float dip)
    {
        float density = getDensity(getContext());
        return (int) (dip * density + DOT_FIVE);
    }

    /**
     * get screen density
     */
    private float getDensity(Context context)
    {
        return context.getResources().getDisplayMetrics().density;
    }

    /**
     * 获取所有柱子的最大值maxColumnHeight
     */
    private double getMaxColumnHeight()
    {

        maxColumnHeight = 0;
        minColumnHeight = 100;
        if(isDimensionScore) {
            return 100;
        }
        if (valuesCmcc != null && valuesCmcc.size() > 0)
        {
            for (int i = 0; i < valuesCmcc.size(); i++)
            {
                maxColumnHeight = maxColumnHeight < valuesCmcc.get(i) ? valuesCmcc.get(i) : maxColumnHeight;
                if (valuesCmcc.get(i) != -255)
                {
                    minColumnHeight = minColumnHeight > valuesCmcc.get(i) ? valuesCmcc.get(i) : minColumnHeight;
                }
            }
        }

        if (maxColumnHeight < 0.05)
        {
            maxColumnHeight = 0.05;
        }
        else if (maxColumnHeight < 0.1)
        {
            maxColumnHeight = 0.1;
        }
        else if (maxColumnHeight < 0.2)
        {
            maxColumnHeight = 0.2;
        }
        else if (maxColumnHeight < 0.5)
        {
            maxColumnHeight = 0.5;
        }
        else if (maxColumnHeight < 1)
        {
            maxColumnHeight = 1;
        }
        else if (maxColumnHeight < 2)
        {
            maxColumnHeight = 2;
        }
        else
        {
            if (maxColumnHeight > 100000)
            {
                maxColumnHeight = maxColumnHeight + (50000 - maxColumnHeight % 50000);
            }
            else if (maxColumnHeight > 10000)
            {
                maxColumnHeight = maxColumnHeight + (5000 - maxColumnHeight % 5000);
            }
            else if (maxColumnHeight > 1000)
            {
                maxColumnHeight = maxColumnHeight + (500 - maxColumnHeight % 500);
            }
            else if (maxColumnHeight > 100)
            {
                maxColumnHeight = maxColumnHeight + (50 - maxColumnHeight % 50);
            }
            else
            {
                maxColumnHeight = maxColumnHeight + (splitLines - maxColumnHeight % splitLines);
            }
        }

        if (100 >= maxColumnHeight)
        {

            if (minColumnHeight >= 99.8)
            {
                minColumnHeight = 99.8;
                isMin99 = true;
            }
            else if (minColumnHeight >= 90)
            {
                minColumnHeight = 90;
                isMinNoZero = true;
            }

        }

        return maxColumnHeight;
    }

    public void notifydChart(boolean isOpen)
    {
        this.isOpen = isOpen;
        invalidate();
    }
}
