package com.huawei.genexcloud.ltequality.dongcha.bean;

import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

import java.util.Iterator;
import java.util.List;

/**
 * Created by jWX556709 on 2020/11/14. 5G质量
 */

public class ResultBean
{
    private String operator;

    private List<Quota> quotaList; //指标列表
    private List<String> batchList; //指标横坐标列表
    private List<QuotaType> quotaTypes; //指标类型

    private String scenesAnalizeDesc;//场景分析的文字内容
    private List<ScenesBean> scenesBeanList;//场景分析的具体数据,按城市分类,一个城市一个数据,包含上行下行丢包率


    public String getScenesAnalizeDesc() {
        return scenesAnalizeDesc;
    }

    public void setScenesAnalizeDesc(String scenesAnalizeDesc) {
        this.scenesAnalizeDesc = scenesAnalizeDesc;
    }

    public List<ScenesBean> getScenesBeanList() {
        return scenesBeanList;
    }

    public void setScenesBeanList(List<ScenesBean> scenesBeanList) {
        this.scenesBeanList = scenesBeanList;
    }

    /**
     * 全国界面下的场景分析bean
     */
    public class ScenesBean {
        private double downWayRate;//上下行丢包率
        private double upWayRate;
        private double sumRate;//两个丢包率之和
        private String province;
        private String city;

        @Override
        public String toString() {
            return "ScenesBean{" +
                    "downWayRate=" + downWayRate +
                    ", upWayRate=" + upWayRate +
                    ", sumRate=" + sumRate +
                    ", province='" + province + '\'' +
                    ", city='" + city + '\'' +
                    '}';
        }

        public double getDownWayRate() {
            return downWayRate;
        }

        public void setDownWayRate(double downWayRate) {
            this.downWayRate = downWayRate;
        }

        public double getUpWayRate() {
            return upWayRate;
        }

        public void setUpWayRate(double upWayRate) {
            this.upWayRate = upWayRate;
        }

        public double getSumRate() {
            return sumRate;
        }

        public void setSumRate(double sumRate) {
            this.sumRate = sumRate;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }
    }


    @Override
    public String toString() {
        return "ResultBean{" +
                "operator='" + operator + '\'' +
                ", quotaList=" + quotaList +
                ", batchList=" + batchList +
                '}';
    }

    public List<QuotaType> getQuotaTypes() {
        return quotaTypes;
    }

    public void setQuotaTypes(List<QuotaType> quotaTypes) {
        this.quotaTypes = quotaTypes;
    }

    public String getOperator()
    {
        return operator;
    }

    public void setOperator(String operator)
    {
        this.operator = operator;
    }

    public List<Quota> getQuotaList()
    {
        return quotaList;
    }

    public void setQuotaList(List<Quota> quotaList)
    {
        this.quotaList = quotaList;
    }

    public List<String> getBatchList()
    {
        return batchList;
    }

    public void setBatchList(List<String> batchList)
    {
        this.batchList = batchList;
    }

    public static class Quota
    {
        private String quotaName; //指标名
        private String quotaUnit; //指标单位
        private double relativeRatio; //环比
        private List<Double> difBatchVaule;
        private List<String> indexLabels; // 后续新增在指标图标中显示维度得分的横坐标信息
        private boolean isDimensionScore; // 是不是单独的维度得分数据标识 这两个字段会导致指标接口与维度得分接口数据耦合，考虑改进
        private boolean isForward;
        private boolean isOpen = false;
        private double sameMonthRatio; //同比

        public List<String> getIndexLabels() {
            return indexLabels;
        }

        public void setIndexLabels(List<String> indexLabels) {
            this.indexLabels = indexLabels;
        }

        public boolean isDimensionScore() {
            return isDimensionScore;
        }

        public void setDimensionScore(boolean dimensionScore) {
            isDimensionScore = dimensionScore;
        }

        public double getSameMonthRatio()
        {
            return sameMonthRatio;
        }

        public void setSameMonthRatio(double sameMonthRatio)
        {
            this.sameMonthRatio = sameMonthRatio;
        }

        public boolean isOpen()
        {
            return isOpen;
        }

        public void setOpen(boolean open)
        {
            isOpen = open;
        }

        public String getQuotaName()
        {
            return quotaName;
        }

        public void setQuotaName(String quotaName)
        {
            this.quotaName = quotaName;
        }

        public String getQuotaUnit()
        {
            return quotaUnit;
        }

        public void setQuotaUnit(String quotaUnit)
        {
            this.quotaUnit = quotaUnit;
        }

        public double getRelativeRatio()
        {
            return relativeRatio;
        }

        public void setRelativeRatio(double relativeRatio)
        {
            this.relativeRatio = relativeRatio;
        }

        public List<Double> getDifBatchVaule()
        {
            return difBatchVaule;
        }

        public void setDifBatchVaule(List<Double> difBatchVaule)
        {
            this.difBatchVaule = difBatchVaule;
        }

        public boolean isForward()
        {
            return isForward;
        }

        public void setForward(boolean forward)
        {
            isForward = forward;
        }

        public boolean isAvailable() {
            if(TextUtils.isEmpty(getQuotaName())
                    || null == getDifBatchVaule() || 0 == getDifBatchVaule().size()) {
                return false;
            }
            return true;
        }
    }


    public class QuotaType {
        private String typeName;
        @SerializedName("quota")
        private List<ResultBean.Quota> quotas;

        @Override
        public String toString() {
            return "QuotaType{" +
                    "typeName='" + typeName + '\'' +
                    ", quotas=" + quotas +
                    '}';
        }

        public String getTypeName() {
            return typeName;
        }

        public void setTypeName(String typeName) {
            this.typeName = typeName;
        }

        public List<Quota> getQuotas() {
            return quotas;
        }

        public void setQuotas(List<Quota> quotas) {
            this.quotas = quotas;
        }

        public boolean isAvailable() {
            if(TextUtils.isEmpty(getTypeName())
                    || null == getQuotas() || 0 == getQuotas().size()) {
                return false;
            }
            //检查指标是否有问题 不合格的移除
            Iterator<Quota> iterator = getQuotas().iterator();
            while (iterator.hasNext()) {
                Quota next = iterator.next();
                if(null == next || !next.isAvailable()) {
                    iterator.remove();
                }
            }
            return true;
        }
    }

}
