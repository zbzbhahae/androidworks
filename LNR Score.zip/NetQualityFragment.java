package com.huawei.genexcloud.ltequality.activity.fragment;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import com.huawei.genexcloud.ltequality.R;
import com.huawei.genexcloud.ltequality.activity.MainActivity;
import com.huawei.genexcloud.ltequality.activity.controller.DimensionViewController;
import com.huawei.genexcloud.ltequality.activity.controller.MapWebViewController;
import com.huawei.genexcloud.ltequality.activity.datastore.OperatorDataSctore;
import com.huawei.genexcloud.ltequality.bean.LocOptBean;
import com.huawei.genexcloud.ltequality.dongcha.adapter.ExpandableAdapter;
import com.huawei.genexcloud.ltequality.dongcha.bean.DimensionCityBean;
import com.huawei.genexcloud.ltequality.dongcha.bean.NationalDataBean;
import com.huawei.genexcloud.ltequality.dongcha.bean.ResultBean;
import com.huawei.genexcloud.ltequality.dongcha.view.ScenesAnalyzeView;
import com.huawei.genexcloud.ltequality.http.ApiService;
import com.huawei.genexcloud.ltequality.http.IResultCallBackListener;
import com.huawei.genexcloud.ltequality.utils.CarrierNameUtils;
import com.huawei.genexcloud.ltequality.utils.CommonProvider;
import com.huawei.genexcloud.ltequality.utils.CommonProviderUtils;
import com.huawei.genexcloud.ltequality.utils.DensityUtil;
import com.huawei.genexcloud.ltequality.utils.PopupWindowUtils;
import com.huawei.genexcloud.ltequality.utils.log.GCLogger;
import com.huawei.genexcloud.ltequality.view.ExpandableListViewForScrollView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zWX1094027 on 2021/9/3.
 *
 * 网络质量视图,包含 洞察结论,红线城市地图,维度得分,
 *
 * locOptData 存放选择的城市和运营商信息 mNetType 用来区分4G 5G
 */

public class NetQualityFragment extends Fragment
    implements SwipeRefreshLayout.OnRefreshListener , ITransfer , View.OnClickListener
{

    private String mNetType = ApiService.TYPE_4G;//默认4G网络制式

    //选择的省市运营商数据
    private LocOptBean locOptData = LocOptBean.getDefaultBean();

    //最外层的scrollview
    private ScrollView scrollView;

    //网络访问数据需要的账号信息
    private String account = null;

    //洞察结论布局
    private ViewGroup insightLayout;
    private ViewGroup insightUpdateLayout;//洞察结论中数据更新至的layout, 地市的维度接口无法获得,需要隐藏
    private ViewGroup insightBackLayout;//用来设置背景
    private TextView insightTxt, insightUpdateTxt;

    //红线城市地图部分
    private MapWebViewController mapController;
    private ViewGroup mapContainer;

    //指标部分
    private ViewGroup indicatorLayout;
    //    private ViewGroup indicatorTypeGroupLayout;
    private TextView indicatorUpdateTxt;
    private ExpandableListViewForScrollView indicatorLv;//指标的list和adapter
    private ExpandableAdapter expandableAdapter;
    private boolean sholdShowTBInList = true;//是否在list中显示坏比项的开关,4g显示5g不显示
    private RadioGroup indicatorTypeLayout;
    //同比指标layout 电信不显示
    private ViewGroup indicatorTBLayout;
    //存放网络返回指标的数据
    private List<ResultBean> lteIndicatorList;

    /*********** 城市界面洞察数据部分,蛛网图 ;来自NetworkInsightView ******************/
    private ViewGroup dimensionContainer;
    private DimensionViewController dimensionController;

    /************** 场景分析部分 ***********************/
    //TODO 还没接口,先行隐藏  210917:需求未定义好
    private ViewGroup scenesAnalizeLayout;
    private ScenesAnalyzeView anaView;

    //刷新layout
    private SwipeRefreshLayout refreshLayout;

    //红线城市和洞察结论的数据bean
    private NationalDataBean nationalDataBean;
    private DimensionCityBean dimensionCityBean;

    private View rootView;
    private boolean isLoaded = false;
    private boolean isCreatedView = false;

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser)
    {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !isLoaded && isCreatedView)
        {
            if (null != getContext() && getContext() instanceof MainActivity)
            {
                LocOptBean temBean = ((MainActivity) getContext()).getLocOptData();
                if (null != temBean)
                {
                    locOptData = temBean;
                }
            }
            loadData();
            isLoaded = true;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        isLoaded = false;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
        @Nullable Bundle savedInstanceState)
    {
        mNetType = (null == getArguments()) ? "" : getArguments().getString("NET_TYPE");
        sholdShowTBInList = "4G".equals(mNetType);
        rootView = inflater.inflate(R.layout.fragment_net_quality, container, false);
        initViews(rootView);
        initData();
        isCreatedView = true;
        return rootView;
    }

    private void initData()
    {
        account = CommonProviderUtils.queryByKey(getContext(), CommonProvider.GenexCloudColumns.USERID).getName();
    }

    private void loadData()
    {
        refreshLayout.setRefreshing(true);
        onRefresh();
    }

    /**
     * findView行为
     */
    private void initViews(View root)
    {
        scrollView = (ScrollView) root.findViewById(R.id.net_quality_scroll);

        refreshLayout = (SwipeRefreshLayout) root.findViewById(R.id.net_quality_refresh);
        refreshLayout.setColorSchemeResources(R.color.refreshlayout_color1_green, R.color.refreshlayout_color2_red,
            R.color.refreshlayout_color3_blue, R.color.refreshlayout_color4_orange);
        refreshLayout.setOnRefreshListener(this);

        insightLayout = (ViewGroup) root.findViewById(R.id.insight_layout);
        insightBackLayout = (ViewGroup) root.findViewById(R.id.insight_back);
        insightTxt = (TextView) root.findViewById(R.id.insight_content_text);
        insightUpdateTxt = (TextView) root.findViewById(R.id.insight_update_text);
        insightUpdateLayout = (ViewGroup) root.findViewById(R.id.insight_update_time_layout);
        root.findViewById(R.id.insight_data_desc).setOnClickListener(this);
        root.findViewById(R.id.ll_quota_des).setOnClickListener(this);

        //初始化红线城市地图模块
        mapContainer = (ViewGroup) root.findViewById(R.id.net_quality_map_container);
        mapController = new MapWebViewController(getActivity());
        mapController.addToViewGroup(mapContainer);
        mapController.setNetType(mNetType);
        mapContainer.setVisibility(View.INVISIBLE);

        indicatorLayout = (ViewGroup) root.findViewById(R.id.net_quality_indicator_layout);
        indicatorLayout.setVisibility(View.INVISIBLE);
        insightLayout.setVisibility(View.GONE);
        indicatorLv = (ExpandableListViewForScrollView) root.findViewById(R.id.indicator_list);
        expandableAdapter = new ExpandableAdapter(getContext());
        indicatorLv.setAdapter(expandableAdapter);
        //监听点击可展开list的展开行为,展开一个,则收起其他指标图
        indicatorLv.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener()
        {
            @Override
            public void onGroupExpand(int groupPosition)
            {
                for (int i = 0; i < expandableAdapter.getGroupCount(); i++)
                {
                    if (groupPosition != i)
                    {
                        indicatorLv.collapseGroup(i);
                    }
                }
            }
        });

        indicatorUpdateTxt = (TextView) root.findViewById(R.id.tv_time1);
        //三元十三维指标的类型按钮布局
        indicatorTypeLayout = (RadioGroup) root.findViewById(R.id.indicator_button_group);
        indicatorTBLayout = (ViewGroup) root.findViewById(R.id.ll_tongbi_container);
        //关于同比表头的逻辑,4G下全部都显示同比表头,5G全部不显示同比表头 隐藏方式为gone,放出更多位置
        if("4G".equals(mNetType)) {
            indicatorTBLayout.setVisibility(View.VISIBLE);
        } else if("5G".equals(mNetType)) {
            indicatorTBLayout.setVisibility(View.GONE);
        }

        //城市维度图部分
        dimensionContainer = (ViewGroup) root.findViewById(R.id.net_quality_dimension_container);
        dimensionController = new DimensionViewController(getActivity());
        dimensionController.addToViewGroup(dimensionContainer);
        //初始化隐藏蛛网视图
        dimensionContainer.setVisibility(View.GONE);

        scenesAnalizeLayout = (ViewGroup) root.findViewById(R.id.layout_scenes_analyze);
        /** 将情景分析部分加入页面 **/ //TODO 不需要情景分析的情况处理
        if (scenesAnalizeLayout != null)
        {
            if (null == anaView)
            {
                anaView = new ScenesAnalyzeView(getContext());
                scenesAnalizeLayout.removeAllViews();
                scenesAnalizeLayout.addView(anaView.getView());
            }
        }
        scenesAnalizeLayout.setVisibility(View.GONE);
    }

    //检查并行的两个网络访问是否都完成了
    private int refreshFlag = 2;

    private void checkRefresh()
    {
        if (refreshFlag == 0)
        {
            refreshLayout.setRefreshing(false);
            scrollView.scrollTo(0, 0);
        }
    }

    //记录上次请求指标数据成功时所用的地市信息,以便在地市界面中减少切换运营商时的请求
    private String lastTimeCity;

    /**
     * 刷新方法
     */
    @Override
    public void onRefresh()
    {
        //TODO 切换page时 未attach便去更新数据
        if (null == getContext())
        {
            return;
        }

        //用于确定加载菊花是否转好的flag
        refreshFlag = 2;

        Map<String, Object> params = new HashMap<>();

        //如果是选择的城市 那么要取拉取维度数据(蛛网图因为后端数据问题,先不使用),如果不是 那要拉取洞察结论和红线地图
        if (locOptData.getLocationType() == LocOptBean.LOC_TYPE_CITY)
        {
            params.put("city", locOptData.getCity());
            params.put("operator", CarrierNameUtils.getEnName(getContext(), locOptData.getOperator(), "CMCC"));
            params.put("userId", account);

            ApiService.getCitySpiderInfoByNetType(params, mNetType, new IResultCallBackListener()
            {
                @Override
                public void onFail(String failMsg)
                {
                    refreshFlag--;
                    checkRefresh();
                }

                @Override
                public void onSuccess(Object obj)
                {
                    refreshFlag--;
                    checkRefresh();
                    dimensionCityBean = (DimensionCityBean) obj;
                    setDimension(dimensionCityBean);
                }

                @Override
                public void onEmpty()
                {
                    refreshFlag--;
                    checkRefresh();
                }
            });

            // 城市界面切换运营商不应该重新获取指标信息

            String city = locOptData.getCity();
            if (!TextUtils.isEmpty(city) && city.equals(lastTimeCity) && null != lteIndicatorList)
            {
                //两城市相同 表示是切换运营商而不是地市
                refreshFlag = 1;
                setIndicatorData(lteIndicatorList);
                return;
            }
        }
        else
        {
            params.put("userId", account);
            ApiService.getInsightAndRedCityByType(params, mNetType, new IResultCallBackListener()
            {
                @Override
                public void onFail(String failMsg)
                {
                    refreshFlag--;
                    checkRefresh();
                }

                @Override
                public void onSuccess(Object obj)
                {
                    refreshFlag--;
                    checkRefresh();
                    nationalDataBean = (NationalDataBean) obj;
                    setInsightData(nationalDataBean);
                }

                @Override
                public void onEmpty()
                {
                    refreshFlag--;
                    checkRefresh();
                }
            });
        }


        final String city = locOptData.getCity();
        params = new HashMap<>();
        params.put("userId", account);
        params.put("province", locOptData.getProvince());
        params.put("city", city);
        ApiService.getQuotaWithType(params, mNetType, new IResultCallBackListener()
        {
            @Override
            public void onFail(String failMsg)
            {
                refreshFlag--;
                checkRefresh();
            }

            @Override
            public void onSuccess(Object obj)
            {
                refreshFlag--;
                checkRefresh();
                //TODO
                lteIndicatorList = (List<ResultBean>) obj;
                if (lteIndicatorList != null)
                {
                    lastTimeCity = city;
                    setIndicatorData(lteIndicatorList);
                }
            }

            @Override
            public void onEmpty()
            {
                refreshFlag--;
                checkRefresh();
            }
        });
    }

    /**
     * 选择的位置是城市 隐藏地图部分和情景分析
     * 
     * @param dimensionCityBean
     */
    private void setDimension(DimensionCityBean dimensionCityBean)
    {
        if (null == getContext())
        {
            return;
        }
        if (dimensionCityBean != null)
        {
            //隐藏地图,场景分析
            mapContainer.setVisibility(View.GONE);
            //            //TODO
            //            scenesAnalizeLayout.setVisibility(View.VISIBLE);
            //显示维度图
            indicatorLayout.setVisibility(View.VISIBLE);
            //在城市维度可见时,给洞察结论设置上背景
            //TODO 暂时不显示维度得分网格图
            dimensionContainer.setVisibility(View.GONE);
            insightLayout.setVisibility(View.VISIBLE);



            //隐藏更新时间
            insightUpdateLayout.setVisibility(View.GONE);
            if (TextUtils.isEmpty(dimensionCityBean.conclusion))
            {
                insightTxt.setText("暂无洞察结论");
            }
            else
            {
                insightTxt.setText(dimensionCityBean.conclusion);
            }
            scrollView.smoothScrollTo(0, 0);

            if(null != dimensionCityBean && null != dimensionCityBean.dimensionQuota
                    && null != dimensionCityBean.dimensionQuota.getIndexLabels()
                    && dimensionCityBean.dimensionQuota.getIndexLabels().size() > 0
                    && locOptData.getLocationType() == LocOptBean.LOC_TYPE_CITY) {
                expandableAdapter.setDimensionScoreQuota(dimensionCityBean.dimensionQuota);
            } else {
                expandableAdapter.setDimensionScoreQuota(null);
            }
        }
    }

    /**
     * 绑定洞察结论数据,红线城市地图数据
     * 
     * @param bean
     */
    private void setInsightData(NationalDataBean bean)
    {
        if (null == bean || getContext() == null)
            return;

        //显示洞察结论,地图,场景分析
        insightLayout.setVisibility(View.VISIBLE);
        //需要显示数据更新时间
        insightUpdateLayout.setVisibility(View.VISIBLE);
        //        //TODO 先行隐藏
        //        scenesAnalizeLayout.setVisibility(View.VISIBLE);
        mapContainer.setVisibility(View.VISIBLE);
        indicatorLayout.setVisibility(View.VISIBLE);
        mapController.loadRedLineCityData(bean, locOptData.getOperator());
        //隐藏维度图 隐藏洞察结论的背景图片
        dimensionContainer.setVisibility(View.GONE);
        //        insightLayout.setBackground(null);
        //        insightBackLayout.setBackground(null);

        //先充值数据状态
        insightTxt.setText("暂无数据");
        insightUpdateTxt.setText("");
        switch (locOptData.getOperator())
        {
            case "移动":
                if (bean.cmccData == null || !bean.cmccData.isPower || null == bean.cmccData.cmccPhoneInsightConclusion)
                {
                    break;
                }
                NationalDataBean.CmccData cmcc = bean.cmccData;
                insightTxt.setText(cmcc.cmccPhoneInsightConclusion.message);
                insightUpdateTxt.setText("数据更新至:" + cmcc.cmccPhoneInsightConclusion.phase);
                break;
            case "联通":
                if (bean.cuccData == null || !bean.cuccData.isPower || null == bean.cuccData.cuccPhoneInsightConclusion)
                {
                    break;
                }
                NationalDataBean.CutcData cutc = bean.cuccData;
                insightTxt.setText(cutc.cuccPhoneInsightConclusion.message);
                insightUpdateTxt.setText("数据更新至:" + cutc.cuccPhoneInsightConclusion.phase);
                break;
            case "电信":
                if (bean.ctccData == null || !bean.ctccData.isPower || null == bean.ctccData.ctccPhoneInsightConclusion)
                {
                    break;
                }
                NationalDataBean.CntcData cntc = bean.ctccData;
                insightTxt.setText(cntc.ctccPhoneInsightConclusion.message);
                insightUpdateTxt.setText("数据更新至:" + cntc.ctccPhoneInsightConclusion.phase);
                break;
        }
        scrollView.smoothScrollTo(0, 0);
    }

    /**
     * 设置指标数据
     * 
     * @param beanList
     */
    private void setIndicatorData(List<ResultBean> beanList)
    {
        indicatorLayout.setVisibility(View.VISIBLE);
        if (null == beanList || getContext() == null)
        {
            return;
        }

        ResultBean bean = null;
        if (beanList == null)
        {
            //            expandableAdapter.setData(null, true);
            expandableAdapter.setData(null, null, null, sholdShowTBInList);
            return;
        }

        String operatorENName = OperatorDataSctore.toShortName(locOptData.getOperator());

        for (int i = 0; i < beanList.size(); i++)
        {
            if (beanList == null || beanList.get(i).getOperator() == null)
            {
                continue;
            }
            bean = beanList.get(i);
            String beanOperatorName = bean.getOperator();

            if ("CMCC".equals(operatorENName) && "CMCC".equals(beanOperatorName))
            {
                bean = beanList.get(i);
                break;
            }

            if ("CUTC".equals(operatorENName) && "CUCC".equals(beanOperatorName))
            {
                bean = beanList.get(i);
                break;
            }

            if ("CNTC".equals(operatorENName) && "CTCC".equals(beanOperatorName))
            {
                bean = beanList.get(i);
                break;
            }
        }
        //有指标数据
        if (bean != null && bean.getBatchList() != null && bean.getBatchList().size() > 0)
        {
            //假数据 TODO
            List<ResultBean.QuotaType> quotaTypeList = bean.getQuotaTypes();
            if (null != quotaTypeList && quotaTypeList.size() > 0)
            {
                indicatorUpdateTxt.setText("数据更新至：" + bean.getBatchList().get(bean.getBatchList().size() - 1));
                //            expandableAdapter.setData(bean, !"CNTC".equals(operatorENName));
                expandableAdapter.setData(quotaTypeList.get(0).getQuotas(), bean.getBatchList(), bean.getOperator(),
                        sholdShowTBInList);
                //默认展开第一项数据
                indicatorLv.expandGroup(0, true);
            }
            //设置指标类型按钮
            resetIndicatorGroupButtons(quotaTypeList);
        }
        else
        {//如果真没有指标数据 不显示指标
            expandableAdapter.setData(null, null, " ", sholdShowTBInList);
            resetIndicatorGroupButtons(null);//同时也不显示指标类型选择
            //隐藏场景分析
            scenesAnalizeLayout.setVisibility(View.GONE);
        }
    }

    /**
     * View的点击事件
     * 
     * @param v
     */
    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.ll_quota_des:
            case R.id.insight_data_desc:
//                showTipPopupWindow();
                showMoveablePop();
                break;
        }
    }

    private void showMoveablePop() {
        List<String> selections = new ArrayList<>();
        selections.add("aaaaa");
        selections.add("bbbbb");
        selections.add("ccccc");
        PopupWindowUtils.createListPopWindow(getActivity(), selections, 0,
                rootView.findViewById(R.id.ll_quota_des),
                new PopupWindowUtils.OnListItemSelected() {
            @Override
            public void onDismiss() {

            }

            @Override
            public void onSelected(String content, int position) {

            }
        });
    }

    /**
     * 点击数据说明后的提示信息
     */
    private void showTipPopupWindow()
    {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.tip_dialog, null);

        final PopupWindow popupWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());

        popupWindow.showAtLocation(getView(), Gravity.CENTER, 0, 0);

        TextView textView = (TextView) view.findViewById(R.id.title_text);
        textView.setText("数据来源各地市PRS话统数据，数据统计每月第二周");

        view.findViewById(R.id.confirm_button).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                popupWindow.dismiss();
            }
        });
    }

    /************* 三维十三元指标部分 *****************/

    /**
     * 点击了指标分类按钮 position为点击的位置 0->? 此方法中去改变三维十三元的指标list显示数据
     * 
     * @param position 点击的位置
     * @param radioBtn 点击的按钮
     */
    private void onIndicatorButtonChecked(int position, RadioButton radioBtn)
    {
        GCLogger.error("position->" + position + "    -------  " + radioBtn);
        //TODO 切换指标list数据
        if (null != lteIndicatorList)
        {
            ResultBean bean = null;

            String operatorENName = OperatorDataSctore.toShortName(locOptData.getOperator());

            for (int i = 0; i < lteIndicatorList.size(); i++)
            {
                if (lteIndicatorList == null || lteIndicatorList.get(i).getOperator() == null)
                {
                    continue;
                }

                bean = lteIndicatorList.get(i);
                String beanOperatorName = bean.getOperator();

                if ("CMCC".equals(operatorENName) && "CMCC".equals(beanOperatorName))
                {
                    bean = lteIndicatorList.get(i);
                    break;
                }

                if ("CUTC".equals(operatorENName) && "CUCC".equals(beanOperatorName))
                {
                    bean = lteIndicatorList.get(i);
                    break;
                }

                if ("CNTC".equals(operatorENName) && "CTCC".equals(beanOperatorName))
                {
                    bean = lteIndicatorList.get(i);
                    break;
                }
            }
            if (bean != null && bean.getBatchList() != null && bean.getBatchList().size() > 0)
            {
                List<ResultBean.QuotaType> quotaTypeList = bean.getQuotaTypes();
                if (null != quotaTypeList && quotaTypeList.size() > position)
                {
                    if(0 == position && locOptData.getLocationType() == LocOptBean.LOC_TYPE_CITY) {
                        expandableAdapter.setIsShowDimensionScore(true);
                    } else {
                        expandableAdapter.setIsShowDimensionScore(false);
                    }
                    expandableAdapter.setData(quotaTypeList.get(position).getQuotas(), bean.getBatchList(),
                        bean.getOperator(), sholdShowTBInList);
                    //默认展开第一项数据
                    indicatorLv.expandGroup(0, true);
                } else {
                    expandableAdapter.setIsShowDimensionScore(false);
                }
            }
        }

    }

    /** 重新添加三维十三元指标的分类按钮 **/
    private void resetIndicatorGroupButtons(List<ResultBean.QuotaType> quotaTypeList)
    {
        if (null == quotaTypeList || quotaTypeList.size() == 0)
        {
            //没有指标类型 需要隐藏 //TODO
            indicatorTypeLayout.removeAllViews();
            return;
        }
        indicatorTypeLayout.removeAllViews();
        for (int i = 0; i < quotaTypeList.size(); i++)
        {
            ResultBean.QuotaType qt = quotaTypeList.get(i);
            String typeName = qt.getTypeName();
            if (TextUtils.isEmpty(typeName))
            {
                continue;
            }
            RadioButton rb = createIndicatorButton(qt.getTypeName());
            rb.setTag(i); //给分类按钮设置位置信息
            indicatorTypeLayout.addView(rb);

        }

        if (indicatorTypeLayout.getChildCount() > 0)
        {
            RadioButton rb = (RadioButton) indicatorTypeLayout.getChildAt(0);
            rb.setChecked(true);
        }
        indicatorTypeLayout.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                View v = group.findViewById(checkedId);
                if (null == v)
                {
                    return;
                }
                if (v instanceof RadioButton)
                {
                    onIndicatorButtonChecked((Integer) v.getTag(), (RadioButton) v);
                }

            }
        });
    }

    /**
     * 创建一个指标分类按钮
     * 
     * @return
     */
    private RadioButton createIndicatorButton(String txt)
    {
        RadioButton rb = new RadioButton(getContext());
        rb.setBackground(getContext().getResources().getDrawable(R.drawable.selector_indicator_title));
        rb.setTextColor(getColorStateListByXML());
        rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12); //12sp文字大小
        rb.setText(txt);
        rb.setButtonDrawable(null);
        RadioGroup.LayoutParams lp = new RadioGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            DensityUtil.dip2px(getContext(), 20));
        lp.setMargins(DensityUtil.dip2px(getContext(), 6), 0, 0, 0);
        rb.setPadding(DensityUtil.dip2px(getContext(), 6), 0, DensityUtil.dip2px(getContext(), 6), 0);
        rb.setLayoutParams(lp);
        return rb;
    }

    private ColorStateList textColorStateList = null;

    /**
     * 获得指标分类按钮文字的选中未选中颜色效果
     * 
     * @return
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private ColorStateList getColorStateListByXML(/** int resId **/
    )
    {
        if (null == textColorStateList)
        {
            int[] colors = new int[] {0xFF007DFF, 0xFF000000 };
            int[][] stats = new int[2][];
            stats[0] = new int[] {android.R.attr.state_checked };
            stats[1] = new int[] {android.R.attr.state_enabled };
            textColorStateList = new ColorStateList(stats, colors);
        }
        return textColorStateList;
    }

    /**
     * 权限查询完毕,可以开始加载数据
     */
    @Override
    public void onStart(LocOptBean bean)
    {
        //        GCLogger.error("zb", "onStart(bean)");
        //        setUserVisibleHint(getUserVisibleHint());
        //        refreshLayout.setRefreshing(true);
    }

    /**
     * 选择了新的区域
     * 
     * @param bean 保存地区 运营商信息
     */
    @Override
    public void onLocationSelected(LocOptBean bean)
    {
        if (null == bean)
        {
            return;
        }
        if (!isLoaded && isCreatedView)
        {
            setUserVisibleHint(getUserVisibleHint());
            return;
        }

        String province = bean.getProvince();
        String city = bean.getCity();
        if (!TextUtils.isEmpty(province) && !TextUtils.isEmpty(city))
        {
            locOptData.setProvince(bean.getProvince());
            locOptData.setCity(bean.getCity());
            locOptData.setLocationType(bean.getLocationType());
            //重新加载数据
            if (null != refreshLayout)
            {
                refreshLayout.setRefreshing(true);
            }
            onRefresh();
        }
    }

    /**
     * 选择了新的运营商 在横屏销毁创建的时候,调用方法可能在fragment生命周期之外
     * 
     * @param bean 保存地区 运营商信息
     */
    @Override
    public void onOperatorSelected(LocOptBean bean)
    {
        if (null != bean && null != getContext())
        {
            String operator = bean.getOperator();
            if (!TextUtils.isEmpty(operator))
            {
                locOptData.setOperator(operator);
                //                locOptData.setOperatorId(bean.getOperatorId());
                if (locOptData.getLocationType() == 2)
                {
                    //目前是城市界面
                    //                    setDimension(dimensionCityBean);
                    //重新加载数据 城市的结论和蛛网图因为是分运营商查询的,需要重新请求数据
                    if (null != refreshLayout)
                    {
                        refreshLayout.setRefreshing(true);
                    }
                    onRefresh();
                }
                else
                {
                    setInsightData(nationalDataBean);
                    setIndicatorData(lteIndicatorList);
                }

            }
        }
    }

}
