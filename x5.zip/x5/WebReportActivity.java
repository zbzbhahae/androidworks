package com.huawei.genexcloud.survey.activity;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;

import com.huawei.genexcloud.framework.base.BaseActivity;
import com.huawei.genexcloud.framework.base.BaseApplication;
import com.huawei.genexcloud.framework.common.Constants;
import com.huawei.genexcloud.framework.log.GCLogger;
import com.huawei.genexcloud.framework.util.AppUtil;
import com.huawei.genexcloud.framework.util.SharedPreferencesUtil;
import com.huawei.genexcloud.survey.R;
import com.tencent.smtt.export.external.interfaces.JsPromptResult;
import com.tencent.smtt.export.external.interfaces.JsResult;
import com.tencent.smtt.export.external.interfaces.WebResourceRequest;
import com.tencent.smtt.export.external.interfaces.WebResourceResponse;
import com.tencent.smtt.sdk.CookieManager;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class WebReportActivity extends BaseActivity {

    private String TAG = "web";
    private String url = "https://genexcloud-china-dongguan.sd.huawei.com/genex/g5commonapp-service/AppBusiness/G5CommonAPP/nrE2ePlanningHome.html#/predictionHome?groupId=6560&taskId=20220414184160071085&userId=zwx1094027&projectId=1f215c17-1300-4688-95ca-540c21098d51";
    private String cookieStr = "locale=zh_CN; sid=12e80b74-d057-41e1-8cc9-224da304dd3e; genexcloudId=12e80b74-d057-41e1-8cc9-224da304dd3e; genexcloud_language=zh_CN; user-id=zwx1094027; encode-user-id=zwx1094027; project=1f215c17-1300-4688-95ca-540c21098d51; project-id=1f215c17-1300-4688-95ca-540c21098d51; timeNum=1650212463992; DongGuanChina_BCM_sid=12e80b74-d057-41e1-8cc9-224da304dd3e";

    private WebView mWebView;

    private String projectId;
    private String taskId;
    private String groupId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void initView() {
        mWebView = findViewById(R.id.web_view);
        initWebViewClient();
        initWebChromeClient();
        WebSettings webSetting = mWebView.getSettings();
        webSetting.setJavaScriptEnabled(true);
        webSetting.setAllowFileAccess(true);
        webSetting.setSupportZoom(true);
        webSetting.setDatabaseEnabled(true);
        webSetting.setAllowFileAccess(true);
        webSetting.setDomStorageEnabled(true);
        webSetting.setBuiltInZoomControls(true);
        webSetting.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        mWebView.setInitialScale(200);
    }

    @Override
    protected void initData() {
        projectId = getIntent().getStringExtra("projectId");
        groupId = getIntent().getStringExtra("groupId");
        taskId = getIntent().getStringExtra("taskId");

        CookieManager cookieManager = CookieManager.getInstance();
        setCookies(url, cookieStr);
        mWebView.loadUrl(url);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_web_report;
    }


    public void setCookies(String cookiesPath, String cookie) {

        String userId = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.LOGIN_USER_KEY, "");
        String uuid = SharedPreferencesUtil.getInstance(BaseApplication.getAppContext())
                .readStringValue(Constants.UU_ID, "");

        StringBuilder sbCookie = new StringBuilder();

        //locale=zh_CN;
        // sid=1c06b6e6-2f27-48bc-b549-b69949fc534f;
        // genexcloudId=1c06b6e6-2f27-48bc-b549-b69949fc534f;
        // genexcloud_language=zh_CN;
        // user-id=mwx598574;
        // encode-user-id=mwx598574;
        // project=51bb628c-f9b7-4b69-9487-6698094bc48e;
        // project-id=51bb628c-f9b7-4b69-9487-6698094bc48e;
        // ui_version=v3; timeNum=1561110426374;
        // terminalType=Mobile& width=700&height=700

        sbCookie.append("locale=zh_CN");
        sbCookie.append(";sid=" + uuid);
        sbCookie.append(";genexcloudId=" + uuid);
        sbCookie.append(";genexcloud_language=zh_CN");
        sbCookie.append(";user-id=" + userId);
        sbCookie.append(";encode-user-id=" + userId);
        sbCookie.append(";project=" + projectId);
        sbCookie.append(";project-id=" + projectId);
        long time = System.currentTimeMillis() + 3600000;
        sbCookie.append(";timeNum=" + time);
        sbCookie.append(";terminalType=Mobile");
        sbCookie.append(";width=" + AppUtil.getScreenDispaly(BaseApplication.getAppContext())[0] / 2);
        sbCookie.append(";height=" + AppUtil.getScreenDispaly(BaseApplication.getAppContext())[1] / 2);
//        sbCookie.append(";width=480");
//        sbCookie.append(";height=800");
        sbCookie.append(";DongGuanChina_BCM_sid=" + uuid);

        String cookieValue = sbCookie.toString();
        if (!TextUtils.isEmpty(cookieValue)) {
            String[] cookieArray = cookieValue.split(";");// 多个Cookie是使用分号分隔的
            for (int i = 0; i < cookieArray.length; i++) {
                int position = cookieArray[i].indexOf("=");// 在Cookie中键值使用等号分隔
                String cookieName = cookieArray[i].substring(0, position);// 获取键
                String cookieValues = cookieArray[i].substring(position + 1);// 获取值

                String value = cookieName + "=" + cookieValues;// 键值对拼接成 value

                CookieManager.getInstance().setCookie(getDomain(cookiesPath), value);// 设置 Cookie
            }
        }
    }

    /**
     * 获取URL的域名
     */
    private String getDomain(String url) {
        url = url.replace("http://", "").replace("https://", "");
        if (url.contains("/")) {
            url = url.substring(0, url.indexOf('/'));
        }
        return url;
    }


    private void initWebViewClient() {
        mWebView.setWebViewClient(new WebViewClient() {

            /**
             * 具体接口使用细节请参考文档：
             * https://x5.tencent.com/docs/webview.html
             * 或 Android WebKit 官方：
             * https://developer.android.com/reference/android/webkit/WebChromeClient
             */

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                GCLogger.error(TAG, "onPageStarted, view:" + view + ", url:" + url);

            }

            @Override
            public void onPageFinished(WebView view, String url) {
                GCLogger.error(TAG, "onPageFinished, view:" + view + ", url:" + url);

            }

            @Override
            public void onReceivedError(WebView webView, int errorCode, String description, String failingUrl) {
                GCLogger.error(TAG, "onReceivedError: " + errorCode
                        + ", description: " + description
                        + ", url: " + failingUrl);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
                if (webResourceRequest.getUrl().toString().contains("debugdebug")) {
                    InputStream in = null;
                    GCLogger.error("AterDebug", "shouldInterceptRequest");
                    try {
                        in = new FileInputStream(new File("/sdcard/1.png"));
                    } catch (Exception e) {

                    }

                    return new WebResourceResponse("image/*", "utf-8", in);
                } else {
                    return super.shouldInterceptRequest(webView, webResourceRequest);
                }

            }
        });
    }

    private void initWebChromeClient() {
        final Context context = this;
        final Activity activity = this;
        mWebView.setWebChromeClient(new WebChromeClient() {
            /**
             * 具体接口使用细节请参考文档：
             * https://x5.tencent.com/docs/webview.html
             * 或 Android WebKit 官方：
             * https://developer.android.com/reference/android/webkit/WebChromeClient
             */

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                GCLogger.error(TAG, "onProgressChanged, newProgress:" + newProgress + ", view:" + view);
            }

            @Override
            public boolean onJsAlert(WebView webView, String url, String message, JsResult result) {
                new AlertDialog.Builder(context).setTitle("JS弹窗Override")
                        .setMessage(message)
                        .setPositiveButton("OK", (dialogInterface, i) -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView webView, String url, String message, JsResult result) {
                new AlertDialog.Builder(context).setTitle("JS弹窗Override")
                        .setMessage(message)
                        .setPositiveButton("OK", (dialogInterface, i) -> result.confirm())
                        .setNegativeButton("Cancel", (dialogInterface, i) -> result.cancel())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsBeforeUnload(WebView webView, String url, String message, JsResult result) {
                new AlertDialog.Builder(context).setTitle("页面即将跳转")
                        .setMessage(message)
                        .setPositiveButton("OK", (dialogInterface, i) -> result.confirm())
                        .setNegativeButton("Cancel", (dialogInterface, i) -> result.cancel())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView webView, String url, String message, String defaultValue, JsPromptResult result) {
                final EditText input = new EditText(context);
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                new AlertDialog.Builder(context).setTitle("JS弹窗Override")
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton("OK", (dialogInterface, i) -> result.confirm(input.getText().toString()))
                        .setCancelable(false)
                        .show();
                return true;
            }

            /**
             * Return value usage see FILE_CHOOSE_REQUEST in
             * {@link BaseWebViewActivity#onActivityResult(int, int, Intent)}
             */
//            @Override
//            public boolean onShowFileChooser(WebView webView,
//                                             ValueCallback<Uri[]> filePathCallback,
//                                             WebChromeClient.FileChooserParams fileChooserParams) {
//                Log.i(TAG, "openFileChooser: " + fileChooserParams.getMode());
//                mFilePathCallback = filePathCallback;
//                openFileChooseProcess(fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
//                return true;
//            }

//            @Override
//            public void onGeolocationPermissionsShowPrompt(String origin,
//                                                           GeolocationPermissionsCallback geolocationPermissionsCallback) {
//                if (verifyLocationPermissions(activity)) {
//                    geolocationPermissionsCallback.invoke(origin, true, false);
//                } else {
//                    locationPermissionUrl = origin;
//                    mGeolocationCallback = geolocationPermissionsCallback;
//                }
//            }
        });
    }

//    private void initJavaScriptInterface() {
//        final Activity context = this;
//        mWebView.addJavascriptInterface(new WebViewJavaScriptFunction() {
//            @Override
//            public void onJsFunctionCalled(String tag) {
//
//            }
//
//            @JavascriptInterface
//            public void openQRCodeScan() {
//                new IntentIntegrator(context).initiateScan();
//            }
//
//            @JavascriptInterface
//            public void openDebugX5() {
//                mWebView.loadUrl("http://debugx5.qq.com");
//            }
//
//            @JavascriptInterface
//            public void openWebkit() {
//                startActivity(new Intent(context, SystemWebViewActivity.class));
//            }
//
//
//        }, "Android");
//    }
}
