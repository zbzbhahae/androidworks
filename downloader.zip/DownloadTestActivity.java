package com.huawei.genexcloudsample.acts;

import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.huawei.genexcloud.sdk.downloader.DownloadEntry;
import com.huawei.genexcloud.sdk.downloader.DownloadListener;
import com.huawei.genexcloud.sdk.downloader.DownloadManager;
import com.huawei.genexcloud.sdk.downloader.DownloadTask;
import com.huawei.genexcloudsample.BaseActivity;
import com.huawei.genexcloudsample.databinding.ActivityTestDownloadBinding;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class DownloadTestActivity extends BaseActivity implements View.OnClickListener {

    public static final String MESSAGE = "下载测试";

    private ActivityTestDownloadBinding binding;

//    private String url = "https://mcloud-uat.huawei.com/mcloud/umag/fg/FreeProxyForDownLoad/speedtest_mag/file/downloadFile?path=/root/downloadApp/Disturb.apk";
//    private String url = "http://cdn.llsapp.com/android/LLS-v4.0-595-20160908-143200.apk";
    private String url = "https://genexcloud-china-dongguan.sd.huawei.com/mobileinfomgmtapps/downLoadFileAction?Url=downLoad_test&fileName=APP%E6%8F%92%E4%BB%B6%E6%A8%A1%E5%9D%97%5C%E7%BD%91%E7%BB%9C%E7%AB%9E%E5%AF%B9%5CNetworkCompetition_8.apk";

    private long taskId = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTestDownloadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.taskButton.setOnClickListener(this);


        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
    }


    @Override
    public void onClick(View v) {
        if (v == binding.taskButton) {
            switch (binding.taskButton.getText().toString()) {
                case "Start":
                    downLoad();
                    binding.taskButton.setText("Cancel");
                    break;
                case "Cancel":
                    cancel(taskId);
                    binding.taskButton.setText("Start");
                    break;
            }
        }
    }

    private void downLoad() {
        Map<String, String> headers = new HashMap<>();
//        headers.put("x-csrf-token", "");
        headers.put("Cookie", "channel_category=referral; channel_name=uniportal.huawei.com; _ga=GA1.2.1010472671.1632080244; Hm_lvt_48e5a2ca327922f1ee2bb5ea69bdd0a6=1632080245; utag_main=v_id:017bff902dcf0020b99805556d5803072003d06a00bd0$_sn:1$_se:4$_ss:0$_st:1632082061084$ses_id:1632080244176%3Bexp-session$_pn:1%3Bexp-session$dc_visit:1$dc_event:3%3Bexp-session$dc_region:ap-northeast-1%3Bexp-session; __hau=SUPPORT.1633411378.383542347; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2217de4eea4abcb-0785b4c8678054-4303066-2073600-17de4eea4aca4f%22%2C%22%24device_id%22%3A%2217de4eea4abcb-0785b4c8678054-4303066-2073600-17de4eea4aca4f%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_referrer%22%3A%22%22%2C%22%24latest_referrer_host%22%3A%22%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%7D%7D; genexcloud-china-dongguansd_genexcloud_sticky=pro_100.94.148.217_443:3; lang=zh_CN; genexcloud-china-dongguansd__sticky=pro_100.94.148.217_443:3; hwsso_login=\"\"; authmethod=authpwd; hwsso_uniportal=V002X8f20svsug5GC5wqHYS9bMWzAlAg5211lb1VjWfkTput5llxAbnsxiqFvd8KCRVYmlR7vfmpqpkA8CVN4Kwl2HrzpyUOBeQ1mfbyr8TYDpUYcTl9jGvQy2qxUrJXuftp4cc2EwcchAQFyJKNGbdJ0HMX0EQQRyPu1wCjrsLZLoGBcPtZ0pgl4yNs1iJhwlcIsVedka9m4Rrl_a4O15oz7agoVLuXBwwOsVb0uvGgNdOBbdbaxkzE8CQMQ_a_aKouKzUDet8zf8iXpwKj33uakuSLd0HmJTcpxIh19bCvPkYjTOH9MbKqJyS4AcxalNWKYzmTWCC3Xv9etuqquM_a_aZVTwA_c_c; hwssotinter=FD-DC-6C-2F-D1-19-FC-B9-3B-4B-5E-14-FC-2D-31-D3; hwssotinter3=27764644100467; sid=1C-95-F8-0C-8C-DC-F4-CC-56-DC-07-73-03-88-73-28-44-A8-AC-05-90-EC-00-06-F8-FA-A1-43-6B-2A-48-03-7D-70-10-8A-84-31-5B-2C; uid=F9-7E-FD-4B-4D-19-76-A2-4B-26-59-14-B0-B5-02-EB; suid=F9-7E-FD-4B-4D-19-76-A2-4B-26-59-14-B0-B5-02-EB; sip=7E-1A-97-8E-3D-46-19-E3-6E-9D-74-DB-3A-F5-34-24-31-DD-35-52-A5-7C-E0-59; logFlag=in; al=10; gc_uniportal_login=true; DongGuanChina_BCM_sid=c2740bb5-62e3-4547-bc82-2ee256a92271; user=zwx1094027; user-id=zwx1094027; userId=zwx1094027; encode-user-id=zwx1094027; ui_version=v3; locale=zh_CN; genexcloud_language=zh_CN; project=; project-id=");
        DownloadEntry entry = new DownloadEntry(url, getExternalCacheDir().getPath(), "lls.apk", headers);
        taskId = DownloadManager.getInstance().downloadFile(entry, new DownloadListener() {
            @Override
            public void onWait(DownloadTask task) {
                binding.taskStatus.setText("onWait()");
                binding.taskBar.setIndeterminate(true);
            }

            @Override
            public void onPending(DownloadTask task) {
                binding.taskStatus.setText("onPending()");
                binding.taskBar.setIndeterminate(true);
            }

            @Override
            public void onDownloading(DownloadTask task) {

                binding.taskStatus.setText("onDownloading()" + new DecimalFormat("#.##").format(task.getEntry().fileDownloadLength * 1f / task.getEntry().fileTotalLength));
                binding.taskBar.setIndeterminate(false);
                binding.taskBar.setMax((int) task.getEntry().fileTotalLength);
                binding.taskBar.setProgress((int) task.getEntry().fileDownloadLength);
            }

            @Override
            public void onCompleted(DownloadTask task) {
                binding.taskStatus.setText("onCompleted()");
                binding.taskBar.setIndeterminate(true);
            }

            @Override
            public void onFailed(DownloadTask task) {
                binding.taskStatus.setText("onFailed()");
                binding.taskBar.setIndeterminate(true);
            }

            @Override
            public void onCancel(DownloadTask task) {
                binding.taskStatus.setText("onCancel()");
                binding.taskBar.setIndeterminate(true);
            }
        });
    }

    private void cancel(long id) {
        DownloadManager.getInstance().cancelTask(id);
    }
}
